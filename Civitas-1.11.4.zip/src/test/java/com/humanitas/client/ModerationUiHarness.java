package com.humanitas.client;

import com.humanitas.*;
import net.minecraft.client.*;
import net.minecraft.nbt.*;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.network.PacketDistributor;
import java.nio.file.*;

/** Opt-in two real clients: administrator UI, forged public actions and publication restrictions. */
@EventBusSubscriber(modid=Humanitas.MODID,value=Dist.CLIENT)
public final class ModerationUiHarness {
    private static int ticks,step,waits;private static boolean failed;private static Path sync;private static CompoundTag ids;
    private static Object get(Object o,String n)throws Exception{var f=o.getClass().getDeclaredField(n);f.setAccessible(true);return f.get(o);}
    private static void set(Object o,String n,Object v)throws Exception{var f=o.getClass().getDeclaredField(n);f.setAccessible(true);f.set(o,v);}
    private static Object call(Object o,String n,Class<?>[] types,Object... args)throws Exception{var m=o.getClass().getDeclaredMethod(n,types);m.setAccessible(true);return m.invoke(o,args);}
    private static void check(boolean b,String why){if(!b)throw new IllegalStateException(why);}
    private static CompoundTag people()throws Exception{var s=Minecraft.getInstance().screen;check(s instanceof PeopleScreen,"Expected player directory");if((boolean)get(s,"busy"))return null;return (CompoundTag)get(s,"data");}
    private static CompoundTag desk()throws Exception{var s=Minecraft.getInstance().screen;if(!(s instanceof OrganizationsScreen)||(boolean)get(s,"busy"))return null;return (CompoundTag)get(s,"data");}
    private static void mark(String n)throws Exception{Files.writeString(sync.resolve(n),"ok");}
    private static boolean marked(String n){return Files.exists(sync.resolve(n));}
    private static void capture(String name){var mc=Minecraft.getInstance();Screenshot.grab(mc.gameDirectory,"moderation-"+name+".png",mc.getMainRenderTarget(),c->{});}
    private static void search(String q)throws Exception{var s=Minecraft.getInstance().screen;((TextInput)get(s,"search")).setValue(q);set(s,"query",q);call(s,"request",new Class<?>[]{boolean.class},true);}
    private static void orgSend(String op,String target,CompoundTag fields){PacketDistributor.sendToServer(new OrganizationsNet.Action(new OrganizationsNet.Request(9500,ids.getString("org"),"agenda",0,"",ids.getString("resolution")),op,target,fields));}
    @SubscribeEvent public static void tick(ClientTickEvent.Post e){
        if(!Boolean.getBoolean("civitas.moderationHarness")||failed)return;var mc=Minecraft.getInstance();if(mc.player==null||mc.level==null||++ticks%30!=0)return;
        try{
            if(sync==null){sync=mc.gameDirectory.toPath().toAbsolutePath().normalize().getParent().resolve("moderation-coordination");ids=NbtIo.readCompressed(sync.resolve("fixture.dat"),NbtAccounter.unlimitedHeap());}
            if(marked("dial-only")){dialPreview(mc);return;}
            if(marked("render-only")){renderOnly(mc);return;}
            boolean admin=mc.player.getGameProfile().getName().equals("CivitasAdmin");Humanitas.LOGGER.info("MODERATION_TEST {} step {}",admin?"admin":"member",step);
            if(admin?admin(mc):member(mc)){step++;waits=0;}else if(++waits>150)throw new IllegalStateException("Timeout step "+step);
        }catch(Exception ex){failed=true;Humanitas.LOGGER.error("MODERATION_TEST_FAILED step "+step,ex);try{Files.writeString(mc.gameDirectory.toPath().resolve("moderation-result.txt"),"FAIL step "+step+": "+ex);}catch(Exception ignored){}mc.stop();}
    }
    private static String renderRequest="";private static int turns,previewTicks;private static final java.util.Set<String> visited=new java.util.HashSet<>();
    @SubscribeEvent public static void previewFrame(net.neoforged.neoforge.client.event.ScreenEvent.Render.Post event){
        if(!Boolean.getBoolean("civitas.moderationHarness")||renderRequest.isEmpty()||!(event.getScreen() instanceof WheelScreen w))return;
        try{
            int mx=0,my=0;if(renderRequest.endsWith("hover")){var c=((java.util.List<?>)get(w,"cardActions")).getFirst();mx=(int)get(c,"x")+(int)get(c,"w")/2;my=(int)get(c,"y")+11;}
            w.render(event.getGuiGraphics(),mx,my,0);event.getGuiGraphics().flush();capture("dial-"+renderRequest);renderRequest="";
        }catch(Exception ex){failed=true;Humanitas.LOGGER.error("DIAL_PREVIEW_FAILED",ex);Minecraft.getInstance().stop();}
    }
    private static void visit(WheelScreen w)throws Exception{
        var items=(String[][])call(w,"playerItems",new Class<?>[]{});
        for(int i=0;i<items.length;i++){double angle=(double)call(w,"itemAngle",new Class<?>[]{int.class,int.class,int.class},0,i,items.length);float fade=(float)call(w,"edgeFade",new Class<?>[]{double.class,int.class},angle,items.length);if(fade>=.6)visited.add(items[i][0]);}
    }
    private static void dialPreview(Minecraft mc)throws Exception{
        if(++previewTicks>180)throw new IllegalStateException("Dial preview timeout");
        Humanitas.LOGGER.info("DIAL_PREVIEW step {}",step);
        switch(step){
            case 0 -> {mc.options.guiScale().set(1);mc.resizeDisplay();var f=new CompoundTag();f.putString("kind","state");PacketDistributor.sendToServer(new OrganizationsNet.Action(new OrganizationsNet.Request(9700,"","contexts",0,"",""),"context",ids.getString("state"),f));}
            case 1 -> CabinetRequests.openFresh();
            case 2 -> {var w=wheel();if(w==null)return;check(!w.data.getBoolean("organizationContext"),"State wheel");check(((String[][])call(w,"playerItems",new Class<?>[]{})).length==11,"Citizen actions retained except removed public player shortcut");renderRequest="open";}
            case 3 -> {var w=wheel();visit(w);var items=(String[][])call(w,"playerItems",new Class<?>[]{});if(turns++<items.length){var r=(int[])call(w,"dialNavRect",new Class<?>[]{int.class,boolean.class},0,false);double before=(double)get(w,"spinLeft");w.mouseClicked(r[0]+10,r[1]+6,0);check((double)get(w,"spinLeft")<before,"Arrow scrolls carousel");if(turns==5)renderRequest="rotated";return;}check(visited.size()==items.length,"Every menu action reached through real arrow clicks");}
            case 4 -> {var w=wheel();mc.options.guiScale().set(2);mc.resizeDisplay();double before=(double)get(w,"spinLeft");w.mouseScrolled(0,mc.getWindow().getGuiScaledHeight()/2,0,1);check((double)get(w,"spinLeft")<before,"Mouse wheel still scrolls");set(w,"spinLeft",0d);set(w,"shownLeft",0d);}
            case 5 -> {renderRequest="compact";}
            case 6 -> {var w=wheel();w.openAdminPanel("players");call(w,"openPlayer",new Class<?>[]{int.class},0);w.mouseScrolled(200,150,0,-100);}
            case 7 -> {renderRequest="mute-normal";}
            case 8 -> {if(!renderRequest.isEmpty())return;var w=wheel();var action=((java.util.List<?>)get(w,"cardActions")).getFirst();int aw=(int)get(action,"w");check(aw>=90&&aw<=132,"Mute action is compact");Files.writeString(mc.gameDirectory.toPath().resolve("dial-hover-rect.txt"),get(action,"x")+","+get(action,"y")+","+aw+",22,"+mc.getWindow().getGuiScaledWidth()+","+mc.getWindow().getGuiScaledHeight());renderRequest="mute-hover";}
            case 9 -> {if(!renderRequest.isEmpty())return;Files.writeString(mc.gameDirectory.toPath().resolve("dial-preview-result.txt"),"PASS: all 11 actions reachable by arrow clicks, mouse wheel works, normal and compact arc renders, compact Mute hover pair captured using real GUI renderer.");mc.stop();}
        }step++;
    }
    private static WheelScreen wheel(){return Minecraft.getInstance().screen instanceof WheelScreen w?w:null;}
    private static void renderOnly(Minecraft mc)throws Exception{
        Humanitas.LOGGER.info("PLAYER_CARD_RESTORE step {}",step);
        switch(step){
            case 0 -> {mc.getToasts().clear();mc.options.guiScale().set(2);mc.resizeDisplay();CabinetRequests.openFresh();}
            case 1 -> {var w=wheel();if(w==null)return;check(w.data.getBoolean("op"),"Admin snapshot");w.openAdminPanel("players");}
            case 2 -> {var w=wheel();var input=(TextInput)get(w,"playerSearch");int x=(int)get(input,"x"),y=(int)get(input,"y");w.mouseClicked(x+5,y+5,0);check(input.focused,"Search receives focus");for(char c:"CivitasAdmin".toCharArray()){w.keyPressed(Character.toUpperCase(c),0,0);w.charTyped(c,0);}check(input.value().equals("CivitasAdmin"),"Name typing preserves wheel key bindings");}
            case 3 -> {var w=wheel();var entries=(java.util.List<?>)call(w,"entries",new Class<?>[]{String.class},"players");check(entries.size()==1,"Original list filtered by name");var row=entries.getFirst();check(get(row,"value").toString().startsWith("Trust Rate:"),"Original Trust Rate row retained");check(get(row,"btnA").equals("ИНФО"),"Original Info button retained");capture("restored-list");((Runnable)get(row,"actA")).run();}
            case 4 -> {var w=wheel();var p=(CompoundTag)call(w,"selectedPlayer",new Class<?>[]{});var lines=(java.util.List<String[]>)call(w,"playerLines",new Class<?>[]{CompoundTag.class},p);for(String key:new String[]{"ЗДОРОВЬЕ","ГОЛОД","УРОВЕНЬ ОПЫТА","ДОВЕРИЕ","ФРАКЦИЯ","УЧАСТИЕ В ВОЙНАХ","ОПЕРАТОР (OP)"})check(lines.stream().anyMatch(r->r[0].equals(key)),"Original card field retained: "+key);check(((java.util.List<?>)get(w,"cardActions")).isEmpty(),"Mute hidden above bottom of long card");capture("restored-card-top");w.mouseScrolled(200,150,0,-100);}
            case 5 -> {var w=wheel();var actions=(java.util.List<?>)get(w,"cardActions");check(actions.size()==1&&get(actions.getFirst(),"label").equals("МУТ"),"Mute only at bottom of player card");capture("restored-card-bottom");var c=actions.getFirst();w.mouseClicked((int)get(c,"x")+4,(int)get(c,"y")+4,0);check(mc.screen instanceof PeopleScreen&&(boolean)get(mc.screen,"directEditor"),"Bottom action opens mute form directly");}
            case 6 -> {if(people()==null)return;check(get(mc.screen,"target").equals(mc.player.getUUID().toString()),"Correct player UUID");((TextInput)get(mc.screen,"duration")).setValue("10");((TextInput)get(mc.screen,"text")).setValue("Restored card integration check");capture("restored-mute-form");call(mc.screen,"send",new Class<?>[]{});}
            case 7 -> {var w=wheel();if(w==null)return;check((boolean)get(w,"detailPlayer")&&get(w,"detailPlayerId").equals(mc.player.getUUID().toString()),"Mutation returns to the same player card");w.mouseScrolled(200,150,0,-100);}
            case 8 -> {var w=wheel();var actions=(java.util.List<?>)get(w,"cardActions");check(actions.size()==1&&get(actions.getFirst(),"label").equals("СНЯТЬ МУТ"),"Unmute at same card position");capture("restored-card-muted");var c=actions.getFirst();w.mouseClicked((int)get(c,"x")+4,(int)get(c,"y")+4,0);}
            case 9 -> {if(people()==null)return;check(get(mc.screen,"editor").equals("unmute"),"Unmute form");call(mc.screen,"send",new Class<?>[]{});}
            case 10 -> {var w=wheel();if(w==null)return;w.mouseScrolled(200,150,0,-100);}
            case 11 -> {var w=wheel();check(get(((java.util.List<?>)get(w,"cardActions")).getFirst(),"label").equals("МУТ"),"Unmute refreshes card immediately");w.keyPressed(org.lwjgl.glfw.GLFW.GLFW_KEY_ESCAPE,0,0);check((int)get(w,"detailIndex")==-1,"Escape closes card");check(((java.util.List<?>)call(w,"entries",new Class<?>[]{String.class},"players")).size()==1,"Original filtered player panel remains open");w.openAdminPanel("states");((TextInput)get(w,"stateSearch")).setValue("аВрОрА");}
            case 12 -> {var w=wheel();var entries=(java.util.List<?>)call(w,"entries",new Class<?>[]{String.class},"states");check(entries.size()==4,"State filter preserves create/reset/delete and matching state");capture("restored-states");Files.writeString(mc.gameDirectory.toPath().resolve("player-card-restore-result.txt"),"PASS: original 1.11.3 panels, Trust Rate, full player fields, Info card, name search, mute only at scroll bottom, direct mute/unmute forms and return to same card; state management actions retained.");mc.stop();}
        }step++;
    }
    private static boolean admin(Minecraft mc)throws Exception{
        switch(step){
            case 0 -> {mc.getToasts().clear();mc.options.guiScale().set(2);mc.resizeDisplay();mc.setScreen(new PeopleScreen(null,"players"));}
            case 1 -> {var d=people();if(d==null)return false;check(d.getBoolean("admin")&&d.getInt("count")>=30,"Admin sees online and offline players");search("DELEGATE250");}
            case 2 -> {var d=people();if(d==null)return false;check(d.getInt("count")==1,"Search runs before pagination");capture("admin-search");call(mc.screen,"open",new Class<?>[]{String.class},ModerationFixture.user("Delegate250").toString());}
            case 3 -> {if(people()==null)return false;call(mc.screen,"start",new Class<?>[]{String.class},"mute");}
            case 4 -> {capture("mute-editor");((TextInput)get(mc.screen,"duration")).setValue("4321");((TextInput)get(mc.screen,"text")).setValue("Publication test");call(mc.screen,"send",new Class<?>[]{});check(!(boolean)get(mc.screen,"busy"),"UI rejects over 72h");((TextInput)get(mc.screen,"duration")).setValue("4320");call(mc.screen,"send",new Class<?>[]{});}
            case 5 -> {var d=people();if(d==null)return false;check(d.getCompound("detail").getBoolean("muted"),"Mute applied by actual UI");long remain=d.getCompound("detail").getLong("until")-System.currentTimeMillis();check(remain>71*3600000L&&remain<=72*3600000L,"72 real hours");capture("muted-detail");mark("muted");}
            case 6 -> {if(!marked("member-blocked"))return false;if(people()==null)return false;call(mc.screen,"start",new Class<?>[]{String.class},"note");((TextInput)get(mc.screen,"text")).setValue("Private moderation evidence");call(mc.screen,"send",new Class<?>[]{});}
            case 7 -> {var d=people();if(d==null)return false;check(d.getCompound("detail").getString("note").equals("Private moderation evidence"),"Private note saved");mark("noted");}
            case 8 -> {if(!marked("member-voted"))return false;if(people()==null)return false;call(mc.screen,"start",new Class<?>[]{String.class},"unmute");((TextInput)get(mc.screen,"text")).setValue("Test complete");call(mc.screen,"send",new Class<?>[]{});}
            case 9 -> {var d=people();if(d==null)return false;check(!d.getCompound("detail").getBoolean("muted"),"Manual unmute");mark("unmuted");mc.setScreen(new PeopleScreen(null,"states"));}
            case 10 -> {if(people()==null)return false;search("аВрОрА");}
            case 11 -> {var d=people();if(d==null)return false;check(d.getInt("count")==1&&d.getList("rows",10).getCompound(0).getString("title").equals("Аврора"),"Admin state search");capture("admin-state-search");mc.setScreen(new StatesScreen(null,"","overview"));}
            case 12 -> {if((boolean)get(mc.screen,"busy"))return false;((TextInput)get(mc.screen,"search")).setValue("сЕвЕр");set(mc.screen,"query","сЕвЕр");call(mc.screen,"request",new Class<?>[]{});}
            case 13 -> {if((boolean)get(mc.screen,"busy"))return false;check(((CompoundTag)get(mc.screen,"data")).getInt("count")==1,"Public state search");capture("public-state-search");mc.setScreen(new OrganizationsScreen(null,"","catalog"));}
            case 14 -> {if(desk()==null)return false;((TextInput)get(mc.screen,"search")).setValue("КОНГРЕСС");set(mc.screen,"query","КОНГРЕСС");call(mc.screen,"request",new Class<?>[]{});}
            case 15 -> {var d=desk();if(d==null)return false;check(d.getInt("count")==1,"Organization name search");capture("organization-search");mark("admin-pass");}
            case 16 -> {if(!marked("member-pass"))return false;Files.writeString(mc.gameDirectory.toPath().resolve("moderation-result.txt"),"PASS: admin/public searches, offline names, moderation UI, 72h bound, notes, unmute; two clients simultaneously connected.");mc.stop();}
        }return true;
    }
    private static boolean member(Minecraft mc)throws Exception{
        switch(step){
            case 0 -> mc.setScreen(new PeopleScreen(null,"players"));
            case 1 -> {var d=people();if(d==null)return false;check(!d.getBoolean("admin"),"Public viewer has no moderation");call(mc.screen,"open",new Class<?>[]{String.class},mc.player.getUUID().toString());}
            case 2 -> {var d=people();if(d==null)return false;check(!d.getCompound("detail").contains("history"),"Private history omitted");int seq=(int)get(mc.screen,"sequence");PacketDistributor.sendToServer(new ModerationNet.Action(seq,ModerationFixture.user("CivitasAdmin").toString(),"mute",4320,"FORGED"));}
            case 3 -> {var d=people();if(d==null||!d.getString("message").contains("администраторам"))return false;mark("member-ready");}
            case 4 -> {if(!marked("muted")||!CabinetClientState.muted())return false;PacketDistributor.sendToServer(CabinetNet.PublishNews.of("BLOCKED NEWS","Blocked content","","",false,false,false,0));PacketDistributor.sendToServer(new CabinetNet.SubmitForm("bill","BLOCKED LAW","Blocked content",""));PacketDistributor.sendToServer(new CitizensNet.Action(9300,ids.getString("north"),"apply","","BLOCKED APPLICATION"));var f=new CompoundTag();f.putString("title","BLOCKED DRAFT");f.putString("body","Blocked content");f.putInt("quorum",50);orgSend("draft","",f);mc.player.connection.sendChat("MODERATION_CHAT_ALLOWED");mark("member-blocked");}
            case 5 -> {if(!marked("noted"))return false;var f=new CompoundTag();f.putString("kind","state");PacketDistributor.sendToServer(new OrganizationsNet.Action(new OrganizationsNet.Request(9601,"","contexts",0,"",""),"context",ids.getString("state"),f));mc.setScreen(new PeopleScreen(null,"players"));}
            case 6 -> {if(people()==null)return false;call(mc.screen,"open",new Class<?>[]{String.class},mc.player.getUUID().toString());}
            case 7 -> {var d=people();if(d==null)return false;var p=d.getCompound("detail");check(!p.contains("note")&&!p.contains("history")&&!p.contains("reason"),"Notes and history stay private after mutation");check(d.getBoolean("muted"),"Viewer gets own restriction only");PacketDistributor.sendToServer(new CabinetNet.SubmitForm("bill","BLOCKED LAW WITH RIGHTS","Blocked content",""));PacketDistributor.sendToServer(CabinetNet.PublishNews.of("BLOCKED STATE NEWS","Blocked content","","",false,false,false,0));capture("public-player-detail");mc.setScreen(new OrganizationsScreen(null,ids.getString("org"),"agenda"));}
            case 8 -> {if(desk()==null)return false;set(mc.screen,"focus",ids.getString("resolution"));call(mc.screen,"request",new Class<?>[]{});}
            case 9 -> {var d=desk();if(d==null)return false;var units=d.getCompound("detail").getList("units",10);check(!units.isEmpty(),"Muted voter retains ballot");var f=new CompoundTag();f.putString("unit",units.getCompound(0).getString("id"));f.putInt("choice",1);call(mc.screen,"send",new Class<?>[]{String.class,String.class,CompoundTag.class},"vote",ids.getString("resolution"),f);PacketDistributor.sendToServer(new CitizensNet.Action(9301,ids.getString("island"),"join","",""));}
            case 10 -> {var d=desk();if(d==null||d.getCompound("detail").getInt("yes")!=1)return false;capture("muted-ballot");mark("member-voted");}
            case 11 -> {if(!marked("unmuted")||CabinetClientState.muted())return false;var f=new CompoundTag();f.putString("kind","state");PacketDistributor.sendToServer(new OrganizationsNet.Action(new OrganizationsNet.Request(9600,"","contexts",0,"",""),"context",ids.getString("state"),f));}
            case 12 -> PacketDistributor.sendToServer(new CabinetNet.SubmitForm("bill","Allowed after unmute","Publication restored",""));
            case 13 -> {mc.options.guiScale().set(4);mc.resizeDisplay();mc.setScreen(new PeopleScreen(null,"players"));}
            case 14 -> {if(people()==null)return false;search("OFFLINE29");}
            case 15 -> {var d=people();if(d==null)return false;check(d.getInt("count")==1,"Public offline player search");capture("compact-public-search");mark("member-pass");Files.writeString(mc.gameDirectory.toPath().resolve("moderation-result.txt"),"PASS: forged moderation denied; own restriction refreshed; public data private; publication attempts blocked; voting and chat available; unmute clears restriction; offline search.");}
            case 16 -> {if(!marked("admin-pass"))return false;mc.stop();}
        }return true;
    }
}
