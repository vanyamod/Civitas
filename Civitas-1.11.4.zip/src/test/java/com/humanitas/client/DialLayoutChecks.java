package com.humanitas.client;

import java.util.*;

/** Every entry is reachable; clickable tiles and visible labels do not collide during rotation. */
public final class DialLayoutChecks {
    private static void check(boolean ok,String message){if(!ok)throw new AssertionError(message);}
    public static void main(String[] args){
        int layouts=0;
        for(double radius:new double[]{60,92,120,149,200,260})for(int count:new int[]{3,6,10,11,12,13,16}){
            boolean[] reached=new boolean[count];
            for(int phase=0;phase<96;phase++)for(double collapse:new double[]{0,.25,.5,.75,1}){
                double rotation=phase*count*DialLayout.step(radius,count)/96;
                int size=DialLayout.buttonSize(radius,count,collapse);List<double[]> points=new ArrayList<>();
                for(int i=0;i<count;i++){
                    double a=DialLayout.angle(radius,rotation,i,count);float fade=DialLayout.fade(radius,a,count);
                    if(fade<=.30)continue;reached[i]=true;
                    double x=radius*(1-collapse)*Math.cos(a),y=radius*((1-collapse)*Math.sin(a)+collapse*a/(Math.PI/2));
                    for(var p:points){
                        check(Math.abs(x-p[0])>=size+3.5||Math.abs(y-p[1])>=size+3.5,"Tiles collide r="+radius+" n="+count+" c="+collapse);
                        if(collapse==0&&fade>=.6&&p[2]>=.6)check(Math.abs(y-p[1])>=16,"Visible labels collide r="+radius+" n="+count);
                    }points.add(new double[]{x,y,fade});
                }layouts++;
            }
            for(boolean visible:reached)check(visible,"Every original item must be reachable");
            for(int i=0;i<count;i++)check(Math.abs(DialLayout.angle(radius,0,i,count)-DialLayout.angle(radius,count*DialLayout.step(radius,count),i,count))<.00001,"Complete rotation preserves order");
        }
        System.out.println("Dial layout: "+layouts+" rotation/collapse layouts passed; all entries reachable; no actionable tile or label overlap.");
    }
}
