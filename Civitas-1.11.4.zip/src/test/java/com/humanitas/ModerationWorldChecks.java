package com.humanitas;

import net.minecraft.nbt.*;
import java.nio.file.*;

/** Verify actual network actions against the gracefully saved isolated server world. */
public final class ModerationWorldChecks {
    private static void check(boolean b,String text){if(!b)throw new AssertionError(text);}
    private static CompoundTag read(Path p)throws Exception{return NbtIo.readCompressed(p,NbtAccounter.unlimitedHeap()).getCompound("data");}
    public static void main(String[] args)throws Exception{
        var dir=Path.of("build/moderation-server/world/data");var d=RepublicData.load(read(dir.resolve("humanitas_res_publica.dat")),null);var c=CitizensData.load(read(dir.resolve("civitas_citizens.dat")),null);var o=OrganizationsData.load(read(dir.resolve("civitas_organizations.dat")),null);var m=ModerationData.load(read(dir.resolve("civitas_moderation.dat")),null);
        var id=ModerationFixture.user("Delegate250");
        check(d.news().isEmpty(),"Forged muted newspaper publication rejected");
        check(d.bills().size()==2&&d.bills().stream().anyMatch(b->b.title.equals("Allowed after unmute")),"Muted bill rejected, post-unmute bill accepted");
        check(d.bills().stream().noneMatch(b->b.title.contains("BLOCKED")),"No blocked law inserted");
        check(o.organizations.values().iterator().next().resolutions.size()==1,"Muted organization draft rejected");
        check(o.organizations.values().iterator().next().resolutions.getFirst().ballots.containsKey(id),"Organization ballot accepted while muted");
        var state=CitizensNet.find(d,ModerationFixture.user("NorthChief").toString());check(!c.state(state.owner).applications.containsKey(id),"Muted application rejected");
        check(CitizensData.member(CitizensNet.find(d,ModerationFixture.user("IslandChief").toString()),id),"Invitation acceptance allowed while muted");
        check(!m.muted(id,System.currentTimeMillis())&&m.records.get(id).note.equals("Private moderation evidence"),"Unmute and private note persisted");
        check(!m.muted(ModerationFixture.user("CivitasAdmin"),System.currentTimeMillis()),"Forged non-admin mute did not affect administrator");
        System.out.println("Two-client world: PASS — blocked publications/application/law/draft; allowed ballot and invitation; unmute restores law proposals; authority and persistence.");
    }
}
