package com.humanitas;

import com.humanitas.OrganizationsData.*;
import net.minecraft.nbt.*;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;

/** Opt-in isolated test world. Never touches a normal profile or save. */
public final class ModerationFixture {
    public static java.util.UUID user(String name){return java.util.UUID.nameUUIDFromBytes(("OfflinePlayer:"+name).getBytes(StandardCharsets.UTF_8));}
    public static void main(String[] args)throws Exception{
        var dir=Path.of("build/moderation-server/world/data");Files.createDirectories(dir);
        if(Files.exists(dir.resolve("humanitas_res_publica.dat")))throw new IllegalStateException("Fixture already exists; use a fresh isolated test directory");
        long now=System.currentTimeMillis();var d=new RepublicData();var a=new Actor(user("CivitasAdmin"),"CivitasAdmin",true);var m=new Actor(user("Delegate250"),"Delegate250",false);
        var state=d.createPolity("Республика","Аврора",a.id(),a.name());state.members.add(m.id());state.memberNames.add(m.name());
        state.roles.add(new RepublicData.Role("official","Совет",Perms.LAW_PROPOSE|Perms.NEWS|Perms.DIPLOMACY));state.memberRoles.put(m.id(),"official");
        var bill=d.createBill("Голосование во время мута","Контроль доступности голосования",a.name(),state.owner);bill.proposedDay=java.time.LocalDate.of(1940,1,1).toEpochDay();
        var north=d.createPolity("Республика","Север",user("NorthChief"),"NorthChief");
        var c=new CitizensData();c.state(north.owner).open=true;c.state(north.owner).instructions="Зачем вы вступаете?";
        var invite=d.createPolity("Республика","Остров",user("IslandChief"),"IslandChief");c.invite(d,invite,m.id(),m.name(),now);
        for(int i=0;i<12;i++)d.createPolity("Республика","Страна "+i,user("Chief"+i),"Chief"+i);
        var orgs=new OrganizationsData();var org=orgs.create(a,"Всемирный конгресс",now);orgs.invite(org,d,a,m.id(),m.name(),now);orgs.join(org,m,now);orgs.assign(org,d,a,m.id(),"secretary",now);
        var resolution=orgs.draft(org,d,a,"Совместное голосование","Мут ограничивает тексты, но не голоса",false,50,false,now);orgs.open(org,d,a,resolution,24,now);
        for(var id:java.util.List.of(a.id(),m.id())){d.selectedStates.put(id,state.owner);d.selectedOrganizations.put(id,org.id);}
        var moderation=new ModerationData();for(int i=0;i<30;i++)moderation.seen(user("Offline"+i),"Offline"+i,now);
        write(dir.resolve("humanitas_res_publica.dat"),d.save(new CompoundTag(),null));write(dir.resolve("civitas_organizations.dat"),orgs.write(new CompoundTag()));write(dir.resolve("civitas_citizens.dat"),c.write(new CompoundTag()));write(dir.resolve("civitas_moderation.dat"),moderation.write(new CompoundTag()));
        var ids=new CompoundTag();ids.putString("org",org.id.toString());ids.putString("resolution",resolution.id.toString());ids.putString("north",north.owner.toString());ids.putString("island",invite.owner.toString());ids.putString("state",state.owner.toString());ids.putInt("bill",bill.id);
        var sync=Path.of("build/moderation-coordination");Files.createDirectories(sync);NbtIo.writeCompressed(ids,sync.resolve("fixture.dat"));
        System.out.println("Moderation fixture ready: isolated world, two actors, offline directory, state law, organization resolution and invitation.");
    }
    private static void write(Path p,CompoundTag data)throws Exception{var root=new CompoundTag();root.put("data",data);NbtIo.writeCompressed(root,p);}
}
