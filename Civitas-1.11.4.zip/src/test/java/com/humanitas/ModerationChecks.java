package com.humanitas;

import net.minecraft.nbt.*;
import java.util.*;

/** Persistence, privacy, real-time expiry, limits and transport of the publication restriction. */
public final class ModerationChecks {
    private static int checks;
    private static void check(boolean b,String why){checks++;if(!b)throw new AssertionError(why);}
    private static void reject(Runnable r){checks++;try{r.run();throw new AssertionError("Expected denial");}catch(IllegalArgumentException expected){}}
    public static void main(String[] args){
        long now=1_800_000_000_000L;UUID who=UUID.randomUUID();var d=new ModerationData();
        check(!d.muted(who,now),"Legacy world starts without restrictions");
        reject(()->d.mute(false,who,"Player","Fake",60,"Reason",now));
        reject(()->d.note(false,who,"Player","Fake","Private",now));
        reject(()->d.unmute(false,who,"Fake","",now));
        for(int minutes:new int[]{Integer.MIN_VALUE,-1,0,4321,Integer.MAX_VALUE})reject(()->d.mute(true,who,"Player","Admin",minutes,"Reason",now));
        reject(()->d.mute(true,who,"Player","Admin",60,"  ",now));
        reject(()->d.mute(true,who,"Player","Admin",60,"x".repeat(301),now));
        check(d.records.isEmpty(),"Invalid actions create no record");
        d.seen(who,"Player",now);d.mute(true,who,"Player","Admin",4320,"Flood",now);
        check(d.records.get(who).until==now+72*60*60*1000L,"Exact real 72 hours");
        check(d.muted(who,now)&&d.muted(who,now+72*60*60*1000L-1),"Mute active throughout duration");
        check(!d.muted(who,now+72*60*60*1000L),"Deadline exclusive, no extra minute");
        d.note(true,who,"Player","Admin","Private evidence",now+1);
        var restored=ModerationData.load(d.write(new CompoundTag()),null);var r=restored.records.get(who);
        check(restored.muted(who,now+1000)&&r.note.equals("Private evidence")&&r.history.size()==2,"Offline mute, private note and history survive reload");
        var publicView=ModerationNet.playerProjection(who,"Player","Avrora",false,r,false,now);
        for(String key:List.of("muted","until","reason","note","history"))check(!publicView.contains(key),"Public directory omits "+key);
        var adminView=ModerationNet.playerProjection(who,"Player","Avrora",false,r,true,now);
        check(adminView.getBoolean("muted")&&adminView.getString("note").equals("Private evidence")&&adminView.getList("history",10).size()==2,"Admin sees moderation history");
        restored.expire(now+72*60*60*1000L);check(r.until==0&&r.reason.isEmpty()&&r.history.size()==3,"Expiry logged and cleared");
        restored.expire(now+72*60*60*1000L+1);check(r.history.size()==3,"Expiry logged once");
        restored.mute(true,who,"Renamed","Admin",1,"Reason",now);restored.unmute(true,who,"Admin","Appeal accepted",now+1);
        check(!restored.muted(who,now+2)&&r.name.equals("Renamed")&&r.note.equals("Private evidence"),"Manual unmute preserves name and private note");
        reject(()->restored.unmute(true,who,"Admin","",now+2));
        for(int i=0;i<50;i++)restored.note(true,who,"Player","Admin","note "+i,now+i);
        check(r.history.size()==40&&r.history.getLast().reason().equals("note 49"),"Bounded latest forty audit entries");
        for(String op:List.of("bill","rename","role","faction","factionRole","roleRename","state"))check(ModerationData.textForm(op),"Form gate "+op);
        for(String op:List.of("create","profile","invite","role","stateApply","draft"))check(ModerationData.organizationWrite(op),"Organization gate "+op);
        for(String op:List.of("constitution","ideology","parliament","government","name","type"))check(ModerationData.textEdit(op),"State edit gate "+op);
        for(String op:List.of("apply","recruit"))check(ModerationData.citizensWrite(op),"Application gate "+op);
        for(String op:List.of("create","note","start","pause","resume","end"))check(ModerationData.diplomacyWrite(op),"Diplomacy text gate "+op);
        for(String op:List.of("vote","join","decline","context","stateWithdraw"))check(!ModerationData.organizationWrite(op),"Non-writing action allowed "+op);
        for(String op:List.of("withdraw","join","decline"))check(!ModerationData.citizensWrite(op),"Consent unaffected "+op);
        check(SearchText.matches("  КОНГРЕСС  ","Всемирный конгресс"),"Case insensitive Cyrillic substring");
        check(SearchText.matches("СЕМЕН","Семён")&&SearchText.matches("ＡＶ","Avrora")&&SearchText.matches("","Any"),"Yo, compatibility Unicode and empty search");
        check(!SearchText.matches("Other","Avrora"),"Unmatched names excluded");
        var b=new net.minecraft.network.RegistryFriendlyByteBuf(io.netty.buffer.Unpooled.buffer(),net.minecraft.core.RegistryAccess.EMPTY);
        try{
            var q=new ModerationNet.Request(73,"players","Игрок",4,who.toString());ModerationNet.Request.CODEC.encode(b,q);check(q.equals(ModerationNet.Request.CODEC.decode(b)),"Directory search/focus codec");b.clear();
            var a=new ModerationNet.Action(74,who.toString(),"mute",4320,"Причина");ModerationNet.Action.CODEC.encode(b,a);check(a.equals(ModerationNet.Action.CODEC.decode(b)),"Mute duration/reason codec");b.clear();
            var c=new CitizensNet.Request(75,"","overview",5,"Аврора");CitizensNet.Request.CODEC.encode(b,c);check(c.equals(CitizensNet.Request.CODEC.decode(b)),"State catalog search codec");
        }finally{b.release();}
        System.out.println("Moderation: "+checks+" checks passed; authority, 72h limit, offline persistence, expiry, privacy, write-policy and Unicode search.");
    }
}
