package com.humanitas;

import net.minecraft.nbt.*;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.*;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.PacketDistributor;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;
import java.util.*;

/** Public name directory with an additional, strictly administrator-only moderation projection. */
public final class ModerationNet {
    private ModerationNet(){}
    private static ResourceLocation id(String n){return ResourceLocation.fromNamespaceAndPath(Humanitas.MODID,n);}
    public record Request(int sequence,String kind,String query,int page,String target) implements CustomPacketPayload {
        public static final Type<Request> TYPE=new Type<>(id("people_request"));
        public static final StreamCodec<RegistryFriendlyByteBuf,Request> CODEC=StreamCodec.of((b,p)->{b.writeVarInt(p.sequence);b.writeUtf(p.kind,12);b.writeUtf(p.query,80);b.writeVarInt(p.page);b.writeUtf(p.target,36);},b->new Request(b.readVarInt(),b.readUtf(12),b.readUtf(80),b.readVarInt(),b.readUtf(36)));
        public Type<Request> type(){return TYPE;}
    }
    public record Action(int sequence,String target,String op,int minutes,String text) implements CustomPacketPayload {
        public static final Type<Action> TYPE=new Type<>(id("moderation_action"));
        public static final StreamCodec<RegistryFriendlyByteBuf,Action> CODEC=StreamCodec.of((b,p)->{b.writeVarInt(p.sequence);b.writeUtf(p.target,36);b.writeUtf(p.op,12);b.writeVarInt(p.minutes);b.writeUtf(p.text,1000);},b->new Action(b.readVarInt(),b.readUtf(36),b.readUtf(12),b.readVarInt(),b.readUtf(1000)));
        public Type<Action> type(){return TYPE;}
    }
    public record Snapshot(CompoundTag data) implements CustomPacketPayload {
        public static final Type<Snapshot> TYPE=new Type<>(id("people_snapshot"));
        public static final StreamCodec<RegistryFriendlyByteBuf,Snapshot> CODEC=StreamCodec.composite(ByteBufCodecs.COMPOUND_TAG,Snapshot::data,Snapshot::new);
        public Type<Snapshot> type(){return TYPE;}
    }
    private static final Map<UUID,Long> READS=new HashMap<>(),WRITES=new HashMap<>();
    private static boolean limited(Map<UUID,Long> map,UUID who,long interval){long now=System.currentTimeMillis();if(now-map.getOrDefault(who,0L)<interval)return true;if(map.size()>4096)map.clear();map.put(who,now);return false;}
    public static void register(PayloadRegistrar r){
        r.playToServer(Request.TYPE,Request.CODEC,(p,c)->c.enqueueWork(()->{if(c.player() instanceof ServerPlayer sp){if(limited(READS,sp.getUUID(),150)){var t=new CompoundTag();t.putInt("sequence",p.sequence);t.putBoolean("retry",true);PacketDistributor.sendToPlayer(sp,new Snapshot(t));}else send(sp,p,"",false);}}));
        r.playToServer(Action.TYPE,Action.CODEC,(p,c)->c.enqueueWork(()->{if(c.player() instanceof ServerPlayer sp)act(sp,p);}));
        r.playToClient(Snapshot.TYPE,Snapshot.CODEC,(p,c)->c.enqueueWork(()->com.humanitas.client.PeopleScreen.receive(p.data)));
    }
    static CompoundTag playerProjection(UUID id,String name,String states,boolean online,ModerationData.Record record,boolean admin,long now){
        var t=new CompoundTag();t.putString("id",id.toString());t.putString("title",name);t.putString("subtitle",(online?"В сети":"Не в сети")+(states.isBlank()?"":" · "+states));t.putBoolean("online",online);t.putString("states",states);
        if(admin){t.putBoolean("muted",record!=null&&record.muted(now));t.putLong("until",record==null?0:record.until);t.putString("reason",record==null?"":record.reason);t.putString("note",record==null?"":record.note);var h=new ListTag();if(record!=null)for(int i=record.history.size()-1;i>=0;i--){var e=record.history.get(i);var v=new CompoundTag();v.putLong("time",e.time());v.putString("action",e.action());v.putString("actor",e.actor());v.putString("reason",e.reason());v.putLong("until",e.until());h.add(v);}t.put("history",h);}return t;
    }
    private static Map<UUID,String> names(ServerPlayer player){
        var server=player.getServer();var data=RepublicData.get(server);Map<UUID,String> map=new LinkedHashMap<>();
        for(var p:data.polities()){map.put(RepublicData.leaderOf(p),p.leaderName.isBlank()?p.ownerName:p.leaderName);if(p.deputy!=null)map.put(p.deputy,p.deputyName);for(int i=0;i<p.members.size();i++)map.put(p.members.get(i),i<p.memberNames.size()?p.memberNames.get(i):"");}
        for(var o:OrganizationsData.get(server).organizations.values())o.members.forEach((id,p)->map.putIfAbsent(id,p.name()));
        ModerationData.get(server).records.forEach((id,r)->{if(!r.name.isBlank())map.put(id,r.name);});
        for(var online:server.getPlayerList().getPlayers())map.put(online.getUUID(),online.getGameProfile().getName());return map;
    }
    private static void act(ServerPlayer player,Action p){
        String message;boolean ok=false;try{
            if(!player.hasPermissions(2))throw new IllegalArgumentException("Модерация доступна только администраторам");
            if(limited(WRITES,player.getUUID(),400))throw new IllegalArgumentException("Подождите перед следующим действием");
            UUID who=UUID.fromString(p.target);String name=names(player).get(who);if(name==null||name.isBlank())throw new IllegalArgumentException("Игрок не найден; обновите список");
            var data=ModerationData.get(player.getServer());long now=System.currentTimeMillis();String actor=player.getGameProfile().getName();
            switch(p.op){case "mute"->data.mute(true,who,name,actor,p.minutes,p.text,now);case "unmute"->data.unmute(true,who,actor,p.text,now);case "note"->data.note(true,who,name,actor,p.text,now);default->throw new IllegalArgumentException("Неизвестное действие");}
            var target=player.getServer().getPlayerList().getPlayer(who);if(target!=null&&!p.op.equals("note")){CabinetNet.refresh(target);target.displayClientMessage(net.minecraft.network.chat.Component.literal(p.op.equals("mute")?ModerationData.message(data.records.get(who),now):"Ограничение публикаций в Civitas снято"),true);}
            if(!p.op.equals("note")&&target!=player)CabinetNet.refresh(player);
            message=p.op.equals("mute")?"Мут выдан · "+name:p.op.equals("unmute")?"Мут снят · "+name:"Заметка сохранена";ok=true;
        }catch(IllegalArgumentException ex){message=ex.getMessage()==null?"Проверьте данные":ex.getMessage();}
        send(player,new Request(p.sequence,"players","",0,p.target),message,ok);
    }
    private static void send(ServerPlayer player,Request p,String message,boolean ok){
        var server=player.getServer();if(server==null)return;boolean admin=player.hasPermissions(2);long now=System.currentTimeMillis();var republic=RepublicData.get(server);var moderation=ModerationData.get(server);
        var t=new CompoundTag();t.putInt("sequence",p.sequence);t.putBoolean("admin",admin);t.putBoolean("actionOk",ok);t.putString("kind",p.kind);t.putString("message",message);t.putString("target",p.target);ModerationData.ownSnapshot(t,player);List<CompoundTag> rows=new ArrayList<>();
        if(p.kind.equals("states")){
            if(admin)for(var state:republic.polities())if(SearchText.matches(p.query,state.name)){var r=new CompoundTag();r.putString("id",state.owner.toString());r.putString("title",state.name);r.putString("subtitle",state.government+" · "+state.members.size()+" участников");r.putString("text","Лидер: "+(state.leaderName.isBlank()?state.ownerName:state.leaderName)+"\nИдеология: "+state.ideology+"\nПарламент: "+state.parliament);rows.add(r);if(state.owner.toString().equals(p.target))t.put("detail",r.copy());}
        }else{
            for(var e:names(player).entrySet()){
                if(e.getValue().isBlank())continue;UUID id=e.getKey();String states=String.join(", ",republic.polities().stream().filter(s->CitizensData.member(s,id)).map(s->s.name).toList());
                var r=playerProjection(id,e.getValue(),states,server.getPlayerList().getPlayer(id)!=null,moderation.records.get(id),admin,now);
                if(id.toString().equals(p.target))t.put("detail",r.copy());
                if(SearchText.matches(p.query,e.getValue())){r.remove("history");r.remove("note");rows.add(r);}
            }
        }
        rows.sort(Comparator.comparing((CompoundTag r)->!r.getBoolean("online")).thenComparing(r->SearchText.fold(r.getString("title"))));
        int pages=Math.max(1,(rows.size()+7)/8),page=Math.max(0,Math.min(pages-1,p.page));var list=new ListTag();for(int i=page*8;i<Math.min(rows.size(),page*8+8);i++)list.add(rows.get(i));t.put("rows",list);t.putInt("page",page);t.putInt("pages",pages);t.putInt("count",rows.size());PacketDistributor.sendToPlayer(player,new Snapshot(t));
    }
}
