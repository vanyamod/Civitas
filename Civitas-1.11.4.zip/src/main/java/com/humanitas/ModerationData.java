package com.humanitas;

import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.*;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.world.level.saveddata.SavedData;
import java.util.*;

/** Mod publication restrictions. No Minecraft chat, command, combat or movement hooks. */
public final class ModerationData extends SavedData {
    public static final int MAX_MINUTES=72*60;
    public record Event(long time,String action,String actor,String reason,long until){}
    public static final class Record {
        public String name="",reason="",note="";public long until,lastSeen;
        public final List<Event> history=new ArrayList<>();
        public boolean muted(long now){return until>now;}
    }
    final Map<UUID,Record> records=new LinkedHashMap<>();
    public static ModerationData get(MinecraftServer server){return server.overworld().getDataStorage().computeIfAbsent(new SavedData.Factory<>(ModerationData::new,ModerationData::load,null),"civitas_moderation");}
    public Record record(UUID id,String name){Record r=records.computeIfAbsent(id,k->new Record());if(name!=null&&!name.isBlank()&&!name.equals(r.name)){r.name=name;setDirty();}return r;}
    public boolean muted(UUID id,long now){Record r=records.get(id);return r!=null&&r.muted(now);}
    public void seen(UUID id,String name,long now){record(id,name).lastSeen=now;setDirty();}
    private static void authorized(boolean admin){if(!admin)throw new IllegalArgumentException("Модерация доступна только администраторам");}
    private void event(Record r,String action,String actor,String reason,long until,long now){r.history.add(new Event(now,action,actor,reason,until));if(r.history.size()>40)r.history.remove(0);setDirty();}
    public void mute(boolean admin,UUID target,String name,String actor,int minutes,String reason,long now){
        authorized(admin);if(minutes<1||minutes>MAX_MINUTES)throw new IllegalArgumentException("Срок мута: от 1 минуты до 72 часов");
        String text=OrganizationsData.clean(reason,300);if(text.isBlank())throw new IllegalArgumentException("Укажите причину мута");
        Record r=record(target,name);r.reason=text;r.until=Math.addExact(now,minutes*60000L);event(r,"Мут в Civitas",actor,text,r.until,now);
    }
    public void unmute(boolean admin,UUID target,String actor,String reason,long now){
        authorized(admin);Record r=records.get(target);if(r==null||!r.muted(now))throw new IllegalArgumentException("Действующего мута нет");
        String text=OrganizationsData.clean(reason,300);r.until=0;event(r,"Мут снят",actor,text,0,now);r.reason="";
    }
    public void note(boolean admin,UUID target,String name,String actor,String text,long now){
        authorized(admin);String clean=OrganizationsData.clean(text,1000);Record r=record(target,name);r.note=clean;event(r,"Служебная заметка",actor,clean,0,now);
    }
    public void expire(long now){for(var r:records.values())if(r.until>0&&r.until<=now){r.until=0;event(r,"Срок мута истёк","Сервер",r.reason,0,now);r.reason="";}}
    public static boolean textEdit(String field){return Set.of("constitution","ideology","parliament","government","name","type").contains(field);}
    public static boolean textForm(String kind){return Set.of("bill","rename","role","faction","factionRole","roleRename","state").contains(kind);}
    public static boolean organizationWrite(String op){return Set.of("create","profile","invite","role","stateApply","draft").contains(op);}
    public static boolean citizensWrite(String op){return Set.of("apply","recruit").contains(op);}
    public static boolean diplomacyWrite(String op){return Set.of("create","note","start","pause","resume","end").contains(op);}
    public static String message(Record r,long now){if(r==null||!r.muted(now))return "";long minutes=(r.until-now+59999)/60000;return "Публикации в Civitas ограничены · осталось "+(minutes>=60?(minutes/60)+" ч "+(minutes%60)+" мин":minutes+" мин")+" · "+r.reason;}
    private static final Map<UUID,Long> NOTIFIED=new HashMap<>();
    public static boolean block(ServerPlayer player){
        Record r=get(player.getServer()).records.get(player.getUUID());long now=System.currentTimeMillis();if(r==null||!r.muted(now))return false;
        if(now-NOTIFIED.getOrDefault(player.getUUID(),0L)>1000){if(NOTIFIED.size()>4096)NOTIFIED.clear();NOTIFIED.put(player.getUUID(),now);player.displayClientMessage(Component.literal(message(r,now)),true);}
        CabinetNet.refresh(player);return true;
    }
    public static void requireWriting(ServerPlayer player){Record r=get(player.getServer()).records.get(player.getUUID());long now=System.currentTimeMillis();if(r!=null&&r.muted(now))throw new IllegalArgumentException(message(r,now));}
    public static void ownSnapshot(CompoundTag t,ServerPlayer player){long now=System.currentTimeMillis();Record r=get(player.getServer()).records.get(player.getUUID());t.putLong("moderationNow",now);t.putLong("muteUntil",r==null?0:r.until);t.putBoolean("muted",r!=null&&r.muted(now));t.putString("muteReason",r==null?"":r.reason);t.putString("muteMessage",message(r,now));}
    @Override public CompoundTag save(CompoundTag root,HolderLookup.Provider provider){return write(root);}
    CompoundTag write(CompoundTag root){ListTag list=new ListTag();records.forEach((id,r)->{var t=new CompoundTag();t.putUUID("id",id);t.putString("name",r.name);t.putString("reason",r.reason);t.putString("note",r.note);t.putLong("until",r.until);t.putLong("seen",r.lastSeen);var h=new ListTag();for(var e:r.history){var v=new CompoundTag();v.putLong("time",e.time);v.putString("action",e.action);v.putString("actor",e.actor);v.putString("reason",e.reason);v.putLong("until",e.until);h.add(v);}t.put("history",h);list.add(t);});root.put("players",list);return root;}
    static ModerationData load(CompoundTag root,HolderLookup.Provider provider){var data=new ModerationData();var list=root.getList("players",10);for(int i=0;i<list.size();i++){var t=list.getCompound(i);if(!t.hasUUID("id"))continue;var r=new Record();r.name=t.getString("name");r.reason=t.getString("reason");r.note=t.getString("note");r.until=t.getLong("until");r.lastSeen=t.getLong("seen");var h=t.getList("history",10);for(int j=Math.max(0,h.size()-40);j<h.size();j++){var v=h.getCompound(j);r.history.add(new Event(v.getLong("time"),v.getString("action"),v.getString("actor"),v.getString("reason"),v.getLong("until")));}data.records.put(t.getUUID("id"),r);}return data;}
}
