package com.humanitas.client;

import com.humanitas.ModerationNet;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.nbt.*;
import net.minecraft.network.chat.Component;
import net.neoforged.neoforge.network.PacketDistributor;
import org.lwjgl.glfw.GLFW;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;
import static com.humanitas.client.CivitasUi.*;

/** One searchable player directory; administrative controls are supplied only to administrators. */
public final class PeopleScreen extends Screen {
    private static int nextSequence;
    private final Screen parent;private final String kind;
    private DocumentPanel panel;private CompoundTag data=new CompoundTag();
    private String target="",query="",notice="",editor="";private int sequence,page,scroll,ticks,durationPreset=3;
    private boolean busy,queued,directEditor;private long since,nextSend,changedAt;
    private final TextInput search=new TextInput(false,80,"Поиск по названию…"),text=new TextInput(true,1000,"Причина или заметка"),duration=new TextInput(false,4,"Минуты");
    private final TextInput reader=new TextInput(true,60000,"");
    private final List<Control> controls=new ArrayList<>();
    private record Control(int x,int y,int w,String label,Style style,Runnable action){}
    private static final int[] PRESETS={15,30,60,360,720,1440,2880,4320};
    public PeopleScreen(Screen parent,String kind){super(Component.literal(kind.equals("states")?"Государства":"Игроки"));this.parent=parent;this.kind=kind;}
    public static PeopleScreen muteForm(WheelScreen parent,String id,boolean unmute){
        var screen=new PeopleScreen(parent,"players");screen.target=id;screen.editor=unmute?"unmute":"mute";screen.directEditor=true;screen.duration.setValue("360");return screen;
    }
    @Override protected void init(){panel=new DocumentPanel(width,height,680,430);if(data.isEmpty())request(true);}
    private void request(boolean foreground){if(foreground){busy=true;since=System.currentTimeMillis();}sequence=++nextSequence;queued=true;flush();}
    private void flush(){long now=System.currentTimeMillis();if(queued&&now>=nextSend){queued=false;nextSend=now+180;PacketDistributor.sendToServer(new ModerationNet.Request(sequence,kind,query,page,target));}}
    public static void receive(CompoundTag t){if(!(Minecraft.getInstance().screen instanceof PeopleScreen s)||s.sequence!=t.getInt("sequence"))return;if(t.getBoolean("retry")){s.queued=true;s.nextSend=System.currentTimeMillis()+200;return;}
        s.data=t.copy();s.busy=false;s.queued=false;s.page=t.getInt("page");if(!t.getString("message").isBlank())s.notice=t.getString("message");
        CabinetClientState.moderation(t);
        if(t.getBoolean("actionOk")){s.editor="";s.text.setValue("");if(s.directEditor&&s.parent instanceof WheelScreen wheel){wheel.updatePlayerModeration(t.getCompound("detail"));Minecraft.getInstance().setScreen(wheel);return;}}
        if(!s.directEditor&&s.kind.equals("players")&&!s.target.isEmpty()&&!t.getCompound("detail").isEmpty()&&s.parent instanceof WheelScreen wheel)wheel.showDirectoryPlayer(t.getCompound("detail"));
    }
    @Override public void tick(){flush();long now=System.currentTimeMillis();if(!search.value().equals(query)){if(changedAt==0)changedAt=now;if(now-changedAt>=250&&!busy&&target.isEmpty()){query=search.value();page=0;scroll=0;changedAt=0;request(false);}}else changedAt=0;
        if(busy&&now-since>8000){busy=false;notice="Ответ задерживается. Обновляем данные…";request(true);}if(++ticks%60==0&&!busy)request(false);}
    private void buttonAt(GuiGraphics g,String label,int x,int y,int w,Style style,Runnable action,int mx,int my){controls.add(new Control(x,y,w,label,style,action));button(g,font,x,y,w,22,label,!busy&&inside(mx,my,x,y,w,22),busy?Style.DISABLED:style);}
    private String fit(String s,int w){return CivitasSurfaces.fit(font,s,Math.max(10,w));}
    private static String date(long t){return t<=0?"—":DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm").withZone(ZoneId.systemDefault()).format(Instant.ofEpochMilli(t));}
    private void read(GuiGraphics g,int mx,int my,int x,int y,int w,int h,String body){if(!reader.value().equals(body))reader.replaceReadOnly(body);reader.focused=false;reader.setBounds(x,y,w,Math.max(20,h));reader.render(g,mx,my);}
    private void open(String id){target=id;editor="";reader.scrollToStart();request(true);}
    private void start(String op){editor=op;text.setValue(op.equals("note")?data.getCompound("detail").getString("note"):"");duration.setValue("360");text.focused=true;reader.scrollToStart();}
    private void send(){if(busy)return;int minutes=0;try{if(editor.equals("mute"))minutes=Integer.parseInt(duration.value());}catch(NumberFormatException e){notice="Укажите срок в минутах: 1–4320";return;}if(editor.equals("mute")&&(minutes<1||minutes>4320)){notice="Срок мута: от 1 минуты до 72 часов";return;}if(!editor.equals("note")&&(text.value().length()>300||editor.equals("mute")&&text.value().isBlank())){notice="Укажите причину мута · до 300 символов";return;}busy=true;since=System.currentTimeMillis();sequence=++nextSequence;queued=false;PacketDistributor.sendToServer(new ModerationNet.Action(sequence,target,editor,minutes,text.value()));}
    @Override public void render(GuiGraphics g,int mx,int my,float partial){
        controls.clear();g.fill(0,0,width,height,BACKDROP);boolean admin=data.getBoolean("admin");var detail=data.getCompound("detail");
        String heading=directEditor?(editor.equals("unmute")?"СНЯТЬ МУТ":"МУТ"):kind.equals("states")?"ГОСУДАРСТВА":"ИГРОКИ";
        panel.draw(g,font,heading,target.isEmpty()?(kind.equals("states")?"Поиск по названию · государства сервера":"Поиск по имени · в сети и офлайн"):detail.getString("title"),55);
        int x=panel.x+14,y=panel.y+66,w=panel.w-28,h=panel.footer()-y-16;
        if(directEditor)drawEditor(g,mx,my,x,y,w,h);
        else if(target.isEmpty())drawRows(g,mx,my,x,y,w,h);
        else if(!editor.isEmpty())drawEditor(g,mx,my,x,y,w,h);
        else if(detail.isEmpty())read(g,mx,my,x,y,w,h,"Запись больше недоступна. Вернитесь к списку и обновите поиск.");
        else drawDetail(g,mx,my,x,y,w,h,detail,admin);
        buttonAt(g,"НАЗАД",x,panel.footer(),88,Style.SECONDARY,this::onClose,mx,my);
        String message=busy?"Ожидание сервера…":notice;g.drawString(font,fit(message,w-98),x+98,panel.footer()+7,DIM,false);
        for(var c:controls)if(inside(mx,my,c.x,c.y,c.w,22)&&font.width(c.label)>c.w-12){g.renderTooltip(font,Component.literal(c.label),mx,my);break;}
    }
    private void drawRows(GuiGraphics g,int mx,int my,int x,int y,int w,int h){
        search.setBounds(x,y,w-82,22);search.render(g,mx,my);buttonAt(g,"НАЙТИ",x+w-76,y,76,Style.SECONDARY,()->{query=search.value();page=0;scroll=0;request(true);},mx,my);
        var rows=data.getList("rows",10);int ry=y+31,rh=Math.max(39,h-62),rowH=43,maxScroll=Math.max(0,rows.size()*rowH-4-rh);if(rh<2*rowH)scroll=Math.round(scroll/(float)rowH)*rowH;scroll=Math.max(0,Math.min(scroll,maxScroll));g.enableScissor(x,ry,x+w,ry+rh);
        for(int i=0;i<rows.size();i++){var r=rows.getCompound(i);int yy=ry+i*rowH-scroll;CivitasSurfaces.surface(g,x,yy,w,39,r.getBoolean("muted"),inside(mx,my,x,yy,w,39));int reserve=82;
            g.drawString(font,fit(r.getString("title"),w-reserve-14),x+9,yy+7,TEXT_LIGHT,false);g.drawString(font,fit(r.getString("subtitle"),w-reserve-14),x+9,yy+23,DIM,false);
            if(yy>=ry&&yy+39<=ry+rh){buttonAt(g,"ИНФО",x+w-72,yy+8,64,Style.SECONDARY,()->open(r.getString("id")),mx,my);}
        }g.disableScissor();if(rows.isEmpty())g.drawString(font,"Ничего не найдено",x+8,ry+14,DIM,false);
        if(maxScroll>0){int th=Math.max(12,rh*rh/(rows.size()*rowH-4)),ty=ry+(rh-th)*scroll/Math.max(1,maxScroll);g.fill(x+w-3,ry,x+w-1,ry+rh,LINE);g.fill(x+w-3,ty,x+w-1,ty+th,GOLD);}
        int by=y+h-23;buttonAt(g,"←",x,by,32,page>0?Style.SECONDARY:Style.DISABLED,()->{if(page>0){page--;scroll=0;request(true);}},mx,my);buttonAt(g,"→",x+w-32,by,32,page+1<data.getInt("pages")?Style.SECONDARY:Style.DISABLED,()->{if(page+1<data.getInt("pages")){page++;scroll=0;request(true);}},mx,my);
        g.drawString(font,(page+1)+" / "+Math.max(1,data.getInt("pages"))+" · найдено "+data.getInt("count"),x+45,by+7,DIM,false);
    }
    private void drawDetail(GuiGraphics g,int mx,int my,int x,int y,int w,int h,CompoundTag d,boolean admin){
        read(g,mx,my,x,y,w,h,d.getString("title")+"\n"+d.getString("id")+"\n"+d.getString("subtitle")+(kind.equals("states")?"\n\n"+d.getString("text"):""));
    }
    private void drawEditor(GuiGraphics g,int mx,int my,int x,int y,int w,int h){
        boolean mute=editor.equals("mute");int offset=0;
        if(mute){g.drawString(font,fit("СРОК В МИНУТАХ · 1–4320 (72 ЧАСА)",w),x,y,GOLD,false);duration.setBounds(x,y+12,90,22);duration.render(g,mx,my);buttonAt(g,"Быстрый срок: "+PRESETS[durationPreset]+" мин ▸",x+100,y+12,Math.max(90,w-100),Style.SECONDARY,()->{durationPreset=(durationPreset+1)%PRESETS.length;duration.setValue(Integer.toString(PRESETS[durationPreset]));},mx,my);offset=40;}
        g.drawString(font,fit(editor.equals("note")?"ЗАМЕТКА · ТОЛЬКО АДМИНИСТРАТОРАМ · ДО 1000 СИМВОЛОВ":"ПРИЧИНА · ДО 300 СИМВОЛОВ",w),x,y+offset,GOLD,false);text.setBounds(x,y+offset+13,w,Math.max(20,h-offset-43));text.render(g,mx,my);
        buttonAt(g,"ОТМЕНА",x,y+h-25,100,Style.SECONDARY,()->editor="",mx,my);buttonAt(g,editor.equals("note")?"СОХРАНИТЬ":mute?"ВЫДАТЬ МУТ":"СНЯТЬ МУТ",x+w-140,y+h-25,140,mute?Style.DANGER:Style.PRIMARY,this::send,mx,my);
    }
    @Override public boolean mouseClicked(double x,double y,int b){if(b!=0)return false;for(var c:controls)if(inside(x,y,c.x,c.y,c.w,22)){if(!busy&&c.style!=Style.DISABLED)c.action.run();return true;}if(busy)return true;if(!editor.isEmpty()){boolean a=duration.mouseClicked(x,y);return text.mouseClicked(x,y)||a;}return target.isEmpty()?search.mouseClicked(x,y):reader.mouseClicked(x,y);}
    @Override public boolean mouseDragged(double x,double y,int b,double dx,double dy){return !editor.isEmpty()?text.mouseDragged(x,y):reader.mouseDragged(x,y);}
    @Override public boolean mouseScrolled(double x,double y,double dx,double dy){if(!editor.isEmpty())return text.mouseScrolled(x,y,dy);if(!target.isEmpty())return reader.mouseScrolled(x,y,dy);scroll-=Math.round((float)dy*24);return true;}
    @Override public boolean charTyped(char c,int mods){if(busy)return false;return !editor.isEmpty()?duration.charTyped(c)||text.charTyped(c):target.isEmpty()&&search.charTyped(c);}
    @Override public boolean keyPressed(int key,int scan,int mods){if(key==GLFW.GLFW_KEY_ESCAPE){onClose();return true;}if(busy)return true;if(!editor.isEmpty())return duration.keyPressed(key,mods)||text.keyPressed(key,mods);if(key==GLFW.GLFW_KEY_ENTER&&target.isEmpty()){query=search.value();page=0;request(true);return true;}return target.isEmpty()&&search.keyPressed(key,mods);}
    @Override public void onClose(){if(directEditor){minecraft.setScreen(parent);return;}if(!editor.isEmpty()){editor="";return;}if(!target.isEmpty()){target="";reader.scrollToStart();request(true);return;}minecraft.setScreen(parent);}
    @Override public boolean isPauseScreen(){return false;}
    @Override public void renderBackground(GuiGraphics g,int mx,int my,float p){}
}
