package com.humanitas.client;

/** A circular sequence viewed through a half-circle; every item remains reachable. */
final class DialLayout {
    private DialLayout(){}
    static int slots(double radius){
        int slots=3;
        for(int n=4;n<=9;n++){
            double first=-Math.PI/2+Math.PI/(2*n),second=first+Math.PI/n;
            if(radius*(Math.sin(second)-Math.sin(first))>=24)slots=n;
        }
        return slots;
    }
    static double step(double radius,int count){return Math.PI/Math.max(1,Math.min(count,slots(radius)));}
    static double angle(double radius,double rotation,int index,int count){
        double step=step(radius,count),period=Math.max(1,count)*step;
        double a=((index+.5)*step+rotation)%period;if(a<0)a+=period;
        return a-Math.PI/2;
    }
    static float fade(double radius,double angle,int count){
        return (float)Math.max(0,Math.min(1,(Math.PI/2-Math.abs(angle))/(step(radius,count)*.34)));
    }
    static int buttonSize(double radius,int count,double collapse){
        double step=step(radius,count),a=2*radius*(1-collapse)*Math.sin(step/2),b=2*radius*collapse*step/Math.PI;
        double end=Math.max(0,Math.PI/2-step/2),t=end;
        if(a>0&&b<a*(Math.sin(end)-Math.cos(end)))t=Math.PI/4+Math.asin(b/(Math.sqrt(2)*a));
        double gap=Math.max(a*Math.sin(t),a*Math.cos(t)+b);
        return Math.max(18,Math.min(36,(int)Math.floor((gap-6)/2)*2));
    }
}
