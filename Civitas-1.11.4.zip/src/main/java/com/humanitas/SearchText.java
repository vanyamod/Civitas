package com.humanitas;

import java.text.Normalizer;
import java.util.Locale;

/** Shared name matching for public and administrative directories. */
public final class SearchText {
    private SearchText(){}
    public static String fold(String value){return Normalizer.normalize(value==null?"":value,Normalizer.Form.NFKC).strip().toLowerCase(Locale.ROOT).replace('ё','е');}
    public static boolean matches(String query,String... values){String q=fold(query);if(q.isEmpty())return true;for(String value:values)if(fold(value).contains(q))return true;return false;}
}
