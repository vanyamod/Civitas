# Civitas 1.11.4 source export

- Minecraft 1.21.1 / NeoForge 21.1.250 / Java 21; protocol 16.
- This clean source copy passed its own Gradle build, including all regression checks,
  68 moderation checks and 113 organization checks.
- Source Java, tests and resources match the working source byte for byte.
- The main release was validated with two real isolated clients and saved-world checks:
  publication restrictions, restored proposals, votes, consent, chat and private notes.
  The original 1.11.3 admin panels/full cards were restored; Mute is a final scrollable
  card action. Direct mute/unmute and return to the same card were checked in game.
- No Git history, worlds, player records, profiles, live configuration, credentials,
  logs, screenshots, caches, backups or build output are included.
- The only bundled JAR is Gradle Wrapper; compile the mod locally or via GitHub Actions.
- Credential-pattern/personal-path scans and source hashes passed.
- Helpers require an explicit installation profile; a build does not auto-install.
- Spaced dial viewport retains every action; 20160 geometry layouts and a real
  cyclic-menu traversal passed. Compact Mute hover was verified in rendered frames.
- Discord-format devblog: docs/DEVLOG-1.11.4.md.

EXPORT-MANIFEST.json lists SHA-256 and bytes for every other exported file.
The manifest excludes itself. Future files added after export are not covered.
