# Civitas 1.11.4 — developer context

Minecraft 1.21.1 / NeoForge 21.1.250 / JDK 21. Network protocol 16.
The mod ID/package remains humanitas / com.humanitas for save compatibility.
Build with `gradlew.bat build` or `bash ./gradlew build`. No local modpack is required.

## Authority and persistence

- RepublicData stores states, roles, parties, bills, constitutions, news and archives.
  State IDs remain founder UUIDs. Preserve existing SavedData keys and identities.
- CabinetNet derives rights from the actual server player. State selection is context,
  not authorization. Law proposals require LAW_PROPOSE; archives require ARCHIVE_VIEW.
- CitizensData/Net provide consent-based membership, recruitment and public history.
  Membership in multiple states is supported; public history excludes private archives.
- OrganizationsData/Net provide administrator-created organizations, delegated rights,
  personal invitations, state applications, delegates and captured-electorate resolutions.
  Organization rights confer no authority over another state. Existing vote watchers
  refresh other open desks; thin law snapshots never overwrite the main HUD cache.
- DiplomacyData/Net implement agreements and supervised wars. WatchdogBridge is an
  optional dashboard bridge; an anti-cheat implementation is not bundled.
- ModerationData stores real-time publication restrictions in civitas_moderation.
  ModerationNet permits mutation only for server administrators (command level 2+).
  Mute: 1–4320 minutes, required reason; private notes and bounded 40-entry history.
  Public player projections contain no moderation notes/history/other-player reasons.
  Own restriction is separate. Server write gates cover news, applications, laws,
  organization content, diplomacy text and media. Reading, voting, consent and chat
  remain available. Expiry uses real server time and survives offline/restarts.
- SearchText implements normalized case-insensitive substring matching. State,
  organization and known-player searches run before pagination. No party search.
The public Players medallion was explicitly removed from the left wheel; retain
the original administrative Players window. The current citizen menu has11 entries.
Civitas PNG branding is a large pixel C in its inventory-style graphite/gold frame;
the source is native SVG following CivitasSurfaces.cut. Watchdog is a
monochrome pixel eye. Both JAR metadata paths were verified in the actual Modrinth
content metadata/icon cache. See docs/branding for selected images and prompts.

## Interface and verification

WheelScreen contains the player/admin menus and state/organization context picker.
WheelScreen retains the original 1.11.3 player/state admin panels and full player cards.
Mute appears only at the bottom of the scrolling card; PeopleScreen supplies a direct
server-authorized mute/unmute form and the public player directory.
StatesScreen and OrganizationsScreen use searchable paged lists. Shared dark surfaces,
document views, responsive forms and the rich news editor are retained.

Build runs moderation, citizen, organization, news, constitution, diplomacy, skin,
pending-action and Watchdog checks. Two real isolated clients verified moderation,
searches, private projections, denied forged actions, allowed votes/chat/consent and
publication restoration after unmute. Saved-world assertions confirmed actual changes.
Minimum-height UI screenshots were inspected after clipping/overlap corrections.
DialLayout keeps a spaced cyclic viewport with every action reachable; arrows, wheel
and keyboard rotate it. Mute is compact with pointer-driven hover. 20160 geometry
layouts and a real cyclic-menu traversal passed; a hover render pair was checked.
300 people / 60 states is a model-data test, not a 300-client load test. The production
modpack was not load-tested. See docs/VALIDATION-1.11.4.md and docs/MODERATION.md.

Fixtures/harnesses are test sources, excluded from normal release JARs. Fixture tasks
only use their explicit build test directories. UI harnesses require opt-in properties.
moderationWorldChecks requires the completed isolated moderation scenario; it is not
part of the ordinary build. The normal build works in a clean checkout without saves.

## Publication

This is a source export: no Git history, profiles, player records, worlds, live configs,
credentials, logs, screenshots, caches or compiled mod JAR. Only Gradle Wrapper is bundled.
The installer requires an explicit profile path and refuses replacement in a running game.
Install the same version on client/server. Keep All Rights Reserved metadata and asset
credits. Do not commit future local saves, configuration, credentials or build outputs.
