# Civitas / Watchdog — pixel avatars

## Civitas — inventory-button monogram

- [PNG avatar](civitas-pixel.png), 512×512, opaque graphite background.
- [Editable SVG](civitas-c.svg), logical 64×64 pixel grid.
- A large gold «С» centered inside the inventory-button-style frame.
- Geometry follows `CivitasSurfaces.cut` / `surface`: integer rectangles,
  stepped cut corners, thin inset frame, graphite fill and the default gold palette.
- The letter is a hand-defined bitmap glyph; the SVG is rendered with nearest-neighbor
  pixel scaling. No generated texture, smoothing or realistic material shading.
- This final monogram is code-native SVG/PNG. It replaces the earlier generated
  full-word logo. The old wordmark is backed up outside the source export.

## Packaging

The root JAR asset is `civitas-icon.png`; NeoForge metadata already points to it
through `logoFile` with `logoBlur=false`. The gameplay UI and Watchdog are unchanged.
Modrinth reads this embedded path and caches the avatar for its uploaded-mod list.

Parser reference: https://github.com/modrinth/code/blob/main/packages/app-lib/src/state/instances/commands/embedded_content_metadata.rs

## Watchdog

[Watchdog PNG](watchdog-pixel.png) remains the selected monochrome pixel eye,
created with the built-in imagegen tool on 2026-11-15.

## Watchdog — final prompt

Make a strict Minecraft resource-pack PIXEL ART mod avatar. Logical 32x32 or 64x64 pixel canvas displayed enlarged using nearest-neighbor: every edge is a chunky staircase of square pixels. A single WATCHFUL EYE looking directly at the viewer, centered on a solid BLACK square, STRICTLY BLACK AND WHITE plus at most two flat gray shades. The eye is a simple horizontal stepped almond with thick off-white pixel outlines, a blocky gray iris, black square pupil, and one tiny square white highlight. Icon fills 80% width, readable at 32 pixels. Style: a hand-pixelled Minecraft item/GUI texture, simple flat pixels. Absolutely NO realistic iris fibers, smooth curves, antialiasing, gradients, skin, fur, metal, 3D, bevels, gloss, rounded vector lines, dog, shield, triangle, text, color or decorations. Flat monochrome pixel art only. Full opaque black background.
