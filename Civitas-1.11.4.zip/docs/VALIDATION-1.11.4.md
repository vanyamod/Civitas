# Civitas 1.11.4 — current validation

Updated 2026-11-15 after restoring the player/state administration UI from the
saved pre-1.11.4 / 1.11.3 source. Minecraft 1.21.1, NeoForge 21.1.250, JDK 21;
network protocol remains 16.

The complete Gradle build passes, including 68 moderation checks, 113 organization
checks and the citizen, news, constitution, diplomacy, skin, pending-action and
Watchdog checks.

The final UI was exercised by a real development client on an isolated loopback
server. Assertions and inspected game screenshots confirm:

- the original player window retains Trust Rate and Info;
- typing a name filters the original list without triggering wheel shortcuts;
- Info opens the original full player card, preserving state, roles, faction,
  diplomacy, OP status, game mode, health, food, experience and trust;
- Mute is absent at the top of a long card and appears only in its scrolling end;
- clicking that action directly opens the duration/reason form for the same UUID;
- a real mute is accepted, returns to the same card and changes its final action
  to Unmute; unmute restores the Mute action;
- closing the card leaves the original filtered player panel open;
- state name search retains Create, Reset, Delete and matching-state Info/Open;
- the explanatory moderation banner and list-row Mute button are removed.

Output: build/moderation-admin/player-card-restore-result.txt and screenshots
moderation-restored-*.png. Fixtures, world data, outputs and screenshots are not
included in the source export or release JAR.

The preceding two-client scenario verified the retained server restriction gates:
forged non-admin moderation denied; muted news, law, application and organization
draft packets rejected; voting, invitation acceptance and Minecraft chat allowed;
unmute restored a law proposal; private data stayed private; restrictions/notes
persisted through save and restart. Publication enforcement is unchanged by the
UI restoration. The final build reruns all model/permission/codec regressions.

Existing SavedData IDs are preserved. civitas_moderation is a separate store.
300 participants / 60 states are model-data checks, not a 300-client load test.
The production modpack and production world saves were not used for isolated tests.
Install the same 1.11.4 release on client and server.

## Compact mute action and dial spacing

The Mute/Unmute action now uses a compact, right-aligned control and actual
pointer coordinates for the standard hover state. A real GUI-renderer pair
(normal/hover) was captured; 8040 pixels inside the button changed. Screenshots
were inspected. The original full card and final scrolling action are retained.

DialLayout keeps every item in its original circular order behind a half-circle
viewport. Capacity adapts to GUI height (up to nine visible slots); arrow controls,
mouse wheel and existing keyboard rotation remain available. Faded-away labels
are not clickable. Square tile spacing is respected while the arc collapses.

`dialLayoutChecks` passed 20160 phase/size/collapse combinations, checking item
reachability, clickable tile separation, label separation and complete rotations.
A real game client reached all twelve citizen actions using the arrow controls,
verified mouse-wheel rotation and captured normal/compact menu renders. This
scenario is opt-in through the isolated UI harness; its outputs stay under build.

## Final left-menu cleanup and pixel avatars

Removed the public Players medallion from PLAYER_ITEMS at the user's request;
the administrative player list, full Info card, search and final Mute action remain.
The current state wheel has eleven entries; earlier twelve-entry traversal results
above describe the preceding UI iteration. Dial model checks include eleven entries.

Both projects now package the selected Minecraft-style pixel PNG at the JAR root,
with logoFile and logoBlur=false in mod metadata. Civitas is a gold bitmap wordmark
on black; Watchdog is a stepped black/white eye. Superseded art is not packaged.
Both final JARs passed CRC, TOML path, square PNG and exact embedded-image checks.
Watchdog has exactly one new icon entry and one metadata change; every other entry,
including all 55 classes, is byte-identical to its previous installed release.

The local Modrinth instance detected both files and loaded both named icon images
in its content accessibility tree. Its embedded-content metadata references existing
512x512 icon cache files. Pixel comparison against the chosen PNGs after thumbnail
resampling passed with mean channel differences below 0.1/255. The launcher database
was read only; no icon override or cache patching was used. Both local JAR copies
match their release hashes. Prompts and selected PNGs are in docs/branding.

## Civitas inventory-button monogram

The final Civitas avatar is a large gold «С» in a graphite cut-corner inventory-style
frame, replacing the full-word logo. It is drawn as native SVG integer rectangles
on a 64x64 grid using the GUI frame geometry, then rendered to a 512x512 PNG with
nearest-neighbor scaling. The result has nine flat colors and no smoothed edges.
The source SVG is docs/branding/civitas-c.svg.

The rebuilt JAR differs from the prior installed release in exactly one entry:
civitas-icon.png. Every class, metadata file and other resource is byte-identical.
The existing logoFile path remains valid; the installed JAR checksum matches.
