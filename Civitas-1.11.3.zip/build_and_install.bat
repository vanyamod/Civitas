@echo off
chcp 65001 >nul
cd /d "%~dp0"
call gradlew.bat build
if errorlevel 1 exit /b 1
if "%~1"=="" (
    echo Build completed. The JAR is in build\libs.
    echo To install, pass the Minecraft profile directory as the first argument.
    exit /b 0
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\install_mod.ps1" -Profile "%~1"
exit /b %errorlevel%
