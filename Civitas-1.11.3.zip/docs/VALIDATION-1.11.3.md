# Civitas 1.11.3 — current validation

Updated 2026-11-14 after GUI/live-update corrections. Minecraft 1.21.1,
NeoForge 21.1.250, JDK 21. Network protocol remains 15.

`gradlew.bat build --offline --console=plain`: PASS. All existing checks pass,
including 113 organization checks and new citizen/law projection checks for a
friend's vote appearing after the viewer's own vote and removal of completed vote access.
The original 300-person / 60-state persistence and permission checks also pass.

Two simultaneously connected development clients (CivitasAdmin and Delegate250),
on an isolated loopback server, verified:

- the same open organization resolution received both players' votes;
- the same open state-law card received both players' votes;
- no reopening of those cards was used between the first and second count;
- an assignment through the actual role picker was accepted and displayed as
  `Председатель · Секретариат`;
- single-line organization name fields are 22 GUI pixels high;
- wheel input over the description moved the outer profile form;
- the charter opened in a separate document renderer.

Results and real game screenshots: `build/gui-fix-admin`, `build/gui-fix-member`,
`build/gui-fix-coordination`, and `build/gui-fix-two-client-result.txt`.
The final news layout scenario also passed: ordinary and compact layouts,
a separate author-choice row, and non-overlapping title/body/source/footer bounds.
Screenshots were inspected, including the normal editor and compact section tabs.

These are isolated development clients, not a full production modpack load test.
The 300/60 data checks do not represent 300 simultaneous connected clients.
Production world saves were not opened or rewritten by the tests.

The final JAR contains no test harness, fixture or check classes. ZIP CRC validation
passed. The reference release build was checksum-verified. Use the corrected JAR on both the client and server.

Artifact: `build/libs/Civitas-1.11.3.jar`.
SHA-256: `8984979e68a6e1fe4d27afac21112d0734cb54be4a07556479003defe71e4b61`.

Header cleanup: removed the redundant press-service/author caption; author selector
remains in its own row. Header shortened by 15 GUI pixels. `jar --offline` compiled
and packaged successfully; reference build was hash-verified. The earlier gameplay
checks above cover the preceding functional changes.
