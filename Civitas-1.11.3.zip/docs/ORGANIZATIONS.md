# Organizations in Civitas 1.11.3

Open **Организации** on the citizen wheel. Everyone can browse organization profiles,
charters, state delegations, public history and completed resolutions. Internal rosters,
roles, drafts and ongoing ballots require affiliation or administrator access.

## Set up the congress

1. An administrator opens the catalog and chooses **Создать**. The administrator is the
   initial chair; no extra server command or configuration is required.
2. Invite the intended chair under **Участники → Пригласить**. The invited player accepts
   under **Организации → Приглашения**. Invitation never silently enrolls a player.
3. Open that participant's card and transfer the chair. The chair may appoint a deputy,
   update the profile and charter, create roles and delegate the required permissions.
4. States use **Делегации → Заявка страны**. Only their leader, deputy or a player with
   DIPLOMACY authority (or an administrator) may submit a state application. A member with
   the organization's state-admission permission approves or rejects it.
5. After admission, the state's authorized diplomat chooses a current citizen as its
   representative. Being an organization official alone does not authorize representing
   someone else's state. Administrators retain their existing full supervision powers.

Direct membership and a state mandate are separate: a valid representative can access
the organization without accepting a second personal invitation. Delegations are listed
separately from direct participants. A representative who loses citizenship immediately
loses the corresponding mandate; the state can nominate someone else. Withdrawing a
delegation preserves its historical votes.

## Roles

Organization permissions are independent of government roles: profile/charter,
members/invitations, roles/assignments, proposing resolutions, personal voting,
news publishing/moderation, opening/removing sessions, admitting states.

The chair and deputy have full organization authority; administrators can manage any
organization from its public catalog card. New members have personal voting permission.
The built-in Secretariat may propose, vote, publish and open sessions. Council has all
permissions except managing roles. Officials cannot grant permissions beyond their own,
alter leadership or remove members whose authority exceeds theirs. Only the chair or an
administrator may appoint leadership. The chair must transfer their post before leaving.
The base member role cannot be deleted; another role can be deleted after its occupants
are reassigned. Creating or deleting an organization requires administrator permission.
Deletion requires the exact organization name.

## Resolution lifecycle

An authorized author submits a **project** with a title, text, voting mode, quorum and
majority. An authorized session manager opens it for 1–168 real hours. The deadline,
rules and electorate are captured at opening; new members do not enter an ongoing vote.
There are three choices: yes, no and abstain. A cast vote is final.

* Personal mode: one vote for each eligible direct member or valid state representative;
  someone with several mandates is still one person.
* State mode: one vote for each admitted state with a valid representative when voting
  opens. A person representing multiple states explicitly chooses which mandate to cast.
  Replacing a representative cannot duplicate that state's vote.
* Quorum is the rounded-up percentage of the captured electorate. Abstentions count
  toward turnout. A simple majority requires more yes than no votes; a qualified majority
  requires at least two thirds of yes/no votes. Zero yes votes never adopts a resolution.
* At the deadline the server records **adopted**, **rejected** or **no quorum**, even if
  nobody has the cabinet open. A manager may remove a project or active session; this
  records **cancelled**, never an adopted decision. Administrators cannot cast an outsider's
  vote merely because they may moderate.

Uncast eligible ballots appear first and are highlighted; remaining active ballots,
projects, and completed resolutions follow. The document card displays the rules, deadline,
turnout and counts. Cast and completed ballots have no voting buttons. Public visitors
can read completed decisions, not internal projects or active sessions.

## Cabinets and news

**Настройки** on the left semicircle → **Государство / организация** lists your state
memberships and organization affiliations. The choice survives reconnects and restarts.
Joining a second state preserves the first membership and other states' invitations.
There is no automatic transfer of laws, roles or authority between cabinets.

The organization wheel contains overview, participants, delegations, roles, resolutions,
news and history. Its news action uses the existing rich editor, photo attachments,
drafts and publication modes. News is signed with the selected organization; faction
authorship is unavailable in that context. Publishing and deleting organization articles
require its news permission or administrator access.

## Data, bounds and installation

The mod ID and original state identifiers stay unchanged. Organization data uses a separate
world SavedData file, `data/civitas_organizations.dat`; context preferences are additive
fields in the existing state store. Existing 1.11.2 worlds need no manual conversion.
Back up the world before upgrading, stop the server and clients, and install the same
1.11.3 JAR on both sides (network protocol 15). Do not downgrade a world after writing
multi-state membership without restoring its pre-upgrade backup.

Lists are searchable and paged eight records at a time. Bounds per organization: 2048
direct members, 512 states, 32 roles, 1024 pending personal invitations (seven-day expiry),
512 state applications, 2048 resolutions and a rolling 2048-entry event journal. The
installation can contain up to 256 organizations. Charter and resolution text: 6000
characters; description: 1000. History is a bounded journal, not an unlimited archive.

State identifiers in this mod are the original founder's UUID. A player can join and
lead several states, but cannot be used as the founding identifier for a second state.
Select another founder when creating it, then arrange memberships/leadership normally.

`gradlew.bat build` runs `organizationsChecks`: authority, consent, captured electorates,
quorum/majorities, deadlines, representative replacement, restart, context preferences,
wire codecs and 300-person/60-state data. This is model coverage, not a claim that 300
simultaneous Minecraft clients were load-tested. `organizationsFixture` seeds only the
isolated `build/organizations-ui-server` directory. The opt-in `-PcivitasUiHarness=true`
adds a test-source-only client scenario; no harness class is included in the release JAR.
