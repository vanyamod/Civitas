package com.humanitas;

import com.humanitas.RepublicData.Polity;
import net.minecraft.nbt.*;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.*;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.PacketDistributor;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;
import java.util.*;

/** Public catalog and private, consent-based recruitment. No client-supplied permission is trusted. */
public final class CitizensNet {
    private CitizensNet() {}
    private static ResourceLocation id(String name) { return ResourceLocation.fromNamespaceAndPath(Humanitas.MODID,name); }
    public record Request(int requestId, String state, String tab, int page) implements CustomPacketPayload {
        public static final Type<Request> TYPE = new Type<>(id("citizens_request"));
        public static final StreamCodec<RegistryFriendlyByteBuf,Request> CODEC = StreamCodec.of((b,p)->{b.writeVarInt(p.requestId);b.writeUtf(p.state,36);b.writeUtf(p.tab,16);b.writeVarInt(p.page);}, b->new Request(b.readVarInt(),b.readUtf(36),b.readUtf(16),b.readVarInt()));
        public Type<Request> type(){return TYPE;}
    }
    public record Action(int requestId, String state, String op, String target, String text) implements CustomPacketPayload {
        public static final Type<Action> TYPE = new Type<>(id("citizens_action"));
        public static final StreamCodec<RegistryFriendlyByteBuf,Action> CODEC = StreamCodec.of((b,p)->{b.writeVarInt(p.requestId);b.writeUtf(p.state,36);b.writeUtf(p.op,16);b.writeUtf(p.target,36);b.writeUtf(p.text,2000);},b->new Action(b.readVarInt(),b.readUtf(36),b.readUtf(16),b.readUtf(36),b.readUtf(2000)));
        public Type<Action> type(){return TYPE;}
    }
    public record Snapshot(CompoundTag data) implements CustomPacketPayload {
        public static final Type<Snapshot> TYPE = new Type<>(id("citizens_snapshot"));
        public static final StreamCodec<RegistryFriendlyByteBuf,Snapshot> CODEC = StreamCodec.composite(ByteBufCodecs.COMPOUND_TAG,Snapshot::data,Snapshot::new);
        public Type<Snapshot> type(){return TYPE;}
    }
    private static final Map<UUID,Long> REQUESTS=new HashMap<>(), ACTIONS=new HashMap<>();
    private static boolean limited(Map<UUID,Long> times, UUID id, long interval) {
        long now=System.nanoTime(); Long old=times.get(id); if(old!=null&&now-old<interval)return true;
        if(times.size()>4096)times.clear(); times.put(id,now);return false;
    }
    public static void register(PayloadRegistrar r) {
        r.playToServer(Request.TYPE,Request.CODEC,(p,c)->c.enqueueWork(()->{if(c.player() instanceof ServerPlayer player && !limited(REQUESTS,player.getUUID(),150_000_000L))send(player,p,"");}));
        r.playToServer(Action.TYPE,Action.CODEC,(p,c)->c.enqueueWork(()->{
            if(!(c.player() instanceof ServerPlayer player))return;
            if(limited(ACTIONS,player.getUUID(),300_000_000L))send(player,new Request(p.requestId,p.state,resultTab(p.op),0),"Подождите немного перед следующим действием");
            else act(player,p);
        }));
        r.playToClient(Snapshot.TYPE,Snapshot.CODEC,(p,c)->c.enqueueWork(()->com.humanitas.client.StatesScreen.receive(p.data)));
    }
    static Polity find(RepublicData data, String id) { return data.polities().stream().filter(p->p.owner.toString().equals(id)).findFirst().orElse(null); }
    static boolean manager(ServerPlayer viewer, Polity p) { return CitizensData.permitted(p,viewer.getUUID(),viewer.hasPermissions(2),Perms.MEMBER_INVITE); }
    public static void invite(ServerPlayer sender, Polity p, UUID target) {
        if(!manager(sender,p)||target==null)return;
        ServerPlayer player=sender.getServer().getPlayerList().getPlayer(target); if(player==null)return;
        CitizensData citizens=CitizensData.get(sender.getServer()); citizens.prune(RepublicData.get(sender.getServer()),System.currentTimeMillis());
        try { citizens.invite(RepublicData.get(sender.getServer()),p,target,player.getGameProfile().getName(),System.currentTimeMillis());
            CabinetNet.refresh(player); CabinetNet.refresh(sender);
            sender.displayClientMessage(net.minecraft.network.chat.Component.literal("Приглашение отправлено. Игрок примет его в разделе «Государства»."),true);
            player.displayClientMessage(net.minecraft.network.chat.Component.literal("Государство «"+p.name+"» приглашает вас. Откройте Civitas → Государства → Приглашения."),true);
        } catch(IllegalArgumentException e) { sender.displayClientMessage(net.minecraft.network.chat.Component.literal(e.getMessage()),true); }
    }
    private static String resultTab(String op){return Set.of("join","decline").contains(op)?"inbox":Set.of("accept","reject","cancelInvite").contains(op)?"review":"overview";}
    private static void require(boolean ok,String message){if(!ok)throw new IllegalArgumentException(message);}
    private static void act(ServerPlayer player, Action a) {
        var server=player.getServer(); if(server==null)return;
        var data=RepublicData.get(server); var citizens=CitizensData.get(server); long now=System.currentTimeMillis(); citizens.prune(data,now);
        Polity p=find(data,a.state); String message; String tab=resultTab(a.op);
        try {
            require(p!=null,"Государство больше не существует"); UUID me=player.getUUID(); var s=citizens.state(p.owner);
            String text=DiplomacyData.clean(a.text,2000);
            switch(a.op) {
                case "apply" -> { citizens.apply(data,p,me,player.getGameProfile().getName(),text,now); message="Заявка отправлена. Дождитесь решения государства"; }
                case "withdraw" -> { require(s.applications.remove(me)!=null,"Заявка уже рассмотрена"); citizens.setDirty();message="Заявка отозвана"; }
                case "join" -> { citizens.join(data,p,me,true,now);message="Вы вступили в государство «"+p.name+"»";tab="inbox"; }
                case "decline" -> { require(s.invites.remove(me)!=null,"Приглашение уже недействительно");citizens.setDirty();message="Приглашение отклонено";tab="inbox"; }
                case "accept", "reject", "cancelInvite" -> {
                    require(manager(player,p),"Нужно право принимать членов государства"); UUID who=UUID.fromString(a.target);
                    if(a.op.equals("accept"))citizens.join(data,p,who,false,now);
                    else require((a.op.equals("reject")?s.applications:s.invites).remove(who)!=null,"Запись уже обработана");
                    citizens.setDirty(); message="Решение сохранено";tab="review";
                    ServerPlayer target=server.getPlayerList().getPlayer(who);if(target!=null){CabinetNet.sendState(target);CabinetNet.refresh(target);}
                }
                case "recruit" -> { require(manager(player,p),"Нужно право принимать членов государства"); require(Set.of("open","closed").contains(a.target),"Выберите режим набора");
                    require(text.length()<=1000,"Условия набора: максимум 1000 символов"); s.open=a.target.equals("open");s.instructions=text;citizens.setDirty();message="Настройки набора сохранены"; }
                default -> throw new IllegalArgumentException("Неизвестное действие");
            }
            for(ServerPlayer other:server.getPlayerList().getPlayers()) { CabinetNet.refresh(other);if(CitizensData.member(p,other.getUUID()))CabinetNet.sendState(other); }
        }catch(IllegalArgumentException e){message=e.getMessage()==null?"Проверьте выбранную запись":e.getMessage();}
        send(player,new Request(a.requestId,a.state,tab,0),message);
    }
    private static CompoundTag row(String id,String title,String subtitle,String text,String kind,long time) {
        CompoundTag t=new CompoundTag();t.putString("id",id);t.putString("title",title);t.putString("subtitle",subtitle);t.putString("text",text);t.putString("kind",kind);t.putLong("time",time);return t;
    }
    /** Whitelist projection: never serialize a Polity, petition collection, archive, draft, or curator notes here. */
    static CompoundTag publicState(Polity p,CitizensData.State s) {
        CompoundTag t=new CompoundTag(); t.putString("id",p.owner.toString());t.putString("name",p.name);t.putString("type",p.type);t.putString("government",p.government);
        t.putString("leader",p.leaderName.isBlank()?p.ownerName:p.leaderName);var people=new HashSet<>(p.members);people.add(RepublicData.leaderOf(p));if(p.deputy!=null)people.add(p.deputy);t.putInt("population",people.size());t.putString("avatar",p.avatarId);
        t.putBoolean("open",s.open);t.putString("instructions",s.instructions);t.putString("constitution",p.constitution);return t;
    }
    private static void send(ServerPlayer viewer,Request request,String message) {
        var server=viewer.getServer(); if(server==null)return;var data=RepublicData.get(server);var citizens=CitizensData.get(server);long now=System.currentTimeMillis();citizens.prune(data,now);
        UUID me=viewer.getUUID(); Polity p=find(data,request.state);String tab=Set.of("overview","history","inbox","review").contains(request.tab)?request.tab:"overview";
        CompoundTag t=new CompoundTag(); t.putInt("requestId",request.requestId);t.putString("tab",tab);t.putString("state",p==null?"":p.owner.toString());t.putString("message",message);
        t.putBoolean("hasState",CitizensData.member(p,me)); List<CompoundTag> rows=new ArrayList<>();
        if(p!=null){var s=citizens.state(p.owner);t.put("detail",publicState(p,s));t.putBoolean("manager",manager(viewer,p));t.putBoolean("invited",s.invites.containsKey(me));t.putBoolean("applied",s.applications.containsKey(me));}
        if(tab.equals("inbox")) {
            for(var state:data.polities()) {var inv=citizens.state(state.owner).invites.get(me);if(inv!=null)rows.add(row(state.owner.toString(),state.name,"Приглашение в государство","Приглашение действует 7 дней. Вступление произойдёт только после вашего согласия.","invite",inv.time()));}
        }else if(tab.equals("review")) {
            if(p==null||!manager(viewer,p))t.putString("message","Этот раздел доступен тем, кто принимает членов государства");
            else {var s=citizens.state(p.owner);for(var petition:s.applications.values())rows.add(row(petition.player().toString(),petition.name(),"Заявка на вступление",petition.text(),"application",petition.time()));
                for(var inv:s.invites.values())rows.add(row(inv.player().toString(),inv.name(),"Ожидает согласия игрока","Вы отправили приглашение. Добавить игрока без его согласия нельзя.","sentInvite",inv.time()));}
        }else if(tab.equals("history")&&p!=null) {
            for(var e:citizens.state(p.owner).history)rows.add(row("event:"+e.time()+":"+rows.size(),e.title(),"История государства",e.detail(),"event",e.time()));
            for(var c:DiplomacyData.get(server).cases())if(c.involves(p.owner)&&isPublic(c)) {
                // Only public facts. Terms, private proposals and staff notes deliberately stay in Diplomacy.
                rows.add(row("diplomacy:"+c.id,c.kind.label+" · "+c.title,c.fromName+" ↔ "+c.toName,c.status.label+"\nСоздано: "+java.time.Instant.ofEpochMilli(c.created)+"\nОбновлено: "+java.time.Instant.ofEpochMilli(c.updated),"event",c.updated));
            }
            for(var bill:data.bills())if(p.owner.equals(bill.state)&&bill.closed)rows.add(row("law:"+bill.id,"Закон #"+bill.number+" · "+bill.title,"Голосование завершено",bill.summary+"\nЗа: "+bill.yes.size()+" · Против: "+bill.no.size()+"\nПредложен: "+gameDate(bill.proposedDay),"law",bill.createdAt));
        }else if(p==null) {
            var sorted=new ArrayList<>(data.polities());sorted.sort(Comparator.comparing(state->state.name,String.CASE_INSENSITIVE_ORDER));
            for(var state:sorted){var s=citizens.state(state.owner);rows.add(row(state.owner.toString(),state.name,(s.open?"Набор открыт":"Набор закрыт")+" · "+state.government+" · "+state.members.size()+" чел.","","state",0));}
        }
        if(!tab.equals("overview")||p!=null)rows.sort(Comparator.comparingLong((CompoundTag r)->r.getLong("time")).reversed());
        int pages=Math.max(1,(rows.size()+5)/6), page=Math.max(0,Math.min(pages-1,request.page));ListTag list=new ListTag();
        for(int i=page*6;i<Math.min(rows.size(),page*6+6);i++)list.add(rows.get(i));
        t.put("rows",list);t.putInt("page",page);t.putInt("pages",pages);t.putInt("count",rows.size());
        PacketDistributor.sendToPlayer(viewer,new Snapshot(t));
    }
    static boolean isPublic(DiplomacyData.Case c){return c.kind==DiplomacyData.Kind.WAR || c.status==DiplomacyData.Status.ACTIVE || c.status==DiplomacyData.Status.PAUSED || c.status==DiplomacyData.Status.ENDED;}
    private static String gameDate(long day){return day==Long.MIN_VALUE?"не записана":java.time.LocalDate.ofEpochDay(day).toString();}
}
