package com.humanitas;

import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.*;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;
import java.util.*;

/** Consent records are independent of the private government archive. Times are real UTC milliseconds. */
public final class CitizensData extends SavedData {
    public static final long INVITE_TTL = 7L * 24 * 60 * 60 * 1000;
    public record Petition(UUID player, String name, String text, long time) {}
    public record Event(long time, String title, String detail) {}
    public static final class State {
        public boolean open;
        public String instructions = "";
        public final Map<UUID, Petition> invites = new LinkedHashMap<>(), applications = new LinkedHashMap<>();
        public final List<Event> history = new ArrayList<>();
    }
    private final Map<UUID, State> states = new HashMap<>();
    public static CitizensData get(MinecraftServer server) {
        return server.overworld().getDataStorage().computeIfAbsent(new SavedData.Factory<>(CitizensData::new, CitizensData::load, null), "civitas_citizens");
    }
    public State state(UUID id) { return states.computeIfAbsent(id, key -> new State()); }
    public static boolean member(RepublicData.Polity p, UUID who) {
        return p != null && (who.equals(RepublicData.leaderOf(p)) || who.equals(p.deputy) || p.members.contains(who));
    }
    public static boolean permitted(RepublicData.Polity p, UUID who, boolean admin, long permission) {
        return p != null && (admin || member(p, who) && Perms.has(RepublicData.permsOf(p, who), permission));
    }
    public static boolean canPropose(RepublicData.Polity p, UUID who, boolean admin) { return permitted(p, who, admin, Perms.LAW_PROPOSE); }
    private static void require(boolean condition, String message) { if (!condition) throw new IllegalArgumentException(message); }
    public void invite(RepublicData data, RepublicData.Polity p, UUID target, String name, long now) {
        require(!member(p, target), "Игрок уже состоит в этом государстве");
        State s = state(p.owner);
        require(!s.invites.containsKey(target), "Приглашение уже отправлено");
        require(s.invites.size() < 128, "Слишком много приглашений; отмените старые");
        s.invites.put(target, new Petition(target, name, "", now)); setDirty();
    }
    public void apply(RepublicData data, RepublicData.Polity p, UUID who, String name, String text, long now) {
        State s = state(p.owner);
        require(!member(p, who), "Вы уже состоите в этом государстве");
        require(s.open, "Набор в государство закрыт");
        require(!s.applications.containsKey(who), "Ваша заявка уже рассматривается");
        require(states.values().stream().filter(other -> other.applications.containsKey(who)).count() < 10, "Можно ожидать решения не более чем в 10 государствах");
        require(s.applications.size() < 128, "Приём заявок временно заполнен");
        require(text.length() <= 2000, "Заявка: максимум 2000 символов");
        require(s.instructions.isBlank() || !text.isBlank(), "Ответьте на вопросы государства");
        s.applications.put(who, new Petition(who, name, text, now)); setDirty();
    }
    /** An accepted application itself is the applicant's consent, including when they are offline. */
    public void join(RepublicData data, RepublicData.Polity p, UUID who, boolean invitation, long now) {
        State s = state(p.owner);
        Petition request = (invitation ? s.invites : s.applications).get(who);
        require(request != null, "Приглашение или заявка уже недействительны");
        require(!invitation || now - request.time < INVITE_TTL, "Срок приглашения истёк");
        require(!member(p, who), "Игрок уже состоит в этом государстве");
        p.members.add(who); p.memberNames.add(request.name);
        s.invites.remove(who); s.applications.remove(who);
        event(p.owner, "Вступление в государство", request.name + " принят в состав государства", now);
        data.logFor(p.owner, request.name + " вступил в государство с согласия обеих сторон.");
        data.setDirty(); setDirty();
    }
    public void event(UUID state, String title, String detail, long now) {
        State s = state(state); s.history.add(new Event(now, title, detail));
        // A bounded in-world journal; diplomatic cases and laws remain in their own persistent stores.
        if (s.history.size() > 2048) s.history.remove(0); setDirty();
    }
    public void prune(RepublicData data, long now) {
        Set<UUID> existing = new HashSet<>(); for (var p : data.polities()) existing.add(p.owner);
        boolean changed = states.keySet().removeIf(id -> !existing.contains(id));
        for (State s : states.values()) changed |= s.invites.values().removeIf(p -> now - p.time >= INVITE_TTL);
        if (changed) setDirty();
    }
    @Override public CompoundTag save(CompoundTag root, HolderLookup.Provider registries) { return write(root); }
    CompoundTag write(CompoundTag root) {
        ListTag list = new ListTag();
        states.forEach((id,s) -> {
            CompoundTag t = new CompoundTag(); t.putUUID("id",id); t.putBoolean("open",s.open); t.putString("instructions",s.instructions);
            t.put("invites", petitions(s.invites)); t.put("applications",petitions(s.applications));
            ListTag h = new ListTag(); for (Event event : s.history) { CompoundTag e = new CompoundTag(); e.putLong("time",event.time); e.putString("title",event.title); e.putString("detail",event.detail); h.add(e); }
            t.put("history",h); list.add(t);
        }); root.put("states",list); return root;
    }
    private static ListTag petitions(Map<UUID,Petition> map) {
        ListTag list = new ListTag(); for (Petition p : map.values()) { CompoundTag t = new CompoundTag(); t.putUUID("player",p.player); t.putString("name",p.name); t.putString("text",p.text); t.putLong("time",p.time); list.add(t); } return list;
    }
    private static void readPetitions(ListTag list, Map<UUID,Petition> map) {
        for (int i=0;i<Math.min(128,list.size());i++) { CompoundTag p = list.getCompound(i); if (!p.hasUUID("player")) continue; UUID id=p.getUUID("player"); map.put(id,new Petition(id,p.getString("name"),p.getString("text"),p.getLong("time"))); }
    }
    static CitizensData load(CompoundTag root, HolderLookup.Provider registries) {
        CitizensData data = new CitizensData(); ListTag list=root.getList("states",Tag.TAG_COMPOUND);
        for (int i=0;i<list.size();i++) { CompoundTag t=list.getCompound(i); if (!t.hasUUID("id")) continue; State s=data.state(t.getUUID("id"));
            s.open=t.getBoolean("open"); s.instructions=t.getString("instructions"); readPetitions(t.getList("invites",10),s.invites); readPetitions(t.getList("applications",10),s.applications);
            ListTag h=t.getList("history",10); for(int j=Math.max(0,h.size()-2048);j<h.size();j++) { CompoundTag e=h.getCompound(j); s.history.add(new Event(e.getLong("time"),e.getString("title"),e.getString("detail"))); }
        } return data;
    }
}
