package com.humanitas;

import com.humanitas.OrganizationsData.*;
import net.minecraft.nbt.*;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.*;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.PacketDistributor;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;
import java.util.*;

/** Paged desks: a 300-person congress never travels in every cabinet refresh. */
public final class OrganizationsNet {
    private OrganizationsNet(){}
    private static ResourceLocation id(String s){return ResourceLocation.fromNamespaceAndPath(Humanitas.MODID,s);}
    public record Request(int sequence,String organization,String tab,int page,String query,String focus) implements CustomPacketPayload {
        public static final Type<Request> TYPE=new Type<>(id("organizations_request"));
        public static final StreamCodec<RegistryFriendlyByteBuf,Request> CODEC=StreamCodec.of((b,p)->{b.writeVarInt(p.sequence);b.writeUtf(p.organization,36);b.writeUtf(p.tab,20);b.writeVarInt(p.page);b.writeUtf(p.query,80);b.writeUtf(p.focus,36);},b->new Request(b.readVarInt(),b.readUtf(36),b.readUtf(20),b.readVarInt(),b.readUtf(80),b.readUtf(36)));
        public Type<Request> type(){return TYPE;}
    }
    public record Action(Request view,String op,String target,CompoundTag fields) implements CustomPacketPayload {
        public static final Type<Action> TYPE=new Type<>(id("organizations_action"));
        public static final StreamCodec<RegistryFriendlyByteBuf,Action> CODEC=StreamCodec.of((b,p)->{Request.CODEC.encode(b,p.view);b.writeUtf(p.op,20);b.writeUtf(p.target,36);ByteBufCodecs.COMPOUND_TAG.encode(b,p.fields);},b->new Action(Request.CODEC.decode(b),b.readUtf(20),b.readUtf(36),ByteBufCodecs.COMPOUND_TAG.decode(b)));
        public Type<Action> type(){return TYPE;}
    }
    public record Snapshot(CompoundTag data) implements CustomPacketPayload {
        public static final Type<Snapshot> TYPE=new Type<>(id("organizations_snapshot"));
        public static final StreamCodec<RegistryFriendlyByteBuf,Snapshot> CODEC=StreamCodec.composite(ByteBufCodecs.COMPOUND_TAG,Snapshot::data,Snapshot::new);
        public Type<Snapshot> type(){return TYPE;}
    }
    private record Watch(Request view,long seen) {}
    private static final Map<UUID,Watch> WATCHES=new HashMap<>();
    private static final Set<UUID> CHANGED=new HashSet<>();
    private static void watch(ServerPlayer player,Request request){if(WATCHES.size()>4096)WATCHES.clear();WATCHES.put(player.getUUID(),new Watch(request,System.currentTimeMillis()));}
    public static void flush(net.minecraft.server.MinecraftServer server){
        long now=System.currentTimeMillis();WATCHES.entrySet().removeIf(e->now-e.getValue().seen>12000||server.getPlayerList().getPlayer(e.getKey())==null);
        if(CHANGED.isEmpty())return;var dirty=new HashSet<>(CHANGED);CHANGED.clear();
        for(var entry:new ArrayList<>(WATCHES.entrySet())){var view=entry.getValue().view;var player=server.getPlayerList().getPlayer(entry.getKey());if(player!=null&&dirty.stream().anyMatch(id->id.toString().equals(view.organization)))send(player,view,"",false);}
    }
    private static final Map<UUID,Long> REQUESTS=new HashMap<>(),ACTIONS=new HashMap<>();
    private static boolean limited(Map<UUID,Long> map,UUID id,long gap){long now=System.nanoTime();Long old=map.get(id);if(old!=null&&now-old<gap)return true;if(map.size()>4096)map.clear();map.put(id,now);return false;}
    public static void register(PayloadRegistrar r){
        r.playToServer(Request.TYPE,Request.CODEC,(p,c)->c.enqueueWork(()->{if(c.player() instanceof ServerPlayer sp){if(limited(REQUESTS,sp.getUUID(),150_000_000L))limitedReply(sp,p.sequence,true);else {watch(sp,p);send(sp,p,"",false);}}}));
        r.playToServer(Action.TYPE,Action.CODEC,(p,c)->c.enqueueWork(()->{if(c.player() instanceof ServerPlayer sp){if(limited(ACTIONS,sp.getUUID(),300_000_000L))limitedReply(sp,p.view.sequence,false);else act(sp,p);}}));
        r.playToClient(Snapshot.TYPE,Snapshot.CODEC,(p,c)->c.enqueueWork(()->com.humanitas.client.OrganizationsScreen.receive(p.data)));
    }
    private static void limitedReply(ServerPlayer player,int sequence,boolean retry){var t=new CompoundTag();t.putInt("sequence",sequence);t.putBoolean("limited",true);t.putBoolean("retry",retry);t.putString("message","Подождите немного перед следующим действием");PacketDistributor.sendToPlayer(player,new Snapshot(t));}
    static Actor actor(ServerPlayer p){return new Actor(p.getUUID(),p.getGameProfile().getName(),p.hasPermissions(2));}
    private static UUID uuid(String value){try{return UUID.fromString(value);}catch(IllegalArgumentException e){throw new IllegalArgumentException("Выберите запись из списка");}}
    private static Organization find(OrganizationsData store,String id){try{return store.organizations.get(UUID.fromString(id));}catch(IllegalArgumentException e){return null;}}
    private static void act(ServerPlayer player,Action command){
        var server=player.getServer();if(server==null)return;var republic=RepublicData.get(server);var store=OrganizationsData.get(server);Actor a=actor(player);var view=command.view;var f=command.fields;
        Organization o=find(store,view.organization);String message;boolean switched=false,actionOk=true;long now=System.currentTimeMillis();
        try{
            if(command.op.equals("context")){CabinetNet.chooseContext(player,f.getString("kind"),uuid(command.target));send(player,view,"Кабинет переключён",true,true);return;}
            if(command.op.equals("create")){o=store.create(a,f.getString("name"),now);view=new Request(view.sequence,o.id.toString(),"overview",0,"","");message="Организация создана. Передайте председательство нужному участнику";}
            else{
                OrganizationsData.require(o!=null,"Организация больше не существует");store.maintain(o,republic,now);
                switch(command.op){
                    case "profile" -> {store.profile(o,republic,a,f.getString("name"),f.getString("description"),f.getString("charter"),now);message="Профиль и устав сохранены";}
                    case "invite" -> {var target=server.getPlayerList().getPlayer(uuid(command.target));OrganizationsData.require(target!=null,"Игрок вышел с сервера; обновите список");store.invite(o,republic,a,target.getUUID(),target.getGameProfile().getName(),now);target.displayClientMessage(net.minecraft.network.chat.Component.literal("«"+o.name+"» приглашает вас. Civitas → Организации → Приглашения"),false);message="Приглашение отправлено";}
                    case "join" -> {store.join(o,a,now);message="Вы вступили в организацию";}
                    case "decline" -> {OrganizationsData.require(o.invites.remove(a.id())!=null,"Приглашение уже обработано");store.setDirty();message="Приглашение отклонено";}
                    case "revoke" -> {OrganizationsData.allowed(o,republic,a,OrganizationsData.MEMBERS);OrganizationsData.require(o.invites.remove(uuid(command.target))!=null,"Приглашение уже обработано");store.setDirty();message="Приглашение отозвано";}
                    case "remove" -> {store.remove(o,republic,a,uuid(command.target),now);message="Состав обновлён";}
                    case "role" -> {store.role(o,republic,a,command.target,f.getString("name"),f.getInt("rights"),now);message="Роль сохранена";}
                    case "deleteRole" -> {OrganizationsData.allowed(o,republic,a,OrganizationsData.ROLES);var role=o.roles.get(command.target);OrganizationsData.require(role!=null&&!command.target.equals("member"),"Базовую роль удалить нельзя");OrganizationsData.require(OrganizationsData.head(o,a)||(role.rights()&~OrganizationsData.rights(o,republic,a))==0,"Нельзя удалить эту роль");OrganizationsData.require(o.members.values().stream().noneMatch(p->p.role().equals(command.target)),"Сначала переназначьте участников этой роли");o.roles.remove(command.target);store.event(o,"Удалена роль",role.name(),now);message="Роль удалена";}
                    case "assign" -> {store.assign(o,republic,a,uuid(command.target),f.getString("role"),now);message="Назначена роль: "+o.roles.get(f.getString("role")).name();}
                    case "chair", "deputy" -> {store.appoint(o,a,uuid(command.target),command.op.equals("deputy"),now);message="Руководство обновлено";}
                    case "clearDeputy" -> {OrganizationsData.require(OrganizationsData.head(o,a),"Нужно право председателя");o.deputy=null;o.deputyName="";store.event(o,"Освобождён заместитель",a.name(),now);message="Заместитель освобождён";}
                    case "stateApply" -> {store.applyState(o,republic,a,uuid(command.target),now);message="Заявка государства отправлена";}
                    case "stateAccept", "stateReject" -> {store.acceptState(o,republic,a,uuid(command.target),command.op.equals("stateAccept"),now);message="Решение по государству сохранено";}
                    case "stateWithdraw" -> {var p=CitizensNet.find(republic,command.target);OrganizationsData.require(OrganizationsData.represents(p,a),"Нужно право дипломатии государства");OrganizationsData.require(o.applications.remove(uuid(command.target))!=null,"Заявка уже обработана");store.setDirty();message="Заявка отозвана";}
                    case "delegate" -> {store.delegate(o,republic,a,uuid(command.target),uuid(f.getString("person")),now);message="Представитель назначен";}
                    case "stateRemove" -> {store.removeState(o,republic,a,uuid(command.target),now);message="Делегация отозвана";}
                    case "draft" -> {var r=store.draft(o,republic,a,f.getString("title"),f.getString("body"),f.getBoolean("states"),f.getInt("quorum"),f.getBoolean("twoThirds"),now);view=new Request(view.sequence,o.id.toString(),"agenda",0,"",r.id.toString());message="Проект внесён в повестку";}
                    case "open" -> {store.open(o,republic,a,OrganizationsData.resolution(o,command.target),f.getInt("hours"),now);message="Голосование открыто. Состав и правила зафиксированы";}
                    case "vote" -> {store.vote(o,republic,a,OrganizationsData.resolution(o,command.target),uuid(f.getString("unit")),f.getInt("choice"),now);message="Ваш голос принят";}
                    case "cancel" -> {store.cancel(o,republic,a,OrganizationsData.resolution(o,command.target),now);message="Резолюция снята с рассмотрения";}
                    case "delete" -> {OrganizationsData.require(a.admin(),"Удалить организацию может только администратор");OrganizationsData.require(o.name.equals(f.getString("confirmation")),"Введите точное название организации");store.organizations.remove(o.id);store.setDirty();view=new Request(view.sequence,"","catalog",0,"","");message="Организация удалена";}
                    default -> throw new IllegalArgumentException("Неизвестное действие");
                }
            }
            // A lightweight cabinet refresh also invalidates lost context/permissions immediately.
            for(var other:server.getPlayerList().getPlayers()) {
                boolean affected=other==player||!command.op.equals("vote")&&o!=null&&o.id.equals(republic.selectedOrganizations.get(other.getUUID()));
                if(affected){CabinetNet.sendState(other);CabinetNet.refresh(other);}
            }
        }catch(IllegalArgumentException ex){actionOk=false;message=ex.getMessage()==null?"Проверьте выбранную запись":ex.getMessage();}
        watch(player,view);
        send(player,view,message,switched,actionOk);
        if(actionOk&&o!=null)CHANGED.add(o.id);
    }
    private static CompoundTag row(String id,String kind,String title,String subtitle,String text){var r=new CompoundTag();r.putString("id",id);r.putString("kind",kind);r.putString("title",title);r.putString("subtitle",subtitle);r.putString("text",text);return r;}
    private static CompoundTag context(String kind,UUID id,String title,String subtitle,boolean active){var r=row(id.toString(),kind,title,subtitle,"");r.putBoolean("active",active);return r;}
    private static CompoundTag profile(Organization o,RepublicData data,Actor a){
        var t=new CompoundTag();t.putString("name",o.name);t.putString("description",o.description);t.putString("charter",o.charter);t.putString("chair",o.chairName);t.putString("deputy",o.deputyName);t.putInt("population",o.members.size());t.putInt("states",o.states.size());t.putInt("rights",OrganizationsData.rights(o,data,a));t.putBoolean("member",OrganizationsData.affiliated(o,data,a.id()));t.putBoolean("directMember",o.members.containsKey(a.id()));t.putBoolean("head",OrganizationsData.head(o,a));t.putBoolean("invited",o.invites.containsKey(a.id()));t.putInt("applications",OrganizationsData.has(o,data,a,OrganizationsData.STATES)?o.applications.size():0);t.putInt("activeVotes",(int)o.resolutions.stream().filter(r->r.status==Status.OPEN).count());t.putLong("created",o.created);return t;
    }
    private static CompoundTag resolution(Organization o,RepublicData data,Actor a,Resolution r){
        var t=row(r.id.toString(),"resolution","#"+r.number+" · "+r.title,r.status.label,r.body);t.putString("status",r.status.name());t.putString("author",r.authorName);t.putBoolean("states",r.states);t.putInt("quorum",r.quorum);t.putBoolean("twoThirds",r.twoThirds);t.putInt("electorate",r.electorate.size());t.putInt("required",r.required());t.putInt("yes",r.count(1));t.putInt("no",r.count(0));t.putInt("abstain",r.count(2));t.putLong("deadline",r.deadline);t.putLong("time",r.created);
        ListTag units=new ListTag();boolean pending=false;for(UUID id:OrganizationsData.units(o,data,a,r)){var u=new CompoundTag();u.putString("id",id.toString());u.putString("name",r.electorate.get(id));boolean voted=r.ballots.containsKey(id);u.putBoolean("voted",voted);u.putInt("vote",r.ballots.getOrDefault(id,-1));units.add(u);if(!voted&&r.status==Status.OPEN)pending=true;}t.put("units",units);t.putBoolean("pending",pending);t.putBoolean("session",OrganizationsData.has(o,data,a,OrganizationsData.SESSIONS));return t;
    }
    static List<CompoundTag> page(List<CompoundTag> rows,int page,int size){int p=Math.max(0,Math.min(Math.max(0,(rows.size()-1)/size),page));return rows.subList(p*size,Math.min(rows.size(),p*size+size));}
    private static void send(ServerPlayer player,Request request,String message,boolean switched){send(player,request,message,switched,false);}
    private static void send(ServerPlayer player,Request request,String message,boolean switched,boolean actionOk){
        var server=player.getServer();if(server==null)return;var data=RepublicData.get(server);var store=OrganizationsData.get(server);Actor a=actor(player);long now=System.currentTimeMillis();
        Organization o=find(store,request.organization);String tab=request.tab;var t=new CompoundTag();t.putInt("sequence",request.sequence);t.putString("organization",o==null?"":o.id.toString());t.putString("tab",tab);t.putString("focus",request.focus);t.putString("message",message);t.putBoolean("switched",switched);t.putBoolean("actionOk",actionOk);t.putBoolean("admin",a.admin());t.putString("me",a.id().toString());t.putLong("now",now);
        List<CompoundTag> rows=new ArrayList<>();
        if(tab.equals("contexts")){
            var activeOrg=CabinetNet.selectedOrganization(data,player);var state=CabinetNet.selectedState(data,player);
            for(var p:data.polities())if(CitizensData.member(p,a.id()))rows.add(context("state",p.owner,p.name,"Государство · "+p.government,activeOrg==null&&state==p));
            for(var org:store.organizations.values())if(OrganizationsData.affiliated(org,data,a.id()))rows.add(context("org",org.id,org.name,"Организация · "+org.members.size()+" участников",org==activeOrg));
        }else if(tab.equals("inbox")){
            for(var org:store.organizations.values()){store.maintain(org,data,now);var invite=org.invites.get(a.id());if(invite!=null){var r=row(org.id.toString(),"invitation",org.name,"Приглашение · действует 7 дней","Вступление произойдёт после вашего согласия.");r.putLong("time",invite.time());rows.add(r);}}
        }else if(o==null){
            for(var org:store.organizations.values()){var r=row(org.id.toString(),"organization",org.name,org.members.size()+" участников · "+org.states.size()+" государств",org.description);rows.add(r);}
        }else{
            store.maintain(o,data,now);t.put("profile",profile(o,data,a));boolean inside=OrganizationsData.affiliated(o,data,a.id())||a.admin();int rights=OrganizationsData.rights(o,data,a);
            switch(tab){
                case "overview" -> {}
                case "people" -> {if(inside)for(var e:o.members.entrySet()){var person=e.getValue();var role=o.roles.get(person.role());String duty=e.getKey().equals(o.chair)?"Председатель":e.getKey().equals(o.deputy)?"Заместитель":role==null?"Без прав":role.name();var r=row(e.getKey().toString(),"person",person.name(),(e.getKey().equals(o.chair)||e.getKey().equals(o.deputy))?duty+" · "+(role==null?"Без роли":role.name()):duty,"");r.putString("role",person.role());r.putString("roleName",role==null?"Без роли":role.name());r.putBoolean("online",server.getPlayerList().getPlayer(e.getKey())!=null);r.putBoolean("chair",e.getKey().equals(o.chair));r.putBoolean("deputy",e.getKey().equals(o.deputy));rows.add(r);}}
                case "roles", "assignRole" -> {if(inside)for(var e:o.roles.entrySet()){var r=row(e.getKey(),"role",e.getValue().name(),Integer.bitCount(e.getValue().rights())+" прав","");r.putInt("rights",e.getValue().rights());rows.add(r);}}
                case "invite" -> {if((rights&OrganizationsData.MEMBERS)!=0)for(var other:server.getPlayerList().getPlayers())if(!o.members.containsKey(other.getUUID())&&!o.invites.containsKey(other.getUUID()))rows.add(row(other.getUUID().toString(),"candidate",other.getGameProfile().getName(),"Пригласить в организацию",""));}
                case "sentInvites" -> {if((rights&OrganizationsData.MEMBERS)!=0)for(var e:o.invites.entrySet()){var r=row(e.getKey().toString(),"sentInvite",e.getValue().name(),"Ожидает согласия игрока","");r.putLong("time",e.getValue().time());rows.add(r);}}
                case "stateApply" -> {for(var p:data.polities())if(OrganizationsData.represents(p,a)&&!o.states.containsKey(p.owner)&&!o.applications.containsKey(p.owner))rows.add(row(p.owner.toString(),"applyState",p.name,"Подать заявку от государства",""));}
                case "nominate" -> {var p=CitizensNet.find(data,request.focus);if(p!=null&&o.states.containsKey(p.owner)&&OrganizationsData.represents(p,a)){Set<UUID> people=new LinkedHashSet<>(p.members);people.add(RepublicData.leaderOf(p));if(p.deputy!=null)people.add(p.deputy);for(UUID id:people)rows.add(row(id.toString(),"nominee",OrganizationsData.memberName(p,id),p.name,""));}}
                case "states" -> {
                    for(var d:o.states.values()){var p=CitizensNet.find(data,d.state().toString());var r=row(d.state().toString(),"delegation",p==null?d.stateName()+" (расформировано)":p.name,d.delegate()==null?"Представитель не назначен":d.delegateName()+(OrganizationsData.validDelegate(d,data,d.delegate())?" · мандат действителен":" · мандат недействителен"),"");r.putBoolean("represent",OrganizationsData.represents(p,a));r.putBoolean("remove",OrganizationsData.represents(p,a)||(rights&OrganizationsData.STATES)!=0);rows.add(r);}
                    if((rights&OrganizationsData.STATES)!=0)for(var e:o.applications.entrySet())rows.add(row(e.getKey().toString(),"stateApplication",e.getValue(),"Заявка на вступление",""));
                    else for(var e:o.applications.entrySet())if(OrganizationsData.represents(CitizensNet.find(data,e.getKey().toString()),a))rows.add(row(e.getKey().toString(),"ownApplication",e.getValue(),"Ваша заявка рассматривается",""));
                }
                case "agenda" -> {for(var r:o.resolutions)if(inside||r.status!=Status.DRAFT&&r.status!=Status.OPEN){var tag=resolution(o,data,a,r);if(r.id.toString().equals(request.focus))t.put("detail",tag.copy());tag.putString("text","");tag.remove("units");rows.add(tag);}rows.sort(Comparator.comparingInt((CompoundTag r)->r.getBoolean("pending")?0:r.getString("status").equals("OPEN")?1:r.getString("status").equals("DRAFT")?2:3).thenComparing(Comparator.comparingLong((CompoundTag r)->r.getLong("time")).reversed()));}
                case "history" -> {for(var e:o.history)if(inside||publicEvent(e)){var r=row(""+rows.size(),"event",e.title(),java.time.Instant.ofEpochMilli(e.time()).toString(),e.text());r.putLong("time",e.time());rows.add(r);}Collections.reverse(rows);}
                default -> {tab="overview";t.putString("tab",tab);}
            }
            if(!inside&&Set.of("people","roles","invite","sentInvites","assignRole","nominate").contains(tab))t.putString("message","Внутренний раздел доступен участникам организации");
        }
        if(!tab.equals("agenda")&&!tab.equals("history"))rows.sort(Comparator.comparing((CompoundTag r)->r.getString("title"),String.CASE_INSENSITIVE_ORDER));
        String query=request.query.strip().toLowerCase(Locale.ROOT);if(!query.isEmpty())rows.removeIf(r->!(r.getString("title")+" "+r.getString("subtitle")).toLowerCase(Locale.ROOT).contains(query));
        int size=8,pages=Math.max(1,(rows.size()+size-1)/size),current=Math.max(0,Math.min(pages-1,request.page));var list=new ListTag();page(rows,current,size).forEach(list::add);t.put("rows",list);t.putInt("page",current);t.putInt("pages",pages);t.putInt("count",rows.size());PacketDistributor.sendToPlayer(player,new Snapshot(t));
    }
    static boolean publicEvent(Event e){return e.title().startsWith("Резолюция #")||Set.of("Организация создана","Обновлены профиль и устав","Государство принято","Государство покинуло организацию","Назначен представитель","Передано председательство","Назначен заместитель","Освобождён заместитель","Опубликована новость").contains(e.title());}
}
