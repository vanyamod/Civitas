package com.humanitas;

import com.humanitas.DiplomacyData.*;
import com.humanitas.RepublicData.Polity;
import net.minecraft.nbt.*;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.*;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.PacketDistributor;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;
import java.util.*;

/** Dedicated payloads keep diplomatic updates small and out of the news editor. */
public final class DiplomacyNet {
    private DiplomacyNet() {}
    private static ResourceLocation id(String name) { return ResourceLocation.fromNamespaceAndPath(Humanitas.MODID, name); }
    public record Request(int page, int selected, String filter, boolean wars) implements CustomPacketPayload {
        public static final Type<Request> TYPE = new Type<>(id("diplomacy_request"));
        public static final StreamCodec<RegistryFriendlyByteBuf, Request> CODEC = StreamCodec.of((b,p) -> {
            b.writeVarInt(p.page); b.writeVarInt(p.selected); b.writeUtf(p.filter, 16); b.writeBoolean(p.wars);
        }, b -> new Request(b.readVarInt(), b.readVarInt(), b.readUtf(16), b.readBoolean()));
        public Type<Request> type() { return TYPE; }
    }
    public record Action(String op, int entry, String source, String target, String kind, String title, String text, int war, int hours) implements CustomPacketPayload {
        public static final Type<Action> TYPE = new Type<>(id("diplomacy_action"));
        public static final StreamCodec<RegistryFriendlyByteBuf, Action> CODEC = StreamCodec.of((b,p) -> {
            b.writeUtf(p.op, 16); b.writeVarInt(p.entry); b.writeUtf(p.source,36); b.writeUtf(p.target,36);
            b.writeUtf(p.kind,24); b.writeUtf(p.title,100); b.writeUtf(p.text,4000); b.writeVarInt(p.war); b.writeVarInt(p.hours);
        }, b -> new Action(b.readUtf(16), b.readVarInt(), b.readUtf(36), b.readUtf(36), b.readUtf(24), b.readUtf(100), b.readUtf(4000), b.readVarInt(), b.readVarInt()));
        public Type<Action> type() { return TYPE; }
    }
    public record Snapshot(CompoundTag data) implements CustomPacketPayload {
        public static final Type<Snapshot> TYPE = new Type<>(id("diplomacy_snapshot"));
        public static final StreamCodec<RegistryFriendlyByteBuf, Snapshot> CODEC = StreamCodec.composite(ByteBufCodecs.COMPOUND_TAG, Snapshot::data, Snapshot::new);
        public Type<Snapshot> type() { return TYPE; }
    }
    public record Feed(CompoundTag data) implements CustomPacketPayload {
        public static final Type<Feed> TYPE = new Type<>(id("diplomacy_feed"));
        public static final StreamCodec<RegistryFriendlyByteBuf, Feed> CODEC = StreamCodec.composite(ByteBufCodecs.COMPOUND_TAG, Feed::data, Feed::new);
        public Type<Feed> type() { return TYPE; }
    }
    public record Close() implements CustomPacketPayload {
        public static final Type<Close> TYPE = new Type<>(id("diplomacy_close"));
        public static final StreamCodec<RegistryFriendlyByteBuf, Close> CODEC = StreamCodec.unit(new Close());
        public Type<Close> type() { return TYPE; }
    }
    private static final Map<UUID, Request> VIEWERS = new HashMap<>();
    private static final Map<UUID, Long> LAST_REQUEST = new HashMap<>(), LAST_ACTION = new HashMap<>(), LAST_CREATE = new HashMap<>();
    private static final Map<UUID, CompoundTag> LAST_FEED = new HashMap<>();
    public static void register(PayloadRegistrar r) {
        r.playToServer(Request.TYPE, Request.CODEC, (p,c) -> c.enqueueWork(() -> {
            if (!(c.player() instanceof ServerPlayer player)) return;
            long now = System.nanoTime(); Long last = LAST_REQUEST.put(player.getUUID(), now);
            if (last != null && now - last < 150_000_000L) return;
            Request request = new Request(Math.max(0, p.page), Math.max(0,p.selected), p.filter, p.wars && player.hasPermissions(2));
            VIEWERS.put(player.getUUID(), request); send(player, request, "");
        }));
        r.playToServer(Action.TYPE, Action.CODEC, (p,c) -> c.enqueueWork(() -> {
            if (c.player() instanceof ServerPlayer player) apply(player,p);
        }));
        r.playToServer(Close.TYPE, Close.CODEC, (p,c) -> c.enqueueWork(() -> VIEWERS.remove(c.player().getUUID())));
        r.playToClient(Snapshot.TYPE, Snapshot.CODEC, (p,c) -> c.enqueueWork(() -> com.humanitas.client.DiplomacyScreen.receive(p.data)));
        r.playToClient(Feed.TYPE, Feed.CODEC, (p,c) -> c.enqueueWork(() -> com.humanitas.client.DiplomacyFeed.receive(p.data)));
    }
    static Actor actor(ServerPlayer player, Polity state) {
        boolean admin = player.hasPermissions(2);
        boolean manager = state != null && (admin || RepublicData.leaderOf(state).equals(player.getUUID()) || player.getUUID().equals(state.deputy)
                || Perms.has(RepublicData.permsOf(state, player.getUUID()), Perms.DIPLOMACY));
        return new Actor(player.getUUID(), player.getGameProfile().getName(), state == null ? null : state.owner, manager, admin, player.hasPermissions(4));
    }
    private static void apply(ServerPlayer player, Action action) {
        var server = player.getServer(); if (server == null) return;
        long now = System.currentTimeMillis(), mono = System.nanoTime(); String message;
        try {
            Long last = LAST_ACTION.put(player.getUUID(), mono);
            if (last != null && mono - last < 400_000_000L) throw new IllegalArgumentException("Дождитесь ответа на предыдущее действие");
            var republic = RepublicData.get(server); var state = CabinetNet.selectedState(republic, player);
            Actor actor = actor(player, state); var data = DiplomacyData.get(server);
            Map<Integer,Status> previousStatuses=new HashMap<>();for(Case c:data.cases())previousStatuses.put(c.id,c.status);
            if (!action.source.equals(state == null ? "" : state.owner.toString())) throw new IllegalArgumentException("Выбранное государство изменилось. Обновите окно");
            if (action.op.equals("create")) {
                Long lastCreate = LAST_CREATE.get(player.getUUID());
                if (lastCreate != null && mono - lastCreate < 5_000_000_000L) throw new IllegalArgumentException("Новое предложение можно отправлять раз в 5 секунд");
                UUID target = UUID.fromString(action.target); Polity other = republic.polities().stream().filter(p -> p.owner.equals(target)).findFirst().orElse(null);
                if (other == null) throw new IllegalArgumentException("Государство-получатель больше не существует");
                var entry = data.create(actor, target, state == null ? "" : state.name, other.name, Kind.valueOf(action.kind), action.title, action.text, action.war, action.hours, now);
                LAST_CREATE.put(player.getUUID(), mono);
                Request old = VIEWERS.getOrDefault(player.getUUID(), new Request(0,0,"all",false));
                VIEWERS.put(player.getUUID(), new Request(0,entry.id,"all", old.wars));
            } else data.act(actor, action.entry, action.op, action.text, now);
            CitizensData citizens=CitizensData.get(server);
            for(Case c:data.cases())if(CitizensNet.isPublic(c) && previousStatuses.get(c.id)!=c.status) {
                String facts=c.fromName+" ↔ "+c.toName+" · "+c.status.label;
                citizens.event(c.from,c.kind.label+" · "+c.title,facts,now);
                citizens.event(c.to,c.kind.label+" · "+c.title,facts,now);
            }
            message = "Сохранено. Участники получили обновление";
            for (ServerPlayer p : server.getPlayerList().getPlayers()) {
                CabinetNet.refresh(p); pushFeed(p);
                Request request = VIEWERS.get(p.getUUID()); if (request != null && p != player) send(p,request,"");
            }
        } catch (IllegalArgumentException ex) { message = ex.getMessage() == null ? "Проверьте данные предложения" : ex.getMessage(); }
        send(player, VIEWERS.getOrDefault(player.getUUID(), new Request(0,0,"all",false)), message);
    }
    static boolean visible(Case c, Actor viewer) {
        return viewer.admin() || c.involves(viewer.state()) || c.kind == Kind.WAR
                || (c.kind == Kind.ALLIANCE || c.kind == Kind.NON_AGGRESSION || c.kind == Kind.TRADE) && c.status == Status.ACTIVE;
    }
    private static void send(ServerPlayer player, Request request, String message) {
        var server = player.getServer(); if (server == null) return;
        var data = DiplomacyData.get(server); var republic = RepublicData.get(server);
        var state = CabinetNet.selectedState(republic,player); Actor viewer = actor(player,state);
        boolean wars = request.wars && viewer.admin();
        CompoundTag t = new CompoundTag(); t.putBoolean("admin",viewer.admin()); t.putBoolean("wars",wars);
        t.putBoolean("manager",viewer.manager()); t.putString("source", state == null ? "" : state.owner.toString());
        t.putString("state",state == null ? "Без государства" : state.name); t.putString("message",message);
        t.putLong("revision",data.revision());
        t.putBoolean("success", message.startsWith("Сохранено."));
        ListTag states = new ListTag();
        for (Polity p : republic.polities()) { CompoundTag s = new CompoundTag(); s.putString("id",p.owner.toString()); s.putString("name",p.name);
            s.putString("type",p.type); s.putString("government",p.government); s.putString("ideology",p.ideology); s.putString("avatar",p.avatarId);
            String relation="Нейтральные отношения";
            if(state!=null)for(Case entry:data.cases())if(entry.samePair(state.owner,p.owner)) {
                if(entry.liveWar()){relation="Военный конфликт";break;}
                if(entry.kind==Kind.ALLIANCE && entry.status==Status.ACTIVE)relation="Союзник";
                else if(entry.kind==Kind.NON_AGGRESSION && entry.status==Status.ACTIVE && !relation.equals("Союзник"))relation="Договор о ненападении";
            }
            s.putString("relation",relation);states.add(s); }
        t.put("states",states);
        var matches = data.cases().stream().filter(c -> visible(c,viewer)).filter(c -> !wars || c.kind == Kind.WAR)
            .filter(c -> switch (request.filter) {
                case "incoming" -> wars ? c.liveWar() && c.curator == null : c.to.equals(viewer.state()) && c.status == Status.PENDING;
                case "active" -> c.current();
                case "history" -> !c.current();
                case "mine" -> wars ? viewer.id().equals(c.curator) && c.liveWar() : c.involves(viewer.state());
                default -> true;
            }).sorted(Comparator.comparingLong((Case c) -> c.updated).reversed().thenComparing(Comparator.comparingInt((Case c) -> c.id).reversed())).toList();
        int pages = Math.max(1,(matches.size()+11)/12), page = Math.min(request.page,pages-1);
        t.putInt("page",page); t.putInt("pages",pages); t.putInt("count",matches.size());
        ListTag entries = new ListTag();
        for (Case c : matches.subList(page*12,Math.min(matches.size(),page*12+12))) entries.add(card(c, viewer, false));
        t.put("entries",entries);
        Case selected = data.find(request.selected);
        if (selected != null && visible(selected,viewer) && (!wars || selected.kind == Kind.WAR)) t.put("selected",card(selected,viewer,true));
        PacketDistributor.sendToPlayer(player,new Snapshot(t));
    }
    static CompoundTag card(Case c, Actor viewer, boolean full) {
        CompoundTag t = new CompoundTag(); t.putInt("id",c.id); t.putInt("war",c.relatedWar);
        t.putString("kind",c.kind.name()); t.putString("kindLabel",c.kind.label); t.putString("status",c.kind == Kind.WAR && c.status == Status.DECLARED ? c.curator == null ? "Нужен куратор" : "Подготовка к началу" : c.status.label);
        t.putString("statusId",c.status.name()); t.putString("title",c.title); t.putString("from",c.fromName); t.putString("to",c.toName);
        t.putString("fromId",c.from.toString()); t.putString("toId",c.to.toString()); t.putString("curator",c.curatorName);
        t.putLong("created",c.created); t.putLong("updated",c.updated); t.putLong("deadline",c.deadline);
        if (full) {
            t.putString("terms",c.terms); t.putString("author",c.author);
            ListTag history = new ListTag(); c.history.forEach(s -> history.add(StringTag.valueOf(s))); t.put("history",history);
            if (viewer.admin()) { ListTag notes = new ListTag(); c.notes.forEach(s -> notes.add(StringTag.valueOf(s))); t.put("notes",notes); }
            for (String action : List.of("accept","reject","withdraw","terminate","claim","release","start","pause","resume","end","note")) t.putBoolean(action,DiplomacyData.may(c,viewer,action));
        }
        return t;
    }
    public static void pushFeed(ServerPlayer player) {
        var server = player.getServer(); if (server == null) return;
        var data = DiplomacyData.get(server); var state = CabinetNet.selectedState(RepublicData.get(server),player);
        Case latestWar = null;
        long own = 0, wars = 0; int pending = 0, unattended = 0, total = 0;
        for (Case c : data.cases()) {
            if (state != null && c.involves(state.owner)) { own = Math.max(own,c.revision); if (c.status == Status.PENDING && c.to.equals(state.owner)) pending++; }
            if (player.hasPermissions(2) && c.kind == Kind.WAR) { if(c.revision > wars)latestWar=c; wars = Math.max(wars,c.revision); if(c.liveWar()) { total++; if(c.curator == null)unattended++; } }
        }
        CompoundTag t = new CompoundTag(); t.putBoolean("admin",player.hasPermissions(2)); t.putLong("own",own); t.putLong("wars",wars);
        t.putInt("pending",pending); t.putInt("unattended",unattended); t.putInt("totalWars",total);
        if(latestWar != null) { t.putString("warSides",latestWar.fromName+" → "+latestWar.toName); t.putString("warStatus",latestWar.status.label); }
        if (!t.equals(LAST_FEED.get(player.getUUID()))) { LAST_FEED.put(player.getUUID(),t.copy()); PacketDistributor.sendToPlayer(player,new Feed(t)); }
    }
    public static void tick(MinecraftServer server) {
        if(server.getTickCount()%100 != 0)return;
        Set<UUID> states = new HashSet<>(); RepublicData.get(server).polities().forEach(p -> states.add(p.owner));
        boolean changed = DiplomacyData.get(server).expireAndReconcile(states,System.currentTimeMillis());
        for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            pushFeed(player);
            if(changed && VIEWERS.containsKey(player.getUUID()))send(player,VIEWERS.get(player.getUUID()),"");
        }
    }
    public static String summary(MinecraftServer server, UUID state, boolean wars) {
        if (state == null) return "—";
        var relevant = DiplomacyData.get(server).cases().stream().filter(c -> c.involves(state))
                .filter(c -> wars ? c.liveWar() : c.kind == Kind.ALLIANCE && c.status == Status.ACTIVE).toList();
        return relevant.isEmpty() ? (wars ? "Нет активных войн" : "Нет союзов")
                : relevant.stream().map(c -> (c.from.equals(state)?c.toName:c.fromName) + (wars ? " · " + c.status.label : "")).collect(java.util.stream.Collectors.joining(", "));
    }
    public static String curated(MinecraftServer server, UUID player) {
        return DiplomacyData.get(server).cases().stream().filter(c -> c.liveWar() && player.equals(c.curator))
            .map(c -> "#"+c.id+" · "+c.fromName+" / "+c.toName).collect(java.util.stream.Collectors.joining(", "));
    }
    public static void logout(net.neoforged.neoforge.event.entity.player.PlayerEvent.PlayerLoggedOutEvent event) {
        UUID id = event.getEntity().getUUID(); VIEWERS.remove(id); LAST_FEED.remove(id); LAST_REQUEST.remove(id); LAST_ACTION.remove(id); LAST_CREATE.remove(id);
    }
    public static void stop(net.neoforged.neoforge.event.server.ServerStoppedEvent event) {
        VIEWERS.clear(); LAST_FEED.clear(); LAST_REQUEST.clear(); LAST_ACTION.clear(); LAST_CREATE.clear();
    }
}
