package com.humanitas.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.FormattedCharSequence;
import java.util.List;
import static com.humanitas.client.CivitasUi.*;

/** A readable document, independent of editor focus and text-field scrolling. */
public final class OrganizationCharterScreen extends Screen {
    private final Screen parent;private final String name,text;
    private DocumentPanel panel;private List<FormattedCharSequence> lines;private int scroll;
    public OrganizationCharterScreen(Screen parent,String name,String text){super(Component.literal("Устав организации"));this.parent=parent;this.name=name;this.text=text;}
    @Override protected void init(){panel=new DocumentPanel(width,height,620,440);lines=font.split(Component.literal(text.isBlank()?"Устав ещё не опубликован.":text),Math.max(40,panel.w-64));}
    @Override public void render(GuiGraphics g,int mx,int my,float partial){
        g.fill(0,0,width,height,BACKDROP);panel.draw(g,font,"УСТАВ ОРГАНИЗАЦИИ",name,58);
        int x=panel.x+24,y=panel.y+76,w=panel.w-48,h=Math.max(20,panel.footer()-y-19),total=lines.size()*15;
        scroll=Math.max(0,Math.min(scroll,Math.max(0,total-h)));g.enableScissor(x,y,x+w,y+h);
        for(int i=0;i<lines.size();i++){int ly=y+i*15-scroll;if(ly+10>=y&&ly<y+h)g.drawString(font,lines.get(i),x+8,ly,TEXT_LIGHT,false);}g.disableScissor();
        if(total>h){int thumb=Math.max(12,h*h/total),ty=y+(h-thumb)*scroll/(total-h);g.fill(x+w-2,y,x+w,y+h,LINE);g.fill(x+w-2,ty,x+w,ty+thumb,GOLD);}
        button(g,font,panel.x+16,panel.footer(),100,22,"НАЗАД",inside(mx,my,panel.x+16,panel.footer(),100,22),Style.SECONDARY);
        g.drawString(font,"Основной документ организации",panel.x+128,panel.footer()+7,DIM,false);
    }
    @Override public boolean mouseScrolled(double x,double y,double dx,double dy){scroll-=Math.round((float)dy*30);return true;}
    @Override public boolean mouseClicked(double x,double y,int b){if(b==0&&inside(x,y,panel.x+16,panel.footer(),100,22)){onClose();return true;}return false;}
    @Override public void onClose(){minecraft.setScreen(parent);}
    @Override public boolean isPauseScreen(){return false;}
    @Override public void renderBackground(GuiGraphics g,int x,int y,float p){}
}
