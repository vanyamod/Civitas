package com.humanitas.client;

import com.humanitas.DiplomacyData.Kind;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import static com.humanitas.client.CivitasUi.*;

/** Small, palette-derived surfaces for the diplomatic desk; no bitmap scaling or font symbols. */
final class DiplomacyVisuals {
    private DiplomacyVisuals() {}
    private static int mix(int a,int b,float t) { return CivitasColors.mix(a,b,t); }
    static void cut(GuiGraphics g,int x,int y,int w,int h,int color) { CivitasSurfaces.cut(g,x,y,w,h,color); }
    static void surface(GuiGraphics g,int x,int y,int w,int h,boolean chosen,boolean hot) { CivitasSurfaces.surface(g,x,y,w,h,chosen,hot); }
    static String fit(Font font,String text,int width) { return CivitasSurfaces.fit(font,text,width); }
    static void button(GuiGraphics g,Font font,int x,int y,int w,int h,String text,boolean hot,boolean selected,boolean enabled,boolean primary,boolean danger) {
        CivitasSurfaces.button(g,font,x,y,w,h,net.minecraft.network.chat.Component.literal(text),hot,
            !enabled?Style.DISABLED:danger?Style.DANGER:primary?Style.PRIMARY:selected?Style.CHOSEN:Style.SECONDARY);
    }
    static void pixels(GuiGraphics g,String[] rows,int x,int y,int scale,int color) {
        CivitasSurfaces.pixels(g,rows,x,y,scale,color);
    }

    static void icon(GuiGraphics g,Kind kind,int x,int y,int scale,int color) {
        String[] shape=switch(kind) {
            case ALLIANCE -> new String[]{"..XXX...XXX..",".X...X.X...X.","X....XXX....X","X...X...X...X","X....XXX....X",".X...X.X...X.","..XXX...XXX..",".............","............."};
            case NON_AGGRESSION -> new String[]{"...XXXXXXX...","...X.....X...","...X..X..X...","...X.XXX.X...","...X..X..X...","....X...X....",".....X.X.....","......X......","............."};
            case TRADE -> new String[]{"..X..........","..XXXXXXXXX..","..X.......X..","........X.X..",".X.X.........",".X.......X...",".XXXXXXXXX...",".........X...","............."};
            case CUSTOM -> new String[]{"..XXXXXXXX...","..X......XX..","..X......XX..","..X.XXXX..X..","..X.......X..","..X.XXXX..X..","..X.......X..","..XXXXXXXXX..","............."};
            case ULTIMATUM -> new String[]{"......X......",".....X.X.....","....X.X.X....","...X..X..X...","..X...X...X..",".X.........X.","X.....X.....X","XXXXXXXXXXXXX","............."};
            case WAR -> new String[]{"......X......",".....XXX.....",".....XXX.....","......X......","......X......","...XXXXXXX...",".....XXX.....","......X......",".....XXX....."};
            case CEASEFIRE -> new String[]{"...XX...XX...","...XX...XX...","...XX...XX...","...XX...XX...","...XX...XX...","...XX...XX...","...XX...XX...",".............","............."};
            case PEACE -> new String[]{".....XXX.....","....X...X....","...X..X..X...","...X..X..X...","...X.XXX.X...","....X...X....",".....XXX.....",".............","............."};
        };
        pixels(g,shape,x,y,scale,color);
    }
    static void seal(GuiGraphics g,Font font,int x,int y,int size,String name,String avatar) {
        cut(g,x,y,size,size,mix(PLATE,GOLD,0.6F));cut(g,x+1,y+1,size-2,size-2,PLATE_DEEP);
        ImageCache.Entry image=avatar.isEmpty()?null:ImageCache.get(avatar);
        if(image!=null) {
            g.blit(image.texture(),x+3,y+3,size-6,size-6,0F,0F,image.width(),image.height(),image.width(),image.height());
        } else {
            int cx=x+size/2,cy=y+size/2;
            g.fill(x+5,y+4,x+size-5,y+5,GOLD_DEEP);g.fill(x+5,y+size-5,x+size-5,y+size-4,GOLD_DEEP);
            String initial=name.isBlank()?"?":name.substring(0,name.offsetByCodePoints(0,1)).toUpperCase(java.util.Locale.ROOT);
            g.drawString(font,initial,cx-font.width(initial)/2,cy-4,GOLD,false);
        }
    }
}
