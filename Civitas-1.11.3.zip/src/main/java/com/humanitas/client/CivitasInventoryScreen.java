package com.humanitas.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.ImageButton;
import net.minecraft.client.gui.components.events.GuiEventListener;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.client.gui.screens.recipebook.RecipeBookComponent;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.InventoryMenu;
import net.minecraft.world.inventory.Slot;

import static com.humanitas.client.CivitasUi.*;

/**
 * Player inventory in the Civitas chancellery style: the same graphite plate, matte gold rim,
 * cream lettering and olive accents as the hotbar. Slots, clicks, tooltips, the recipe book and
 * the cabinet seal keep their vanilla behaviour because this is still an {@link InventoryScreen}.
 */
public class CivitasInventoryScreen extends InventoryScreen {
    private CabinetButton recipeButton;

    public CivitasInventoryScreen(Player player) {
        super(player);
    }

    @Override
    protected void init() {
        super.init();

        // The vanilla recipe-book button is the only plain ImageButton here. Swap it for a Civitas
        // medallion at the vanilla position (inside the crafting panel), not over the output slot.
        // Remove it from every list (renderables, children and narratables), otherwise the invisible
        // vanilla button keeps consuming clicks and toggles the book a second time.
        ImageButton vanillaButton = null;
        for (GuiEventListener listener : this.children()) {
            if (listener.getClass() == ImageButton.class) {
                vanillaButton = (ImageButton) listener;
                break;
            }
        }
        if (vanillaButton != null) {
            this.removeWidget(vanillaButton);
        }
        this.recipeButton = new CabinetButton(this.leftPos + 104, this.height / 2 - 22, 20, 18,
                () -> "☰", 1.2F, this::toggleRecipeBook)
                .withRecipeIcon()
                .withTip(() -> "Рецепты");
        this.addRenderableWidget(this.recipeButton);
    }

    private void toggleRecipeBook() {
        RecipeBookComponent book = getRecipeBookComponent();
        book.toggleVisibility();
        // Rebuilding the widgets re-runs init(), so every widget that positions itself from leftPos
        // (including ClientSort's sort button) follows the inventory when the book opens or closes.
        this.rebuildWidgets();
    }

    @Override
    protected void renderBg(GuiGraphics g, float partialTick, int mouseX, int mouseY) {
        int x = this.leftPos;
        int y = this.topPos;

        drawFrame(g, x, y);
        drawSlots(g, x, y);
        drawDivider(g, x, y);
        drawCraftingArrow(g, x, y);
        drawPortrait(g, x, y, mouseX, mouseY);
    }

    /** Diplomatic-style panel with a thin inlaid edge. */
    private void drawFrame(GuiGraphics g, int x, int y) {
        int w = this.imageWidth;
        int h = this.imageHeight;

        CivitasSurfaces.panel(g,x,y,w,h);
    }

    private void drawSlots(GuiGraphics g, int x, int y) {
        for (Slot slot : this.menu.slots) {
            if (!slot.isActive()) continue;
            CivitasEquipmentStyle.cell(g,x+slot.x-1,y+slot.y-1,18,
                    slot.index==InventoryMenu.RESULT_SLOT,false);
        }
    }

    /** A compact section rule in the gap before the hotbar row. */
    private void drawDivider(GuiGraphics g, int x, int y) {
        CivitasEquipmentStyle.divider(g,x+8,y+139,this.imageWidth-16);
    }

    /** The vanilla texture supplied this arrow; now it is a small olive-and-gold rule. */
    private void drawCraftingArrow(GuiGraphics g, int x, int y) {
        CivitasEquipmentStyle.craftingArrow(g,x+136,y+32);
    }

    private void drawPortrait(GuiGraphics g, int x, int y, int mouseX, int mouseY) {
        int px=x+26, py=y+8, pw=49, ph=70;
        CivitasEquipmentStyle.portrait(g,px,py,pw,ph);
        if(this.minecraft!=null && this.minecraft.player!=null) {
            InventoryScreen.renderEntityInInventoryFollowsMouse(g,px,py,px+pw,py+ph,
                    30,0.0625F,mouseX,mouseY,this.minecraft.player);
        }
    }

    @Override
    protected void renderLabels(GuiGraphics g, int mouseX, int mouseY) {
        // The plate is intentionally title-less: the seal and the portrait already identify it.
    }

    @Override
    protected void renderSlotHighlight(GuiGraphics g, Slot slot, int mouseX, int mouseY, float partialTick) {
        if (slot.isHighlightable()) {
            renderSlotHighlight(g, slot.x, slot.y, 0, HOVER);
        }
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        super.render(g, mouseX, mouseY, partialTick);
        if (getRecipeBookComponent().isVisible()) {
            styleRecipeBook(g);
        }
    }

    /**
     * Frames the vanilla recipe book instead of painting over it. The old full-body tint hid the
     * recipe cards and made JEI's book look broken; a frame keeps every page readable.
     */
    private void styleRecipeBook(GuiGraphics g) {
        RecipeBookComponent book = getRecipeBookComponent();
        if (!book.isVisible()) return;

        // The book always sits at the centre of the screen; only its horizontal offset changes
        // when the screen is wide enough to keep the inventory visible next to it.
        boolean narrow = this.width < 379;
        int bx = (this.width - RecipeBookComponent.IMAGE_WIDTH) / 2 - (narrow ? 0 : 86);
        int by = (this.height - RecipeBookComponent.IMAGE_HEIGHT) / 2;
        int fx = bx - (narrow ? 2 : 31);
        int fy = by - 2;
        int fw = RecipeBookComponent.IMAGE_WIDTH + (narrow ? 4 : 33);
        int fh = RecipeBookComponent.IMAGE_HEIGHT + 4;

        CivitasUi.frame(g, fx, fy, fw, fh);

    }
}
