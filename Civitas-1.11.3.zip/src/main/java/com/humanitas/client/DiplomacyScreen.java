package com.humanitas.client;

import com.humanitas.DiplomacyData.Kind;
import com.humanitas.DiplomacyNet;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.nbt.*;
import net.minecraft.network.chat.Component;
import net.neoforged.neoforge.network.PacketDistributor;
import java.util.*;
import static com.humanitas.client.CivitasUi.*;

/** Palette-aware diplomatic desk, with separate list, document and composition views. */
public final class DiplomacyScreen extends Screen {
    private record Control(int x,int y,int w,int h,String label,Runnable action,boolean enabled,boolean danger,boolean paint) {}
    private final Screen parent;
    private final boolean wars;
    private CompoundTag data = new CompoundTag();
    private final List<Control> controls = new ArrayList<>();
    private DocumentPanel panel;
    private int page, selected, scroll, relatedWar;
    private String filter="all", mode="list", target="", targetName="", source="", promptAction="", feedback="";
    private Kind kind=Kind.ALLIANCE;
    private int hours=24;
    private boolean sending, confirmWar;
    private long sentAt, nextRefresh;
    private final TextInput search=new TextInput(false,80,"Поиск государства…");
    private final TextInput replyHours=new TextInput(false,2,"24");
    private int mouseX,mouseY;
    private final TextInput title=new TextInput(false,100,"Название документа");
    private final TextInput text=new TextInput(true,4000,"Условия, обязательства и сроки");
    private final TextInput document=new TextInput(true,220000,"");
    private String documentValue="";
    public DiplomacyScreen(Screen parent, boolean wars) { super(Component.literal(wars?"Военные дела":"Дипломатия")); this.parent=parent; this.wars=wars; replyHours.setValue("24"); }
    @Override protected void init() { panel=new DocumentPanel(width,height); request(); }
    private void request() { PacketDistributor.sendToServer(new DiplomacyNet.Request(page,selected,filter,wars)); nextRefresh=net.minecraft.Util.getMillis()+5000; }
    public static void receive(CompoundTag snapshot) {
        if(!(Minecraft.getInstance().screen instanceof DiplomacyScreen screen))return;
        screen.data=snapshot;
        if(!screen.mode.equals("compose") && !screen.mode.equals("prompt"))screen.source=snapshot.getString("source");
        screen.page=snapshot.getInt("page");
        if(!snapshot.getString("message").isEmpty()) {
            screen.feedback=snapshot.getString("message");
            if(screen.sending && snapshot.getBoolean("success")) {
                screen.mode="detail"; screen.selected=snapshot.getCompound("selected").getInt("id");
                screen.text.setValue(""); screen.title.setValue(""); screen.confirmWar=false;
            }
            screen.sending=false;
        }
        DiplomacyFeed.mark(screen.wars);
    }
    @Override public void tick() {
        if(sending && net.minecraft.Util.getMillis()-sentAt>15000) { sending=false; feedback="Ответ задерживается. Обновите список перед повтором"; }
        if(!sending && net.minecraft.Util.getMillis()>=nextRefresh)request();
    }
    private void send(String op,String note) {
        if(sending)return;
        sending=true; sentAt=net.minecraft.Util.getMillis(); feedback="Ожидание подтверждения сервера…";
        PacketDistributor.sendToServer(new DiplomacyNet.Action(op,selected,source,"","","",note,0,24));
    }
    private void add(int x,int y,int w,String label,Runnable run,boolean enabled,boolean danger) { controls.add(new Control(x,y,w,20,label,run,enabled&&!sending,danger,true)); }
    private void add(int x,int y,int w,String label,Runnable run) { add(x,y,w,label,run,true,false); }
    private void hotspot(int x,int y,int w,int h,String label,Runnable run) {
        controls.add(new Control(x,y,w,h,label,run,!sending,false,false));
        CivitasSounds.register(x,y,w,h,sending?Style.DISABLED:Style.SECONDARY);
    }
    private void line(GuiGraphics g,String value,int x,int y,int w,int color) { g.drawString(font,font.plainSubstrByWidth(value,Math.max(1,w)),x,y,color,false); }
    private static String time(long value) { return value<=0?"—":java.time.format.DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm 'UTC'").withZone(java.time.ZoneOffset.UTC).format(java.time.Instant.ofEpochMilli(value)); }
    @Override public void render(GuiGraphics g,int mx,int my,float partial) {
        controls.clear(); mouseX=mx;mouseY=my;
        if(mode.equals("templates"))panel=new DocumentPanel(width,height,548,322);
        else if(mode.equals("targets")) {
            int columns=Math.min(548,width-24)-32>=400?2:1;
            int count=Math.max(1,data.getList("states",Tag.TAG_COMPOUND).size()-1);
            panel=new DocumentPanel(width,height,548,Math.min(360,144+((count+columns-1)/columns)*64));
        } else panel=new DocumentPanel(width,height);
        g.fill(0,0,width,height,BACKDROP);
        String heading=mode.equals("targets")?"ВЫБОР ГОСУДАРСТВА":mode.equals("templates")?"ТИП ДОКУМЕНТА":wars?"ВОЙНЫ · КУРАТОРСТВО":"ДИПЛОМАТИЯ";
        panel.draw(g,font,heading,!feedback.isEmpty()?feedback:data.isEmpty()?"Получение данных…":data.getString("state"),54);
        if(wars && !data.isEmpty() && !data.getBoolean("admin")) {
            line(g,"Доступно только администраторам",panel.x+16,panel.y+70,panel.w-32,DIM);
        } else switch(mode) {
            case "compose" -> compose(g);
            case "targets" -> targets(g);
            case "templates" -> templates(g);
            case "detail" -> detail(g,mx,my);
            case "prompt" -> prompt(g,mx,my);
            default -> listing(g);
        }
        add(panel.x+14,panel.footer(),86,mode.equals("list")?"ЗАКРЫТЬ":"НАЗАД",this::back);

        for(Control c:controls) {
            if(!c.paint)continue;
            String label=c.label.startsWith("• ")?c.label.substring(2):c.label;
            boolean primary=label.equals("ОТПРАВИТЬ")||label.startsWith("ПОДТВЕРДИТЬ")||label.equals("НОВОЕ ПРЕДЛОЖЕНИЕ");
            DiplomacyVisuals.button(g,font,c.x,c.y,c.w,c.h,label,inside(mx,my,c.x,c.y,c.w,c.h),c.label.startsWith("• "),c.enabled,primary,c.danger);
        }
        if(mode.equals("compose")) { title.render(g,mx,my); text.render(g,mx,my); }
        if(mode.equals("targets"))search.render(g,mx,my);
        if(mode.equals("templates") && kind!=Kind.WAR)replyHours.render(g,mx,my);
        for(Control c:controls)if(c.paint && inside(mx,my,c.x,c.y,c.w,c.h) && font.width(c.label)>c.w-12) {
            g.renderTooltip(font,Component.literal(c.label.replace("• ","")),mx,my);break;
        }
    }

    private void listing(GuiGraphics g) {
        int x=panel.x+14,y=panel.y+62,w=panel.w-28;
        String[] ids={"all","incoming","active","mine","history"};
        String[] labels={"Все",wars?"Свободные":"Входящие","Действуют","Мои","История"};
        int tab=Math.max(36,(w-16)/5);
        for(int i=0;i<ids.length;i++){final String id=ids[i];add(x+i*(tab+4),y,tab,(filter.equals(id)?"• ":"")+labels[i],()->{filter=id;page=scroll=selected=0;request();});}
        y+=27;
        if(!wars) {
            add(x,y,Math.min(150,w),"НОВОЕ ПРЕДЛОЖЕНИЕ",()->begin(Kind.ALLIANCE,null),data.getBoolean("manager"),false);
            line(g,data.getBoolean("manager")?"Договоры подписывают обе стороны":"Чтение · для действий нужно право дипломатии",x+158,y+6,w-158,DIM);
            y+=27;
        } else { line(g,"Возьмите дело → согласуйте правила → подтвердите начало",x,y+5,w,DIM); y+=23; }
        ListTag items=data.getList("entries",Tag.TAG_COMPOUND);
        int visible=Math.max(1,(panel.footer()-y-37)/42); scroll=Math.max(0,Math.min(scroll,Math.max(0,items.size()-visible)));
        for(int i=scroll;i<Math.min(items.size(),scroll+visible);i++) {
            CompoundTag c=items.getCompound(i); int ry=y+(i-scroll)*42;
            g.fill(x,ry,x+w,ry+38,PLATE); g.fill(x,ry,x+3,ry+38,c.getString("kind").equals("WAR")?GOLD:OLIVE);
            line(g,"#"+c.getInt("id")+" · "+c.getString("title"),x+10,ry+5,w-105,TEXT_LIGHT);
            line(g,c.getString("from")+" → "+c.getString("to"),x+10,ry+16,w-105,DIM);
            line(g,c.getString("status")+(c.getString("curator").isBlank()?"":" · "+c.getString("curator")),x+10,ry+27,w-105,GOLD);
            add(x+w-86,ry+9,78,"ИНФО",()->{selected=c.getInt("id");mode="detail";source=data.getString("source");request();});
        }
        if(items.isEmpty())line(g,"В этом разделе пока нет записей",x+10,y+14,w-20,DIM);
        int by=panel.footer()-24;
        add(x,by,54,"←",()->{page--;scroll=0;request();},page>0,false);
        line(g,(page+1)+" / "+Math.max(1,data.getInt("pages"))+" · записей "+data.getInt("count"),x+66,by+6,w-130,DIM);
        add(x+w-54,by,54,"→",()->{page++;scroll=0;request();},page+1<data.getInt("pages"),false);
    }
    private CompoundTag current() { return data.getCompound("selected"); }
    private void detail(GuiGraphics g,int mx,int my) {
        CompoundTag c=current(); int x=panel.x+16,y=panel.y+62,w=panel.w-32;
        if(c.isEmpty() || c.getInt("id")!=selected){line(g,"Загрузка документа…",x,y,w,DIM);return;}
        line(g,"#"+selected+" · "+c.getString("kindLabel")+" · "+c.getString("status"),x,y,w,GOLD);
        List<String[]> actions=new ArrayList<>();
        String[][] names={{"accept","ПРИНЯТЬ"},{"reject","ОТКЛОНИТЬ"},{"withdraw","ОТОЗВАТЬ"},{"terminate","РАСТОРГНУТЬ"},{"claim","КУРИРОВАТЬ"},{"release","СНЯТЬ КУРАТОРА"},{"start","НАЧАТЬ"},{"pause","ПРИОСТАНОВИТЬ"},{"resume","ВОЗОБНОВИТЬ"},{"end","ЗАВЕРШИТЬ"},{"note","ЗАМЕТКА АДМИНА"}};
        for(String[] a:names)if(c.getBoolean(a[0]))actions.add(a);
        boolean participant=data.getBoolean("manager") && (data.getString("source").equals(c.getString("fromId"))||data.getString("source").equals(c.getString("toId")));
        if(c.getString("kind").equals("WAR") && participant && Set.of("DECLARED","ACTIVE","PAUSED").contains(c.getString("statusId"))) {
            actions.add(new String[]{"peace","ПРЕДЛОЖИТЬ МИР"});
            if(c.getString("statusId").equals("ACTIVE"))actions.add(new String[]{"ceasefire","ПЕРЕМИРИЕ"});
        }
        int columns=w>=330?3:2, bw=(w-(columns-1)*5)/columns, rows=(actions.size()+columns-1)/columns;
        int actionY=panel.footer()-9-rows*22;
        StringBuilder body=new StringBuilder(c.getString("title")).append("\n\n").append(c.getString("from")).append(" → ").append(c.getString("to"))
            .append("\nАвтор: ").append(c.getString("author")).append("\nСоздано: ").append(time(c.getLong("created")));
        if(c.getLong("deadline")>0)body.append("\nОтвет до: ").append(time(c.getLong("deadline"))).append(" (реальное время)");
        if(c.getString("kind").equals("WAR"))body.append("\nКуратор: ").append(c.getString("curator").isBlank()?"не назначен":c.getString("curator"))
            .append("\nСтатус дела не меняет PvP и защиту территории.");
        body.append("\n\nУСЛОВИЯ / ПРИЧИНА\n").append(c.getString("terms")).append("\n\nХРОНОЛОГИЯ\n");
        ListTag history=c.getList("history",Tag.TAG_STRING); for(int i=0;i<history.size();i++)body.append(history.getString(i)).append("\n\n");
        if(data.getBoolean("admin")) { ListTag notes=c.getList("notes",Tag.TAG_STRING); if(!notes.isEmpty())body.append("\nВНУТРЕННИЕ ЗАМЕТКИ · ТОЛЬКО АДМИНИСТРАТОРАМ\n"); for(int i=0;i<notes.size();i++)body.append(notes.getString(i)).append("\n\n"); }
        String value=body.toString(); if(!value.equals(documentValue)){documentValue=value;document.setValue(value);document.scrollToStart();}
        document.setBounds(x,y+18,w,Math.max(22,actionY-y-24));document.render(g,mx,my);
        for(int i=0;i<actions.size();i++) {
            String[] a=actions.get(i); add(x+(i%columns)*(bw+5),actionY+(i/columns)*22,bw,a[1],()->{
                source=data.getString("source");
                if(a[0].equals("peace")||a[0].equals("ceasefire"))begin(a[0].equals("peace")?Kind.PEACE:Kind.CEASEFIRE,c);
                else if(a[0].equals("claim")||a[0].equals("release"))send(a[0],"");
                else { promptAction=a[0];mode="prompt";text.setValue("");text.focused=true; }
            },true,Set.of("reject","withdraw","terminate","end").contains(a[0]));
        }
    }
    private void begin(Kind newKind,CompoundTag war) {
        source=data.getString("source"); kind=newKind; relatedWar=war==null?0:war.getInt("id");
        target=war==null?"":source.equals(war.getString("fromId"))?war.getString("toId"):war.getString("fromId");
        targetName=war==null?"Выберите государство":source.equals(war.getString("fromId"))?war.getString("to"):war.getString("from");
        title.setValue(newKind.label); text.setValue(template(newKind)); confirmWar=false; mode="compose";
    }
    private static String template(Kind kind) {
        return switch(kind) {
            case ALLIANCE -> "Стороны заключают союз и обязуются согласовывать взаимную помощь.\nОбязательства сторон:\nСрок действия и выход из союза:";
            case NON_AGGRESSION -> "Стороны обязуются не нападать друг на друга.\nОбласть действия:\nПорядок расторжения:";
            case TRADE -> "Предмет торговли:\nЧто предоставляет каждая сторона:\nЦена, сроки и место передачи:";
            case ULTIMATUM -> "Требования:\nПричина требований:\nПоследствия отказа (без автоматического объявления войны):";
            case WAR -> "Причина конфликта:\nЦели и требования:\nПредлагаемые правила и ограничения:\nЖелаемое время начала:";
            case PEACE -> "Стороны прекращают войну.\nУсловия мира:\nОбязательства и сроки исполнения:";
            case CEASEFIRE -> "Стороны временно прекращают боевые действия.\nУсловия и срок перемирия:\nПорядок возобновления через куратора:";
            case CUSTOM -> "";
        };
    }
    private String description(Kind kind) {
        return switch(kind) {
            case ALLIANCE -> "Взаимная помощь и общие обязательства";
            case NON_AGGRESSION -> "Гарантии безопасности и отказ от нападения";
            case TRADE -> "Ресурсы, расчёты и сроки поставок";
            case CUSTOM -> "Свободные условия в собственном документе";
            case ULTIMATUM -> "Требования стороне с ограничением по времени";
            case WAR -> "Причины конфликта и согласование с куратором";
            default -> kind.label;
        };
    }
    private boolean readHours() {
        try {int value=Integer.parseInt(replyHours.value());if(value<1||value>72)return false;hours=value;return true;}
        catch(NumberFormatException ex){return false;}
    }
    private void setHours(int value) { hours=Math.max(1,Math.min(72,value));replyHours.setValue(Integer.toString(hours)); }
    private void templates(GuiGraphics g) {
        int x=panel.x+16,y=panel.y+64,w=panel.w-32;
        int columns=w>=440?3:2, gap=8, cw=(w-(columns-1)*gap)/columns;
        int deadlineY=panel.footer()-58, available=deadlineY-y-9;
        int ch=panel.h>=290?68:52, pitch=ch+8, visible=Math.max(1,(available+8)/pitch);
        Kind[] kinds={Kind.ALLIANCE,Kind.NON_AGGRESSION,Kind.TRADE,Kind.CUSTOM,Kind.ULTIMATUM,Kind.WAR};
        int rows=(kinds.length+columns-1)/columns;scroll=Math.max(0,Math.min(scroll,Math.max(0,rows-visible)));
        for(int i=scroll*columns;i<Math.min(kinds.length,(scroll+visible)*columns);i++) {
            Kind k=kinds[i];int cx=x+(i%columns)*(cw+gap),cy=y+(i/columns-scroll)*pitch;
            boolean hot=inside(mouseX,mouseY,cx,cy,cw,ch),chosen=kind==k;
            DiplomacyVisuals.surface(g,cx,cy,cw,ch,chosen,hot);
            DiplomacyVisuals.cut(g,cx+9,cy+9,27,25,alpha(GOLD,chosen?35:17));
            DiplomacyVisuals.icon(g,k,cx+16,cy+17,1,chosen?GOLD:TEXT_LIGHT);
            String label=k==Kind.CUSTOM?"Свой документ":k==Kind.TRADE?"Торговля":k.label;
            line(g,label,cx+44,cy+12,cw-53,chosen?GOLD:TEXT_LIGHT);
            if(ch>=62) {
                var lines=font.split(Component.literal(description(k)),cw-22);
                for(int line=0;line<Math.min(2,lines.size());line++)g.drawString(font,lines.get(line),cx+11,cy+39+line*10,DIM,false);
            } else line(g,description(k),cx+11,cy+36,cw-22,DIM);
            hotspot(cx,cy,cw,ch,description(k),()->{
                if(k!=Kind.WAR&&!readHours()){feedback="Введите срок ответа от 1 до 72 часов";return;}
                if(text.value().equals(template(kind)))text.setValue(template(k));
                if(title.value().equals(kind.label))title.setValue(k.label);
                kind=k;confirmWar=false;feedback="";mode="compose";
            });
        }
        scrollbar(g,x+w+4,y,Math.min(available,visible*pitch-8),rows,visible,scroll);
        g.fill(x,deadlineY,x+w,deadlineY+1,LINE);
        if(kind==Kind.WAR) {
            line(g,"НАЧАЛО ПО РЕШЕНИЮ КУРАТОРА",x+2,deadlineY+11,w-4,GOLD);
            line(g,"Условия и время согласуются с администрацией",x+2,deadlineY+27,w-4,DIM);
        } else {
            boolean valid=readHours();
            line(g,"СРОК ОТВЕТА",x+2,deadlineY+8,w-4,GOLD);
            int rowY=deadlineY+23, bw=24, fieldW=40;
            add(x,rowY,bw,"−",()->setHours(hours-1),valid&&hours>1,false);
            replyHours.setBounds(x+bw+5,rowY,fieldW,20);
            add(x+bw+fieldW+10,rowY,bw,"+",()->setHours(hours+1),valid&&hours<72,false);
            int left=x+2*bw+fieldW+21;
            line(g,valid?"ч":"1–72",left,rowY+6,32,valid?DIM:HEART);
            int start=left+30, remaining=x+w-start;
            int[] presets={1,12,24,48,72};int pw=Math.min(40,(remaining-16)/5);
            for(int i=0;i<presets.length;i++){int value=presets[i];add(start+i*(pw+4),rowY,pw,(hours==value&&valid?"• ":"")+value,()->setHours(value));}
        }
    }
    private void scrollbar(GuiGraphics g,int x,int y,int h,int rows,int visible,int offset) {
        if(rows<=visible||h<10)return;
        g.fill(x,y,x+2,y+h,LINE);int th=Math.max(10,h*visible/rows),ty=y+(h-th)*offset/(rows-visible);
        g.fill(x,ty,x+2,ty+th,GOLD);
    }
    private void compose(GuiGraphics g) {
        int x=panel.x+16,y=panel.y+62,w=panel.w-32,kw=Math.min(132,w/3);
        add(x,y,kw,kind.label+(kind==Kind.WAR?"":" / "+hours+" ч"),()->{mode="templates";scroll=0;replyHours.setValue(Integer.toString(hours));},relatedWar==0,false);
        add(x+kw+5,y,w-kw-5,targetName,()->{if(relatedWar==0){mode="targets";scroll=0;search.setValue("");search.focused=false;}},relatedWar==0,false);y+=27;
        title.setBounds(x,y,w,20); y+=27;
        text.setBounds(x,y,w,Math.max(22,panel.footer()-y-14));
        int bw=Math.min(170,w-100);
        add(x+w-bw,panel.footer(),bw,kind==Kind.WAR?(confirmWar?"ПОДТВЕРДИТЬ ВОЙНУ":"ОБЪЯВИТЬ ВОЙНУ"):"ОТПРАВИТЬ",()->{
            if(kind==Kind.WAR&&!confirmWar){confirmWar=true;feedback="Начало подтвердит куратор. Нажмите ещё раз для объявления";return;}
            sending=true;sentAt=net.minecraft.Util.getMillis();feedback="Ожидание подтверждения сервера…";
            PacketDistributor.sendToServer(new DiplomacyNet.Action("create",0,source,target,kind.name(),title.value(),text.value(),relatedWar,hours));
        },!target.isBlank()&&!title.value().isBlank()&&!text.value().isBlank(),kind==Kind.WAR);
    }
    private void targets(GuiGraphics g) {
        int x=panel.x+16,y=panel.y+64,w=panel.w-32;
        String query=search.value().strip().toLowerCase(Locale.ROOT);
        List<CompoundTag> states=new ArrayList<>();ListTag list=data.getList("states",Tag.TAG_COMPOUND);
        for(int i=0;i<list.size();i++) {
            CompoundTag state=list.getCompound(i);
            if(!state.getString("id").equals(source)&&state.getString("name").toLowerCase(Locale.ROOT).contains(query))states.add(state);
        }
        search.setBounds(x,y,Math.max(120,w-100),20);
        line(g,"Найдено: "+states.size(),x+w-90,y+6,90,DIM);y+=29;
        int columns=w>=400?2:1,gap=8,cw=(w-(columns-1)*gap)/columns;
        int ch=panel.h>=330?56:panel.h>=285?52:44,pitch=ch+8,available=panel.footer()-y-13;
        int rows=Math.max(1,(states.size()+columns-1)/columns),visible=Math.max(1,(available+8)/pitch);
        scroll=Math.max(0,Math.min(scroll,Math.max(0,rows-visible)));
        for(int i=scroll*columns;i<Math.min(states.size(),(scroll+visible)*columns);i++) {
            CompoundTag state=states.get(i);int cx=x+(i%columns)*(cw+gap),cy=y+(i/columns-scroll)*pitch;
            boolean chosen=target.equals(state.getString("id")),hot=inside(mouseX,mouseY,cx,cy,cw,ch);
            DiplomacyVisuals.surface(g,cx,cy,cw,ch,chosen,hot);
            int size=ch>=50?28:26;DiplomacyVisuals.seal(g,font,cx+10,cy+10,size,state.getString("name"),state.getString("avatar"));
            int tx=cx+size+20,tw=cw-size-33;
            line(g,state.getString("name"),tx,cy+10,tw,chosen?GOLD:TEXT_LIGHT);
            String government=state.getString("government");String meta=state.getString("type");
            if(meta.isBlank())meta="Государство";
            if(!government.isBlank()&&!government.equalsIgnoreCase(meta))meta+=" · "+government;
            line(g,meta,tx,cy+23,tw,DIM);
            if(ch>=50)line(g,state.getString("relation").isBlank()?"Дипломатический контакт":state.getString("relation"),tx,cy+39,tw,OLIVE);
            hotspot(cx,cy,cw,ch,state.getString("name"),()->{target=state.getString("id");targetName=state.getString("name");mode="compose";confirmWar=false;feedback="";});
        }
        if(states.isEmpty())line(g,query.isEmpty()?"Других государств пока нет":"Совпадений не найдено",x+6,y+18,w-12,DIM);
        scrollbar(g,x+w+4,y,Math.min(available,visible*pitch-8),rows,visible,scroll);
    }
    private void prompt(GuiGraphics g,int mx,int my) {
        int x=panel.x+16,y=panel.y+66,w=panel.w-32;
        boolean note=Set.of("start","pause","resume","end","note").contains(promptAction);
        line(g,note?"Укажите условия или причину решения":"Подтвердите действие по документу #"+selected,x,y,w,GOLD);
        line(g,promptAction.equals("note")?"Эту заметку видят только администраторы":note?"Решение попадёт в историю, доступную сторонам":"Принятие означает согласие со всеми условиями документа",x,y+16,w,DIM);
        text.setBounds(x,y+37,w,Math.max(22,panel.footer()-y-83)); if(note)text.render(g,mx,my);
        add(x+w-146,panel.footer()-31,146,"ПОДТВЕРДИТЬ",()->send(promptAction,note?text.value():""),!note||!text.value().isBlank(),!promptAction.equals("accept")&&!promptAction.equals("note"));
    }
    private void back() {
        if(sending)return;
        switch(mode) {
            case "list" -> onClose();
            case "templates" -> {if(kind!=Kind.WAR&&!readHours()){feedback="Введите срок ответа от 1 до 72 часов";return;}mode="compose";}
            case "targets" -> mode="compose";
            case "prompt" -> mode="detail";
            default -> {mode="list";selected=0;scroll=0;request();}
        }
        feedback="";
    }
    @Override public boolean mouseClicked(double x,double y,int b) {
        if(b!=0)return false;
        for(Control c:controls)if(inside(x,y,c.x,c.y,c.w,c.h)){if(c.enabled){c.action.run();}return true;}
        if(mode.equals("targets"))return search.mouseClicked(x,y);
        if(mode.equals("templates")&&kind!=Kind.WAR)return replyHours.mouseClicked(x,y);
        if(mode.equals("compose")){title.mouseClicked(x,y);text.mouseClicked(x,y);confirmWar=false;return true;}
        if(mode.equals("prompt"))return text.mouseClicked(x,y);
        if(mode.equals("detail"))return document.mouseClicked(x,y);
        return super.mouseClicked(x,y,b);
    }
    @Override public boolean mouseScrolled(double x,double y,double dx,double dy) {
        if(mode.equals("detail"))return document.mouseScrolled(x,y,dy);
        if(mode.equals("compose")||mode.equals("prompt"))return text.mouseScrolled(x,y,dy);
        scroll=Math.max(0,scroll+(dy<0?1:-1));return true;
    }
    @Override public boolean mouseDragged(double x,double y,int b,double dx,double dy) { return mode.equals("detail")?document.mouseDragged(x,y):mode.equals("targets")?search.mouseDragged(x,y):mode.equals("templates")?replyHours.mouseDragged(x,y):text.mouseDragged(x,y); }
    @Override public boolean charTyped(char c,int mods) { if(sending)return true;confirmWar=false;
        if(mode.equals("targets")){boolean changed=search.charTyped(c);if(changed)scroll=0;return changed;}
        if(mode.equals("templates"))return kind!=Kind.WAR&&Character.isDigit(c)&&replyHours.charTyped(c);
        return mode.equals("compose")?(title.charTyped(c)||text.charTyped(c)):mode.equals("prompt")&&text.charTyped(c); }
    @Override public boolean keyPressed(int key,int scan,int mods) {
        if(key==org.lwjgl.glfw.GLFW.GLFW_KEY_ESCAPE){back();return true;}
        if(sending)return true;
        if(mode.equals("targets")){boolean handled=search.keyPressed(key,mods);if(handled)scroll=0;return handled||super.keyPressed(key,scan,mods);}
        if(mode.equals("templates"))return replyHours.keyPressed(key,mods)||super.keyPressed(key,scan,mods);
        if(mode.equals("compose"))return title.keyPressed(key,mods)||text.keyPressed(key,mods)||super.keyPressed(key,scan,mods);
        if(mode.equals("prompt"))return text.keyPressed(key,mods)||super.keyPressed(key,scan,mods);
        return super.keyPressed(key,scan,mods);
    }
    @Override public void onClose() { if(minecraft.getConnection()!=null)PacketDistributor.sendToServer(new DiplomacyNet.Close());minecraft.setScreen(parent); }
    @Override public void renderBackground(GuiGraphics g,int x,int y,float p) {}
    @Override public boolean isPauseScreen() { return false; }
}
