package com.humanitas.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractWidget;

import static com.humanitas.client.CivitasUi.*;

/**
 * Civitas styling for the ClientSort inventory trigger button.
 *
 * <p>A dark graphite plate with a thin gold rim and a soft top highlight. The icon is three pixel
 * bars of decreasing width, drawn as plain rectangles, so it is centred exactly and does not depend
 * on the font's glyphs or their side bearings.</p>
 */
public final class CivitasClientSortStyle {
    private CivitasClientSortStyle() {}

    /** Bar widths from top to bottom: a descending "sort" mark. */
    private static final int[] BAR_WIDTHS = {7, 5, 3};

    /**
     * One pixel mask per ClientSort operation, drawn as 1px rectangles so each icon is centred exactly.
     * '#' is an ink pixel. Each operation keeps its own shape, so the four buttons never look alike.
     */
    private static final String[] SORT = {
            "#######",
            ".#####.",
            "..###.."};
    private static final String[] STACK_FILL = {
            "#######",
            "#.....#",
            "#.###.#",
            "#.###.#",
            "#.###.#",
            "#.....#",
            "#######"};
    private static final String[] MATCH_TRANSFER = {
            "...#...",
            "..###..",
            ".#####.",
            "...#...",
            "...#..."};
    private static final String[] TRANSFER = {
            "...#...",
            "....##.",
            "#######",
            "....##.",
            "...#..."};

    /** The icon for a button, picked by the ClientSort class it belongs to. */
    private static String[] iconOf(AbstractWidget widget) {
        return switch (widget.getClass().getSimpleName()) {
            case "StackFillButton" -> STACK_FILL;
            case "MatchTransferButton" -> MATCH_TRANSFER;
            case "TransferButton" -> TRANSFER;
            default -> SORT;
        };
    }

    public static void render(GuiGraphics g, AbstractWidget widget, int mouseX, int mouseY) {
        int x = widget.getX();
        int y = widget.getY();
        int w = widget.getWidth();
        int h = widget.getHeight();
        boolean hot = widget.isHovered();

        CivitasSurfaces.surface(g,x,y,w,h,false,hot);

        String[] mask = iconOf(widget);
        int colour = hot ? GOLD : TEXT_LIGHT;
        int iw = mask[0].length();
        int ih = mask.length;
        int ox = x + (w - iw) / 2;
        int oy = y + (h - ih) / 2;
        for (int row = 0; row < ih; row++) {
            for (int col = 0; col < iw; col++) {
                if (mask[row].charAt(col) == '#') {
                    g.fill(ox + col, oy + row, ox + col + 1, oy + row + 1, colour);
                }
            }
        }
    }
}
