package com.humanitas.client;

import net.minecraft.client.Minecraft;
import net.minecraft.nbt.CompoundTag;
import java.nio.file.*;
import java.util.Properties;

/** Per-server, per-player seen revisions; a new administrator still sees outstanding cases. */
public final class DiplomacyFeed {
    private DiplomacyFeed() {}
    public static boolean admin;
    public static int unattended, totalWars, pending;
    public static String warSides="", warStatus="";
    private static long ownStart, ownEnd;
    private static long own, wars, ownSeen, warsSeen, noticeStart, noticeEnd;
    private static String loaded = "";
    private static final Properties seen = new Properties();
    private static String key() {
        var mc = Minecraft.getInstance(); var server = mc.getCurrentServer();
        return (server == null ? "local" : server.ip) + ":" + (mc.player == null ? "" : mc.player.getUUID());
    }
    private static Path file() { return Minecraft.getInstance().gameDirectory.toPath().resolve("config/civitas-diplomacy-seen.properties"); }
    public static void receive(CompoundTag t) {
        boolean initial = !key().equals(loaded);
        if(initial) {
            loaded = key(); seen.clear();
            try(var in=Files.newInputStream(file())) { seen.load(in); } catch(java.io.IOException ignored) {}
            ownSeen = number(loaded+".own"); warsSeen = number(loaded+".wars");
        }
        long before = wars, priorOwn = own;
        admin = t.getBoolean("admin"); own = t.getLong("own"); wars = admin ? t.getLong("wars") : 0;
        warSides = admin ? t.getString("warSides") : ""; warStatus = admin ? t.getString("warStatus") : "";
        pending = t.getInt("pending"); unattended = admin ? t.getInt("unattended") : 0; totalWars = admin ? t.getInt("totalWars") : 0;
        if(!initial && own > priorOwn) { ownStart=net.minecraft.Util.getMillis();ownEnd=ownStart+7000; }
        if(admin && (initial && unattended > 0 || warUnread() && (initial && totalWars > 0 || !initial && wars > before))) {
            noticeStart = net.minecraft.Util.getMillis(); noticeEnd = noticeStart + 8000;
            Minecraft.getInstance().getSoundManager().play(net.minecraft.client.resources.sounds.SimpleSoundInstance.forUI(net.minecraft.sounds.SoundEvents.NOTE_BLOCK_PLING.value(),1.0F));
        }
        if(!admin)noticeStart = noticeEnd = 0;
        if(initial && !seen.containsKey(loaded+".own")) { ownSeen=own; store(); }
    }
    private static long number(String key) { try { return Long.parseLong(seen.getProperty(key,"0")); } catch(NumberFormatException ex) { return 0; } }
    public static boolean warUnread() { return admin && wars > warsSeen; }
    public static boolean unread() { return own > ownSeen; }
    public static void mark(boolean warView) {
        boolean changed = warView ? warsSeen != wars : ownSeen != own;
        if(warView) { warsSeen=wars; noticeEnd=Math.min(noticeEnd,net.minecraft.Util.getMillis()+350); }
        else { ownSeen=own; ownEnd=Math.min(ownEnd,net.minecraft.Util.getMillis()+350); }
        if(changed)store();
    }
    private static void store() {
        seen.setProperty(loaded+".own",Long.toString(ownSeen)); seen.setProperty(loaded+".wars",Long.toString(warsSeen));
        try { Files.createDirectories(file().getParent()); try(var out=Files.newOutputStream(file())) { seen.store(out,"Civitas diplomatic notifications"); } } catch(java.io.IOException ignored) {}
    }
    public static float ownOpacity() {
        long now=net.minecraft.Util.getMillis(); float t=Math.max(0,Math.min(1,Math.min((now-ownStart)/280F,(ownEnd-now)/350F)));
        return t*t*(3-2*t);
    }
    public static float opacity() {
        if(!admin)return 0;
        long now=net.minecraft.Util.getMillis(); float t=Math.max(0,Math.min(1,Math.min((now-noticeStart)/280F,(noticeEnd-now)/350F)));
        return t*t*(3-2*t);
    }
    public static void reset() { admin=false; pending=unattended=totalWars=0; own=wars=ownSeen=warsSeen=noticeStart=noticeEnd=ownStart=ownEnd=0; warSides=warStatus=""; loaded=""; }
}
