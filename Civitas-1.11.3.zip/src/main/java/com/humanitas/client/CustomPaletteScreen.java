package com.humanitas.client;

import com.humanitas.CivitasClientConfig;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import static com.humanitas.client.CivitasUi.*;

/** Internal palette editor; its legacy entry point stays hidden in the public wheel. */
public final class CustomPaletteScreen extends Screen {
    private final Screen parent;
    private final TextInput[] fields=new TextInput[4];
    private static final String[] LABELS={"Фон","Текст","Рамки","Акцент"};
    private String error="";
    private DocumentPanel panel;
    public CustomPaletteScreen(Screen parent){super(Component.literal("Своя палитра"));this.parent=parent;}
    @Override protected void init(){
        panel=new DocumentPanel(width,height,340,284);
        String[] saved=CivitasClientConfig.CUSTOM_COLORS.get().split(",");
        for(int i=0;i<4;i++) {
            if(fields[i]==null){fields[i]=new TextInput(false,7,"");fields[i].setValue(saved.length==4?saved[i]:"FFFFFF");}
            fields[i].setBounds(panel.x+panel.w-112,panel.y+65+i*32,94,20);
        }
    }
    @Override public void render(GuiGraphics g,int mx,int my,float partial){
        g.fill(0,0,width,height,BACKDROP);panel.draw(g,font,"СВОЯ ПАЛИТРА","HEX · шесть цифр на цвет",50);
        for(int i=0;i<4;i++){g.drawString(font,LABELS[i],panel.x+18,panel.y+71+i*32,TEXT_LIGHT,false);fields[i].render(g,mx,my);}
        if(!error.isEmpty())g.drawString(font,font.plainSubstrByWidth(error,panel.w-32),panel.x+16,panel.footer()-21,GOLD,false);
        button(g,font,panel.x+14,panel.footer(),96,20,"НАЗАД",inside(mx,my,panel.x+14,panel.footer(),96,20),Style.SECONDARY);
        button(g,font,panel.x+panel.w-110,panel.footer(),96,20,"СОХРАНИТЬ",inside(mx,my,panel.x+panel.w-110,panel.footer(),96,20),Style.PRIMARY);
    }
    @Override public boolean mouseClicked(double x,double y,int b){
        if(b!=0)return false;
        if(inside(x,y,panel.x+14,panel.footer(),96,20)){onClose();return true;}
        if(inside(x,y,panel.x+panel.w-110,panel.footer(),96,20)){
            try {String[] colors=new String[4];for(int i=0;i<4;i++)colors[i]=fields[i].value();CivitasPaletteState.setCustom(colors,true);onClose();}
            catch(IllegalArgumentException ex){error="Введите 6 HEX-цифр, например 86CBD4";}return true;
        }
        for(TextInput input:fields)input.mouseClicked(x,y);return true;
    }
    @Override public boolean charTyped(char c,int mods){for(TextInput input:fields)if(input.charTyped(c))return true;return false;}
    @Override public boolean keyPressed(int key,int scan,int mods){for(TextInput input:fields)if(input.keyPressed(key,mods))return true;return super.keyPressed(key,scan,mods);}
    @Override public boolean mouseDragged(double x,double y,int b,double dx,double dy){for(TextInput input:fields)if(input.mouseDragged(x,y))return true;return false;}
    @Override public void onClose(){minecraft.setScreen(parent);}
    @Override public void renderBackground(GuiGraphics g,int x,int y,float partial){}
    @Override public boolean isPauseScreen(){return false;}
}
