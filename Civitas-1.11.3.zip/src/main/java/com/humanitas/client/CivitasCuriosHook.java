package com.humanitas.client;

import com.humanitas.Humanitas;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.ImageButton;
import net.minecraft.client.gui.components.Renderable;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.screens.recipebook.RecipeBookComponent;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.RecipeBookMenu;
import net.minecraft.world.inventory.Slot;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ScreenEvent;

import java.lang.reflect.Field;
import java.util.Map;
import java.util.WeakHashMap;

/**
 * Makes the recipe book usable inside Curios.
 *
 * <p>Curios hard-codes {@code widthTooNarrow = true} in its screen, so opening recipes replaces
 * the whole inventory with a full-screen book. Its book also sits on top of the Curios slot
 * panel. This hook is deliberately built on events and reflection: Civitas has no compile-time
 * dependency on Curios, and if Curios changes its internals the hook simply leaves the screen
 * untouched instead of crashing.</p>
 */
@EventBusSubscriber(modid = Humanitas.MODID, value = Dist.CLIENT)
public final class CivitasCuriosHook {
    private static final String CURIOS_SCREEN = "top.theillusivec4.curios.client.gui.CuriosScreen";
    private static final String CURIOS_WIDGETS = "top.theillusivec4.curios.client.gui.";
    static final String CURIOS_SLOT = "top.theillusivec4.curios.common.inventory.CurioSlot";

    private static final int BOOK_W = 147;
    private static final int BOOK_H = 166;
    private static final int INV_W = 176;
    private static final int INV_H = 166;
    private static final int GAP = 10;

    private static final Map<Screen, State> STATES = new WeakHashMap<>();

    private static Field widthTooNarrow;
    private static Field recipeBookGui;
    private static Field leftPos;
    private static Field panelWidth;
    private static Field recipeBookButton;
    private static boolean bound;
    private static boolean broken;

    private static final class State {
        final RecipeBookComponent book;
        CabinetButton button;
        boolean narrow;

        State(RecipeBookComponent book) {
            this.book = book;
        }
    }

    private CivitasCuriosHook() {}

    @SubscribeEvent
    public static void init(ScreenEvent.Init.Post event) {
        Screen screen = event.getScreen();
        if (broken || !isCurios(screen)) return;

        try {
            bind(screen.getClass());
            RecipeBookComponent book = (RecipeBookComponent) recipeBookGui.get(screen);
            Minecraft mc = Minecraft.getInstance();
            RecipeBookMenu<?, ?> menu = menuOf(screen);
            if (book == null || mc.player == null || menu == null) return;

            // Curios always calls this "narrow": that is why the book covers the inventory.
            widthTooNarrow.setBoolean(screen, false);
            book.init(screen.width, screen.height, mc, false, menu);

            State state = new State(book);
            replaceRecipeButton(event, screen, state, book);
            STATES.put(screen, state);
            apply(screen, state);
        } catch (ReflectiveOperationException | RuntimeException e) {
            broken = true;
            Humanitas.LOGGER.warn("Civitas: cannot adjust the Curios screen, keeping its stock layout", e);
        }
    }

    @SubscribeEvent
    public static void beforeRender(ScreenEvent.Render.Pre event) {
        Screen screen = event.getScreen();
        State state = STATES.get(screen);
        if (state == null || !isCurios(screen)) return;

        try {
            apply(screen, state);
        } catch (ReflectiveOperationException | RuntimeException e) {
            STATES.remove(screen);
        }
    }

    /**
     * The vanilla Curios screen has a plain recipe-book ImageButton. Replace it with the same
     * Civitas medallion used by the normal inventory, so the two screens feel alike.
     */
    private static void replaceRecipeButton(ScreenEvent.Init.Post event, Screen screen, State state,
                                            RecipeBookComponent book) throws IllegalAccessException {
        if (recipeBookButton == null) return;

        Object value = recipeBookButton.get(screen);
        if (!(value instanceof ImageButton old)) return;

        int x = old.getX();
        int y = old.getY();
        int w = old.getWidth();
        int h = old.getHeight();
        event.removeListener(old);

        state.button = new CabinetButton(x, y, w, h, () -> "☰", 1.2F, book::toggleVisibility)
                .withRecipeIcon()
                .withTip(() -> "Рецепты");
        event.addListener(state.button);
    }

    private static void apply(Screen screen, State state) throws IllegalAccessException {
        Minecraft mc = Minecraft.getInstance();
        RecipeBookMenu<?, ?> menu = menuOf(screen);

        if (widthTooNarrow.getBoolean(screen)) {
            if (state.book.isVisible()) return; // stock full-screen book is showing
            if (mc.player == null || menu == null) return;

            // The book was closed after a narrow fallback: restore the wide flag, so the next
            // opening uses the side-by-side layout whenever the screen has room for it.
            widthTooNarrow.setBoolean(screen, false);
            state.book.init(screen.width, screen.height, mc, false, menu);
            state.narrow = false;
        }

        int current = leftPos.getInt(screen);
        int desired;

        if (state.book.isVisible()) {
            int bookX = bookX(screen, false);
            desired = bookX + BOOK_W + panel(screen) + GAP;

            if (desired < 2 || desired + INV_W > screen.width - 2) {
                // Not enough room for book + Curios panel + inventory. Fall back to Curios'
                // own narrow book instead of drawing the panels on top of each other.
                if (mc.player != null && menu != null) {
                    widthTooNarrow.setBoolean(screen, true);
                    state.book.init(screen.width, screen.height, mc, true, menu);
                    state.narrow = true;
                }
                desired = centered(screen.width);
            } else {
                state.narrow = false;
            }
        } else {
            desired = centered(screen.width);
            state.narrow = false;
        }

        int dx = desired - current;
        if (dx != 0) {
            leftPos.setInt(screen, desired);
            shiftCuriosWidgets(screen, dx, state.button);
        }

        if (state.button != null) {
            state.button.setX(desired + 104);
            state.button.setY(screen.height / 2 - 22);
        }
    }

    /**
     * Curios positions its render buttons, page buttons and cosmetic button once, in init().
     * When the inventory moves right to make room for the book, those widgets have to move too.
     */
    private static void shiftCuriosWidgets(Screen screen, int dx, CabinetButton own) {
        for (Renderable renderable : screen.renderables) {
            if (!(renderable instanceof AbstractWidget widget) || widget == own) continue;
            if (widget.getClass().getName().startsWith(CURIOS_WIDGETS)) {
                widget.setX(widget.getX() + dx);
            }
        }
    }

    @SubscribeEvent
    public static void afterRender(ScreenEvent.Render.Post event) {
        Screen screen = event.getScreen();
        State state = STATES.get(screen);
        if (state == null) return;

        GuiGraphics g = event.getGuiGraphics();
        if (state.book.isVisible()) {
            drawBookFrame(g, screen, state.narrow);
        }
        // The inventory plate itself is painted from CuriosScreenMixin, under the slots. Only the
        // recipe book needs an overlay frame: it is a vanilla component with no background hook.
    }

    private static void drawBookFrame(GuiGraphics g, Screen screen, boolean narrow) {
        int bx = bookX(screen, narrow);
        int by = (screen.height - BOOK_H) / 2;
        int fx = bx - (narrow ? 2 : 31);
        int fy = by - 2;
        int fw = BOOK_W + (narrow ? 4 : 33);
        int fh = BOOK_H + 4;

        CivitasUi.frame(g, fx, fy, fw, fh);

        if (fy > 18) {
            Font font = Minecraft.getInstance().font;
            String heading = "РЕЦЕПТЫ";
            int hx = bx + (BOOK_W - font.width(heading)) / 2;
            g.drawString(font, heading, hx, fy - 13, CivitasUi.GOLD, true);
            g.fill(hx - 14, fy - 6, hx + font.width(heading) + 14, fy - 5,
                    CivitasUi.alpha(CivitasUi.GOLD, 0x80));
        }
    }

    private static int bookX(Screen screen, boolean narrow) {
        // RecipeBookComponent uses xOffset 86 next to a wide inventory and 0 in narrow mode.
        return (screen.width - BOOK_W) / 2 - (narrow ? 0 : 86);
    }

    private static int centered(int width) {
        return Math.max(2, (width - INV_W) / 2);
    }

    private static int left(Screen screen) {
        try {
            return leftPos.getInt(screen);
        } catch (IllegalAccessException e) {
            return centered(screen.width);
        }
    }

    private static int panel(Screen screen) {
        try {
            return panelWidth == null ? 0 : Math.max(0, panelWidth.getInt(screen));
        } catch (IllegalAccessException e) {
            return 0;
        }
    }

    /**
     * Panel width for {@link CivitasCuriosStyle}. Curios exposes it as a public field, but the
     * field is only set while {@code renderBg} runs; the slot positions are the reliable fallback.
     */
    static int panelOf(Screen screen) {
        int panel = panel(screen);
        if (panel > 0 || !(screen instanceof AbstractContainerScreen<?> container)) return panel;

        for (Slot slot : container.getMenu().slots) {
            if (slot.x < 0 && slot.getClass().getName().equals(CURIOS_SLOT)) {
                panel = Math.max(panel, 7 - slot.x);
            }
        }
        return panel;
    }

    static boolean narrowOf(Screen screen) {
        try {
            return widthTooNarrow != null && widthTooNarrow.getBoolean(screen);
        } catch (IllegalAccessException e) {
            return false;
        }
    }

    private static RecipeBookMenu<?, ?> menuOf(Screen screen) {
        AbstractContainerMenu menu = ((AbstractContainerScreen<?>) screen).getMenu();
        return menu instanceof RecipeBookMenu<?, ?> bookMenu ? bookMenu : null;
    }

    private static boolean isCurios(Screen screen) {
        return screen.getClass().getName().equals(CURIOS_SCREEN);
    }

    private static void bind(Class<?> screenClass) throws NoSuchFieldException {
        if (bound) return;

        widthTooNarrow = screenClass.getField("widthTooNarrow");
        panelWidth = screenClass.getField("panelWidth");

        recipeBookGui = screenClass.getDeclaredField("recipeBookGui");
        recipeBookGui.setAccessible(true);

        try {
            recipeBookButton = screenClass.getDeclaredField("recipeBookButton");
            recipeBookButton.setAccessible(true);
        } catch (NoSuchFieldException ignored) {
            recipeBookButton = null;
        }

        try {
            leftPos = AbstractContainerScreen.class.getDeclaredField("leftPos");
        } catch (NoSuchFieldException e) {
            // Production runtime fallback for older NeoForge mapping names.
            leftPos = AbstractContainerScreen.class.getDeclaredField("f_97726_");
        }
        leftPos.setAccessible(true);

        bound = true;
    }
}
