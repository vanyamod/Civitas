package com.humanitas.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.world.inventory.Slot;

import static com.humanitas.client.CivitasUi.*;

/**
 * The Civitas plate for Curios' inventory screen.
 *
 * <p>Curios draws the vanilla inventory texture and its own accessory panel in {@code renderBg},
 * then the screen draws slot contents on top. The mixin calls this class at the tail of
 * {@code renderBg}: the opaque plate is painted over the stock textures, and the slot wells are
 * painted before the items, so nothing is hidden. No Curios class is referenced here, which keeps
 * the screen styling optional at runtime.</p>
 */
public final class CivitasCuriosStyle {
    private static final int INV_W = 176;
    private static final int INV_H = 166;

    private CivitasCuriosStyle() {}

    /** Paints the whole plate and every slot well. Called from the Curios screen mixin. */
    public static void background(GuiGraphics g, AbstractContainerScreen<?> screen, int mouseX, int mouseY) {
        // Curios' narrow fallback hides the inventory on purpose. Painting under the book would
        // leave a half-empty plate around it, so leave that path entirely vanilla.
        if (CivitasCuriosHook.narrowOf(screen)) return;

        int left = screen.getGuiLeft();
        int top = screen.getGuiTop();
        int panel = CivitasCuriosHook.panelOf(screen);

        int bodyX = left - panel - 3;
        int bodyY = top - 3;
        int bodyW = panel + INV_W + 6;
        int bodyH = INV_H + 6;

        int x0 = bodyX + 1;
        int y0 = bodyY + 1;
        int x1 = bodyX + bodyW - 1;
        int y1 = bodyY + bodyH - 1;

        CivitasSurfaces.panel(g,bodyX,bodyY,bodyW,bodyH);
        if(panel>0) {
            g.fill(left-panel+2,top+3,left-3,top+INV_H-3,PLATE_DEEP);
            g.fill(left-2,top+8,left-1,top+INV_H-8,mix(PLATE,TEXT_LIGHT,0.18F));
        }

        drawSlots(g, screen, left, top, x0, y0, x1, y1);
        drawPortrait(g, screen, mouseX, mouseY);
        drawCraftingArrow(g, left, top);
        drawDivider(g, left, top);

        // The heavy gold rim goes on last so it sits above the plate and the slot edges.
        CivitasUi.frame(g, bodyX, bodyY, bodyW, bodyH);
    }

    /** Title and the accessory-bay heading. Called from the Curios screen mixin in local space. */
    public static void labels(GuiGraphics g, AbstractContainerScreen<?> screen) {
        if (CivitasCuriosHook.narrowOf(screen)) return;

        Font font = Minecraft.getInstance().font;
        int panel = CivitasCuriosHook.panelOf(screen);
        int top = screen.getGuiTop();

        if (top < 18) return;

        String heading = "АКСЕССУАРЫ";
        int textWidth = font.width(heading);
        if (panel >= textWidth + 10) {
            int hx = -panel + (panel - textWidth) / 2;
            g.drawString(font, heading, hx, -15, GOLD, true);
            g.fill(hx - 10, -7, hx + textWidth + 10, -6,
                    CivitasColors.alpha(GOLD, 0x80));
        } else if (panel > 0) {
            // Narrow bay: a small gold badge instead of text that would spill over the inventory.
            int cx = -panel / 2;
            g.fill(cx - 16, -11, cx - 5, -10, CivitasColors.alpha(GOLD, 0x70));
            g.fill(cx + 6, -11, cx + 17, -10, CivitasColors.alpha(GOLD, 0x70));
            g.fill(cx - 1, -13, cx + 1, -11, GOLD);
            g.fill(cx - 2, -11, cx + 2, -10, GOLD_DEEP);
            g.fill(cx - 1, -10, cx + 1, -9, GOLD);
        }
    }

    private static void drawSlots(GuiGraphics g, AbstractContainerScreen<?> screen,
                                  int left, int top, int x0, int y0, int x1, int y1) {
        for(Slot slot:screen.getMenu().slots) {
            if(!slot.isActive())continue;
            int sx=left+slot.x-1,sy=top+slot.y-1;
            if(sx<x0 || sy<y0 || sx+18>x1 || sy+18>y1)continue;
            boolean result=slot.index==0;
            boolean curio=slot.getClass().getName().equals(CivitasCuriosHook.CURIOS_SLOT);
            CivitasEquipmentStyle.cell(g,sx,sy,18,result,false);
            if(curio)g.fill(sx+5,sy+16,sx+13,sy+17,GOLD_DEEP);
        }
    }

    private static void drawPortrait(GuiGraphics g, AbstractContainerScreen<?> screen,
                                     int mouseX, int mouseY) {
        int x=screen.getGuiLeft()+26,y=screen.getGuiTop()+8,w=49,h=70;
        CivitasEquipmentStyle.portrait(g,x,y,w,h);
        Minecraft mc=Minecraft.getInstance();
        if(mc.player!=null)InventoryScreen.renderEntityInInventoryFollowsMouse(g,
                x,y,x+w,y+h,30,0.0625F,mouseX,mouseY,mc.player);
    }

    /** The vanilla texture supplied this arrow; now it is a small olive-and-gold rule. */
    private static void drawCraftingArrow(GuiGraphics g, int left, int top) {
        CivitasEquipmentStyle.craftingArrow(g,left+136,top+32);
    }

    /** A small gold clasp in the four-pixel gap between the inventory grid and the hotbar row. */
    private static void drawDivider(GuiGraphics g, int left, int top) {
        CivitasEquipmentStyle.divider(g,left+8,top+139,INV_W-16);
    }
}
