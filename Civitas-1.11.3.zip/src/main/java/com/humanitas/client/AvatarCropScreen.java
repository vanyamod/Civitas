package com.humanitas.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Selects a square region of a state avatar before it is uploaded. */
final class AvatarCropScreen extends Screen {
    private final Screen parent;
    private final ImageAttachment attachment;
    private final byte[] original;
    private final int imageW, imageH, ticket;
    private final String previewKey = ImageCache.newLocalKey();
    private final ImageCache.Entry preview;
    private double cropX, cropY, cropSize;
    private boolean dragging;
    private boolean confirmed;
    private double dragX, dragY;
    private int imageX, imageY, drawW, drawH;
    private double factor;

    AvatarCropScreen(Screen parent, ImageAttachment attachment, byte[] original, byte[] previewBytes,
                     int width, int height, int ticket) {
        super(Component.literal("Аватар государства"));
        this.parent = parent;
        this.attachment = attachment;
        this.original = original;
        this.imageW = width;
        this.imageH = height;
        this.ticket = ticket;
        this.preview = ImageCache.register(previewKey, previewBytes);
        cropSize = Math.min(width, height);
        cropX = (width - cropSize) / 2.0;
        cropY = (height - cropSize) / 2.0;
    }

    private void layout() {
        int maxW = Math.max(1, width - 48), maxH = Math.max(1, height - 108);
        factor = Math.min(maxW / (double) imageW, maxH / (double) imageH);
        drawW = Math.max(1, (int) Math.round(imageW * factor));
        drawH = Math.max(1, (int) Math.round(imageH * factor));
        imageX = (width - drawW) / 2;
        imageY = 48 + Math.max(0, (maxH - drawH) / 2);
    }

    @Override public void render(GuiGraphics g, int mx, int my, float partialTick) {
        g.fill(0, 0, width, height, CivitasColors.alpha(CivitasUi.PLATE_DEEP,0xF2));
        layout();
        g.drawCenteredString(font, "АВАТАР ГОСУДАРСТВА", width / 2, 12, CivitasUi.TEXT_LIGHT);
        g.drawCenteredString(font, "Перетащите рамку · колесо — масштаб · рамка притягивается к центру", width / 2, 27, CivitasUi.DIM);
        if (preview != null) {
            g.blit(preview.texture(), imageX, imageY, drawW, drawH, 0f, 0f,
                    preview.width(), preview.height(), preview.width(), preview.height());
            int x = imageX + (int) Math.round(cropX * factor);
            int y = imageY + (int) Math.round(cropY * factor);
            int s = Math.max(1, (int) Math.round(cropSize * factor));
            g.fill(imageX, imageY, imageX + drawW, y, 0x99000000);
            g.fill(imageX, y + s, imageX + drawW, imageY + drawH, 0x99000000);
            g.fill(imageX, y, x, y + s, 0x99000000);
            g.fill(x + s, y, imageX + drawW, y + s, 0x99000000);
            int color = centeredX() && centeredY() ? 0xFFFFFFFF : CivitasUi.GOLD;
            g.fill(x, y, x + s, y + 1, color); g.fill(x, y + s - 1, x + s, y + s, color);
            g.fill(x, y, x + 1, y + s, color); g.fill(x + s - 1, y, x + s, y + s, color);
            if (centeredX()) g.fill(x + s / 2, y, x + s / 2 + 1, y + s, 0x66FFFFFF);
            if (centeredY()) g.fill(x, y + s / 2, x + s, y + s / 2 + 1, 0x66FFFFFF);
        } else g.drawCenteredString(font, "Не удалось открыть изображение", width / 2, height / 2, 0xFFFF5555);
        int y = height - 34;
        CivitasUi.button(g, font, width / 2 - 122, y, 116, 22, "ОТМЕНА", CivitasUi.inside(mx, my, width / 2 - 122, y, 116, 22), CivitasUi.Style.SECONDARY);
        CivitasUi.button(g, font, width / 2 + 6, y, 116, 22, "СОХРАНИТЬ", CivitasUi.inside(mx, my, width / 2 + 6, y, 116, 22), preview == null ? CivitasUi.Style.DISABLED : CivitasUi.Style.PRIMARY);
    }

    private boolean centeredX() { return Math.abs(cropX + cropSize / 2 - imageW / 2.0) * factor < 0.75; }
    private boolean centeredY() { return Math.abs(cropY + cropSize / 2 - imageH / 2.0) * factor < 0.75; }
    private static double clamp(double v, double min, double max) { return Math.max(min, Math.min(max, v)); }
    private void constrain(boolean snap) {
        cropX = clamp(cropX, 0, imageW - cropSize); cropY = clamp(cropY, 0, imageH - cropSize);
        if (snap && Math.abs(cropX + cropSize / 2 - imageW / 2.0) * factor < 6) cropX = (imageW - cropSize) / 2;
        if (snap && Math.abs(cropY + cropSize / 2 - imageH / 2.0) * factor < 6) cropY = (imageH - cropSize) / 2;
    }

    @Override public boolean mouseClicked(double mx, double my, int button) {
        if (button != 0) return super.mouseClicked(mx, my, button);
        int y = height - 34;
        if (CivitasUi.inside(mx, my, width / 2 - 122, y, 116, 22)) { onClose(); return true; }
        if (preview != null && CivitasUi.inside(mx, my, width / 2 + 6, y, 116, 22)) {
            int s = Math.max(1, Math.min(Math.min(imageW, imageH), (int) Math.round(cropSize)));
            int x = (int) clamp(Math.round(cropX), 0, imageW - s);
            int cy = (int) clamp(Math.round(cropY), 0, imageH - s);
            confirmed = true;
            ImageCache.release(previewKey);
            Minecraft.getInstance().setScreen(parent);
            attachment.cropAndUpload(original, x, cy, s, ticket);
            return true;
        }
        layout();
        dragging = mx >= imageX + cropX * factor && mx < imageX + (cropX + cropSize) * factor
                && my >= imageY + cropY * factor && my < imageY + (cropY + cropSize) * factor;
        if (dragging) { dragX = cropX; dragY = cropY; }
        return dragging || super.mouseClicked(mx, my, button);
    }
    @Override public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (button == 0 && dragging && factor > 0) {
            dragX = clamp(dragX + dx / factor, 0, imageW - cropSize);
            dragY = clamp(dragY + dy / factor, 0, imageH - cropSize);
            cropX = dragX; cropY = dragY; constrain(true); return true;
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }
    @Override public boolean mouseReleased(double mx, double my, int button) { dragging = false; return super.mouseReleased(mx, my, button); }
    @Override public boolean mouseScrolled(double mx, double my, double sx, double sy) {
        if (sy == 0) return false;
        double cx = cropX + cropSize / 2, cy = cropY + cropSize / 2;
        cropSize = clamp(cropSize * Math.pow(0.85, sy), Math.min(32, Math.min(imageW, imageH)), Math.min(imageW, imageH));
        cropX = cx - cropSize / 2; cropY = cy - cropSize / 2; constrain(true);
        return true;
    }
    @Override public void onClose() {
        ImageCache.release(previewKey);
        attachment.cancelCrop(ticket);
        Minecraft.getInstance().setScreen(parent);
    }
    @Override public void removed() {
        ImageCache.release(previewKey);
        if (!confirmed) attachment.cancelCrop(ticket);
        super.removed();
    }
    @Override public boolean isPauseScreen() { return false; }
}
