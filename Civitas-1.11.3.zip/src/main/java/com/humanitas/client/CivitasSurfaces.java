package com.humanitas.client;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import static com.humanitas.client.CivitasUi.*;

/** Shared diplomatic-style surfaces. Geometry and colour are independent of menu behaviour. */
public final class CivitasSurfaces {
    private CivitasSurfaces() {}
    public static void cut(GuiGraphics g,int x,int y,int w,int h,int color) {
        if(w<=0||h<=0)return;
        if(w<5||h<5){g.fill(x,y,x+w,y+h,color);return;}
        g.fill(x+2,y,x+w-2,y+h,color);g.fill(x,y+2,x+w,y+h-2,color);
        g.fill(x+1,y+1,x+w-1,y+h-1,color);
    }
    public static void surface(GuiGraphics g,int x,int y,int w,int h,boolean chosen,boolean hot) {
        cut(g,x+1,y+2,w,h,0x50000000);
        int edge=chosen?GOLD:mix(PLATE,TEXT_LIGHT,hot?0.36F:0.17F);
        cut(g,x,y,w,h,edge);
        cut(g,x+1,y+1,w-2,h-2,mix(PLATE,chosen?GOLD:TEXT_LIGHT,chosen?0.10F:hot?0.08F:0.025F));
        g.fill(x+4,y+1,x+w-4,y+2,mix(edge,TEXT_LIGHT,0.13F));
        if(chosen && w>=18 && h>=16) {
            g.fill(x+1,y+6,x+3,y+h-6,GOLD);
            g.fill(x+w-10,y+4,x+w-4,y+5,GOLD);g.fill(x+w-5,y+4,x+w-4,y+10,GOLD);
        }
    }
    public static void panel(GuiGraphics g,int x,int y,int w,int h) {
        cut(g,x+3,y+4,w,h,0x65000000);
        cut(g,x,y,w,h,mix(GOLD,TEXT_LIGHT,0.08F));
        cut(g,x+1,y+1,w-2,h-2,mix(PLATE,GOLD,0.12F));
        cut(g,x+2,y+2,w-4,h-4,PLATE_DEEP);
        g.fillGradient(x+3,y+3,x+w-3,y+h-3,PANEL,PLATE_DEEP);
        g.fill(x+5,y+2,x+w-5,y+3,mix(GOLD_DEEP,TEXT_LIGHT,0.20F));
    }
    public static void frame(GuiGraphics g,int x,int y,int w,int h) {
        int edge=mix(GOLD,TEXT_LIGHT,0.08F),inner=mix(PLATE,GOLD,0.26F);
        g.fill(x+2,y,x+w-2,y+1,edge);g.fill(x,y+2,x+1,y+h-2,edge);
        g.fill(x+2,y+h-1,x+w-2,y+h,edge);g.fill(x+w-1,y+2,x+w,y+h-2,edge);
        g.fill(x+1,y+1,x+2,y+2,edge);g.fill(x+w-2,y+1,x+w-1,y+2,edge);
        g.fill(x+1,y+h-2,x+2,y+h-1,edge);g.fill(x+w-2,y+h-2,x+w-1,y+h-1,edge);
        g.fill(x+2,y+1,x+w-2,y+2,inner);g.fill(x+1,y+2,x+2,y+h-2,inner);
        g.fill(x+2,y+h-2,x+w-2,y+h-1,inner);g.fill(x+w-2,y+2,x+w-1,y+h-2,inner);
    }
    public static String fit(Font font,String text,int width) {
        if(width<=0)return "";
        return font.width(text)<=width?text:font.plainSubstrByWidth(text,Math.max(0,width-font.width("…")))+"…";
    }
    public static void button(GuiGraphics g,Font font,int x,int y,int w,int h,Component label,boolean hot,Style style) {
        if(w<=0||h<=0)return;
        CivitasSounds.register(x,y,w,h,style);
        boolean enabled=style!=Style.DISABLED, primary=style==Style.PRIMARY;
        boolean selected=style==Style.CHOSEN, danger=style==Style.DANGER;
        int accent=danger?mix(GOLD,HEART,0.42F):GOLD;
        int color;
        if(primary&&enabled) {
            cut(g,x,y,w,h,accent);cut(g,x+1,y+1,w-2,h-2,hot?mix(CREAM,accent,0.18F):CREAM_DEEP);color=INK;
        } else {
            surface(g,x,y,w,h,selected,hot&&enabled);
            if(danger&&enabled)g.fill(x+3,y+h-2,x+w-3,y+h-1,accent);
            color=!enabled?mix(PLATE,TEXT_LIGHT,0.35F):selected?GOLD:TEXT_LIGHT;
        }
        int padding=w<28?4:12;
        Component shown=font.width(label)<=w-padding?label:Component.literal(fit(font,label.getString(),w-padding));
        g.drawString(font,shown,x+(w-font.width(shown))/2,y+(h-8)/2,color,false);
    }
    public static void pixels(GuiGraphics g,String[] rows,int x,int y,int scale,int color) {
        for(int row=0;row<rows.length;row++)for(int col=0;col<rows[row].length();col++)
            if(rows[row].charAt(col)=='X')g.fill(x+col*scale,y+row*scale,x+(col+1)*scale,y+(row+1)*scale,color);
    }
    public static void field(GuiGraphics g,int x,int y,int w,int h,boolean focused) {
        cut(g,x-1,y-1,w+2,h+2,focused?GOLD:mix(PLATE,TEXT_LIGHT,0.22F));
        cut(g,x,y,w,h,mix(PLATE_DEEP,TEXT_LIGHT,0.035F));
        g.fill(x+2,y,x+w-2,y+1,0x50000000);
    }
}
