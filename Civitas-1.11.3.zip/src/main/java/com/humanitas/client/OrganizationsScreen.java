package com.humanitas.client;

import com.humanitas.OrganizationsData;
import com.humanitas.OrganizationsNet;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.nbt.*;
import net.minecraft.network.chat.Component;
import net.neoforged.neoforge.network.PacketDistributor;
import org.lwjgl.glfw.GLFW;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;
import static com.humanitas.client.CivitasUi.*;

/** Searchable organization desk and persistent context switcher, using the current GUI palette. */
public final class OrganizationsScreen extends Screen {
    private static int nextSequence;
    private final Screen parent;
    private DocumentPanel panel;
    private CompoundTag data=new CompoundTag(),selected;
    private String editingRole="";
    private String organization,tab,focus="",form="",notice="",query="";
    private int page,sequence,ticks,scroll,navScroll,formScroll,rightsMask,quorum=50,hours=24;
    private int formMaxScroll,overviewMaxScroll;
    private int clipTop=Integer.MIN_VALUE,clipBottom=Integer.MAX_VALUE;
    private long pendingSince,nextRequestAt;
    private boolean busy,queued,statesVote,twoThirds,awaitingAction;
    private final TextInput search=new TextInput(false,80,"Поиск по названию или имени…"),reader=new TextInput(true,20000,"");
    private final List<TextInput> inputs=new ArrayList<>();
    private final List<String> labels=new ArrayList<>();
    private final List<Control> controls=new ArrayList<>();
    private record Control(int x,int y,int w,int h,String label,Style style,Runnable action){}
    private static final String[][] TABS={{"overview","Обзор и устав"},{"people","Участники"},{"states","Делегации"},{"roles","Роли и права"},{"agenda","Резолюции"},{"history","Хроника"}};
    public OrganizationsScreen(Screen parent){this(parent,"","catalog");}
    public OrganizationsScreen(Screen parent,String organization,String tab){super(Component.literal("Организации"));this.parent=parent;this.organization=organization;this.tab=tab;}
    @Override protected void init(){panel=new DocumentPanel(width,height,740,460);if(data.isEmpty())request();}
    private OrganizationsNet.Request view(){return new OrganizationsNet.Request(sequence,organization,tab,page,query,focus);}
    private void backgroundRequest(){sequence=++nextSequence;queued=true;flush();}
    private void request(){busy=true;pendingSince=System.currentTimeMillis();sequence=++nextSequence;queued=true;flush();}
    private void flush(){long now=System.currentTimeMillis();if(queued&&now>=nextRequestAt){queued=false;nextRequestAt=now+180;PacketDistributor.sendToServer(view());}}
    public static void receive(CompoundTag tag){
        if(!(Minecraft.getInstance().screen instanceof OrganizationsScreen s)||tag.getInt("sequence")!=s.sequence)return;
        if(tag.getBoolean("limited")){
            s.notice=tag.getString("message");s.awaitingAction=false;
            if(tag.getBoolean("retry")){s.queued=true;s.nextRequestAt=System.currentTimeMillis()+200;s.pendingSince=System.currentTimeMillis();}
            else{s.busy=false;s.queued=false;}
            return;
        }
        s.busy=false;s.queued=false;s.data=tag.copy();s.organization=tag.getString("organization");s.tab=tag.getString("tab");s.focus=tag.getString("focus");s.page=tag.getInt("page");
        if(!tag.getString("message").isBlank())s.notice=tag.getString("message");
        if(tag.getBoolean("switched")){Minecraft.getInstance().setScreen(null);CabinetRequests.openFresh();return;}
        if(s.awaitingAction&&tag.getBoolean("actionOk")){s.form="";s.inputs.clear();s.selected=null;s.scroll=0;}
        s.awaitingAction=false;
        if(s.selected!=null){String id=s.selected.getString("id"),kind=s.selected.getString("kind");s.selected=null;var rows=tag.getList("rows",10);for(int i=0;i<rows.size();i++){var row=rows.getCompound(i);if(id.equals(row.getString("id"))&&kind.equals(row.getString("kind")))s.selected=row;}}
    }
    private void navigate(String org,String next){if(busy)return;organization=org;tab=next;focus="";page=0;scroll=0;selected=null;form="";inputs.clear();query="";search.setValue("");notice="";request();}
    private void picker(String next,String target){if(busy)return;tab=next;focus=target;page=0;scroll=0;selected=null;form="";query="";search.setValue("");request();}
    private void send(String op,String target,CompoundTag fields,String destination,String newFocus){
        if(busy)return;awaitingAction=true;busy=true;pendingSince=System.currentTimeMillis();sequence=++nextSequence;queued=false;
        PacketDistributor.sendToServer(new OrganizationsNet.Action(new OrganizationsNet.Request(sequence,organization,destination,0,"",newFocus),op,target,fields));
    }
    private void send(String op,String target,CompoundTag fields){send(op,target,fields,tab,focus);}
    private void simple(String op,String target){send(op,target,new CompoundTag());}
    private int rights(){return data.getCompound("profile").getInt("rights");}
    private boolean has(int right){return (rights()&right)==right;}
    private boolean internal(){return data.getBoolean("admin")||data.getCompound("profile").getBoolean("member");}
    private void start(String form,String... labelValues){
        if(form.equals("role"))editingRole=selected==null?"":selected.getString("id");
        this.form=form;inputs.clear();labels.clear();scroll=0;formScroll=0;
        for(int i=0;i<labelValues.length;i+=2){String label=labelValues[i];labels.add(label);int max=label.contains("Устав")||label.startsWith("Текст")?6000:label.contains("Описание")?1000:label.contains("роли")?64:label.equals("Название")||label.contains("название")?80:100;
            var input=new TextInput(label.contains("Устав")||label.contains("Описание")||label.startsWith("Текст"),max,"");input.setValue(labelValues[i+1]);input.scrollToStart();inputs.add(input);}
        if(!inputs.isEmpty())inputs.get(0).focused=true;
    }
    @Override public void tick(){flush();if(busy&&System.currentTimeMillis()-pendingSince>8000){busy=false;awaitingAction=false;notice="Ответ задерживается. Запрашиваем состояние; действие не повторяется.";request();}if(++ticks%80==0&&!busy)backgroundRequest();}
    private void buttonAt(GuiGraphics g,String label,int x,int y,int w,Style style,Runnable action,int mx,int my){
        if(y>=clipTop&&y+22<=clipBottom)controls.add(new Control(x,y,w,22,label,style,action));button(g,font,x,y,w,22,label,!busy&&inside(mx,my,x,y,w,22),busy?Style.DISABLED:style);
    }
    private String fit(String value,int w){return CivitasSurfaces.fit(font,value,Math.max(8,w));}
    private static String date(long time){if(time<=0)return "—";return DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm").withZone(ZoneId.systemDefault()).format(Instant.ofEpochMilli(time));}
    private void read(GuiGraphics g,int mx,int my,int x,int y,int w,int h,String text){if(!reader.value().equals(text)){reader.replaceReadOnly(text);}reader.focused=false;reader.setBounds(x,y,w,Math.max(20,h));reader.render(g,mx,my);}
    @Override public void render(GuiGraphics g,int mx,int my,float partial){
        controls.clear();g.fill(0,0,width,height,BACKDROP);var p=data.getCompound("profile");
        String heading=tab.equals("contexts")?"ВЫБОР КАБИНЕТА":organization.isEmpty()?"ОРГАНИЗАЦИИ":p.getString("name").isEmpty()?"ОРГАНИЗАЦИЯ":p.getString("name");
        String meta=tab.equals("contexts")?"Ваши государства и организации · выбор сохраняется":organization.isEmpty()?"Объединения игроков и государств":p.getInt("population")+" участников · "+p.getInt("states")+" государств · голосований "+p.getInt("activeVotes");
        panel.draw(g,font,heading,meta,55);int x=panel.x+14,y=panel.y+65,w=panel.w-28,h=panel.footer()-y-17;
        int side=Math.max(84,Math.min(112,w/5));drawNavigation(g,mx,my,x,y,side,h);int cx=x+side+12,cw=w-side-12;
        if(!form.isEmpty())drawForm(g,mx,my,cx,y,cw,h);
        else if(!focus.isEmpty()&&tab.equals("agenda"))drawResolution(g,mx,my,cx,y,cw,h,data.getCompound("detail"));
        else if(selected!=null)drawSelected(g,mx,my,cx,y,cw,h);
        else if(tab.equals("overview")&&!organization.isEmpty())drawOverview(g,mx,my,cx,y,cw,h,p);
        else drawRows(g,mx,my,cx,y,cw,h);
        buttonAt(g,"НАЗАД",x,panel.footer(),78,Style.SECONDARY,this::onClose,mx,my);
        g.drawString(font,fit(busy?"Ожидание сервера…":notice,w-88),x+88,panel.footer()+7,DIM,false);
        for(var c:controls)if(font.width(c.label)>c.w-12&&inside(mx,my,c.x,c.y,c.w,c.h)){g.renderTooltip(font,Component.literal(c.label),mx,my);break;}
    }
    private void drawNavigation(GuiGraphics g,int mx,int my,int x,int y,int w,int h){
        var nav=new ArrayList<String[]>();if(!organization.isEmpty())nav.addAll(Arrays.asList(TABS));nav.add(new String[]{"catalog","Все организации"});nav.add(new String[]{"inbox","Приглашения"});nav.add(new String[]{"contexts","Сменить кабинет"});
        navScroll=Math.max(0,Math.min(navScroll,Math.max(0,nav.size()*27-h)));g.enableScissor(x,y,x+w,y+h);
        for(int i=0;i<nav.size();i++){String[] item=nav.get(i);int ry=y+i*27-navScroll;if(ry<y||ry+22>y+h)continue;boolean root=Set.of("catalog","inbox","contexts").contains(item[0]);buttonAt(g,fit(item[1],w-12),x,ry,w,tab.equals(item[0])?Style.CHOSEN:Style.SECONDARY,()->navigate(root?"":organization,item[0]),mx,my);}
        g.disableScissor();if(nav.size()*27>h)g.drawString(font,"↕",x+w-10,y+h-8,DIM,false);
    }
    private void drawOverview(GuiGraphics g,int mx,int my,int x,int y,int w,int h,CompoundTag p){
        int bodyH=Math.max(20,h-36);
        var description=font.split(Component.literal(p.getString("description").isBlank()?"Описание организации пока не заполнено.":p.getString("description")),w-24);
        int descriptionH=30+description.size()*12;
        int total=58+descriptionH+12+98+22;
        overviewMaxScroll=Math.max(0,total-bodyH);scroll=Math.max(0,Math.min(scroll,overviewMaxScroll));
        g.enableScissor(x,y,x+w,y+bodyH);int cy=y-scroll;
        int half=(w-8)/2;
        overviewCard(g,x,cy,half,48,"ПРЕДСЕДАТЕЛЬ",p.getString("chair"));
        overviewCard(g,x+half+8,cy,w-half-8,48,"ЗАМЕСТИТЕЛЬ",p.getString("deputy").isBlank()?"Не назначен":p.getString("deputy"));
        cy+=58;CivitasSurfaces.surface(g,x,cy,w,descriptionH,false,false);g.drawString(font,"ОБ ОРГАНИЗАЦИИ",x+12,cy+10,GOLD,false);
        for(int i=0;i<description.size();i++)g.drawString(font,description.get(i),x+12,cy+26+i*12,TEXT_LIGHT,false);
        cy+=descriptionH+12;CivitasSurfaces.surface(g,x,cy,w,98,false,false);g.drawString(font,"УСТАВ",x+12,cy+10,GOLD,false);
        String charter=p.getString("charter");var preview=font.split(Component.literal(charter.isBlank()?"Устав ещё не опубликован.":charter),w-24);
        for(int i=0;i<Math.min(3,preview.size());i++)g.drawString(font,preview.get(i),x+12,cy+27+i*12,DIM,false);
        clipTop=y;clipBottom=y+bodyH;
        buttonAt(g,charter.isBlank()?"ОТКРЫТЬ ДОКУМЕНТ":"ЧИТАТЬ УСТАВ",x+12,cy+66,Math.min(w-24,160),Style.SECONDARY,()->minecraft.setScreen(new OrganizationCharterScreen(this,p.getString("name"),charter)),mx,my);
        clipTop=Integer.MIN_VALUE;clipBottom=Integer.MAX_VALUE;
        cy+=110;g.drawString(font,"Основана: "+date(p.getLong("created")),x+4,cy,DIM,false);g.disableScissor();
        if(overviewMaxScroll>0){int thumb=Math.max(12,bodyH*bodyH/total),ty=y+(bodyH-thumb)*scroll/overviewMaxScroll;g.fill(x+w-3,y,x+w-1,y+bodyH,LINE);g.fill(x+w-3,ty,x+w-1,ty+thumb,GOLD);}
        int by=y+h-26;int bw=Math.max(50,(w-12)/3);
        if(internal()||data.getBoolean("admin"))buttonAt(g,"В кабинет",x,by,bw,Style.PRIMARY,()->{var f=new CompoundTag();f.putString("kind","org");send("context",organization,f);},mx,my);
        else if(p.getBoolean("invited")){buttonAt(g,"Вступить",x,by,bw,Style.PRIMARY,()->simple("join",""),mx,my);buttonAt(g,"Отклонить",x+bw+6,by,bw,Style.SECONDARY,()->simple("decline",""),mx,my);}
        if(has(OrganizationsData.PROFILE))buttonAt(g,"Профиль",x+bw+6,by,bw,Style.SECONDARY,()->start("profile","Название",p.getString("name"),"Описание",p.getString("description"),"Устав",p.getString("charter")),mx,my);
        buttonAt(g,"Действия",x+2*(bw+6),by,bw,Style.SECONDARY,()->start("actions"),mx,my);
    }
    private void overviewCard(GuiGraphics g,int x,int y,int w,int h,String heading,String value){
        CivitasSurfaces.surface(g,x,y,w,h,false,false);g.drawString(font,fit(heading,w-20),x+10,y+10,GOLD,false);g.drawString(font,fit(value,w-20),x+10,y+29,TEXT_LIGHT,false);
    }
    private void drawRows(GuiGraphics g,int mx,int my,int x,int y,int w,int h){
        int searchW=Math.max(40,w-62);search.setBounds(x,y,searchW,22);search.render(g,mx,my);buttonAt(g,"НАЙТИ",x+searchW+6,y,w-searchW-6,Style.SECONDARY,()->{query=search.value();page=0;scroll=0;request();},mx,my);
        int ry=y+30,rh=h-62;var rows=data.getList("rows",10);int rowH=43;scroll=Math.max(0,Math.min(scroll,Math.max(0,rows.size()*rowH-rh)));
        g.enableScissor(x,ry,x+w,ry+Math.max(10,rh));
        for(int i=0;i<rows.size();i++){var r=rows.getCompound(i);int yy=ry+i*rowH-scroll;boolean hot=inside(mx,my,x,yy,w,39)&&inside(mx,my,x,ry,w,rh);CivitasSurfaces.surface(g,x,yy,w,39,r.getBoolean("pending")||r.getBoolean("active"),hot);
            g.drawString(font,fit(r.getBoolean("active")?"✓ "+r.getString("title"):r.getString("title"),w-80),x+9,yy+7,r.getBoolean("pending")?GOLD:TEXT_LIGHT,false);
            String sub=r.getBoolean("pending")?"ЖДЁТ ВАШЕГО ГОЛОСА · "+r.getString("subtitle"):r.getString("subtitle");g.drawString(font,fit(sub,w-80),x+9,yy+23,DIM,false);
            if(yy>=ry&&yy+39<=ry+rh)buttonAt(g,"ВЫБРАТЬ",x+w-68,yy+9,61,r.getBoolean("pending")?Style.PRIMARY:Style.SECONDARY,()->choose(r),mx,my);
        }if(rows.isEmpty())g.drawString(font,fit(busy?"Загрузка…":"Здесь пока нет записей",w-16),x+8,ry+12,DIM,false);g.disableScissor();
        if(rows.size()*rowH>rh){int thumb=Math.max(12,rh*rh/(rows.size()*rowH));int ty=ry+(rh-thumb)*scroll/Math.max(1,rows.size()*rowH-rh);g.fill(x+w-3,ry,x+w-1,ry+rh,LINE);g.fill(x+w-3,ty,x+w-1,ty+thumb,GOLD);}
        int by=y+h-24;buttonAt(g,"←",x,by,28,page>0?Style.SECONDARY:Style.DISABLED,()->{if(page>0){page--;scroll=0;request();}},mx,my);
        buttonAt(g,"→",x+33,by,28,page+1<data.getInt("pages")?Style.SECONDARY:Style.DISABLED,()->{if(page+1<data.getInt("pages")){page++;scroll=0;request();}},mx,my);
        g.drawString(font,(page+1)+"/"+Math.max(1,data.getInt("pages"))+" · "+data.getInt("count"),x+68,by+7,DIM,false);
        String label="";Runnable add=null;
        if(organization.isEmpty()&&tab.equals("catalog")&&data.getBoolean("admin")){label="СОЗДАТЬ";add=()->start("create","Название","");}
        if(tab.equals("people")&&has(OrganizationsData.MEMBERS)){label="ПРИГЛАСИТЬ";add=()->navigate(organization,"invite");}
        if(tab.equals("roles")&&has(OrganizationsData.ROLES)){label="НОВАЯ РОЛЬ";add=()->{rightsMask=OrganizationsData.VOTE;start("role","Название роли","");};}
        if(tab.equals("states")){label="ЗАЯВКА СТРАНЫ";add=()->navigate(organization,"stateApply");}
        if(tab.equals("agenda")&&has(OrganizationsData.PROPOSE)){label="НОВЫЙ ПРОЕКТ";add=()->{statesVote=false;twoThirds=false;quorum=50;start("draft","Название резолюции","","Текст резолюции","");};}
        if(add!=null){int bw=Math.max(72,Math.min(128,w-150));buttonAt(g,label,x+w-bw,by,bw,Style.PRIMARY,add,mx,my);}
    }
    private void choose(CompoundTag row){
        String id=row.getString("id");switch(row.getString("kind")){
            case "organization", "invitation" -> navigate(id,"overview");
            case "state", "org" -> {var f=new CompoundTag();f.putString("kind",row.getString("kind"));send("context",id,f);}
            case "candidate" -> send("invite",id,new CompoundTag(),"people","");
            case "applyState" -> send("stateApply",id,new CompoundTag(),"states","");
            case "nominee" -> {var f=new CompoundTag();f.putString("person",id);send("delegate",focus,f,"states","");}
            case "role" -> {if(tab.equals("assignRole")){var f=new CompoundTag();f.putString("role",id);send("assign",focus,f,"people","");}else{selected=row.copy();}}
            case "resolution" -> {focus=id;selected=null;reader.setValue("");reader.scrollToStart();request();}
            default -> {selected=row.copy();reader.setValue("");reader.scrollToStart();}
        }
    }
    private void drawSelected(GuiGraphics g,int mx,int my,int x,int y,int w,int h){
        var r=selected;String kind=r.getString("kind"),id=r.getString("id");int by=y+h-25;
        if(kind.equals("person")){
            read(g,mx,my,x,y,w,h-65,r.getString("title")+"\n"+r.getString("subtitle")+"\n\nРОЛЬ\n"+r.getString("roleName")+"\n\n"+(r.getBoolean("online")?"Сейчас на сервере":"Не в сети")+"\n\nРоль определяет доступ только в этой организации.");
            int bw=Math.max(48,(w-12)/3);int upper=by-28;
            if(has(OrganizationsData.ROLES))buttonAt(g,"Роль",x,upper,bw,Style.SECONDARY,()->picker("assignRole",id),mx,my);
            if(data.getCompound("profile").getBoolean("head")){
                if(!r.getBoolean("chair")&&!r.getBoolean("deputy"))buttonAt(g,"Председатель",x+bw+6,upper,bw,Style.SECONDARY,()->confirm("chair",id,"Передать председательство",r.getString("title")),mx,my);
                if(!r.getBoolean("chair"))buttonAt(g,r.getBoolean("deputy")?"Освободить":"Заместитель",x+2*(bw+6),upper,bw,Style.SECONDARY,()->confirm(r.getBoolean("deputy")?"clearDeputy":"deputy",id,"Изменить заместителя",r.getString("title")),mx,my);
            }
            if(!r.getBoolean("chair")&&(has(OrganizationsData.MEMBERS)||id.equals(data.getString("me"))))buttonAt(g,id.equals(data.getString("me"))?"Выйти":"Исключить",x+w-98,by,98,Style.DANGER,()->confirm("remove",id,"Изменить состав",r.getString("title")),mx,my);
        }else if(kind.equals("role")){
            StringBuilder text=new StringBuilder(r.getString("title")+"\n\n");for(int i=0;i<OrganizationsData.RIGHTS.length;i++)text.append((r.getInt("rights")&(1<<i))!=0?"✓ ":"— ").append(OrganizationsData.RIGHTS[i]).append('\n');read(g,mx,my,x,y,w,h-35,text.toString());
            if(has(OrganizationsData.ROLES)){buttonAt(g,"ИЗМЕНИТЬ",x+w-190,by,90,Style.SECONDARY,()->{rightsMask=r.getInt("rights");start("role","Название роли",r.getString("title"));},mx,my);if(!id.equals("member"))buttonAt(g,"Удалить",x+w-94,by,94,Style.DANGER,()->confirm("deleteRole",id,"Удалить роль",r.getString("title")),mx,my);}
        }else{
            read(g,mx,my,x,y,w,h-35,r.getString("title")+"\n"+r.getString("subtitle")+(r.getLong("time")>0?"\n"+date(r.getLong("time")):"")+"\n\n"+r.getString("text"));
            if(kind.equals("delegation")){if(r.getBoolean("represent"))buttonAt(g,"Представитель",x+w-216,by,120,Style.SECONDARY,()->picker("nominate",id),mx,my);if(r.getBoolean("remove"))buttonAt(g,"Отозвать",x+w-90,by,90,Style.DANGER,()->confirm("stateRemove",id,"Отозвать делегацию",r.getString("title")),mx,my);}
            if(kind.equals("stateApplication")){buttonAt(g,"Принять",x+w-190,by,90,Style.PRIMARY,()->simple("stateAccept",id),mx,my);buttonAt(g,"Отклонить",x+w-94,by,94,Style.SECONDARY,()->simple("stateReject",id),mx,my);}
            if(kind.equals("ownApplication"))buttonAt(g,"Отозвать заявку",x+w-140,by,140,Style.SECONDARY,()->simple("stateWithdraw",id),mx,my);
            if(kind.equals("sentInvite"))buttonAt(g,"Отозвать",x+w-94,by,94,Style.SECONDARY,()->simple("revoke",id),mx,my);
        }
        buttonAt(g,"К списку",x,by,78,Style.SECONDARY,()->selected=null,mx,my);
    }
    private int unitIndex;
    private void drawResolution(GuiGraphics g,int mx,int my,int x,int y,int w,int h,CompoundTag r){
        if(r.isEmpty()){g.drawString(font,"Запись недоступна или удалена",x,y,DIM,false);buttonAt(g,"К повестке",x,y+20,100,Style.SECONDARY,()->{focus="";request();},mx,my);return;}
        String status=r.getString("status");boolean open=status.equals("OPEN"),draft=status.equals("DRAFT");
        String text=r.getString("title")+"\n"+r.getString("subtitle")+" · автор: "+r.getString("author")+"\n\n"+(r.getBoolean("states")?"Одно государство — один голос":"Личное голосование участников")+"\nКворум: "+r.getInt("quorum")+"% · большинство: "+(r.getBoolean("twoThirds")?"не менее 2/3":"больше голосов за, чем против")+"\n"+(draft?"Состав голосующих фиксируется при открытии.":"Состав: "+r.getInt("electorate")+" · нужно для кворума: "+r.getInt("required")+"\nДо: "+date(r.getLong("deadline"))+"\nЗа: "+r.getInt("yes")+" · против: "+r.getInt("no")+" · воздержались: "+r.getInt("abstain"))+"\n\n"+r.getString("text");
        buttonAt(g,"К повестке",x,y,100,Style.SECONDARY,()->{focus="";request();},mx,my);
        if((open||draft)&&r.getBoolean("session"))buttonAt(g,"Снять с повестки",x+w-130,y,130,Style.SECONDARY,()->confirm("cancel",focus,"Снять резолюцию",r.getString("title")),mx,my);
        int extra=open?62:36;read(g,mx,my,x,y+29,w,h-extra-29,text);int by=y+h-25;int bw=Math.max(48,(w-12)/3);
        if(open){var units=r.getList("units",10);if(!units.isEmpty()){unitIndex=Math.floorMod(unitIndex,units.size());var unit=units.getCompound(unitIndex);int uy=by-29;
                buttonAt(g,fit(unit.getString("name"),w-12)+(units.size()>1?" ▸":""),x,uy,w,Style.SECONDARY,()->unitIndex=(unitIndex+1)%units.size(),mx,my);
                if(!unit.getBoolean("voted")){for(int i=0;i<3;i++){int choice=i==0?1:i==1?0:2;String label=i==0?"ЗА":i==1?"ПРОТИВ":"ВОЗДЕРЖАТЬСЯ";buttonAt(g,label,x+i*(bw+6),by,bw,i==0?Style.PRIMARY:Style.SECONDARY,()->{var f=new CompoundTag();f.putString("unit",unit.getString("id"));f.putInt("choice",choice);send("vote",focus,f);},mx,my);}}
                else g.drawString(font,"Голос принят: "+(unit.getInt("vote")==1?"за":unit.getInt("vote")==0?"против":"воздержался"),x,by+6,GOLD,false);
            }else g.drawString(font,"У вас нет мандата в этом составе",x,by+6,DIM,false);
        }else if(draft&&r.getBoolean("session")){
            buttonAt(g,"Срок: "+hours+" ч ▸",x,by,Math.min(128,w/2),Style.SECONDARY,()->{int[] options={1,6,12,24,48,72,168};int at=0;while(at<options.length&&options[at]!=hours)at++;hours=options[(at+1)%options.length];},mx,my);
            buttonAt(g,"ОТКРЫТЬ ГОЛОСОВАНИЕ",x+w-Math.min(190,w/2)+6,by,Math.min(190,w/2)-6,Style.PRIMARY,()->{var f=new CompoundTag();f.putInt("hours",hours);send("open",focus,f);},mx,my);
        }else buttonAt(g,"К повестке",x,by,100,Style.SECONDARY,()->{focus="";scroll=0;request();},mx,my);

    }
    private String confirmOp="",confirmTarget="",confirmTitle="",confirmText="";
    private void confirm(String op,String target,String title,String text){confirmOp=op;confirmTarget=target;confirmTitle=title;confirmText=text;start("confirm");}
    private void drawForm(GuiGraphics g,int mx,int my,int x,int y,int w,int h){
        int by=y+h-25;
        if(form.equals("actions")){
            int yy=y;
            if(has(OrganizationsData.MEMBERS)){buttonAt(g,"Активные приглашения",x,yy,w,Style.SECONDARY,()->navigate(organization,"sentInvites"),mx,my);yy+=29;}
            if(data.getCompound("profile").getBoolean("directMember")){buttonAt(g,"Выйти из организации",x,yy,w,Style.DANGER,()->confirm("remove",data.getString("me"),"Покинуть организацию",data.getCompound("profile").getString("name")),mx,my);yy+=29;}
            if(data.getBoolean("admin"))buttonAt(g,"Удалить организацию",x,yy,w,Style.DANGER,()->start("delete","Точное название", ""),mx,my);
        }else if(form.equals("confirm")){
            read(g,mx,my,x,y,w,h-35,confirmTitle+"\n\n"+confirmText+"\n\nДействие изменит данные на сервере.");buttonAt(g,"ПОДТВЕРДИТЬ",x+w-126,by,126,Style.DANGER,()->simple(confirmOp,confirmTarget),mx,my);
        }else{
            int virtualH=Math.max(h,form.equals("role")?225:form.equals("draft")||form.equals("profile")?245:100);
            formMaxScroll=Math.max(0,virtualH-h);formScroll=Math.max(0,Math.min(formScroll,formMaxScroll));int contentY=y-formScroll;
            clipTop=y;clipBottom=by-8;g.enableScissor(x-1,y,x+w+1,by-8);
            int reserve=form.equals("draft")?65:form.equals("role")?116:0;int usable=Math.max(25,virtualH-38-reserve);int yy=contentY;
            for(int i=0;i<inputs.size();i++){TextInput input=inputs.get(i);String label=labels.get(i);int fieldH;
                if(inputs.size()==1)fieldH=22;
                else if(i==inputs.size()-1)fieldH=Math.max(20,contentY+usable-yy-14);
                else fieldH=label.contains("Описание")?Math.min(50,Math.max(22,usable/4)):22;
                g.drawString(font,label,x,yy,GOLD,false);input.setBounds(x,yy+13,w,Math.max(20,fieldH));input.render(g,mx,my);yy+=fieldH+21;
            }
            if(form.equals("draft")){int cy=contentY+virtualH-91;int half=(w-6)/2;
                buttonAt(g,statesVote?"Голосуют государства":"Голосуют участники",x,cy,w,Style.CHOSEN,()->statesVote=!statesVote,mx,my);
                buttonAt(g,"Кворум: "+quorum+"% ▸",x,cy+27,half,Style.SECONDARY,()->{int[] q={25,50,66,75,100};int at=0;while(at<q.length&&q[at]!=quorum)at++;quorum=q[(at+1)%q.length];},mx,my);
                buttonAt(g,twoThirds?"Большинство: 2/3":"Простое большинство",x+half+6,cy+27,half,Style.SECONDARY,()->twoThirds=!twoThirds,mx,my);
            }
            if(form.equals("role")){int cy=contentY+virtualH-145;int half=(w-6)/2;for(int i=0;i<OrganizationsData.RIGHTS.length;i++){int bit=1<<i;buttonAt(g,((rightsMask&bit)!=0?"✓ ":"— ")+OrganizationsData.RIGHTS[i],x+(i%2)*(half+6),cy+(i/2)*27,half,(rightsMask&bit)!=0?Style.CHOSEN:Style.SECONDARY,()->rightsMask^=bit,mx,my);}}
            g.disableScissor();clipTop=Integer.MIN_VALUE;clipBottom=Integer.MAX_VALUE;
            if(virtualH>h){int track=h-36,thumb=Math.max(12,track*track/(virtualH-36));int ty=y+(track-thumb)*formScroll/Math.max(1,virtualH-h);g.fill(x+w+2,y,x+w+4,y+track,LINE);g.fill(x+w+2,ty,x+w+4,ty+thumb,GOLD);}
            buttonAt(g,form.equals("draft")?"ВНЕСТИ ПРОЕКТ":form.equals("delete")?"УДАЛИТЬ":"СОХРАНИТЬ",x+w-130,by,130,form.equals("delete")?Style.DANGER:Style.PRIMARY,this::saveForm,mx,my);
        }
        buttonAt(g,"ОТМЕНА",x,by,86,Style.SECONDARY,()->{form="";inputs.clear();},mx,my);
    }
    private void saveForm(){var f=new CompoundTag();switch(form){
        case "create" -> {f.putString("name",inputs.get(0).value());send("create","",f);}
        case "profile" -> {f.putString("name",inputs.get(0).value());f.putString("description",inputs.get(1).value());f.putString("charter",inputs.get(2).value());send("profile","",f,"overview","");}
        case "role" -> {f.putString("name",inputs.get(0).value());f.putInt("rights",rightsMask);send("role",editingRole,f,"roles","");}
        case "draft" -> {f.putString("title",inputs.get(0).value());f.putString("body",inputs.get(1).value());f.putBoolean("states",statesVote);f.putInt("quorum",quorum);f.putBoolean("twoThirds",twoThirds);send("draft","",f,"agenda","");}
        case "delete" -> {f.putString("confirmation",inputs.get(0).value());send("delete","",f);}
    }}
    @Override public boolean mouseClicked(double x,double y,int button){if(button!=0)return false;for(var c:controls)if(inside(x,y,c.x,c.y,c.w,c.h)){if(!busy&&c.style!=Style.DISABLED)c.action.run();return true;}if(busy)return true;if(!form.isEmpty()){boolean result=false;for(var input:inputs)result=input.mouseClicked(x,y)||result;return result;}if(selected!=null||!focus.isEmpty()||tab.equals("overview"))return reader.mouseClicked(x,y);return search.mouseClicked(x,y);}
    @Override public boolean mouseDragged(double x,double y,int b,double dx,double dy){if(!form.isEmpty()){for(var input:inputs)if(input.mouseDragged(x,y))return true;return false;}return reader.mouseDragged(x,y);}
    @Override public boolean mouseScrolled(double x,double y,double dx,double dy){int side=Math.max(84,Math.min(112,(panel.w-28)/5));if(x<panel.x+14+side){navScroll-=Math.round((float)dy*27);return true;}if(!form.isEmpty()){
            int next=Math.max(0,Math.min(formMaxScroll,formScroll-Math.round((float)dy*24)));
            if(next!=formScroll&&!hasShiftDown()){formScroll=next;return true;}
            for(var input:inputs)if(input.mouseScrolled(x,y,dy))return true;
            formScroll=next;return true;
        }if(selected==null&&focus.isEmpty()&&tab.equals("overview")&&!organization.isEmpty()){scroll=Math.max(0,Math.min(overviewMaxScroll,scroll-Math.round((float)dy*24)));return true;}if(selected!=null||!focus.isEmpty())return reader.mouseScrolled(x,y,dy);scroll-=Math.round((float)dy*24);return true;}
    @Override public boolean charTyped(char c,int mods){if(busy)return false;if(!form.isEmpty()){for(var input:inputs)if(input.charTyped(c))return true;return false;}return search.charTyped(c);}
    @Override public boolean keyPressed(int key,int scan,int mods){if(key==GLFW.GLFW_KEY_ESCAPE){onClose();return true;}if(busy)return true;if(key==GLFW.GLFW_KEY_TAB&&!inputs.isEmpty()){int at=0;for(int i=0;i<inputs.size();i++)if(inputs.get(i).focused)at=i;inputs.forEach(i->i.focused=false);inputs.get((at+1)%inputs.size()).focused=true;return true;}if(!form.isEmpty()){for(var input:inputs)if(input.keyPressed(key,mods))return true;return false;}if(key==GLFW.GLFW_KEY_ENTER&&search.focused){query=search.value();page=0;scroll=0;request();return true;}return search.keyPressed(key,mods);}
    @Override public void onClose(){if(busy){minecraft.setScreen(parent);return;}if(!form.isEmpty()){form="";inputs.clear();return;}if(selected!=null){selected=null;return;}if(!focus.isEmpty()&&tab.equals("agenda")){focus="";request();return;}if(Set.of("invite","sentInvites","assignRole","nominate","stateApply").contains(tab)){navigate(organization,tab.equals("stateApply")||tab.equals("nominate")?"states":"people");return;}minecraft.setScreen(parent);}
    @Override public boolean isPauseScreen(){return false;}
    @Override public void renderBackground(GuiGraphics g,int mx,int my,float partial){}
}
