package com.humanitas.client;

import net.minecraft.client.gui.GuiGraphics;
import static com.humanitas.client.CivitasUi.*;

/** Compact equipment surfaces; item bounds and menu interaction remain vanilla. */
public final class CivitasEquipmentStyle {
    private CivitasEquipmentStyle() {}

    public static void cell(GuiGraphics g,int x,int y,int size,boolean result,boolean selected) {
        int edge=selected?GOLD:mix(PLATE,TEXT_LIGHT,result?0.32F:0.16F);
        CivitasSurfaces.cut(g,x,y,size,size,edge);
        CivitasSurfaces.cut(g,x+1,y+1,size-2,size-2,
                mix(PLATE_DEEP,selected?GOLD:TEXT_LIGHT,selected?0.12F:0.025F));
        g.fill(x+3,y+1,x+size-3,y+2,mix(edge,TEXT_LIGHT,0.12F));
        if(result||selected) {
            g.fill(x+4,y+size-2,x+size-4,y+size-1,GOLD);
        }
        if(selected) {
            g.fill(x+1,y+3,x+2,y+7,GOLD);
            g.fill(x+size-2,y+size-7,x+size-1,y+size-3,GOLD);
        }
    }

    public static void divider(GuiGraphics g,int x,int y,int w) {
        int center=x+w/2;
        int edge=mix(PLATE,TEXT_LIGHT,0.16F);
        g.fill(x,y,center-7,y+1,edge);
        g.fill(center+7,y,x+w,y+1,edge);
        g.fill(center-4,y,center+4,y+1,GOLD_DEEP);
        g.fill(center-1,y-1,center+1,y+2,GOLD);
    }

    public static void portrait(GuiGraphics g,int x,int y,int w,int h) {
        CivitasSurfaces.surface(g,x-1,y-1,w+2,h+2,false,false);
        CivitasSurfaces.cut(g,x,y,w,h,PLATE_DEEP);
        g.fillGradient(x+1,y+1,x+w-1,y+h-1,mix(PLATE,GOLD,0.07F),PLATE_DEEP);
        g.fill(x+5,y+2,x+13,y+3,GOLD_DEEP);
        g.fill(x+w-13,y+h-3,x+w-5,y+h-2,GOLD_DEEP);
    }

    public static void craftingArrow(GuiGraphics g,int x,int y) {
        g.fill(x,y+3,x+12,y+4,mix(PLATE,TEXT_LIGHT,0.40F));
        CivitasSurfaces.pixels(g,new String[]{"X...","XX..","XXX.","XXXX","XXX.","XX..","X..."},x+10,y,1,GOLD);
    }
}
