package com.humanitas.client;

import net.minecraft.nbt.*;
import java.util.*;

/** A ballot needing the viewer's decision precedes already cast ballots and completed votes. */
public final class LawOrder {
    private LawOrder() {}
    public static boolean waiting(CompoundTag bill) { return !bill.getBoolean("closed") && bill.getBoolean("canVote") && bill.getString("mine").isEmpty(); }
    public static int group(CompoundTag bill) { return bill.getBoolean("closed") ? 3 : waiting(bill) ? 0 : bill.getString("mine").isEmpty() ? 1 : 2; }
    public static List<CompoundTag> sorted(ListTag list) {
        List<CompoundTag> result=new ArrayList<>();for(int i=0;i<list.size();i++)result.add(list.getCompound(i));
        result.sort(Comparator.comparingInt(LawOrder::group).thenComparing(Comparator.comparingInt((CompoundTag b)->b.getInt("id")).reversed()));return result;
    }
}
