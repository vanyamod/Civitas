package com.humanitas.client;

import com.humanitas.CivitasClientConfig;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.resources.ResourceLocation;
import java.util.Set;
import static com.humanitas.client.CivitasUi.*;

/** Shared recipe-book rendering, including categories, filters, navigation and recipe alternatives. */
public final class CivitasRecipeStyle {
    private CivitasRecipeStyle() {}
    public enum Part { NONE, TAB, FILTER, FORWARD, BACKWARD, BOOK, SLOT, OVERLAY }
    private static final Set<String> FILTERS=Set.of("filter_enabled","filter_disabled","filter_enabled_highlighted","filter_disabled_highlighted",
        "furnace_filter_enabled","furnace_filter_disabled","furnace_filter_enabled_highlighted","furnace_filter_disabled_highlighted");
    private static final Set<String> SLOTS=Set.of("slot_craftable","slot_uncraftable","slot_many_craftable","slot_many_uncraftable",
        "crafting_overlay","crafting_overlay_highlighted","crafting_overlay_disabled","crafting_overlay_disabled_highlighted",
        "furnace_overlay","furnace_overlay_highlighted","furnace_overlay_disabled","furnace_overlay_disabled_highlighted");
    public static boolean enabled() { try { return CivitasClientConfig.CUSTOM_INVENTORY.get(); } catch(RuntimeException e) { return false; } }
    public static Part part(ResourceLocation sprite) {
        if(!sprite.getNamespace().equals("minecraft")||!sprite.getPath().startsWith("recipe_book/"))return Part.NONE;
        String name=sprite.getPath().substring("recipe_book/".length());
        if(FILTERS.contains(name))return Part.FILTER;
        if(SLOTS.contains(name))return Part.SLOT;
        return switch(name) {
            case "tab","tab_selected" -> Part.TAB;
            case "page_forward","page_forward_highlighted" -> Part.FORWARD;
            case "page_backward","page_backward_highlighted" -> Part.BACKWARD;
            case "button","button_highlighted" -> Part.BOOK;
            case "overlay_recipe" -> Part.OVERLAY;
            default -> Part.NONE;
        };
    }
    public static boolean supported(ResourceLocation sprite) { return part(sprite)!=Part.NONE; }
    public static void background(GuiGraphics g,int x,int y,int w,int h) { CivitasSurfaces.panel(g,x,y,w,h); }
    public static void prepareSearch(EditBox search) {
        if(search==null||!enabled())return;
        search.setBordered(false);search.setX(search.getX()+4);search.setY(search.getY()+3);
        search.setWidth(search.getWidth()-8);search.setHeight(search.getHeight()-6);
    }
    public static void search(GuiGraphics g,EditBox search) {
        CivitasSurfaces.field(g,search.getX()-4,search.getY()-3,search.getWidth()+8,search.getHeight()+6,search.isFocused());
        search.setTextColor(TEXT_LIGHT&0xFFFFFF);search.setTextColorUneditable(DIM&0xFFFFFF);
        search.setHint(net.minecraft.network.chat.Component.translatable("gui.recipebook.search_hint").withStyle(s->s.withColor(DIM&0xFFFFFF).withItalic(true)));
    }
    public static void slot(GuiGraphics g,ResourceLocation sprite,int x,int y,int w,int h) {
        String path=sprite.getPath(); boolean craftable=!path.contains("uncraftable")&&!path.contains("disabled");
        CivitasSurfaces.surface(g,x,y,w,h,false,path.contains("highlighted"));
        g.fill(x+4,y+h-2,x+w-4,y+h-1,craftable?GOLD:CivitasColors.mix(PLATE,TEXT_LIGHT,0.20F));
        if(path.contains("many")) {g.fill(x+w-5,y+3,x+w-3,y+4,GOLD);g.fill(x+w-4,y+4,x+w-3,y+6,GOLD);}
    }
    public static void widget(GuiGraphics g,ResourceLocation sprite,int x,int y,int w,int h) {
        Part part=part(sprite);String path=sprite.getPath();boolean hot=path.endsWith("highlighted");
        if(part==Part.OVERLAY){background(g,x,y,w,h);return;}
        if(part==Part.SLOT){slot(g,sprite,x,y,w,h);return;}
        boolean selected=part==Part.TAB&&path.endsWith("tab_selected") || part==Part.FILTER&&path.contains("filter_enabled");
        CivitasSurfaces.surface(g,x,y,w,h,selected,hot);
        int color=selected||hot?GOLD:TEXT_LIGHT;
        String[] icon=switch(part) {
            case FORWARD -> new String[]{"X....","XX...","XXX..","XXXX.","XXX..","XX...","X...."};
            case BACKWARD -> new String[]{"....X","...XX","..XXX",".XXXX","..XXX","...XX","....X"};
            case FILTER -> selected?new String[]{"XXXXXXXXX",".X.....X.","..X...X..","...X.X...","....X....","....X....","....X...."}
                :new String[]{"XX.XXXXXX",".........","XX.XXXXXX",".........","XX.XXXXXX",".........","XX.XXXXXX"};
            case BOOK -> new String[]{".XXXX.XXXX.","X....X....X","X.XX.X.XX.X","X....X....X","X.XX.X.XX.X","X....X....X",".XXXX.XXXX."};
            default -> new String[0];
        };
        if(icon.length>0)CivitasSurfaces.pixels(g,icon,x+(w-icon[0].length())/2,y+(h-icon.length)/2,1,color);
    }
}
