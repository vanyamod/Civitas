package com.humanitas.client;

import net.minecraft.client.Minecraft;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/**
 * Client settings of the Civitas wheel. Stored in config/civitas-settings.properties, so they
 * survive a restart.
 */
public final class CivitasSettings {
    private static final Properties PROPS = new Properties();
    private static boolean loaded = false;
    private static int backdrop = 60;
    private static int sound = 70;
    private static boolean labelsAlways = true;
    private static boolean reducedMotion = false;
    private static boolean rememberWindows = true;

    private CivitasSettings() {}

    private static void load() {
        if (loaded) return;
        loaded = true;
        Path path = file();
        if (Files.isRegularFile(path)) {
            try (InputStream in = Files.newInputStream(path)) {
                PROPS.load(in);
            } catch (IOException ignored) {
                // start with the defaults
            }
        }
        backdrop = readInt("backdrop", backdrop);
        sound = readInt("sound", sound);
        labelsAlways = Boolean.parseBoolean(PROPS.getProperty("labelsAlways", "true"));
        reducedMotion = Boolean.parseBoolean(PROPS.getProperty("reducedMotion", "false"));
        rememberWindows = Boolean.parseBoolean(PROPS.getProperty("rememberWindows", "true"));
    }

    private static int readInt(String key, int def) {
        try {
            return Integer.parseInt(PROPS.getProperty(key, Integer.toString(def)));
        } catch (NumberFormatException e) {
            return def;
        }
    }

    private static Path file() {
        return Minecraft.getInstance().gameDirectory.toPath()
                .resolve("config").resolve("civitas-settings.properties");
    }

    private static void save() {
        PROPS.setProperty("backdrop", Integer.toString(backdrop));
        PROPS.setProperty("sound", Integer.toString(sound));
        PROPS.setProperty("labelsAlways", Boolean.toString(labelsAlways));
        PROPS.setProperty("reducedMotion", Boolean.toString(reducedMotion));
        PROPS.setProperty("rememberWindows", Boolean.toString(rememberWindows));
        Path path = file();
        try {
            Files.createDirectories(path.getParent());
            try (OutputStream out = Files.newOutputStream(path)) {
                PROPS.store(out, "Civitas client settings");
            }
        } catch (IOException ignored) {
            // not critical: the settings still apply for this session
        }
    }

    public static void resetDefaults() {
        loaded=true; PROPS.clear(); backdrop=60; sound=70; labelsAlways=true; reducedMotion=false; rememberWindows=true; save();
        var cfg=com.humanitas.CivitasClientConfig.SPEC;
        com.humanitas.CivitasClientConfig.CUSTOM_HOTBAR.set(true);
        com.humanitas.CivitasClientConfig.CUSTOM_INVENTORY.set(true);
        com.humanitas.CivitasClientConfig.WHEEL_GUI.set(true);
        com.humanitas.CivitasClientConfig.STATUS_STYLE.set("bars");
        com.humanitas.CivitasClientConfig.PALETTE.set("graphite");
        com.humanitas.CivitasClientConfig.HUD_VISIBLE.set(true);
        com.humanitas.CivitasClientConfig.CUSTOM_COLORS.set("16171A,F2EAD6,D4AF37,6B7F3A");
        cfg.save(); CivitasPaletteState.load();
    }

    private static int clamp(int v) {
        return Math.max(0, Math.min(100, v));
    }

    /** Darkness of the backdrop behind the wheel, 0 to 100 percent. */
    public static int backdropPercent() {
        load();
        return backdrop;
    }

    public static void setBackdropPercent(int value) {
        load();
        backdrop = clamp(value);
        save();
    }

    /** Volume of the Civitas UI clicks, 0 to 100 percent. */
    public static int soundPercent() {
        load();
        return sound;
    }

    public static void setSoundPercent(int value) {
        load();
        sound = clamp(value);
        save();
    }

    /** When off, a medallion's label is shown only while the cursor is over it. */
    public static boolean labelsAlways() {
        load();
        return labelsAlways;
    }

    public static void toggleLabelsAlways() {
        load();
        labelsAlways = !labelsAlways;
        save();
    }
    public static boolean reducedMotion(){load();return reducedMotion;}
    public static void toggleReducedMotion(){load();reducedMotion=!reducedMotion;save();}
    public static boolean rememberWindows(){load();return rememberWindows;}
    public static void toggleRememberWindows(){load();rememberWindows=!rememberWindows;save();}
}
