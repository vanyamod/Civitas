package com.humanitas.client;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

/**
 * One palette and one button look for the whole mod. Every field is mutable: {@link #applyPalette}
 * swaps the whole set of colours at once, so changing the palette recolours every screen that reads
 * these values. The fields are deliberately not {@code final}, otherwise the compiler would inline
 * their values and the swap could not take effect.
 */
public final class CivitasUi {
    private CivitasUi() {}

    public static int HEADER;
    public static int CREAM;
    public static int CREAM_CARD;
    public static int CREAM_DEEP;
    public static int CREAM_HOVER;
    public static int CREAM_ACTIVE;
    public static int FIELD;
    public static int GOLD;
    public static int GOLD_DEEP;
    public static int OLIVE;
    public static int INK;
    public static int MUTED;
    public static int TEXT_LIGHT;
    public static int BACKDROP;
    public static int SCRIM;

    public static int PLATE;
    public static int PLATE_SOLID;
    public static int PLATE_DEEP;
    public static int PANEL;
    public static int CELL_LINE;
    public static int SELECT_FILL;
    public static int DIM;
    public static int LINE;
    public static int ICON_EMPTY;
    public static int HEART;
    public static int HEART_POISON;
    public static int HEART_WITHER;
    public static int HEART_FROZEN;
    public static int HEART_ABSORB;
    public static int HEART_MOUNT;
    public static int SHIELD;
    public static int FOOD_COLOR;
    public static int FOOD_HUNGER;
    public static int AIR_COLOR;
    public static int SLOT_EDGE;
    public static int SLOT_FILL;
    public static int SLOT_RESULT;
    public static int SLOT_LIGHT;
    public static int SLOT_SHADE = 0x50000000;
    public static int PORTRAIT;
    public static int RULE;
    public static int HOVER;
    public static int HIGHLIGHT;

    public enum Style {
        PRIMARY, SECONDARY, DANGER, CHOSEN, DISABLED
    }

    static {
        applyPalette(CivitasPalette.GRAPHITE);
    }

    /** Swaps every colour to the given palette. */
    public static void applyPalette(CivitasPalette p) {
        // Panels are deliberately opaque: a translucent body lets wheel labels and list rows
        // bleed through the plate, which looks like a rendering bug. Opaque colours keep every
        // window readable no matter what is drawn underneath it.
        HEADER = p.plate();
        CREAM = p.paper();
        CREAM_CARD = p.paperCard();
        CREAM_DEEP = p.paperDeep();
        CREAM_HOVER = p.paperHover();
        CREAM_ACTIVE = p.paperActive();
        FIELD = p.field();
        GOLD = p.metal();
        GOLD_DEEP = p.metalDeep();
        OLIVE = p.accent();
        INK = p.ink();
        MUTED = p.muted();
        TEXT_LIGHT = p.text();
        BACKDROP = CivitasColors.alpha(p.plateDeep(), 0x99);
        SCRIM = CivitasColors.alpha(p.plateDeep(), 0xB4);

        PLATE = p.plate();
        PLATE_SOLID = p.plate();
        PLATE_DEEP = p.plateDeep();
        PANEL = p.plate();
        CELL_LINE = CivitasColors.alpha(p.metal(), 0x40);
        SELECT_FILL = CivitasColors.alpha(p.paper(), 0x4C);
        DIM = CivitasColors.mix(p.muted(), p.metal(), 0.45F);
        LINE = CivitasColors.alpha(p.metal(), 0x30);
        ICON_EMPTY = CivitasColors.alpha(p.accent(), 0x9A);
        HEART = p.life();
        HEART_POISON = p.lifeAlt();
        HEART_WITHER = p.lifeWither();
        HEART_FROZEN = p.lifeCold();
        HEART_ABSORB = p.lifeAbsorb();
        HEART_MOUNT = p.lifeMount();
        SHIELD = p.shield();
        FOOD_COLOR = p.food();
        FOOD_HUNGER = p.foodBad();
        AIR_COLOR = p.air();
        SLOT_EDGE = p.slotEdge();
        SLOT_FILL = p.slot();
        SLOT_RESULT = p.slotResult();
        SLOT_LIGHT = CivitasColors.alpha(p.paper(), 0x22);
        PORTRAIT = p.portrait();
        RULE = CivitasColors.alpha(p.metal(), 0x66);
        HOVER = CivitasColors.alpha(p.metal(), 0x60);
        HIGHLIGHT = CivitasColors.alpha(p.paperActive(), 0x70);
    }

    public static void button(GuiGraphics g, Font font, int x, int y, int w, int h,
                               String label, boolean hot, Style style) {
        button(g, font, x, y, w, h, Component.literal(label), hot, style);
    }

    public static void button(GuiGraphics g, Font font, int x, int y, int w, int h,
                               Component label, boolean hot, Style style) {
        CivitasSurfaces.button(g,font,x,y,w,h,label,hot,style);
    }

    /** Shared modal plate, matching the diplomacy desk. */
    public static void panel(GuiGraphics g,int x,int y,int w,int h) { CivitasSurfaces.panel(g,x,y,w,h); }

    /** Transparent inventory frame; leaves slots and item renderers untouched. */
    public static void frame(GuiGraphics g,int x,int y,int w,int h) { CivitasSurfaces.frame(g,x,y,w,h); }

    /** Centre the glyph's font advance box consistently in all medallions. */
    public static void icon(GuiGraphics g, Font font, String symbol, float cx, float cy, float scale, int colour) {
        float w = Math.max(0, font.width(symbol) - 1) * scale;
        float h = (font.lineHeight - 1) * scale;
        // The font advance box is not the same as the visible pixels: several Minecraft
        // glyphs have asymmetric bearings or empty rows. Offsets are in font pixels.
        float dx = switch (symbol) {
            case "☰", "⌂", "✎", "⚑" -> 0.28F;
            case "⚔" -> 0.46F;
            case "✉", "☺", "◆", "✒" -> 0.18F;
            case "⚐" -> 0.38F;
            default -> 0F;
        };
        float dy = switch (symbol) {
            case "⌂" -> 1.20F;
            case "⚔", "✎" -> 1.02F;
            case "☺" -> 0.74F;
            case "☰" -> 0.56F;
            case "✉" -> 0.46F;
            case "✒" -> 0.37F;
            case "⚙", "◆", "⚑", "⚖", "⚜" -> 0.20F;
            case "⚐" -> 1.25F;
            default -> 0F;
        };
        float x = cx - w / 2F + dx * scale;
        float y = cy - h / 2F + dy * scale;
        g.pose().pushPose();
        g.pose().translate(x, y, 0);
        g.pose().scale(scale, scale, 1F);
        g.drawString(font, symbol, 0, 0, colour, false);
        g.pose().popPose();
    }

    public static boolean inside(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    public static int alpha(int colour, int a) { return CivitasColors.alpha(colour, a); }
    public static int mix(int a, int b, float t) { return CivitasColors.mix(a, b, t); }
}
