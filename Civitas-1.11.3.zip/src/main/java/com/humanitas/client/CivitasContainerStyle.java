package com.humanitas.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.screens.inventory.ContainerScreen;
import net.minecraft.client.gui.screens.inventory.DispenserScreen;
import net.minecraft.client.gui.screens.inventory.HopperScreen;
import net.minecraft.client.gui.screens.inventory.ShulkerBoxScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.inventory.DispenserMenu;
import net.minecraft.world.inventory.HopperMenu;
import net.minecraft.world.inventory.ShulkerBoxMenu;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.entity.player.Inventory;

import static com.humanitas.client.CivitasUi.*;

/**
 * The Civitas look for the vanilla storage screens. The plate, rim, cells and seam are the same as the
 * Civitas player inventory, so a chest, a shulker box and the inventory read as one set. The storage
 * part sits above the seam, the player's own inventory below it.
 *
 * <p>Each screen is a thin subclass of the vanilla screen, so slots, clicks, tooltips and sorting keep
 * their stock behaviour. Only the background, the labels and the slot highlight are replaced.</p>
 */
public final class CivitasContainerStyle {
    private CivitasContainerStyle() {}

    /** Plate, gold rim with mitered corners, inner rule and corner studs. Same as the Civitas inventory. */
    static void drawPlate(GuiGraphics g, int x, int y, int w, int h) {
        CivitasSurfaces.panel(g,x,y,w,h);
    }

    /** Every active slot of the menu, storage and player alike, as a Civitas cell. */
    static void drawCells(GuiGraphics g, AbstractContainerScreen<?> screen, int x, int y) {
        for (Slot slot : screen.getMenu().slots) {
            if (!slot.isActive()) continue;
            CivitasEquipmentStyle.cell(g,x+slot.x-1,y+slot.y-1,18,false,false);
        }
    }

    /**
     * The gold seam between the storage and the player's inventory. The player's block starts 82 pixels
     * above the bottom of the vanilla screen, so the seam sits 6 pixels above it.
     */
    static void drawSeam(GuiGraphics g, int x, int y, int w, int h) {
        CivitasEquipmentStyle.divider(g,x+8,y+h-88,w-16);
    }

    /** Background of any storage screen: the plate, the cells and the seam. */
    static void background(GuiGraphics g, AbstractContainerScreen<?> screen, int x, int y, int w, int h) {
        drawPlate(g, x, y, w, h);
        g.fill(x+4,y+4,x+w-4,y+17,mix(PLATE,TEXT_LIGHT,0.035F));
        g.fill(x+8,y+16,x+w-8,y+17,mix(PLATE,TEXT_LIGHT,0.14F));
        drawCells(g, screen, x, y);
        drawSeam(g, x, y, w, h);
    }

    /** The screen title in cream, in the place vanilla uses. The player label is left out, as in the Civitas inventory. */
    static void drawTitle(GuiGraphics g, Component title) {
        g.drawString(Minecraft.getInstance().font, title, 8, 6, TEXT_LIGHT, false);
    }

    /** Hover highlight of a cell, the same colour as the Civitas inventory. */
    static boolean highlightable(Slot slot) {
        return slot.isHighlightable();
    }

    // ---------- screens ----------

    /** Chests, barrels and the ender chest. */
    public static final class Chest extends ContainerScreen {
        public Chest(ChestMenu menu, Inventory inventory, Component title) {
            super(menu, inventory, title);
        }

        @Override
        protected void renderBg(GuiGraphics g, float partialTick, int mouseX, int mouseY) {
            background(g, this, this.leftPos, this.topPos, this.imageWidth, this.imageHeight);
        }

        @Override
        protected void renderLabels(GuiGraphics g, int mouseX, int mouseY) {
            drawTitle(g, this.getTitle());
        }

        @Override
        protected void renderSlotHighlight(GuiGraphics g, Slot slot, int mouseX, int mouseY, float partialTick) {
            if (highlightable(slot)) {
                renderSlotHighlight(g, slot.x, slot.y, 0, HOVER);
            }
        }
    }

    /** Shulker boxes, in every colour. */
    public static final class Shulker extends ShulkerBoxScreen {
        public Shulker(ShulkerBoxMenu menu, Inventory inventory, Component title) {
            super(menu, inventory, title);
        }

        @Override
        protected void renderBg(GuiGraphics g, float partialTick, int mouseX, int mouseY) {
            background(g, this, this.leftPos, this.topPos, this.imageWidth, this.imageHeight);
        }

        @Override
        protected void renderLabels(GuiGraphics g, int mouseX, int mouseY) {
            drawTitle(g, this.getTitle());
        }

        @Override
        protected void renderSlotHighlight(GuiGraphics g, Slot slot, int mouseX, int mouseY, float partialTick) {
            if (highlightable(slot)) {
                renderSlotHighlight(g, slot.x, slot.y, 0, HOVER);
            }
        }
    }

    /** Hoppers: a single row of five cells. */
    public static final class Hopper extends HopperScreen {
        public Hopper(HopperMenu menu, Inventory inventory, Component title) {
            super(menu, inventory, title);
        }

        @Override
        protected void renderBg(GuiGraphics g, float partialTick, int mouseX, int mouseY) {
            background(g, this, this.leftPos, this.topPos, this.imageWidth, this.imageHeight);
        }

        @Override
        protected void renderLabels(GuiGraphics g, int mouseX, int mouseY) {
            drawTitle(g, this.getTitle());
        }

        @Override
        protected void renderSlotHighlight(GuiGraphics g, Slot slot, int mouseX, int mouseY, float partialTick) {
            if (highlightable(slot)) {
                renderSlotHighlight(g, slot.x, slot.y, 0, HOVER);
            }
        }
    }

    /** Droppers and dispensers: a 3x3 grid. */
    public static final class Dispenser extends DispenserScreen {
        public Dispenser(DispenserMenu menu, Inventory inventory, Component title) {
            super(menu, inventory, title);
        }

        @Override
        protected void renderBg(GuiGraphics g, float partialTick, int mouseX, int mouseY) {
            background(g, this, this.leftPos, this.topPos, this.imageWidth, this.imageHeight);
        }

        @Override
        protected void renderLabels(GuiGraphics g, int mouseX, int mouseY) {
            drawTitle(g, this.getTitle());
        }

        @Override
        protected void renderSlotHighlight(GuiGraphics g, Slot slot, int mouseX, int mouseY, float partialTick) {
            if (highlightable(slot)) {
                renderSlotHighlight(g, slot.x, slot.y, 0, HOVER);
            }
        }
    }
}
