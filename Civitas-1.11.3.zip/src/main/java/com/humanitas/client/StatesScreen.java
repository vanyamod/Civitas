package com.humanitas.client;

import com.humanitas.CitizensNet;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.nbt.*;
import net.minecraft.network.chat.Component;
import net.neoforged.neoforge.network.PacketDistributor;
import org.lwjgl.glfw.GLFW;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;
import static com.humanitas.client.CivitasUi.*;

/** Public state cards, incoming invitations and authorized recruitment use one consistent desk. */
public final class StatesScreen extends Screen {
    private final Screen parent;
    private CompoundTag data=new CompoundTag(), selected;
    private DocumentPanel panel;
    private String state, tab, editor="", notice="";
    private int page, ticks, scroll, sequence;
    private long pendingSince, nextRequestAt;
    private boolean requestQueued;
    private boolean busy, recruitmentOpen;
    private final TextInput text=new TextInput(true,2000,"");
    private final TextInput reader=new TextInput(true,18000,"");
    private final List<Control> controls=new ArrayList<>();
    private record Control(String label,int x,int y,int w,int h,Runnable action,Style style) {}
    public StatesScreen(Screen parent,String state,String tab){super(Component.literal("Государства"));this.parent=parent;this.state=state;this.tab=tab;}
    public StatesScreen(Screen parent){this(parent,"","overview");}
    @Override protected void init(){panel=new DocumentPanel(width,height,650,420);if(data.isEmpty())request();}
    private void request(){busy=true;pendingSince=System.currentTimeMillis();sequence++;requestQueued=true;flushRequest();}
    private void flushRequest(){long now=System.currentTimeMillis();if(requestQueued&&now>=nextRequestAt){requestQueued=false;nextRequestAt=now+180;PacketDistributor.sendToServer(new CitizensNet.Request(sequence,state,tab,page));}}
    public static void receive(CompoundTag tag){
        if(!(Minecraft.getInstance().screen instanceof StatesScreen screen))return;
        if(tag.getInt("requestId")!=screen.sequence)return;
        if(!screen.state.equals(tag.getString("state"))||!screen.tab.equals(tag.getString("tab"))) {
            // A deleted state resolves to the catalog; late snapshots from another tab are ignored.
            if(!(tag.getString("state").isEmpty()&&!screen.state.isEmpty()&&screen.tab.equals(tag.getString("tab"))))return;
            screen.state="";
        }
        screen.data=tag.copy();screen.page=tag.getInt("page");screen.busy=false;
        if(!tag.getString("message").isBlank())screen.notice=tag.getString("message");
        if(screen.selected!=null){String id=screen.selected.getString("id");screen.selected=null;var rows=tag.getList("rows",10);for(int i=0;i<rows.size();i++)if(rows.getCompound(i).getString("id").equals(id))screen.selected=rows.getCompound(i);}
    }
    private void navigate(String state,String tab){if(busy)return;this.state=state;this.tab=tab;page=0;selected=null;editor="";scroll=0;notice="";request();}
    private void send(String op,String target,String body){
        if(busy)return;
        String destination=tab.equals("inbox")&&selected!=null?selected.getString("id"):state;
        busy=true;pendingSince=System.currentTimeMillis();state=destination;tab=Set.of("join","decline").contains(op)?"inbox":Set.of("accept","reject","cancelInvite").contains(op)?"review":"overview";
        selected=null;editor="";scroll=0;
        PacketDistributor.sendToServer(new CitizensNet.Action(++sequence,destination,op,target,body));
    }
    @Override public void tick(){flushRequest();if(busy&&System.currentTimeMillis()-pendingSince>8000){busy=false;notice="Ответ сервера задерживается. Обновляем состояние…";request();}if(++ticks%60==0&&!busy&&editor.isEmpty())request();}
    private void buttonAt(GuiGraphics g,String label,int x,int y,int w,Style style,Runnable action,int mx,int my){
        controls.add(new Control(label,x,y,w,22,action,style));button(g,font,x,y,w,22,label,!busy&&inside(mx,my,x,y,w,22),busy?Style.DISABLED:style);
    }
    private String fit(String s,int w){return CivitasSurfaces.fit(font,s,w);}
    @Override public void render(GuiGraphics g,int mx,int my,float partial){
        controls.clear();g.fill(0,0,width,height,BACKDROP);
        CompoundTag detail=data.getCompound("detail");
        String heading=tab.equals("inbox")?"ПРИГЛАШЕНИЯ":tab.equals("review")?"ПРИЁМ В ГОСУДАРСТВО":tab.equals("history")?"ПУБЛИЧНАЯ ИСТОРИЯ":"ГОСУДАРСТВА";
        panel.draw(g,font,heading,state.isEmpty()?"Выберите страну, познакомьтесь с ней и подайте заявку":detail.getString("name"),78);
        int x=panel.x+14,w=panel.w-28,y=panel.y+49;
        buttonAt(g,"Каталог",x,y,95,state.isEmpty()&&tab.equals("overview")?Style.CHOSEN:Style.SECONDARY,()->navigate("","overview"),mx,my);
        buttonAt(g,"Приглашения",x+101,y,115,tab.equals("inbox")?Style.CHOSEN:Style.SECONDARY,()->navigate("","inbox"),mx,my);
        if(!state.isEmpty()&&!tab.equals("inbox"))buttonAt(g,"Карточка",x+222,y,95,Style.SECONDARY,()->navigate(state,"overview"),mx,my);
        int cy=panel.y+89,ch=Math.max(20,panel.footer()-cy-42);
        if(!editor.isEmpty())drawEditor(g,mx,my,x,cy,w,ch);
        else if(selected!=null)drawSelected(g,mx,my,x,cy,w,ch);
        else if(!state.isEmpty()&&tab.equals("overview"))drawState(g,mx,my,x,cy,w,ch,detail);
        else drawRows(g,mx,my,x,cy,w,ch);
        buttonAt(g,"НАЗАД",x,panel.footer(),90,Style.SECONDARY,()->onClose(),mx,my);
        String msg=busy?"Действие обрабатывается…":notice;
        g.drawString(font,fit(msg,Math.max(10,w-102)),x+100,panel.footer()+7,DIM,false);
    }
    private void readonly(GuiGraphics g,int mx,int my,int x,int y,int w,int h,String content){
        if(!reader.value().equals(content)){reader.setValue(content);reader.scrollToStart();}reader.focused=false;reader.setBounds(x,y,w,h);reader.render(g,mx,my);
    }
    private void drawState(GuiGraphics g,int mx,int my,int x,int y,int w,int h,CompoundTag s){
        String content=(s.getString("type").equalsIgnoreCase(s.getString("government"))?s.getString("government"):s.getString("type")+" · "+s.getString("government"))+"\nЛидер: "+s.getString("leader")+"\nУчастников: "+s.getInt("population")+"\n\n"+(s.getBoolean("open")?"НАБОР ОТКРЫТ":"НАБОР ЗАКРЫТ")+"\n"+(s.getString("instructions").isBlank()?"Государство не указало дополнительных условий.":s.getString("instructions"));
        if(data.getBoolean("applied"))content+="\n\nВаша заявка ожидает решения.";
        if(data.getBoolean("invited"))content+="\n\nУ вас есть приглашение от этого государства.";
        readonly(g,mx,my,x,y,w,h,content);int by=y+h+8;int bw=Math.max(62,(w-18)/4);
        buttonAt(g,"История",x,by,bw,Style.SECONDARY,()->navigate(state,"history"),mx,my);
        buttonAt(g,"Конституция",x+bw+6,by,bw,Style.SECONDARY,()->minecraft.setScreen(new ConstitutionScreen(this,s.getString("constitution"),false,Long.MIN_VALUE,Long.MIN_VALUE)),mx,my);
        if(data.getBoolean("manager")) {
            buttonAt(g,"Заявки",x+2*(bw+6),by,bw,Style.SECONDARY,()->navigate(state,"review"),mx,my);
            buttonAt(g,"Набор",x+3*(bw+6),by,bw,Style.PRIMARY,()->{editor="recruit";recruitmentOpen=s.getBoolean("open");text.setValue(s.getString("instructions"));},mx,my);
        }else if(!data.getBoolean("hasState")) {
            if(data.getBoolean("invited"))buttonAt(g,"Вступить",x+2*(bw+6),by,bw,Style.PRIMARY,()->send("join","",""),mx,my);
            else if(data.getBoolean("applied"))buttonAt(g,"Отозвать",x+2*(bw+6),by,bw,Style.SECONDARY,()->send("withdraw","",""),mx,my);
            else if(s.getBoolean("open"))buttonAt(g,"Подать заявку",x+2*(bw+6),by,2*bw+6,Style.PRIMARY,()->{editor="apply";text.setValue("");},mx,my);
        }
    }
    private void drawRows(GuiGraphics g,int mx,int my,int x,int y,int w,int h){
        var rows=data.getList("rows",10);if(rows.isEmpty())g.drawString(font,tab.equals("review")?"Новых заявок и приглашений пока нет":"В этом разделе пока нет записей",x+8,y+17,DIM,false);
        int rowH=43;scroll=Math.max(0,Math.min(Math.max(0,rows.size()*rowH-h),scroll));
        g.enableScissor(x-1,y,x+w+1,y+h);
        for(int i=0;i<rows.size();i++){CompoundTag row=rows.getCompound(i);int ry=y+i*rowH-scroll;boolean hot=inside(mx,my,x,ry,w,rowH-4)&&inside(mx,my,x,y,w,h);
            CivitasSurfaces.surface(g,x,ry,w,rowH-4,false,hot);
            g.drawString(font,fit(row.getString("title"),w-100),x+10,ry+7,TEXT_LIGHT,false);
            g.drawString(font,fit(row.getString("subtitle"),w-100),x+10,ry+23,DIM,false);
            if(ry>=y&&ry+rowH-4<=y+h)buttonAt(g,row.getString("kind").equals("state")?"ОТКРЫТЬ":"ИНФО",x+w-82,ry+8,74,Style.SECONDARY,()->{
                if(row.getString("kind").equals("state"))navigate(row.getString("id"),"overview");else{selected=row.copy();text.setValue("");}},mx,my);
        }g.disableScissor();int by=y+h+8;
        buttonAt(g,"←",x,by,36,page>0?Style.SECONDARY:Style.DISABLED,()->{if(page>0){page--;scroll=0;request();}},mx,my);
        g.drawString(font,(page+1)+" / "+Math.max(1,data.getInt("pages"))+" · "+data.getInt("count")+" записей",x+47,by+7,DIM,false);
        buttonAt(g,"→",x+w-36,by,36,page+1<data.getInt("pages")?Style.SECONDARY:Style.DISABLED,()->{if(page+1<data.getInt("pages")){page++;scroll=0;request();}},mx,my);
    }
    private void drawSelected(GuiGraphics g,int mx,int my,int x,int y,int w,int h){
        String kind=selected.getString("kind"),id=selected.getString("id");String date="";
        if(selected.getLong("time")>1_000_000_000_000L)date="\n"+DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm").withZone(ZoneId.systemDefault()).format(Instant.ofEpochMilli(selected.getLong("time")));
        readonly(g,mx,my,x,y,w,h,selected.getString("title")+"\n"+selected.getString("subtitle")+date+"\n\n"+selected.getString("text"));int by=y+h+8;
        buttonAt(g,"К списку",x,by,95,Style.SECONDARY,()->{selected=null;text.setValue("");},mx,my);
        if(kind.equals("application")){buttonAt(g,"Принять",x+w-200,by,95,Style.PRIMARY,()->send("accept",id,""),mx,my);buttonAt(g,"Отклонить",x+w-99,by,99,Style.SECONDARY,()->send("reject",id,""),mx,my);}
        if(kind.equals("invite")){buttonAt(g,"Вступить",x+w-200,by,95,Style.PRIMARY,()->send("join","",""),mx,my);buttonAt(g,"Отклонить",x+w-99,by,99,Style.SECONDARY,()->send("decline","",""),mx,my);}
        if(kind.equals("sentInvite"))buttonAt(g,"Отменить приглашение",x+w-184,by,184,Style.SECONDARY,()->send("cancelInvite",id,""),mx,my);
    }
    private void drawEditor(GuiGraphics g,int mx,int my,int x,int y,int w,int h){
        boolean recruit=editor.equals("recruit");g.drawString(font,recruit?"Условия и вопросы для кандидатов · до 1000 символов":"Ваша заявка · до 2000 символов",x,y,GOLD,false);
        if(recruit){buttonAt(g,"Открытый набор",x,y+16,140,recruitmentOpen?Style.CHOSEN:Style.SECONDARY,()->recruitmentOpen=true,mx,my);buttonAt(g,"Закрытый набор",x+146,y+16,140,!recruitmentOpen?Style.CHOSEN:Style.SECONDARY,()->recruitmentOpen=false,mx,my);}
        int offset=recruit?46:18;text.setBounds(x,y+offset,w,Math.max(18,h-offset));text.render(g,mx,my);int by=y+h+8;
        buttonAt(g,"Отмена",x,by,90,Style.SECONDARY,()->editor="",mx,my);
        buttonAt(g,recruit?"Сохранить":"Отправить заявку",x+w-150,by,150,Style.PRIMARY,()->send(recruit?"recruit":"apply",recruit?(recruitmentOpen?"open":"closed"):"",text.value()),mx,my);
    }
    @Override public boolean mouseClicked(double x,double y,int b){if(b!=0)return false;for(var c:controls)if(inside(x,y,c.x,c.y,c.w,c.h)){if(!busy&&c.style!=Style.DISABLED)c.action.run();return true;}return (!editor.isEmpty()?text:reader).mouseClicked(x,y);}
    @Override public boolean mouseDragged(double x,double y,int b,double dx,double dy){return (!editor.isEmpty()?text:reader).mouseDragged(x,y);}
    @Override public boolean mouseScrolled(double x,double y,double dx,double dy){if(selected!=null||!editor.isEmpty()||!state.isEmpty()&&tab.equals("overview"))return (!editor.isEmpty()?text:reader).mouseScrolled(x,y,dy);scroll-=Math.round((float)dy*24);return true;}
    @Override public boolean charTyped(char c,int mods){return !editor.isEmpty()&&text.charTyped(c);}
    @Override public boolean keyPressed(int key,int scan,int mods){if(key==GLFW.GLFW_KEY_ESCAPE){onClose();return true;}return !editor.isEmpty()&&text.keyPressed(key,mods);}
    @Override public void onClose(){if(busy){minecraft.setScreen(parent);return;}if(!editor.isEmpty()){editor="";return;}if(selected!=null){selected=null;return;}minecraft.setScreen(parent);}
    @Override public boolean isPauseScreen(){return false;}
    @Override public void renderBackground(GuiGraphics g,int x,int y,float p){}
}
