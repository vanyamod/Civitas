package com.humanitas;

import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.*;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;
import java.util.*;

/** Organization authority and ballots live on the server; a selected cabinet is only a preference. */
public final class OrganizationsData extends SavedData {
    public static final int PROFILE=1, MEMBERS=2, ROLES=4, PROPOSE=8, VOTE=16, NEWS=32, SESSIONS=64, STATES=128, ALL=255;
    public static final String[] RIGHTS={"Профиль и устав","Участники и приглашения","Роли и назначения","Предлагать резолюции","Голосовать лично","Публиковать новости","Открывать голосования","Принимать государства"};
    public static final long INVITE_TTL=7L*24*60*60*1000;
    public final Map<UUID,Organization> organizations=new LinkedHashMap<>();
    public record Actor(UUID id,String name,boolean admin) {}
    public record Person(String name,String role) {}
    public record Role(String name,int rights) {}
    public record Invitation(String name,long time) {}
    public record Delegation(UUID state,String stateName,UUID delegate,String delegateName) {}
    public record Event(long time,String title,String text) {}
    public enum Status {
        DRAFT("Проект"), OPEN("Идёт голосование"), ADOPTED("Принята"), REJECTED("Отклонена"), NO_QUORUM("Нет кворума"), CANCELLED("Снята");
        public final String label; Status(String label){this.label=label;}
    }
    public static final class Resolution {
        public UUID id=UUID.randomUUID(),author;
        public String title="",body="",authorName="";
        public int number,quorum=50; public boolean states,twoThirds;
        public long created,opened,deadline,finished;
        public Status status=Status.DRAFT;
        // The keys are people OR states, never the current delegate's player UUID in state mode.
        public final Map<UUID,String> electorate=new LinkedHashMap<>();
        public final Map<UUID,Integer> ballots=new LinkedHashMap<>();
        public int count(int choice){return (int)ballots.values().stream().filter(v->v==choice).count();}
        public boolean pending(UUID unit){return status==Status.OPEN&&unit!=null&&electorate.containsKey(unit)&&!ballots.containsKey(unit);}
        public int required(){return (electorate.size()*quorum+99)/100;}
        public boolean finish(long now){
            if(status!=Status.OPEN||now<deadline)return false;
            int yes=count(1),no=count(0);
            status=ballots.size()<required()?Status.NO_QUORUM:yes>0&&(twoThirds?3L*yes>=2L*(yes+no):yes>no)?Status.ADOPTED:Status.REJECTED;
            finished=deadline;return true;
        }
    }
    public static final class Organization {
        public UUID id=UUID.randomUUID(),chair,deputy;
        public String name="",description="",charter="",chairName="",deputyName="";
        public long created; public int nextNumber=1;
        public final Map<UUID,Person> members=new LinkedHashMap<>();
        public final Map<String,Role> roles=new LinkedHashMap<>();
        public final Map<UUID,Invitation> invites=new LinkedHashMap<>();
        public final Map<UUID,Delegation> states=new LinkedHashMap<>();
        public final Map<UUID,String> applications=new LinkedHashMap<>();
        public final List<Resolution> resolutions=new ArrayList<>();
        public final List<Event> history=new ArrayList<>();
        public Organization(){roles.put("member",new Role("Участник",VOTE));roles.put("secretary",new Role("Секретариат",PROPOSE|VOTE|NEWS|SESSIONS));roles.put("council",new Role("Совет",ALL&~ROLES));}
    }
    public static OrganizationsData get(MinecraftServer server){return server.overworld().getDataStorage().computeIfAbsent(new SavedData.Factory<>(OrganizationsData::new,OrganizationsData::load,null),"civitas_organizations");}
    public static void require(boolean ok,String message){if(!ok)throw new IllegalArgumentException(message);}
    public static boolean validDelegate(Delegation d,RepublicData data,UUID who){return d.delegate!=null&&d.delegate.equals(who)&&CitizensData.member(CitizensNet.find(data,d.state.toString()),who);}
    public static boolean affiliated(Organization o,RepublicData data,UUID who){return o.members.containsKey(who)||o.states.values().stream().anyMatch(d->validDelegate(d,data,who));}
    public static int rights(Organization o,RepublicData data,Actor a){
        if(a.admin)return ALL;
        if(!affiliated(o,data,a.id))return 0;
        if(a.id.equals(o.chair)||a.id.equals(o.deputy))return ALL;
        Person p=o.members.get(a.id);return p==null?VOTE:o.roles.getOrDefault(p.role,new Role("Участник",0)).rights;
    }
    public static boolean has(Organization o,RepublicData data,Actor a,int permission){return (rights(o,data,a)&permission)==permission;}
    public static void allowed(Organization o,RepublicData data,Actor a,int permission){require(has(o,data,a,permission),"У вас нет права: "+RIGHTS[Integer.numberOfTrailingZeros(permission)]);}
    public static boolean head(Organization o,Actor a){return a.admin||a.id.equals(o.chair);}
    public static String clean(String s,int max){require(s!=null&&s.length()<=max,"Слишком длинный текст (максимум "+max+")");return DiplomacyData.clean(s,max).strip();}
    public Organization create(Actor a,String name,long now){
        require(a.admin,"Организации создаёт только администратор");require(organizations.size()<256,"Достигнут предел организаций");
        name=clean(name,80);require(!name.isBlank(),"Укажите название");String finalName=name;require(organizations.values().stream().noneMatch(o->o.name.equalsIgnoreCase(finalName)),"Организация с таким названием уже существует");
        Organization o=new Organization();o.name=name;o.chair=a.id;o.chairName=a.name;o.created=now;o.members.put(a.id,new Person(a.name,"member"));organizations.put(o.id,o);event(o,"Организация создана",a.name,now);return o;
    }
    public void event(Organization o,String title,String text,long now){o.history.add(new Event(now,title,text));if(o.history.size()>2048)o.history.remove(0);setDirty();}
    public void maintain(Organization o,RepublicData data,long now){
        if(o.invites.values().removeIf(i->now-i.time>=INVITE_TTL))setDirty();
        if(o.applications.keySet().removeIf(id->CitizensNet.find(data,id.toString())==null))setDirty();
        for(var r:o.resolutions)if(r.finish(now))event(o,"Резолюция #"+r.number+" · "+r.status.label,r.title,now);
    }
    public void profile(Organization o,RepublicData data,Actor a,String name,String description,String charter,long now){
        allowed(o,data,a,PROFILE);name=clean(name,80);require(!name.isBlank(),"Укажите название");String n=name;require(organizations.values().stream().noneMatch(other->other!=o&&other.name.equalsIgnoreCase(n)),"Название уже занято");
        String desc=clean(description,1000),doc=clean(charter,6000);o.name=name;o.description=desc;o.charter=doc;event(o,"Обновлены профиль и устав",a.name,now);
    }
    public void invite(Organization o,RepublicData data,Actor a,UUID target,String name,long now){
        allowed(o,data,a,MEMBERS);require(!o.members.containsKey(target),"Игрок уже участник");require(!o.invites.containsKey(target),"Приглашение уже отправлено");require(o.invites.size()<1024,"Сначала обработайте действующие приглашения");
        o.invites.put(target,new Invitation(name,now));event(o,"Отправлено приглашение",name+" · "+a.name,now);
    }
    public void join(Organization o,Actor a,long now){
        var invite=o.invites.get(a.id);require(invite!=null&&now-invite.time<INVITE_TTL,"Приглашение истекло или отозвано");require(!o.members.containsKey(a.id),"Вы уже участник");require(o.members.size()<2048,"Достигнут предел участников");
        o.members.put(a.id,new Person(a.name,"member"));o.invites.remove(a.id);event(o,"Новый участник",a.name,now);
    }
    public void remove(Organization o,RepublicData data,Actor a,UUID target,long now){
        if(!a.id.equals(target))allowed(o,data,a,MEMBERS);
        require(!target.equals(o.chair),"Сначала передайте председательство");
        require(!target.equals(o.deputy)||head(o,a),"Заместителя может освободить председатель или администратор");
        require(a.id.equals(target)||head(o,a)||(rights(o,data,a)&rights(o,data,new Actor(target,"",false)))==rights(o,data,new Actor(target,"",false)),"Нельзя исключить участника с более широкими правами");
        Person person=o.members.remove(target);require(person!=null,"Участник не найден");if(target.equals(o.deputy)){o.deputy=null;o.deputyName="";}
        // Leaving also relinquishes representation; a state can nominate a replacement.
        o.states.replaceAll((id,d)->target.equals(d.delegate)?new Delegation(id,d.stateName,null,""):d);
        event(o,"Участник покинул организацию",person.name,now);
    }
    public void role(Organization o,RepublicData data,Actor a,String id,String name,int mask,long now){
        allowed(o,data,a,ROLES);require((mask&~ALL)==0,"Неизвестные права");require(head(o,a)||(mask&~rights(o,data,a))==0,"Нельзя выдать права, которых у вас нет");
        if(id.isEmpty()){require(o.roles.size()<32,"Не более 32 ролей");id=UUID.randomUUID().toString();}
        else require(o.roles.containsKey(id),"Роль не найдена");Role old=o.roles.get(id);require(old==null||head(o,a)||(old.rights&~rights(o,data,a))==0,"Нельзя изменить эту роль");
        name=clean(name,64);require(!name.isBlank(),"Укажите название роли");o.roles.put(id,new Role(name,mask));event(o,"Обновлена роль",name+" · "+a.name,now);
    }
    public void assign(Organization o,RepublicData data,Actor a,UUID target,String role,long now){
        allowed(o,data,a,ROLES);Person person=o.members.get(target);Role next=o.roles.get(role);require(person!=null&&next!=null,"Участник или роль не найдены");
        require(head(o,a)||!target.equals(o.chair)&&!target.equals(o.deputy),"Нельзя менять права руководства");
        require(head(o,a)||(next.rights&~rights(o,data,a))==0&&(rights(o,data,new Actor(target,"",false))&~rights(o,data,a))==0,"Нельзя выдать или изменить эти права");
        o.members.put(target,new Person(person.name,role));event(o,"Назначена роль",person.name+" · "+next.name,now);
    }
    public void appoint(Organization o,Actor a,UUID target,boolean deputy,long now){
        require(head(o,a),"Назначать руководство может председатель или администратор");Person person=o.members.get(target);require(person!=null,"Выберите участника организации");
        require(deputy?!target.equals(o.chair):!target.equals(o.deputy),"Сначала освободите эту должность");
        if(deputy){o.deputy=target;o.deputyName=person.name;}else{o.chair=target;o.chairName=person.name;}
        event(o,deputy?"Назначен заместитель":"Передано председательство",person.name,now);
    }
    public static boolean represents(RepublicData.Polity p,Actor a){return CitizensData.permitted(p,a.id,a.admin,Perms.DIPLOMACY);}
    public void applyState(Organization o,RepublicData data,Actor a,UUID state,long now){
        var p=CitizensNet.find(data,state.toString());require(p!=null&&represents(p,a),"Нужно право дипломатии этого государства");require(!o.states.containsKey(state),"Государство уже состоит в организации");require(!o.applications.containsKey(state),"Заявка уже подана");require(o.applications.size()<512,"Слишком много заявок");
        o.applications.put(state,p.name);event(o,"Заявка государства",p.name,now);
    }
    public void acceptState(Organization o,RepublicData data,Actor a,UUID state,boolean accept,long now){
        allowed(o,data,a,STATES);String name=o.applications.get(state);require(name!=null&&CitizensNet.find(data,state.toString())!=null,"Заявка больше недействительна");require(!accept||o.states.size()<512,"Не более 512 делегаций");
        o.applications.remove(state);if(accept)o.states.put(state,new Delegation(state,name,null,""));event(o,accept?"Государство принято":"Заявка государства отклонена",name,now);
    }
    public void delegate(Organization o,RepublicData data,Actor a,UUID state,UUID who,long now){
        var p=CitizensNet.find(data,state.toString());require(p!=null&&represents(p,a),"Представителя назначает уполномоченный дипломат государства");require(o.states.containsKey(state),"Государство не входит в организацию");require(CitizensData.member(p,who),"Представитель должен состоять в этом государстве");
        String name=memberName(p,who);o.states.put(state,new Delegation(state,p.name,who,name));event(o,"Назначен представитель",p.name+" · "+name,now);
    }
    public static String memberName(RepublicData.Polity p,UUID who){if(who.equals(RepublicData.leaderOf(p)))return p.leaderName.isBlank()?p.ownerName:p.leaderName;if(who.equals(p.deputy))return p.deputyName;int i=p.members.indexOf(who);return i>=0&&i<p.memberNames.size()?p.memberNames.get(i):who.toString();}
    public void removeState(Organization o,RepublicData data,Actor a,UUID state,long now){
        var p=CitizensNet.find(data,state.toString());require(has(o,data,a,STATES)||represents(p,a),"Нет права отзывать делегацию");var old=o.states.remove(state);require(old!=null,"Делегация не найдена");event(o,"Государство покинуло организацию",old.stateName,now);
    }
    public Resolution draft(Organization o,RepublicData data,Actor a,String title,String body,boolean states,int quorum,boolean twoThirds,long now){
        allowed(o,data,a,PROPOSE);title=clean(title,100);body=clean(body,6000);require(!title.isBlank()&&!body.isBlank(),"Заполните название и текст резолюции");require(quorum>=1&&quorum<=100,"Кворум от 1 до 100 процентов");require(o.resolutions.size()<2048,"Достигнут предел резолюций организации");
        Resolution r=new Resolution();r.number=o.nextNumber++;r.author=a.id;r.authorName=a.name;r.title=title;r.body=body;r.states=states;r.quorum=quorum;r.twoThirds=twoThirds;r.created=now;o.resolutions.add(r);event(o,"Внесён проект #"+r.number,title,now);return r;
    }
    public void open(Organization o,RepublicData data,Actor a,Resolution r,int hours,long now){
        allowed(o,data,a,SESSIONS);require(r.status==Status.DRAFT,"Открыть можно только проект");require(hours>=1&&hours<=168,"Срок от 1 часа до 7 суток");
        Map<UUID,String> eligible=new LinkedHashMap<>();
        if(r.states){for(var d:o.states.values())if(d.delegate!=null&&validDelegate(d,data,d.delegate))eligible.put(d.state,d.stateName);}
        else {for(var entry:o.members.entrySet())if(has(o,data,new Actor(entry.getKey(),entry.getValue().name,false),VOTE))eligible.put(entry.getKey(),entry.getValue().name);
            for(var d:o.states.values())if(d.delegate!=null&&validDelegate(d,data,d.delegate)&&has(o,data,new Actor(d.delegate,d.delegateName,false),VOTE))eligible.putIfAbsent(d.delegate,d.delegateName);}
        require(!eligible.isEmpty(),r.states?"Сначала назначьте действующих представителей государств":"Нет участников с правом голоса");
        r.electorate.putAll(eligible);r.opened=now;r.deadline=now+hours*3600000L;r.status=Status.OPEN;event(o,"Открыто голосование #"+r.number,r.title+" · голосов "+eligible.size(),now);
    }
    public static List<UUID> units(Organization o,RepublicData data,Actor a,Resolution r){
        if(r.status!=Status.OPEN||!affiliated(o,data,a.id))return List.of();
        if(!r.states)return has(o,data,new Actor(a.id,a.name,false),VOTE)&&r.electorate.containsKey(a.id)?List.of(a.id):List.of();
        return o.states.values().stream().filter(d->validDelegate(d,data,a.id)&&r.electorate.containsKey(d.state)).map(Delegation::state).toList();
    }
    public void vote(Organization o,RepublicData data,Actor a,Resolution r,UUID unit,int choice,long now){
        maintain(o,data,now);require(r.status==Status.OPEN,"Голосование завершено или ещё не открыто");require(choice>=0&&choice<=2,"Неизвестный голос");require(units(o,data,a,r).contains(unit),"Вы не представляете этот голос в зафиксированном составе");require(!r.ballots.containsKey(unit),"Голос уже принят; повторное голосование невозможно");
        r.ballots.put(unit,choice);setDirty();
    }
    public void cancel(Organization o,RepublicData data,Actor a,Resolution r,long now){allowed(o,data,a,SESSIONS);maintain(o,data,now);require(r.status==Status.DRAFT||r.status==Status.OPEN,"Резолюция уже завершена");r.status=Status.CANCELLED;r.finished=now;event(o,"Снята резолюция #"+r.number,r.title+" · "+a.name,now);}
    public static Resolution resolution(Organization o,String id){return o.resolutions.stream().filter(r->r.id.toString().equals(id)).findFirst().orElseThrow(()->new IllegalArgumentException("Резолюция не найдена"));}

    private static CompoundTag personTag(UUID id,String name){CompoundTag t=new CompoundTag();t.putUUID("id",id);t.putString("name",name);return t;}
    private static void putUUID(CompoundTag t,String key,UUID id){if(id!=null)t.putUUID(key,id);}
    @Override public CompoundTag save(CompoundTag root,HolderLookup.Provider registries){return write(root);}
    CompoundTag write(CompoundTag root){
        ListTag list=new ListTag();for(var o:organizations.values()){
            CompoundTag t=personTag(o.id,o.name);t.putString("description",o.description);t.putString("charter",o.charter);putUUID(t,"chair",o.chair);putUUID(t,"deputy",o.deputy);t.putString("chairName",o.chairName);t.putString("deputyName",o.deputyName);t.putLong("created",o.created);t.putInt("next",o.nextNumber);
            ListTag members=new ListTag();o.members.forEach((id,p)->{var m=personTag(id,p.name);m.putString("role",p.role);members.add(m);});t.put("members",members);
            ListTag roles=new ListTag();o.roles.forEach((id,r)->{var m=new CompoundTag();m.putString("id",id);m.putString("name",r.name);m.putInt("rights",r.rights);roles.add(m);});t.put("roles",roles);
            ListTag invites=new ListTag();o.invites.forEach((id,i)->{var m=personTag(id,i.name);m.putLong("time",i.time);invites.add(m);});t.put("invites",invites);
            ListTag states=new ListTag();o.states.forEach((id,d)->{var m=personTag(id,d.stateName);putUUID(m,"delegate",d.delegate);m.putString("delegateName",d.delegateName);states.add(m);});t.put("states",states);
            ListTag apps=new ListTag();o.applications.forEach((id,n)->apps.add(personTag(id,n)));t.put("applications",apps);
            ListTag rs=new ListTag();for(var r:o.resolutions){var m=personTag(r.id,r.title);putUUID(m,"author",r.author);m.putString("authorName",r.authorName);m.putString("body",r.body);m.putInt("number",r.number);m.putBoolean("states",r.states);m.putInt("quorum",r.quorum);m.putBoolean("twoThirds",r.twoThirds);m.putString("status",r.status.name());m.putLong("created",r.created);m.putLong("opened",r.opened);m.putLong("deadline",r.deadline);m.putLong("finished",r.finished);
                ListTag voters=new ListTag();r.electorate.forEach((id,n)->{var v=personTag(id,n);if(r.ballots.containsKey(id))v.putInt("vote",r.ballots.get(id));voters.add(v);});m.put("voters",voters);rs.add(m);}t.put("resolutions",rs);
            ListTag history=new ListTag();for(var e:o.history){var m=new CompoundTag();m.putLong("time",e.time);m.putString("title",e.title);m.putString("text",e.text);history.add(m);}t.put("history",history);list.add(t);
        }root.put("organizations",list);return root;
    }
    static OrganizationsData load(CompoundTag root,HolderLookup.Provider registries){
        OrganizationsData data=new OrganizationsData();var list=root.getList("organizations",10);
        for(int i=0;i<list.size();i++){var t=list.getCompound(i);if(!t.hasUUID("id")||!t.hasUUID("chair"))continue;var o=new Organization();o.id=t.getUUID("id");o.name=t.getString("name");o.description=t.getString("description");o.charter=t.getString("charter");o.chair=t.getUUID("chair");o.chairName=t.getString("chairName");o.deputy=t.hasUUID("deputy")?t.getUUID("deputy"):null;o.deputyName=t.getString("deputyName");o.created=t.getLong("created");o.nextNumber=Math.max(1,t.getInt("next"));
            var members=t.getList("members",10);for(int j=0;j<members.size();j++){var m=members.getCompound(j);if(m.hasUUID("id"))o.members.put(m.getUUID("id"),new Person(m.getString("name"),m.getString("role")));}
            if(t.contains("roles")){o.roles.clear();var roles=t.getList("roles",10);for(int j=0;j<roles.size();j++){var r=roles.getCompound(j);o.roles.put(r.getString("id"),new Role(r.getString("name"),r.getInt("rights")&ALL));}}
            var invites=t.getList("invites",10);for(int j=0;j<invites.size();j++){var m=invites.getCompound(j);if(m.hasUUID("id"))o.invites.put(m.getUUID("id"),new Invitation(m.getString("name"),m.getLong("time")));}
            var states=t.getList("states",10);for(int j=0;j<states.size();j++){var m=states.getCompound(j);if(m.hasUUID("id")){UUID id=m.getUUID("id");o.states.put(id,new Delegation(id,m.getString("name"),m.hasUUID("delegate")?m.getUUID("delegate"):null,m.getString("delegateName")));}}
            var apps=t.getList("applications",10);for(int j=0;j<apps.size();j++){var m=apps.getCompound(j);if(m.hasUUID("id"))o.applications.put(m.getUUID("id"),m.getString("name"));}
            var rs=t.getList("resolutions",10);for(int j=0;j<rs.size();j++){var m=rs.getCompound(j);if(!m.hasUUID("id"))continue;var r=new Resolution();r.id=m.getUUID("id");r.title=m.getString("name");r.body=m.getString("body");r.author=m.hasUUID("author")?m.getUUID("author"):o.chair;r.authorName=m.getString("authorName");r.number=m.getInt("number");o.nextNumber=Math.max(o.nextNumber,r.number+1);r.states=m.getBoolean("states");r.quorum=Math.max(1,Math.min(100,m.getInt("quorum")));r.twoThirds=m.getBoolean("twoThirds");try{r.status=Status.valueOf(m.getString("status"));}catch(IllegalArgumentException e){r.status=Status.CANCELLED;}r.created=m.getLong("created");r.opened=m.getLong("opened");r.deadline=m.getLong("deadline");r.finished=m.getLong("finished");
                var voters=m.getList("voters",10);for(int k=0;k<voters.size();k++){var v=voters.getCompound(k);if(!v.hasUUID("id"))continue;UUID id=v.getUUID("id");r.electorate.put(id,v.getString("name"));if(v.contains("vote")&&v.getInt("vote")>=0&&v.getInt("vote")<=2)r.ballots.put(id,v.getInt("vote"));}o.resolutions.add(r);}
            var history=t.getList("history",10);for(int j=Math.max(0,history.size()-2048);j<history.size();j++){var h=history.getCompound(j);o.history.add(new Event(h.getLong("time"),h.getString("title"),h.getString("text")));}data.organizations.put(o.id,o);
        }return data;
    }
}
