package com.humanitas;

import com.mojang.logging.LogUtils;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.config.ModConfig;
import net.neoforged.neoforge.common.NeoForge;
import org.slf4j.Logger;

@Mod(Humanitas.MODID)
public final class Humanitas {
    public static final String MODID = "humanitas";
    public static final Logger LOGGER = LogUtils.getLogger();

    public Humanitas(IEventBus modEventBus, ModContainer container) {
        container.registerConfig(ModConfig.Type.COMMON, CivitasConfig.SPEC, "civitas/server.toml");
        container.registerConfig(ModConfig.Type.CLIENT, CivitasClientConfig.SPEC, "civitas-client.toml");
        modEventBus.addListener(CabinetNet::register);
        NeoForge.EVENT_BUS.addListener(DiplomacyNet::logout);
        NeoForge.EVENT_BUS.addListener(DiplomacyNet::stop);
        NeoForge.EVENT_BUS.addListener(HumanitasCommands::onRegisterCommands);
        NeoForge.EVENT_BUS.addListener(CabinetNet::onPlayerLogin);
        NeoForge.EVENT_BUS.addListener(CabinetNet::onServerTick);
        NeoForge.EVENT_BUS.addListener(MediaStore::onServerStarted);
    }
}
