package com.humanitas;

import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;
import java.util.*;

/** Persistent diplomatic cases. UUIDs identify states, never their mutable display names. */
public final class DiplomacyData extends SavedData {
    public enum Kind {
        ALLIANCE("Союз"), NON_AGGRESSION("Ненападение"), TRADE("Торговый договор"),
        CUSTOM("Предложение"), ULTIMATUM("Ультиматум"), WAR("Война"),
        CEASEFIRE("Перемирие"), PEACE("Мирный договор");
        public final String label;
        Kind(String label) { this.label = label; }
    }
    public enum Status {
        PENDING("Ожидает ответа"), ACTIVE("Действует"), DECLARED("Объявлена"),
        PAUSED("Перемирие"), REJECTED("Отклонено"), WITHDRAWN("Отозвано"),
        EXPIRED("Срок истёк"), ENDED("Завершено");
        public final String label;
        Status(String label) { this.label = label; }
    }
    public record Actor(UUID id, String name, UUID state, boolean manager, boolean admin, boolean senior) {}
    public static final class Case {
        public int id, relatedWar;
        public Kind kind;
        public Status status;
        public UUID from, to, curator;
        public String fromName, toName, title, terms, author, curatorName = "";
        public long created, updated, deadline, revision;
        public final List<String> history = new ArrayList<>(), notes = new ArrayList<>();
        public boolean involves(UUID state) { return state != null && (state.equals(from) || state.equals(to)); }
        public boolean liveWar() { return kind == Kind.WAR && (status == Status.DECLARED || status == Status.ACTIVE || status == Status.PAUSED); }
        public boolean current() { return status == Status.PENDING || status == Status.ACTIVE || status == Status.DECLARED || status == Status.PAUSED; }
        public boolean samePair(UUID a, UUID b) { return from.equals(a) && to.equals(b) || from.equals(b) && to.equals(a); }
        CompoundTag save() {
            CompoundTag t = new CompoundTag();
            t.putInt("id", id); t.putInt("war", relatedWar); t.putString("kind", kind.name()); t.putString("status", status.name());
            t.putUUID("from", from); t.putUUID("to", to); if (curator != null) t.putUUID("curator", curator);
            t.putString("fromName", fromName); t.putString("toName", toName); t.putString("title", title); t.putString("terms", terms);
            t.putString("author", author); t.putString("curatorName", curatorName);
            t.putLong("created", created); t.putLong("updated", updated); t.putLong("deadline", deadline); t.putLong("revision", revision);
            ListTag h = new ListTag(); history.forEach(s -> h.add(net.minecraft.nbt.StringTag.valueOf(s))); t.put("history", h);
            ListTag n = new ListTag(); notes.forEach(s -> n.add(net.minecraft.nbt.StringTag.valueOf(s))); t.put("notes", n); return t;
        }
        static Case load(CompoundTag t) {
            Case c = new Case(); c.id = t.getInt("id"); c.relatedWar = t.getInt("war");
            c.kind = Kind.valueOf(t.getString("kind")); c.status = Status.valueOf(t.getString("status"));
            c.from = t.getUUID("from"); c.to = t.getUUID("to"); c.curator = t.hasUUID("curator") ? t.getUUID("curator") : null;
            c.fromName = t.getString("fromName"); c.toName = t.getString("toName"); c.title = t.getString("title"); c.terms = t.getString("terms");
            c.author = t.getString("author"); c.curatorName = t.getString("curatorName");
            c.created = t.getLong("created"); c.updated = t.getLong("updated"); c.deadline = t.getLong("deadline"); c.revision = t.getLong("revision");
            var h = t.getList("history", Tag.TAG_STRING); for (int i = 0; i < h.size(); i++) c.history.add(h.getString(i));
            var n = t.getList("notes", Tag.TAG_STRING); for (int i = 0; i < n.size(); i++) c.notes.add(n.getString(i)); return c;
        }
    }
    private final List<Case> cases = new ArrayList<>();
    private int nextId = 1;
    private long revision;
    public static DiplomacyData get(MinecraftServer server) {
        return server.overworld().getDataStorage().computeIfAbsent(new SavedData.Factory<>(DiplomacyData::new, DiplomacyData::load, null), "civitas_diplomacy");
    }
    public List<Case> cases() { return List.copyOf(cases); }
    public Case find(int id) { return cases.stream().filter(c -> c.id == id).findFirst().orElse(null); }
    public long revision() { return revision; }
    public static String clean(String value, int max) {
        String s = value == null ? "" : value.replaceAll("[\\p{Cntrl}&&[^\\n\\t]]", "").replace('§', ' ').strip();
        if (s.length() > max) throw new IllegalArgumentException("Текст слишком длинный (максимум " + max + ")"); return s;
    }
    private static void require(boolean condition, String reason) { if (!condition) throw new IllegalArgumentException(reason); }
    private void changed(Case c, Actor actor, String message, long now) {
        c.revision = ++revision; c.updated = now;
        c.history.add(java.time.Instant.ofEpochMilli(now) + " · " + actor.name + ": " + message);
        if (c.history.size() > 100) c.history.remove(0); setDirty();
    }
    public Case create(Actor actor, UUID other, String fromName, String otherName, Kind kind, String title, String terms, int war, int hours, long now) {
        require(actor.manager && actor.state != null, "Нужно право вести дипломатию государства");
        require(other != null && !other.equals(actor.state), "Выберите другое государство");
        require(cases.size() < 4096, "Дипломатический архив заполнен; обратитесь к администратору");
        title = clean(title, 100); terms = clean(terms, 4000);
        require(!title.isBlank() && !terms.isBlank(), "Заполните название и условия / причину");
        for (Case old : cases) if (old.samePair(actor.state, other)) {
            require(!(old.kind == kind && old.status == Status.PENDING), "Такое предложение уже ожидает ответа");
            if (kind == Kind.WAR) {
                require(!old.liveWar(), "Между этими государствами уже объявлена война");
                require(!(old.kind == Kind.ALLIANCE || old.kind == Kind.NON_AGGRESSION) || old.status != Status.ACTIVE,
                        "Сначала расторгните союз или договор о ненападении");
            }
            if (kind == Kind.ALLIANCE || kind == Kind.NON_AGGRESSION) {
                require(!old.liveWar(), "Сначала заключите мир");
                require(old.kind != kind || old.status != Status.ACTIVE, "Такой договор уже действует");
            }
        }
        if (kind == Kind.PEACE || kind == Kind.CEASEFIRE) {
            Case linked = find(war);
            require(linked != null && linked.liveWar() && linked.samePair(actor.state, other), "Выберите действующую войну этих государств");
            require(kind != Kind.CEASEFIRE || linked.status == Status.ACTIVE, "Перемирие предлагают после начала войны");
        } else require(war == 0, "Некорректная связь с войной");
        require(hours >= 1 && hours <= 72, "Срок ответа: от 1 до 72 реальных часов");
        Case c = new Case(); c.id = nextId++; c.kind = kind; c.from = actor.state; c.to = other;
        c.fromName = fromName; c.toName = otherName; c.title = title; c.terms = terms; c.author = actor.name;
        c.relatedWar = war; c.created = now; c.deadline = kind == Kind.WAR ? 0 : now + hours * 3_600_000L;
        c.status = kind == Kind.WAR ? Status.DECLARED : Status.PENDING;
        cases.add(c); changed(c, actor, kind == Kind.WAR ? "Объявлена война; требуется куратор" : "Направлено предложение", now); return c;
    }
    public static boolean may(Case c, Actor a, String action) {
        if (c == null) return false;
        boolean side = a.manager && c.involves(a.state), supervisor = a.admin && (a.senior || a.id.equals(c.curator));
        return switch (action) {
            case "accept", "reject" -> side && c.to.equals(a.state) && c.status == Status.PENDING;
            case "withdraw" -> side && c.from.equals(a.state) && (c.status == Status.PENDING || c.status == Status.DECLARED);
            case "terminate" -> side && c.kind != Kind.WAR && c.kind != Kind.PEACE && c.kind != Kind.CEASEFIRE && c.status == Status.ACTIVE;
            case "claim" -> a.admin && c.liveWar() && c.curator == null;
            case "release" -> a.admin && c.liveWar() && c.curator != null && (a.id.equals(c.curator) || a.senior);
            case "start" -> supervisor && c.curator != null && c.kind == Kind.WAR && c.status == Status.DECLARED;
            case "pause" -> supervisor && c.kind == Kind.WAR && c.status == Status.ACTIVE;
            case "resume" -> supervisor && c.kind == Kind.WAR && c.status == Status.PAUSED;
            case "end" -> supervisor && c.liveWar();
            case "note" -> supervisor && c.kind == Kind.WAR && c.notes.size() < 100;
            default -> false;
        };
    }
    public void act(Actor a, int id, String action, String note, long now) {
        Case c = find(id); require(c != null, "Запись не найдена");
        require(may(c, a, action), "Действие недоступно: проверьте права и текущее состояние");
        note = clean(note, 1000);
        if (Set.of("start", "pause", "resume", "end", "note").contains(action)) require(!note.isBlank(), "Укажите условия или причину решения");
        if (action.equals("accept") || action.equals("reject")) require(now < c.deadline, "Срок ответа уже истёк");
        String message;
        switch (action) {
            case "accept" -> {
                if(c.kind == Kind.ALLIANCE || c.kind == Kind.NON_AGGRESSION)
                    require(cases.stream().noneMatch(other -> other.liveWar() && other.samePair(c.from,c.to)), "Во время войны сначала нужно заключить мир");
                if (c.kind == Kind.PEACE || c.kind == Kind.CEASEFIRE) {
                    Case war = find(c.relatedWar);
                    require(war != null && war.liveWar() && (c.kind != Kind.CEASEFIRE || war.status == Status.ACTIVE), "Война уже изменила состояние");
                    war.status = c.kind == Kind.PEACE ? Status.ENDED : Status.PAUSED;
                    changed(war, a, c.kind == Kind.PEACE ? "Обе стороны заключили мир (#" + c.id + ")" : "Обе стороны приняли перемирие (#" + c.id + ")", now);
                    closeRelated(war, c.id, a, now);
                }
                c.status = Status.ACTIVE; message = "Условия приняты второй стороной";
            }
            case "reject" -> { c.status = Status.REJECTED; message = "Предложение отклонено"; }
            case "withdraw" -> { c.status = Status.WITHDRAWN; if(c.kind == Kind.WAR)closeRelated(c,0,a,now); message = "Инициатор отозвал предложение"; }
            case "terminate" -> { c.status = Status.ENDED; message = "Договор расторгнут"; }
            case "claim" -> { c.curator = a.id; c.curatorName = a.name; message = "Назначен куратор: " + a.name; }
            case "release" -> { c.curator = null; c.curatorName = ""; message = "Куратор освобождён; дело доступно администрации"; }
            case "start" -> { c.status = Status.ACTIVE; message = "Куратор подтвердил начало. Условия: " + note; }
            case "pause" -> { c.status = Status.PAUSED; closeRelated(c, 0, a, now); message = "Приостановлено куратором: " + note; }
            case "resume" -> { c.status = Status.ACTIVE; closeRelated(c,0,a,now); message = "Возобновлено куратором: " + note; }
            case "end" -> { c.status = Status.ENDED; closeRelated(c, 0, a, now); message = "Завершено куратором: " + note; }
            case "note" -> {
                c.notes.add(java.time.Instant.ofEpochMilli(now) + " · " + a.name + ": " + note);
                // Internal notes never enter the public timeline.
                c.updated = now; c.revision = ++revision; setDirty(); return;
            }
            default -> throw new IllegalArgumentException("Неизвестное действие");
        }
        changed(c, a, message, now);
    }
    private void closeRelated(Case war, int except, Actor actor, long now) {
        for (Case offer : cases) if (offer.relatedWar == war.id && offer.id != except && (offer.status == Status.PENDING || offer.kind == Kind.CEASEFIRE && offer.status == Status.ACTIVE)) {
            offer.status = offer.status == Status.ACTIVE ? Status.ENDED : Status.WITHDRAWN; changed(offer, actor, "Закрыто из-за изменения состояния войны", now);
        }
    }
    public boolean expireAndReconcile(Set<UUID> states, long now) {
        boolean any = false; Actor system = new Actor(new UUID(0, 0), "Система", null, false, false, false);
        for (Case c : cases) if (c.current()) {
            if (!states.contains(c.from) || !states.contains(c.to)) {
                c.status = Status.ENDED; changed(c, system, "Одно из государств удалено", now); any = true;
            } else if (c.status == Status.PENDING && now >= c.deadline) {
                c.status = Status.EXPIRED; changed(c, system, "Истёк срок ответа; война автоматически не объявляется", now); any = true;
            }
        }
        return any;
    }
    @Override public CompoundTag save(CompoundTag tag, HolderLookup.Provider provider) {
        tag.putInt("nextId", nextId); tag.putLong("revision", revision);
        ListTag items = new ListTag(); cases.forEach(c -> items.add(c.save())); tag.put("cases", items); return tag;
    }
    public static DiplomacyData load(CompoundTag tag, HolderLookup.Provider provider) {
        DiplomacyData data = new DiplomacyData(); data.nextId = Math.max(1, tag.getInt("nextId")); data.revision = tag.getLong("revision");
        var list = tag.getList("cases", Tag.TAG_COMPOUND);
        for (int i = 0; i < list.size(); i++) {
            Case c = Case.load(list.getCompound(i)); data.cases.add(c);
            data.nextId = Math.max(data.nextId, c.id + 1); data.revision = Math.max(data.revision, c.revision);
        }
        return data;
    }
}
