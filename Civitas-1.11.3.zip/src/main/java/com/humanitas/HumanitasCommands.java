package com.humanitas;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.event.RegisterCommandsEvent;

/**
 * Commands:
 *  /civitas open                              - open the GUI (same as the inventory button)
 *  /civitas create <тип> <название> <ник>     - create a state (admin)
 *  /civitas delete <название>                 - delete a state by exact name (admin)
 */
public final class HumanitasCommands {
    private HumanitasCommands() {}

    public static void onRegisterCommands(RegisterCommandsEvent event) {
        CommandDispatcher<CommandSourceStack> dispatcher = event.getDispatcher();
        dispatcher.register(Commands.literal("civitas")
                .then(Commands.literal("open").executes(HumanitasCommands::openCabinet))
                .then(Commands.literal("create").requires(source -> source.hasPermission(2))
                        .then(Commands.argument("args", StringArgumentType.greedyString())
                                .executes(ctx -> createFromArgs(ctx, StringArgumentType.getString(ctx, "args")))))
                .then(Commands.literal("delete").requires(source -> source.hasPermission(2))
                        .then(Commands.argument("name", StringArgumentType.greedyString())
                                .executes(ctx -> deleteState(ctx, StringArgumentType.getString(ctx, "name"))))));
    }

    private static int openCabinet(CommandContext<CommandSourceStack> context) throws CommandSyntaxException {
        CabinetNet.sendSnapshot(context.getSource().getPlayerOrException());
        return 1;
    }

    private static int createFromArgs(CommandContext<CommandSourceStack> ctx, String raw) {
        CreateArgs.Parsed p = CreateArgs.parse(raw);
        if (p == null) return fail(ctx, "Формат: /civitas create <тип> <\"название\"> <ник владельца>");
        MinecraftServer server = ctx.getSource().getServer();
        ServerPlayer owner = server.getPlayerList().getPlayerByName(p.owner());
        if (owner == null) return fail(ctx, "Игрок " + p.owner() + " должен быть онлайн");
        RepublicData data = RepublicData.get(server);
        if(data.polities().stream().anyMatch(existing->existing.owner.equals(owner.getUUID())))return fail(ctx,"Этот игрок уже указан основателем государства. Выберите другого основателя; членство в нескольких странах разрешено.");
        data.createPolity(p.type(), p.name(), owner.getUUID(), owner.getGameProfile().getName());
        data.setDirty();
        ctx.getSource().sendSuccess(() -> Component.literal("Создано: " + p.name()), true);
        return 1;
    }

    private static int deleteState(CommandContext<CommandSourceStack> ctx, String rawName) {
        String name = rawName.trim();
        MinecraftServer server = ctx.getSource().getServer();
        RepublicData data = RepublicData.get(server);
        RepublicData.Polity target = null;
        for (RepublicData.Polity p : data.polities()) {
            if (p.name.equals(name)) {
                target = p;
                break;
            }
        }
        if (target == null) return fail(ctx, "Государство «" + name + "» не найдено");

        data.deleteState(target);
        data.setDirty();
        Humanitas.LOGGER.info("[Civitas] Государство «{}» удалено", name);
        ServerPlayer ownerOnline = server.getPlayerList().getPlayer(target.owner);
        if (ownerOnline != null) {
            CabinetNet.sendState(ownerOnline);
        }
        ctx.getSource().sendSuccess(() -> Component.literal("Удалено: " + name), true);
        return 1;
    }

    private static int fail(CommandContext<CommandSourceStack> ctx, String message) {
        ctx.getSource().sendFailure(Component.literal(message));
        return 0;
    }
}
