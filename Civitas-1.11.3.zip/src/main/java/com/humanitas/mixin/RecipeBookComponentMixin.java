package com.humanitas.mixin;

import com.humanitas.client.CivitasRecipeStyle;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.recipebook.RecipeBookComponent;
import net.minecraft.resources.ResourceLocation;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import net.minecraft.client.gui.components.EditBox;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/**
 * Replaces the white vanilla texture behind the recipe book with the Civitas plate. Only the
 * background blit is redirected; search box, tabs, filter button and recipe cells keep working.
 */
@Mixin(RecipeBookComponent.class)
public abstract class RecipeBookComponentMixin {
    @Shadow private EditBox searchBox;
    @Inject(method="initVisuals()V",at=@At("TAIL"))
    private void civitas$searchSetup(CallbackInfo ci) { CivitasRecipeStyle.prepareSearch(searchBox); }

    @Redirect(method="render(Lnet/minecraft/client/gui/GuiGraphics;IIF)V",at=@At(value="INVOKE",target="Lnet/minecraft/client/gui/components/EditBox;render(Lnet/minecraft/client/gui/GuiGraphics;IIF)V"))
    private void civitas$search(EditBox search,GuiGraphics g,int mx,int my,float partial) {
        if(CivitasRecipeStyle.enabled())CivitasRecipeStyle.search(g,search);
        search.render(g,mx,my,partial);
    }

    @Redirect(
            method = "render(Lnet/minecraft/client/gui/GuiGraphics;IIF)V",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/gui/GuiGraphics;blit(Lnet/minecraft/resources/ResourceLocation;IIIIII)V"))
    private void civitas$background(GuiGraphics g, ResourceLocation texture, int x, int y,
                                    int u, int v, int w, int h) {
        if(CivitasRecipeStyle.enabled())CivitasRecipeStyle.background(g,x,y,w,h);
        else g.blit(texture,x,y,u,v,w,h);
    }
}
