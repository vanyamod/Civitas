package com.humanitas.mixin;

import com.humanitas.client.CivitasRecipeStyle;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.ResourceLocation;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Covers the book's tabs, filters, pagination and alternative-recipe popup at their shared draw path. */
@Mixin(GuiGraphics.class)
public abstract class RecipeSpriteMixin {
    @Inject(method="blitSprite(Lnet/minecraft/resources/ResourceLocation;IIIII)V",at=@At("HEAD"),cancellable=true)
    private void civitas$recipeSprite(ResourceLocation sprite,int x,int y,int z,int w,int h,CallbackInfo ci) {
        if(!CivitasRecipeStyle.supported(sprite) || !CivitasRecipeStyle.enabled())return;
        GuiGraphics g=(GuiGraphics)(Object)this;
        g.pose().pushPose();g.pose().translate(0,0,z);
        CivitasRecipeStyle.widget(g,sprite,x,y,w,h);
        g.pose().popPose();ci.cancel();
    }
}
