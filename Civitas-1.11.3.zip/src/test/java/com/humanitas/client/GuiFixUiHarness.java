package com.humanitas.client;

import com.humanitas.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Screenshot;
import net.minecraft.nbt.*;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.network.PacketDistributor;
import java.lang.reflect.*;
import java.nio.file.*;

/** Two simultaneously connected clients exercise the real UI, role assignment and live ballots. */
@EventBusSubscriber(modid=Humanitas.MODID,value=Dist.CLIENT)
public final class GuiFixUiHarness {
    private static int ticks,step,waits;private static boolean failed;private static String org="",resolution="";private static Path sync;
    private static Object get(Object o,String n)throws Exception{var f=o.getClass().getDeclaredField(n);f.setAccessible(true);return f.get(o);}
    private static void set(Object o,String n,Object v)throws Exception{var f=o.getClass().getDeclaredField(n);f.setAccessible(true);f.set(o,v);}
    private static Object call(Object o,String n,Class<?>[] types,Object... args)throws Exception{var m=o.getClass().getDeclaredMethod(n,types);m.setAccessible(true);return m.invoke(o,args);}
    private static void check(boolean ok,String message){if(!ok)throw new IllegalStateException(message);}
    private static CompoundTag data()throws Exception{var screen=Minecraft.getInstance().screen;check(screen instanceof OrganizationsScreen,"Expected organization desk");check(!(boolean)get(screen,"busy"),"Request pending");return (CompoundTag)get(screen,"data");}
    private static void open(String tab){Minecraft.getInstance().setScreen(new OrganizationsScreen(null,org,tab));}
    private static void capture(String name){var mc=Minecraft.getInstance();Screenshot.grab(mc.gameDirectory,"fix-"+name+".png",mc.getMainRenderTarget(),c->Humanitas.LOGGER.info("Fix screenshot {}",name));}
    private static void mark(String name)throws Exception{Files.writeString(sync.resolve(name),"ok");}
    private static boolean marked(String name){return Files.exists(sync.resolve(name));}
    private static void send(String op,String target,CompoundTag fields)throws Exception{call(Minecraft.getInstance().screen,"send",new Class<?>[]{String.class,String.class,CompoundTag.class},op,target,fields);}
    private static void focusResolution()throws Exception{var d=data();resolution=d.getList("rows",10).getCompound(0).getString("id");set(Minecraft.getInstance().screen,"focus",resolution);call(Minecraft.getInstance().screen,"request",new Class<?>[]{});}
    private static void voteOrg()throws Exception{var r=data().getCompound("detail");var f=new CompoundTag();f.putString("unit",r.getList("units",10).getCompound(0).getString("id"));f.putInt("choice",1);send("vote",resolution,f);}
    @SubscribeEvent public static void tick(ClientTickEvent.Post e){
        if(!Boolean.getBoolean("civitas.guiFixHarness")||failed)return;var mc=Minecraft.getInstance();if(mc.player==null||mc.level==null||++ticks%30!=0)return;
        try{
            if(sync==null){sync=mc.gameDirectory.toPath().toAbsolutePath().normalize().getParent().resolve("gui-fix-coordination");Files.createDirectories(sync);}
            if(marked("render-news-only")){renderNews(mc);return;}
            boolean admin=mc.player.getGameProfile().getName().equals("CivitasAdmin");Humanitas.LOGGER.info("GUI_FIX {} step {}",admin?"admin":"member",step);
            boolean advance=run(mc,admin);if(advance){step++;waits=0;}else if(++waits>100)throw new IllegalStateException("Timed out waiting for peer at "+step);
        }catch(Exception ex){failed=true;Humanitas.LOGGER.error("GUI_FIX_FAILED "+step,ex);try{Files.writeString(mc.gameDirectory.toPath().resolve("gui-fix-result.txt"),"FAIL step "+step+": "+ex);}catch(Exception ignored){}mc.stop();}
    }
    private static void renderNews(Minecraft mc)throws Exception{
        Humanitas.LOGGER.info("NEWS_LAYOUT_FIX step {}",step);
        switch(step){
            case 0 -> {mc.getToasts().clear();mc.options.guiScale().set(2);mc.resizeDisplay();CabinetRequests.openFresh();}
            case 1 -> {if(!(mc.screen instanceof WheelScreen))return;CabinetClientState.canPostFaction=true;CabinetClientState.canPostState=true;mc.setScreen(new NewsEditorScreen(mc.screen));}
            case 2 -> {
                check(!(boolean)get(mc.screen,"compact"),"Normal window layout");
                Object title=get(mc.screen,"title"),body=get(mc.screen,"body"),footer=get(mc.screen,"footer");
                check((int)get(title,"y")+(int)get(title,"h")<=(int)get(body,"y"),"Title and body do not overlap");
                check((int)get(body,"y")+(int)get(body,"h")<(int)get(footer,"y"),"Body and source do not overlap");
                capture("news-normal-fixed");mc.options.guiScale().set(4);mc.resizeDisplay();
            }
            case 3 -> {check((boolean)get(mc.screen,"compact"),"Small window uses section tabs");capture("news-small-title-fixed");call(mc.screen,"focus",new Class<?>[]{TextInput.class},get(mc.screen,"body"));}
            case 4 -> {Object body=get(mc.screen,"body");check((int)get(body,"h")>=20&&(int)get(body,"y")+(int)get(body,"h")<=(int)get(mc.screen,"bottom"),"Compact body stays above footer");capture("news-small-body-fixed");call(mc.screen,"focus",new Class<?>[]{TextInput.class},get(mc.screen,"footer"));}
            case 5 -> {capture("news-small-source-fixed");Files.writeString(mc.gameDirectory.toPath().resolve("news-layout-result.txt"),"PASS: normal and small layouts; separate author row; title/body/source/footer bounds do not overlap.");}
            case 6 -> mc.stop();
        }step++;
    }
    private static boolean run(Minecraft mc,boolean admin)throws Exception{
        switch(step){
            case 0 -> {CabinetRequests.openFresh();}
            case 1 -> {if(!(mc.screen instanceof WheelScreen))return false;org=((WheelScreen)mc.screen).data.getString("organizationId");check(!org.isBlank(),"Saved congress context");open("overview");}
            case 2 -> {data();capture("overview");if(admin){call(mc.screen,"start",new Class<?>[]{String.class,String[].class},"create",new String[]{"Название","Компактное название"});}else mark("member-ready");}
            case 3 -> {if(admin){var fields=(java.util.List<?>)get(mc.screen,"inputs");check((int)get(fields.get(0),"h")==22,"Single line title height must be 22");capture("name-compact");open("overview");}}
            case 4 -> {if(admin){var p=data().getCompound("profile");mc.setScreen(new OrganizationCharterScreen(mc.screen,p.getString("name"),p.getString("charter")));}}
            case 5 -> {if(admin){capture("charter");open("overview");}}
            case 6 -> {if(admin){var p=data().getCompound("profile");call(mc.screen,"start",new Class<?>[]{String.class,String[].class},"profile",new String[]{"Название",p.getString("name"),"Описание",p.getString("description"),"Устав",p.getString("charter")});mc.screen.resize(mc,440,240);}}
            case 7 -> {if(admin){var fields=(java.util.List<?>)get(mc.screen,"inputs");var desc=fields.get(1);int x=(int)get(desc,"x"),y=(int)get(desc,"y");int before=(int)get(mc.screen,"formScroll");mc.screen.mouseScrolled(x+8,y+8,0,-1);check((int)get(mc.screen,"formScroll")>before,"Wheel over description must scroll profile");capture("profile-scroll");mc.screen.resize(mc,mc.getWindow().getGuiScaledWidth(),mc.getWindow().getGuiScaledHeight());open("people");}}
            case 8 -> {if(admin){data();call(mc.screen,"picker",new Class<?>[]{String.class,String.class},"assignRole",mc.player.getUUID().toString());}}
            case 9 -> {if(admin){var d=data();var rows=d.getList("rows",10);CompoundTag role=null;for(int i=0;i<rows.size();i++)if(rows.getCompound(i).getString("id").equals("secretary"))role=rows.getCompound(i);check(role!=null,"Secretary role offered");call(mc.screen,"choose",new Class<?>[]{CompoundTag.class},role);}}
            case 10 -> {if(admin){var rows=data().getList("rows",10);boolean found=false;for(int i=0;i<rows.size();i++){var r=rows.getCompound(i);if(r.getString("id").equals(mc.player.getUUID().toString())){found=r.getString("role").equals("secretary")&&r.getString("subtitle").contains("Секретариат");}}check(found,"Role assigned through picker and visible alongside chair title");capture("role-assigned");CabinetClientState.canPostFaction=true;CabinetClientState.canPostState=true;mc.setScreen(new NewsEditorScreen(mc.screen));}}
            case 11 -> {if(admin){int top=(int)get(mc.screen,"top"),py=(int)get(mc.screen,"py");check(top>=py+65,"Author selection gets a separate header row");capture("news-header");}open("agenda");}
            case 12 -> {data();focusResolution();}
            case 13 -> {data();mark(admin?"admin-org-view":"member-org-view");if(!admin)voteOrg();}
            case 14 -> {if(!admin){if(!data().getCompound("detail").getList("units",10).getCompound(0).getBoolean("voted"))return false;mark("member-org-voted");}else{if(!marked("member-org-voted"))return false;check(data().getCompound("detail").getInt("yes")==1,"Peer's first organization vote is visible");voteOrg();mark("admin-org-voted");}}
            case 15 -> {if(!marked("admin-org-voted"))return false;check(data().getCompound("detail").getInt("yes")==2,"Both organization votes update without closing GUI");capture(admin?"admin-live-org":"member-live-org");mark(admin?"admin-org-pass":"member-org-pass");}
            case 16 -> {if(!marked("admin-org-pass")||!marked("member-org-pass"))return false;var f=new CompoundTag();f.putString("kind","state");String state=java.util.UUID.nameUUIDFromBytes("OfflinePlayer:CivitasAdmin".getBytes(java.nio.charset.StandardCharsets.UTF_8)).toString();PacketDistributor.sendToServer(new OrganizationsNet.Action(new OrganizationsNet.Request(9000,"","contexts",0,"",""),"context",state,f));}
            case 17 -> {mc.setScreen(null);CabinetRequests.openFresh();}
            case 18 -> {if(!(mc.screen instanceof WheelScreen))return false;var d=((WheelScreen)mc.screen).data;var bill=d.getList("bills",10).getCompound(0);mc.setScreen(new LawInfoScreen(mc.screen,bill));}
            case 19 -> {mark(admin?"admin-law-view":"member-law-view");if(!admin)call(mc.screen,"vote",new Class<?>[]{boolean.class},true);}
            case 20 -> {var law=(CompoundTag)get(mc.screen,"law");if(!admin){if(!law.getString("mine").equals("yes"))return false;mark("member-law-voted");}else{if(!marked("member-law-voted"))return false;if(law.getInt("yes")!=1)return false;call(mc.screen,"vote",new Class<?>[]{boolean.class},true);mark("admin-law-voted");}}
            case 21 -> {if(!marked("admin-law-voted"))return false;var law=(CompoundTag)get(mc.screen,"law");if(law.getInt("yes")!=2)return false;capture(admin?"admin-live-law":"member-live-law");Files.writeString(mc.gameDirectory.toPath().resolve("gui-fix-result.txt"),"PASS: two simultaneously connected players saw both organization and state-law votes in the same open GUI; "+(admin?"compact fields, profile scrolling, charter, role picker and news header verified":"peer live updates verified"));mark(admin?"admin-pass":"member-pass");}
            case 22 -> {if(!marked("admin-pass")||!marked("member-pass"))return false;if(admin){CabinetClientState.canPostFaction=true;CabinetClientState.canPostState=true;mc.setScreen(new NewsEditorScreen(mc.screen));}else mc.stop();}
            case 23 -> {if(admin)capture("news-final");}
            case 24 -> {if(admin)mc.stop();}
        }return true;
    }
}
