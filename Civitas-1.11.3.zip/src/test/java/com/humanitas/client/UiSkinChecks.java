package com.humanitas.client;

import net.minecraft.resources.ResourceLocation;
import static com.humanitas.client.CivitasRecipeStyle.Part.*;

/** Guards recipe-widget coverage and readable menu text across every built-in palette. */
public final class UiSkinChecks {
    private static int checks;
    private static void check(boolean condition){checks++;if(!condition)throw new AssertionError("UI skin assertion #"+checks);}
    private static double component(int color,int shift){double c=(color>>shift&255)/255.0;return c<=0.04045?c/12.92:Math.pow((c+0.055)/1.055,2.4);}
    private static double luminance(int color){return 0.2126*component(color,16)+0.7152*component(color,8)+0.0722*component(color,0);}
    private static double contrast(int a,int b){double x=luminance(a),y=luminance(b);return (Math.max(x,y)+0.05)/(Math.min(x,y)+0.05);}
    private static void part(String name,CivitasRecipeStyle.Part expected){check(CivitasRecipeStyle.part(ResourceLocation.withDefaultNamespace("recipe_book/"+name))==expected);}
    public static void main(String[] args){
        part("tab",TAB);part("tab_selected",TAB);part("button",BOOK);part("button_highlighted",BOOK);
        for(String prefix:new String[]{"filter","furnace_filter"})for(String state:new String[]{"enabled","disabled"})for(String focus:new String[]{"","_highlighted"})part(prefix+"_"+state+focus,FILTER);
        for(String direction:new String[]{"forward","backward"})for(String focus:new String[]{"","_highlighted"})part("page_"+direction+focus,direction.equals("forward")?FORWARD:BACKWARD);
        for(String name:new String[]{"slot_craftable","slot_uncraftable","slot_many_craftable","slot_many_uncraftable","crafting_overlay","crafting_overlay_disabled_highlighted","furnace_overlay","furnace_overlay_disabled_highlighted"})part(name,SLOT);
        part("overlay_recipe",OVERLAY);part("future_unknown_widget",NONE);
        check(CivitasRecipeStyle.part(ResourceLocation.fromNamespaceAndPath("another_mod","recipe_book/tab"))==NONE);
        check(CivitasRecipeStyle.part(ResourceLocation.withDefaultNamespace("widget/button"))==NONE);
        for(CivitasPalette palette:CivitasPalette.values()){
            CivitasUi.applyPalette(palette);
            int normal=CivitasColors.mix(CivitasUi.PLATE,CivitasUi.TEXT_LIGHT,0.025F);
            int hover=CivitasColors.mix(CivitasUi.PLATE,CivitasUi.TEXT_LIGHT,0.08F);
            int selected=CivitasColors.mix(CivitasUi.PLATE,CivitasUi.GOLD,0.10F);
            check(contrast(CivitasUi.TEXT_LIGHT,normal)>=4.5);
            check(contrast(CivitasUi.TEXT_LIGHT,hover)>=4.5);
            check(contrast(CivitasUi.GOLD,selected)>=3.0);
            check(contrast(CivitasUi.INK,CivitasUi.CREAM_DEEP)>=4.5);
        }
        CivitasUi.applyPalette(CivitasPalette.GRAPHITE);
        System.out.println("UI skin: "+checks+" recipe coverage, namespace isolation and palette contrast checks passed.");
    }
}
