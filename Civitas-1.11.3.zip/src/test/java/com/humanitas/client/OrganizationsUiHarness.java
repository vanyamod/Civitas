package com.humanitas.client;

import com.humanitas.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Screenshot;
import net.minecraft.nbt.*;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.ScreenEvent;
import net.neoforged.neoforge.network.PacketDistributor;
import java.lang.reflect.*;
import java.nio.file.*;

/** Opt-in, test-source-only client scenario. Exercises real networking and captures real rendered frames. */
@EventBusSubscriber(modid=Humanitas.MODID,value=Dist.CLIENT)
public final class OrganizationsUiHarness {
    private static int ticks,step;private static String org="",stateA="",stateB="",resolution="";private static boolean failed;
    private static Object get(Object o,String field)throws Exception{Field f=o.getClass().getDeclaredField(field);f.setAccessible(true);return f.get(o);}
    private static void set(Object o,String field,Object value)throws Exception{Field f=o.getClass().getDeclaredField(field);f.setAccessible(true);f.set(o,value);}
    private static void form(String kind,String... fields)throws Exception{var method=OrganizationsScreen.class.getDeclaredMethod("start",String.class,String[].class);method.setAccessible(true);method.invoke(Minecraft.getInstance().screen,kind,fields);}
    private static void capture(String name){var mc=Minecraft.getInstance();Screenshot.grab(mc.gameDirectory,"org-"+name+".png",mc.getMainRenderTarget(),c->Humanitas.LOGGER.info("UI capture {}: {}",name,c.getString()));}
    private static void open(String tab){Minecraft.getInstance().setScreen(new OrganizationsScreen(null,org,tab));}
    private static CompoundTag ready()throws Exception{var mc=Minecraft.getInstance();if(!(mc.screen instanceof OrganizationsScreen))throw new IllegalStateException("Expected OrganizationsScreen, got "+mc.screen);if((boolean)get(mc.screen,"busy"))throw new IllegalStateException("Organization request still pending");return (CompoundTag)get(mc.screen,"data");}
    private static void require(boolean ok,String message){if(!ok)throw new IllegalStateException(message);}
    private static void choose(String kind,String id){var f=new CompoundTag();f.putString("kind",kind);PacketDistributor.sendToServer(new OrganizationsNet.Action(new OrganizationsNet.Request(100000+step,"","contexts",0,"",""),"context",id,f));}
    @SubscribeEvent public static void key(ScreenEvent.KeyPressed.Pre event){if(Boolean.getBoolean("civitas.uiHarness"))event.setCanceled(true);}
    @SubscribeEvent public static void mouse(ScreenEvent.MouseButtonPressed.Pre event){if(Boolean.getBoolean("civitas.uiHarness"))event.setCanceled(true);}
    @SubscribeEvent public static void scroll(ScreenEvent.MouseScrolled.Pre event){if(Boolean.getBoolean("civitas.uiHarness"))event.setCanceled(true);}
    @SubscribeEvent public static void opened(ScreenEvent.Opening event){if(Boolean.getBoolean("civitas.uiHarness"))Humanitas.LOGGER.info("UI harness screen: {}",event.getNewScreen()==null?"game":event.getNewScreen().getClass().getSimpleName());}
    @SubscribeEvent public static void tick(ClientTickEvent.Post event){
        if(!Boolean.getBoolean("civitas.uiHarness")||Boolean.getBoolean("civitas.guiFixHarness")||failed)return;var mc=Minecraft.getInstance();if(mc.level==null||mc.player==null)return;if(++ticks%60!=0)return;
        try{if(mc.player.getGameProfile().getName().equals("Delegate250")){memberStep(mc);return;}Humanitas.LOGGER.info("Organization UI harness step {}",step);switch(step++){
            case 0 -> {mc.getWindow().setWindowed(1280,800);mc.options.guiScale().set(2);mc.resizeDisplay();mc.getToasts().clear();CabinetRequests.openFresh();}
            case 1 -> {require(mc.screen instanceof WheelScreen,"Wheel must open");var d=((WheelScreen)mc.screen).data;require(d.getBoolean("organizationContext"),"Saved organization must be selected on login");org=d.getString("organizationId");capture("01-wheel");open("overview");}
            case 2 -> {var d=ready();require(d.getCompound("profile").getInt("population")==300,"Expected 300 participants");capture("02-overview");open("people");}
            case 3 -> {var d=ready();require(d.getInt("count")==300&&d.getList("rows",10).size()==8,"Bounded people page");capture("03-people");set(mc.screen,"query","Delegate299");set(mc.screen,"page",0);var m=OrganizationsScreen.class.getDeclaredMethod("request");m.setAccessible(true);m.invoke(mc.screen);}
            case 4 -> {require(ready().getInt("count")==1,"Search must return one participant");capture("04-search");open("states");}
            case 5 -> {require(ready().getInt("count")==60,"Sixty delegations");capture("05-states");open("roles");}
            case 6 -> {var d=ready();capture("06-roles");set(mc.screen,"rightsMask",OrganizationsData.PROPOSE|OrganizationsData.VOTE|OrganizationsData.NEWS);form("role","Название роли","Дипломатическая служба");}
            case 7 -> {capture("07-role-editor");open("agenda");}
            case 8 -> {var d=ready();require(d.getInt("count")==12,"Twelve fixture resolutions");var rows=d.getList("rows",10);require(rows.getCompound(0).getBoolean("pending"),"Uncast ballots must be first");resolution=rows.getCompound(0).getString("id");capture("08-agenda");set(mc.screen,"focus",resolution);var m=OrganizationsScreen.class.getDeclaredMethod("request");m.setAccessible(true);m.invoke(mc.screen);}
            case 9 -> {require(!ready().getCompound("detail").getList("units",10).isEmpty(),"Actual electorate must permit a vote");capture("09-ballot");var d=ready();var f=new CompoundTag();f.putString("unit",d.getCompound("detail").getList("units",10).getCompound(0).getString("id"));f.putInt("choice",1);var m=OrganizationsScreen.class.getDeclaredMethod("send",String.class,String.class,CompoundTag.class);m.setAccessible(true);m.invoke(mc.screen,"vote",resolution,f);}
            case 10 -> {require(ready().getCompound("detail").getList("units",10).getCompound(0).getBoolean("voted"),"Server accepted the real ballot");capture("10-voted");open("agenda");}
            case 11 -> {ready();form("draft","Название резолюции","Международная торговая хартия","Текст резолюции","1. Общие правила сотрудничества.\n2. Прозрачные условия торговли.\n3. Публикация итогов заседания.");}
            case 12 -> {capture("11-draft-editor");mc.setScreen(new OrganizationsScreen(null,"","contexts"));}
            case 13 -> {var d=ready();require(d.getInt("count")==4,"Two states and two organizations");var rows=d.getList("rows",10);for(int i=0;i<rows.size();i++){var r=rows.getCompound(i);if(r.getString("kind").equals("state")){if(stateA.isEmpty())stateA=r.getString("id");else stateB=r.getString("id");}}capture("12-contexts");choose("state",stateA);}
            case 14 -> {mc.setScreen(null);CabinetRequests.openFresh();}
            case 15 -> {var d=((WheelScreen)mc.screen).data;require(!d.getBoolean("organizationContext")&&d.getString("stateId").equals(stateA),"First chosen state must be authoritative");capture("13-state-one");choose("state",stateB);}
            case 16 -> {mc.setScreen(null);CabinetRequests.openFresh();}
            case 17 -> {var d=((WheelScreen)mc.screen).data;require(d.getString("stateId").equals(stateB),"Second chosen state must be authoritative");capture("14-state-two");choose("org",org);}
            case 18 -> {mc.setScreen(null);CabinetRequests.openFresh();}
            case 19 -> {var d=((WheelScreen)mc.screen).data;require(d.getBoolean("organizationContext")&&d.getBoolean("canPostState"),"Organization publishing scope must be restored");mc.setScreen(new NewsEditorScreen(mc.screen));}
            case 20 -> {capture("15-org-news-editor");mc.options.guiScale().set(3);mc.resizeDisplay();open("agenda");}
            case 21 -> {ready();capture("16-scale-three");open("roles");}
            case 22 -> {ready();set(mc.screen,"rightsMask",255);form("role","Название роли","Совет конгресса");}
            case 23 -> {capture("17-role-scale-three");Files.writeString(mc.gameDirectory.toPath().resolve("organization-ui-result.txt"),"PASS: real server snapshots; 300 people / 60 states; search; captured ballot cast; two states and organizations switched; role/draft/news forms at GUI scales 2 and 3.\n");Humanitas.LOGGER.info("ORGANIZATION_UI_HARNESS_PASS");}
            case 24 -> mc.stop();
            default -> {}
        }}catch(Exception ex){failed=true;Humanitas.LOGGER.error("ORGANIZATION_UI_HARNESS_FAILED step "+(step-1),ex);try{Files.writeString(mc.gameDirectory.toPath().resolve("organization-ui-result.txt"),"FAIL step "+(step-1)+": "+ex);}catch(Exception ignored){}mc.stop();}
    }
    private static void send(String op,String target,CompoundTag fields)throws Exception{var m=OrganizationsScreen.class.getDeclaredMethod("send",String.class,String.class,CompoundTag.class);m.setAccessible(true);m.invoke(Minecraft.getInstance().screen,op,target,fields);}
    private static void memberStep(Minecraft mc)throws Exception{
        Humanitas.LOGGER.info("Organization member UI step {}",step);switch(step++){
            case 0 -> {mc.options.guiScale().set(3);mc.resizeDisplay();mc.getToasts().clear();mc.setScreen(new OrganizationsScreen(null));}
            case 1 -> {var d=ready();require(!d.getBoolean("admin")&&d.getInt("count")==2,"Ordinary participant sees catalog without admin privileges");var f=new CompoundTag();f.putString("name","Forbidden organization");send("create","",f);}
            case 2 -> {var d=ready();require(!d.getBoolean("actionOk")&&d.getInt("count")==2,"Forged non-admin create must be rejected by real server");var rows=d.getList("rows",10);for(int i=0;i<rows.size();i++)if(rows.getCompound(i).getString("title").equals("Всемирный конгресс"))org=rows.getCompound(i).getString("id");require(!org.isEmpty(),"Congress is in public catalog");open("overview");}
            case 3 -> {var d=ready();require(d.getCompound("profile").getInt("rights")==OrganizationsData.VOTE&&!d.getCompound("profile").getBoolean("head"),"Ordinary membership has only vote permission");capture("member-01-profile");choose("org",org);}
            case 4 -> {mc.setScreen(null);CabinetRequests.openFresh();}
            case 5 -> {var d=((WheelScreen)mc.screen).data;require(d.getBoolean("organizationContext")&&!d.getBoolean("canPostState")&&!d.getBoolean("canArchive")&&!d.getBoolean("canPropose"),"Cabinet cannot inherit admin or state authority");capture("member-02-wheel");open("agenda");}
            case 6 -> {var d=ready();var rows=d.getList("rows",10);for(int i=0;i<rows.size();i++)if(rows.getCompound(i).getBoolean("pending")){resolution=rows.getCompound(i).getString("id");break;}require(!resolution.isEmpty(),"Ordinary member has a pending personal ballot");set(mc.screen,"focus",resolution);var m=OrganizationsScreen.class.getDeclaredMethod("request");m.setAccessible(true);m.invoke(mc.screen);}
            case 7 -> {var d=ready().getCompound("detail");require(!d.getBoolean("session"),"Member cannot moderate session");var units=d.getList("units",10);require(units.size()==1,"One personal ballot unit");capture("member-03-ballot");var f=new CompoundTag();f.putString("unit",units.getCompound(0).getString("id"));f.putInt("choice",2);send("vote",resolution,f);}
            case 8 -> {var d=ready();require(d.getCompound("detail").getList("units",10).getCompound(0).getBoolean("voted"),"Ordinary member vote persists in refreshed server snapshot");capture("member-04-voted");open("roles");}
            case 9 -> {ready();capture("member-05-roles");Files.writeString(mc.gameDirectory.toPath().resolve("organization-ui-result.txt"),"PASS: non-admin catalog, forged create rejected, scoped permissions, no publishing/moderation authority, personal ballot accepted through actual server.\n");Humanitas.LOGGER.info("ORGANIZATION_MEMBER_UI_PASS");}
            case 10 -> mc.stop();
            default -> {}
        }
    }
}
