package com.humanitas;

import net.minecraft.nbt.*;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Explicit fixture writer for the isolated development world; never targets a player's save. */
public final class CitizensFixture {
    private static UUID user(String name){return UUID.nameUUIDFromBytes(("OfflinePlayer:"+name).getBytes(StandardCharsets.UTF_8));}
    public static void main(String[] args)throws Exception{
        Path folder=Path.of("build/citizens-ui-server/world/data").toAbsolutePath();Files.createDirectories(folder);
        if(Files.exists(folder.resolve("humanitas_res_publica.dat")))return;
        RepublicData data=new RepublicData();UUID leader=user("CivitasAdmin"),citizen=user("CivitasCitizen"),guest=user("CivitasGuest");
        var a=data.createPolity("Республика","Аврора",leader,"CivitasAdmin");a.members.add(citizen);a.memberNames.add("CivitasCitizen");
        a.constitution="Граждане участвуют в жизни государства. Законы вносят уполномоченные роли.";
        var b=data.createPolity("Королевство","Нордхольм",user("NorthernChief"),"NorthernChief");
        CitizensData citizens=new CitizensData();citizens.state(a.owner).open=true;citizens.state(a.owner).instructions="Расскажите о себе и о том, чем хотите заниматься.";
        citizens.apply(data,a,guest,"CivitasGuest","Хочу развивать торговлю и строить города.",System.currentTimeMillis());
        citizens.invite(data,b,user("CivitasInvitee"),"CivitasInvitee",System.currentTimeMillis());
        for(int i=1;i<=5;i++){var law=data.createBill("Развитие города "+i,"Описание законопроекта.\n\nЗдесь находится текст и условия предлагаемого закона.","CivitasAdmin",a.owner);law.proposedDay=java.time.LocalDate.of(1948,1,i).toEpochDay();if(i==1)law.closed=true;if(i==2)law.yes.add(citizen.toString());}
        data.logFor(a.owner,"Служебная запись: обычный гражданин не должен её видеть.");
        write(folder.resolve("humanitas_res_publica.dat"),data.save(new CompoundTag(),null));
        write(folder.resolve("civitas_citizens.dat"),citizens.write(new CompoundTag()));
        System.out.println("Isolated UI fixture prepared: "+folder);
    }
    private static void write(Path path,CompoundTag data)throws Exception{CompoundTag root=new CompoundTag();root.put("data",data);NbtIo.writeCompressed(root,path);}
}
