package com.humanitas;

import com.humanitas.OrganizationsData.*;
import net.minecraft.nbt.*;
import java.util.*;

/** Authority, consent, delegate replacement, immutable electorates, restart and congress-scale data. */
public final class OrganizationsChecks {
    private static int checks;
    private static void check(boolean ok,String message){checks++;if(!ok)throw new AssertionError(message);}
    private static void reject(Runnable task){checks++;try{task.run();throw new AssertionError("Unauthorized or stale action accepted");}catch(IllegalArgumentException expected){}}
    private static Actor user(String name){return new Actor(UUID.randomUUID(),name,false);}
    private static Actor admin(String name){return new Actor(UUID.randomUUID(),name,true);}
    public static void main(String[] args){
        long now=1_800_000_000_000L;RepublicData republic=new RepublicData();OrganizationsData store=new OrganizationsData();
        Actor admin=admin("Administrator"),chair=user("Chair"),plain=user("Member"),outsider=user("Outsider"),successor=user("Successor");
        reject(()->store.create(plain,"Forbidden",now));var o=store.create(admin,"Всемирный конгресс",now);
        reject(()->store.create(admin,"Всемирный конгресс",now));
        store.invite(o,republic,admin,chair.id(),chair.name(),now);check(!o.members.containsKey(chair.id()),"Invitation does not silently add a player");
        reject(()->store.join(o,outsider,now));store.join(o,chair,now);store.appoint(o,admin,chair.id(),false,now);
        check(OrganizationsData.has(o,republic,chair,OrganizationsData.ALL),"Non-admin chair has full organization control");
        store.invite(o,republic,chair,plain.id(),plain.name(),now);store.join(o,plain,now);
        check(OrganizationsData.has(o,republic,plain,OrganizationsData.VOTE),"Default member can cast personal ballot");
        reject(()->store.profile(o,republic,plain,"Hijack","","",now));reject(()->store.invite(o,republic,plain,outsider.id(),outsider.name(),now));
        reject(()->store.draft(o,republic,plain,"Forbidden","Body",false,50,false,now));
        reject(()->store.role(o,republic,plain,"","Admin",OrganizationsData.ALL,now));
        reject(()->store.role(o,republic,chair,UUID.randomUUID().toString(),"Unknown",1,now));
        store.profile(o,republic,chair,o.name,"Объединение государств","Устав конгресса",now);
        store.role(o,republic,chair,"","Редакция",OrganizationsData.NEWS,now);String press=o.roles.entrySet().stream().filter(e->e.getValue().name().equals("Редакция")).findFirst().orElseThrow().getKey();
        store.assign(o,republic,chair,plain.id(),press,now);check(OrganizationsData.has(o,republic,plain,OrganizationsData.NEWS)&&!OrganizationsData.has(o,republic,plain,OrganizationsData.PROPOSE),"Rights stay scoped to explicit role");
        store.assign(o,republic,chair,plain.id(),"member",now);
        store.role(o,republic,chair,"","Кадры",OrganizationsData.ROLES|OrganizationsData.MEMBERS,now);String hr=o.roles.entrySet().stream().filter(e->e.getValue().name().equals("Кадры")).findFirst().orElseThrow().getKey();
        store.assign(o,republic,chair,plain.id(),hr,now);reject(()->store.role(o,republic,plain,"","Escalation",OrganizationsData.ALL,now));reject(()->store.assign(o,republic,plain,plain.id(),"council",now));reject(()->store.remove(o,republic,plain,chair.id(),now));
        store.assign(o,republic,chair,plain.id(),"member",now);
        store.invite(o,republic,chair,successor.id(),successor.name(),now);store.join(o,successor,now);store.appoint(o,chair,successor.id(),true,now);
        reject(()->store.remove(o,republic,plain,successor.id(),now));reject(()->store.remove(o,republic,chair,chair.id(),now));
        var personal=store.draft(o,republic,chair,"Общее заседание","Текст резолюции",false,50,false,now);
        reject(()->store.open(o,republic,plain,personal,1,now));store.open(o,republic,chair,personal,1,now);
        check(personal.electorate.size()==4,"Electorate captured including four current members");
        store.vote(o,republic,plain,personal,plain.id(),1,now);reject(()->store.vote(o,republic,plain,personal,plain.id(),0,now));
        reject(()->store.vote(o,republic,admin("Unenrolled admin"),personal,plain.id(),1,now));
        store.vote(o,republic,chair,personal,chair.id(),2,now);check(personal.status==Status.OPEN,"Never finish before deadline");
        check(personal.finish(now+3600000)&&personal.status==Status.ADOPTED,"Abstention counts for quorum, not majority");
        reject(()->store.vote(o,republic,successor,personal,successor.id(),0,now+3600001));
        check(OrganizationsData.units(o,republic,plain,personal).isEmpty(),"Completed ballots carry no actionable voting units");
        var quorum=store.draft(o,republic,chair,"Кворум","Текст",false,100,false,now);store.open(o,republic,chair,quorum,1,now);store.vote(o,republic,chair,quorum,chair.id(),1,now);quorum.finish(now+3600000);check(quorum.status==Status.NO_QUORUM,"Single yes cannot pass without required turnout");
        var tie=store.draft(o,republic,chair,"Равенство","Текст",false,50,false,now);store.open(o,republic,chair,tie,1,now);store.vote(o,republic,chair,tie,chair.id(),1,now);store.vote(o,republic,plain,tie,plain.id(),0,now);tie.finish(now+3600000);check(tie.status==Status.REJECTED,"Tie is rejected");
        var qualified=store.draft(o,republic,chair,"Две трети","Текст",false,50,true,now);store.open(o,republic,chair,qualified,1,now);store.vote(o,republic,chair,qualified,chair.id(),1,now);store.vote(o,republic,plain,qualified,plain.id(),0,now);qualified.finish(now+3600000);check(qualified.status==Status.REJECTED,"Half is insufficient for two thirds");
        var cancelled=store.draft(o,republic,chair,"Снятие","Текст",false,50,false,now);store.cancel(o,republic,chair,cancelled,now);reject(()->store.open(o,republic,chair,cancelled,1,now));
        // Realistic persisted structure: 300 direct participants and sixty independent state mandates.
        List<Actor> people=new ArrayList<>();while(o.members.size()<300){Actor p=user("Участник "+o.members.size());people.add(p);store.invite(o,republic,chair,p.id(),p.name(),now);store.join(o,p,now);}
        List<RepublicData.Polity> states=new ArrayList<>();for(int i=0;i<60;i++){Actor p=people.get(i);var state=republic.createPolity("Республика","Государство "+i,p.id(),p.name());states.add(state);store.applyState(o,republic,p,state.owner,now);reject(()->store.acceptState(o,republic,plain,state.owner,true,now));store.acceptState(o,republic,chair,state.owner,true,now);store.delegate(o,republic,p,state.owner,p.id(),now);}
        var stateVote=store.draft(o,republic,chair,"Мандаты государств","Одна страна — один голос",true,50,true,now);store.open(o,republic,chair,stateVote,24,now);
        check(stateVote.electorate.size()==60,"Exactly sixty states, not three hundred personal votes");
        Actor first=people.get(0),replacement=people.get(100);var firstState=states.get(0);store.vote(o,republic,first,stateVote,firstState.owner,1,now);
        firstState.members.add(replacement.id());firstState.memberNames.add(replacement.name());store.delegate(o,republic,first,firstState.owner,replacement.id(),now);
        reject(()->store.vote(o,republic,replacement,stateVote,firstState.owner,1,now));check(stateVote.ballots.size()==1,"Replacing delegate cannot duplicate a state vote");
        reject(()->store.vote(o,republic,first,stateVote,firstState.owner,0,now));reject(()->store.delegate(o,republic,plain,firstState.owner,plain.id(),now));
        var second=states.get(1);second.members.add(replacement.id());second.memberNames.add(replacement.name());store.delegate(o,republic,people.get(1),second.owner,replacement.id(),now);
        check(OrganizationsData.units(o,republic,replacement,stateVote).size()==2,"One diplomat may represent two states with distinct explicit ballots");
        store.vote(o,republic,replacement,stateVote,second.owner,2,now);check(stateVote.ballots.size()==2,"Second state's ballot remains independent");
        int replacementIndex=second.members.indexOf(replacement.id());second.members.remove(replacementIndex);second.memberNames.remove(replacementIndex);check(OrganizationsData.units(o,republic,replacement,stateVote).size()==1,"Lost citizenship revokes state mandate immediately");
        Actor late=user("Late voter");store.invite(o,republic,chair,late.id(),late.name(),now);store.join(o,late,now);check(!personal.electorate.containsKey(late.id()),"New members never enter an already captured electorate");
        Actor expired=user("Expired");store.invite(o,republic,chair,expired.id(),expired.name(),now);reject(()->store.join(o,expired,now+OrganizationsData.INVITE_TTL));store.maintain(o,republic,now+OrganizationsData.INVITE_TTL);check(!o.invites.containsKey(expired.id()),"Expired invites are pruned");
        var restored=OrganizationsData.load(store.write(new CompoundTag()),null);var saved=restored.organizations.get(o.id);check(saved.members.size()==301&&saved.states.size()==60,"Congress roster survives restart");
        check(saved.chair.equals(chair.id())&&saved.deputy.equals(successor.id())&&saved.charter.equals("Устав конгресса"),"Leadership and charter survive restart");
        var savedVote=OrganizationsData.resolution(saved,stateVote.id.toString());check(savedVote.electorate.size()==60&&savedVote.ballots.size()==2&&savedVote.twoThirds,"Rules, electorate and cast votes survive restart");check(saved.history.size()<=2048,"Bounded organization history");
        republic.selectedStates.put(replacement.id(),second.owner);check(CabinetNet.findPolity(republic,replacement.id())!=second,"Stale state preference confers no membership");
        republic.selectedStates.put(replacement.id(),firstState.owner);check(CabinetNet.findPolity(republic,replacement.id())==firstState,"Explicit valid state selection overrides scan order");
        republic.selectedOrganizations.put(replacement.id(),o.id);var republicReload=RepublicData.load(republic.save(new CompoundTag(),null),null);check(republicReload.selectedStates.get(replacement.id()).equals(firstState.owner)&&republicReload.selectedOrganizations.get(replacement.id()).equals(o.id),"Selected cabinets persist with existing state data");
        check(OrganizationsData.load(new CompoundTag(),null).organizations.isEmpty(),"Legacy worlds need no migration or reset");
        check(!OrganizationsNet.publicEvent(new Event(now,"Внесён проект #1","Private draft"))&&!OrganizationsNet.publicEvent(new Event(now,"Отправлено приглашение","Private person")),"Public history excludes private projects and invitations");
        check(OrganizationsNet.publicEvent(new Event(now,"Резолюция #1 · Принята","Public result")),"Public history retains completed outcomes");
        List<CompoundTag> rows=new ArrayList<>();for(int i=0;i<300;i++){var t=new CompoundTag();t.putInt("index",i);rows.add(t);}check(OrganizationsNet.page(rows,0,8).size()==8&&OrganizationsNet.page(rows,37,8).size()==4&&OrganizationsNet.page(rows,999,8).getFirst().getInt("index")==296,"Paged roster stays bounded and clamps stale page");
        var buffer=new net.minecraft.network.RegistryFriendlyByteBuf(io.netty.buffer.Unpooled.buffer(),net.minecraft.core.RegistryAccess.EMPTY);
        try{var request=new OrganizationsNet.Request(19,o.id.toString(),"agenda",3,"Поиск",personal.id.toString());OrganizationsNet.Request.CODEC.encode(buffer,request);check(OrganizationsNet.Request.CODEC.decode(buffer).equals(request),"Request sequence, search and focus survive transport");buffer.clear();var f=new CompoundTag();f.putString("unit",firstState.owner.toString());f.putInt("choice",1);var action=new OrganizationsNet.Action(request,"vote",personal.id.toString(),f);OrganizationsNet.Action.CODEC.encode(buffer,action);check(OrganizationsNet.Action.CODEC.decode(buffer).equals(action),"Explicit mandate survives action codec");}finally{buffer.release();}
        System.out.println("Organizations: "+checks+" checks passed; 300 participants / 60 states, consent, authority, ballots, restart, context selection and pagination.");
    }
}
