package com.humanitas;

import com.humanitas.OrganizationsData.*;
import net.minecraft.nbt.*;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Only the named isolated development server is seeded. No production save is opened. */
public final class OrganizationsFixture {
    private static UUID user(String name){return UUID.nameUUIDFromBytes(("OfflinePlayer:"+name).getBytes(StandardCharsets.UTF_8));}
    public static void main(String[] args)throws Exception{
        Path folder=Path.of("build/organizations-ui-server/world/data").toAbsolutePath();Files.createDirectories(folder);
        if(Files.exists(folder.resolve("civitas_organizations.dat")))return;
        var data=new RepublicData();var store=new OrganizationsData();long now=System.currentTimeMillis();
        Actor admin=new Actor(user("CivitasAdmin"),"CivitasAdmin",true);var o=store.create(admin,"Всемирный конгресс",now);
        o.description="Площадка сотрудничества государств. Общие решения, дипломатические представительства и единая повестка.";
        o.charter="Статья 1. Государства сохраняют самостоятельность.\n\nСтатья 2. Каждое государство назначает своего представителя.\n\nСтатья 3. Правила голосования и состав фиксируются до начала заседания. Воздержавшиеся учитываются при определении кворума.\n\nСтатья 4. Секретариат публикует решения и новости конгресса.";
        for(int i=1;i<300;i++){String name=String.format(Locale.ROOT,"Delegate%03d",i);o.members.put(user(name),new Person(name,i<8?"secretary":"member"));}
        for(int i=0;i<60;i++){String chief=i==0?"CivitasAdmin":String.format(Locale.ROOT,"Delegate%03d",i);var p=data.createPolity("Республика",i==0?"Аврора":i==1?"Нордхольм":"Государство "+i,user(chief),chief);
            if(i==1){p.members.add(admin.id());p.memberNames.add(admin.name());}
            o.states.put(p.owner,new Delegation(p.owner,p.name,user(chief),chief));}
        for(int i=1;i<=12;i++){var r=store.draft(o,data,admin,i==1?"Открытие международного торгового пути":i==2?"Единый порядок дипломатических представительств":"Заседание конгресса №"+i,"Предлагается согласовать общий порядок сотрудничества.\n\n1. Представители государств обсуждают условия.\n2. Решение принимается по установленному кворуму.\n3. Секретариат публикует итоги.",i%2==0,50,i%3==0,now-i*60000L);if(i<=8){store.open(o,data,admin,r,24,now);if(i==3)store.vote(o,data,admin,r,admin.id(),1,now);}if(i==10)store.cancel(o,data,admin,r,now);}
        var observers=store.create(admin,"Союз наблюдателей",now);observers.description="Независимое объединение участников.";
        data.selectedStates.put(admin.id(),user("CivitasAdmin"));data.selectedOrganizations.put(admin.id(),o.id);
        write(folder.resolve("humanitas_res_publica.dat"),data.save(new CompoundTag(),null));write(folder.resolve("civitas_organizations.dat"),store.write(new CompoundTag()));
        System.out.println("Organization UI fixture prepared: "+folder);
    }
    private static void write(Path path,CompoundTag data)throws Exception{var root=new CompoundTag();root.put("data",data);NbtIo.writeCompressed(root,path);}
}
