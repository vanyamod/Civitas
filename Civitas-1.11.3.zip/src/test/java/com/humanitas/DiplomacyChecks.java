package com.humanitas;

import com.humanitas.DiplomacyData.*;
import java.util.*;

/** State-machine regressions: hostile actors, competing curators and restart persistence. */
public final class DiplomacyChecks {
    private static int checks;
    private static void check(boolean value) { checks++; if(!value)throw new AssertionError("Diplomacy assertion #"+checks); }
    private static void denied(Runnable action) { checks++; try { action.run(); } catch(IllegalArgumentException expected) { return; } throw new AssertionError("Action incorrectly allowed #"+checks); }
    public static void main(String[] args) {
        long now=1_800_000_000_000L;
        UUID a=UUID.randomUUID(),b=UUID.randomUUID(),third=UUID.randomUUID();
        Actor alice=new Actor(UUID.randomUUID(),"Alice",a,true,false,false);
        Actor bob=new Actor(UUID.randomUUID(),"Bob",b,true,false,false);
        Actor outsider=new Actor(UUID.randomUUID(),"Other",third,true,false,false);
        Actor member=new Actor(UUID.randomUUID(),"Member",a,false,false,false);
        Actor admin=new Actor(UUID.randomUUID(),"Admin",null,false,true,false);
        Actor otherAdmin=new Actor(UUID.randomUUID(),"OtherAdmin",null,false,true,false);
        Actor senior=new Actor(UUID.randomUUID(),"Senior",null,false,true,true);
        DiplomacyData d=new DiplomacyData();
        denied(()->d.create(member,b,"A","B",Kind.ALLIANCE,"Alliance","Terms",0,24,now));
        denied(()->d.create(alice,a,"A","A",Kind.ALLIANCE,"Self","Terms",0,24,now));
        Case alliance=d.create(alice,b,"A","B",Kind.ALLIANCE,"Alliance","Terms",0,24,now);
        check(alliance.status==Status.PENDING);
        denied(()->d.act(alice,alliance.id,"accept","",now));
        denied(()->d.act(outsider,alliance.id,"accept","",now));
        denied(()->d.act(member,alliance.id,"accept","",now));
        denied(()->d.create(bob,a,"B","A",Kind.ALLIANCE,"Other alliance","Terms",0,24,now));
        d.act(bob,alliance.id,"accept","",now+1);check(alliance.status==Status.ACTIVE);
        denied(()->d.act(bob,alliance.id,"accept","",now+2));
        denied(()->d.create(alice,b,"A","B",Kind.WAR,"War","Reason",0,24,now));
        d.act(alice,alliance.id,"terminate","",now+2);
        Case war=d.create(alice,b,"A","B",Kind.WAR,"War","Reason",0,24,now+3);
        check(war.status==Status.DECLARED);
        denied(()->d.create(bob,a,"B","A",Kind.WAR,"War 2","Reason",0,24,now+3));
        denied(()->d.act(alice,war.id,"claim","",now));
        denied(()->d.act(admin,war.id,"start","Rules",now));
        d.act(admin,war.id,"claim","",now);check(war.curator.equals(admin.id()));
        denied(()->d.act(otherAdmin,war.id,"claim","",now));
        denied(()->d.act(otherAdmin,war.id,"release","",now));
        denied(()->d.act(otherAdmin,war.id,"end","Reason",now));
        denied(()->d.act(admin,war.id,"start","",now));
        d.act(admin,war.id,"start","Rules approved",now);check(war.status==Status.ACTIVE);
        denied(()->d.create(alice,third,"A","Third",Kind.PEACE,"Peace","Terms",war.id,24,now));
        denied(()->d.create(alice,b,"A","B",Kind.ALLIANCE,"Alliance","Terms",0,24,now));
        Case ceasefire=d.create(bob,a,"B","A",Kind.CEASEFIRE,"Ceasefire","Terms",war.id,24,now);
        d.act(alice,ceasefire.id,"accept","",now+1);check(war.status==Status.PAUSED);
        d.act(admin,war.id,"resume","Talks failed",now+2);check(war.status==Status.ACTIVE);
        check(ceasefire.status==Status.ENDED);
        d.act(admin,war.id,"note","Private evidence",now+3);
        check(war.notes.size()==1 && war.history.stream().noneMatch(s->s.contains("Private evidence")));
        check(DiplomacyNet.visible(war,outsider));
        Case privateOffer=d.create(alice,third,"A","Third",Kind.CUSTOM,"Private","Secret terms",0,24,now);
        check(!DiplomacyNet.visible(privateOffer,bob));check(DiplomacyNet.visible(privateOffer,admin));
        var publicCard=DiplomacyNet.card(war,alice,true);
        check(!publicCard.contains("notes") && !publicCard.getBoolean("end") && !publicCard.getBoolean("claim"));
        check(DiplomacyNet.card(war,admin,true).getList("notes",net.minecraft.nbt.Tag.TAG_STRING).size()==1);
        d.act(senior,war.id,"release","",now); check(war.curator==null);
        d.act(otherAdmin,war.id,"claim","",now);check(war.curator.equals(otherAdmin.id()));
        Case peace=d.create(alice,b,"A","B",Kind.PEACE,"Peace","Terms",war.id,24,now);
        d.act(bob,peace.id,"accept","",now+1);check(war.status==Status.ENDED);
        denied(()->d.act(otherAdmin,war.id,"resume","Reason",now));
        Case ultimatum=d.create(alice,b,"A","B",Kind.ULTIMATUM,"Ultimatum","Demands",0,1,now);
        denied(()->d.act(bob,ultimatum.id,"accept","",now+3_600_000));
        check(d.expireAndReconcile(Set.of(a,b,third),now+3_600_001));
        check(ultimatum.status==Status.EXPIRED);check(d.cases().stream().filter(Case::liveWar).count()==0);
        var restored=DiplomacyData.load(d.save(new net.minecraft.nbt.CompoundTag(),null),null);
        check(restored.find(war.id).status==Status.ENDED);
        check(restored.find(war.id).curator.equals(otherAdmin.id()));
        check(restored.find(war.id).notes.equals(war.notes));check(restored.revision()==d.revision());
        check(restored.cases().size()==d.cases().size());
        check(restored.expireAndReconcile(Set.of(a,b),now+3_600_002));check(restored.find(privateOffer.id).status==Status.ENDED);
        check(DiplomacyData.clean("hello\u0000§aworld",100).equals("hello aworld"));
        denied(()->DiplomacyData.clean("x".repeat(4001),4000));
        var newWar=restored.create(alice,b,"Renamed A","B",Kind.WAR,"New war","Reason",0,24,now+4_000_000);
        check(newWar.id>ultimatum.id && newWar.involves(a));
        DiplomacyData conflict=new DiplomacyData();
        Case pending=conflict.create(alice,b,"A","B",Kind.ALLIANCE,"Alliance","Terms",0,24,now);
        Case declared=conflict.create(alice,b,"A","B",Kind.WAR,"War","Reason",0,24,now);
        denied(()->conflict.act(bob,pending.id,"accept","",now+1));
        Case abandonedPeace=conflict.create(bob,a,"B","A",Kind.PEACE,"Peace","Terms",declared.id,24,now);
        conflict.act(alice,declared.id,"withdraw","",now+2);check(abandonedPeace.status==Status.WITHDRAWN);
        denied(()->new DiplomacyData().create(alice,b,"A","B",Kind.CUSTOM,"Range","Terms",0,0,now));
        denied(()->new DiplomacyData().create(alice,b,"A","B",Kind.CUSTOM,"Range","Terms",0,73,now));
        denied(()->new DiplomacyData().create(alice,b,"A","B",Kind.CUSTOM,"Range","Terms",0,168,now));
        check(new DiplomacyData().create(alice,b,"A","B",Kind.CUSTOM,"Range","Terms",0,37,now).deadline==now+37L*3_600_000);
        check(new DiplomacyData().create(alice,b,"A","B",Kind.CUSTOM,"Range","Terms",0,72,now).deadline==now+72L*3_600_000);
        System.out.println("Diplomacy: "+checks+" authority, lifecycle, privacy, expiry and persistence checks passed.");
    }
}
