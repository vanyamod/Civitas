package com.humanitas;

import com.humanitas.OrganizationsData.*;
import net.minecraft.nbt.*;
import java.nio.file.*;
import java.nio.charset.StandardCharsets;

public final class GuiFixFixture {
    private static java.util.UUID user(String n){return java.util.UUID.nameUUIDFromBytes(("OfflinePlayer:"+n).getBytes(StandardCharsets.UTF_8));}
    public static void main(String[] args)throws Exception{
        var folder=Path.of("build/gui-fix-server/world/data");Files.createDirectories(folder);if(Files.exists(folder.resolve("civitas_organizations.dat")))return;
        long now=System.currentTimeMillis();var republic=new RepublicData();var admin=new Actor(user("CivitasAdmin"),"CivitasAdmin",true);var member=new Actor(user("Delegate250"),"Delegate250",false);
        var state=republic.createPolity("Республика","Аврора",admin.id(),admin.name());state.members.add(member.id());state.memberNames.add(member.name());
        var bill=republic.createBill("Общее голосование","Проверка живого обновления голосов двух игроков",admin.name(),state.owner);bill.proposedDay=java.time.LocalDate.of(1948,1,1).toEpochDay();
        var store=new OrganizationsData();var org=store.create(admin,"Всемирный конгресс",now);store.invite(org,republic,admin,member.id(),member.name(),now);store.join(org,member,now);
        org.description="Объединение государств для сотрудничества, обсуждения инициатив и принятия совместных решений.";
        org.charter="Статья 1. Общие положения\n\nГосударства сохраняют самостоятельность. Представители обсуждают общую повестку.\n\nСтатья 2. Голосование\n\nКаждый участник голосует самостоятельно. Результаты доступны во время заседания.\n\nСтатья 3. Секретариат\n\nСекретариат публикует итоги и ведёт документы организации.";
        var r=store.draft(org,republic,admin,"Торговая хартия","Решение конгресса о международном сотрудничестве.",false,50,false,now);store.open(org,republic,admin,r,24,now);
        for(var id:java.util.List.of(admin.id(),member.id())){republic.selectedStates.put(id,state.owner);republic.selectedOrganizations.put(id,org.id);}
        write(folder.resolve("humanitas_res_publica.dat"),republic.save(new CompoundTag(),null));write(folder.resolve("civitas_organizations.dat"),store.write(new CompoundTag()));
    }
    private static void write(Path p,CompoundTag data)throws Exception{var t=new CompoundTag();t.put("data",data);NbtIo.writeCompressed(t,p);}
}
