# Civitas 1.11.3

Civitas is a political and interface mod for Minecraft Java Edition 1.21.1 and NeoForge.
It provides states, organizations with state delegations, roles and permissions, legislation, constitutional voting,
a news editor with Discord webhook publishing, and a configurable client HUD.

## Build

Install JDK 21. The Gradle wrapper downloads the build tools and dependencies; internet access is required for the first build.

Windows:

```powershell
.\gradlew.bat build
```

Linux / macOS:

```sh
bash ./gradlew build
```

Output: `build/libs/Civitas-1.11.3.jar`.
The build runs regression checks for news formatting, constitutional/senate voting data,
pending UI actions, organization permissions/ballots and the Watchdog dashboard.

## Run and install

```powershell
.\gradlew.bat runClient
.\gradlew.bat runServer
```

Tested baseline: Minecraft 1.21.1, NeoForge 21.1.250, Java 21.
Install the same release on the client and server. The mod identifier remains `humanitas`
to preserve existing worlds and data. Network protocol: `15`.
Close Minecraft before replacing a JAR. Do not keep multiple Civitas releases in `mods`.
The optional Windows helper `tools/install_mod.ps1 -Profile '<profile directory>'` refuses
installation while that profile is running and backs up older releases outside `mods`.

ClientSort is optional for compatibility testing:
`-PcivitasClientSortJar='<path to a local ClientSort JAR>'`.
No Modrinth profile or third-party mod JAR is required to compile this project.

## Configuration

Configuration files are generated on first run. The Discord webhook URL defaults to empty
and is configured only on the server. Never commit live configuration files, webhooks,
world saves, player records or API credentials.

See [CONTEXT.md](CONTEXT.md) for architecture, behavior and known issues, and
[docs/NEWS_EDITOR.md](docs/NEWS_EDITOR.md) for editor details.

## Source and licensing

The project metadata retains `All Rights Reserved`; this export does not grant a new license.
`TEMPLATE_LICENSE.txt` covers the original NeoForged MDK template files only.
Third-party assets and dependencies retain their respective terms.
This archive contains source/resources and the Gradle wrapper, not a game/modpack distribution.

## Diplomacy and supervised wars

Version 1.11.0 adds bilateral agreements, ultimatums and supervised war cases.
Open Diplomacy in the citizen wheel; administrators get a separate Wars section
and private war notifications. See [the diplomacy guide](docs/DIPLOMACY.md).
Client and server must both use the current protocol 15. War status alone does not change PvP or claims.

## Organizations and multiple memberships

Version 1.11.3 adds administrator-created organizations, delegated management,
state representatives, resolutions with quorum and captured electorates, and persistent
switching between state and organization cabinets. Open **Настройки** on the left wheel
and choose **Государство / организация**. See [the organization guide](docs/ORGANIZATIONS.md)
and [the 1.11.3 devblog](docs/DEVLOG-1.11.3.md).
