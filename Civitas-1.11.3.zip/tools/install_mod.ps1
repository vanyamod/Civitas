﻿param(
    [Parameter(Mandatory=$true)]
    [string]$Profile
)
$ErrorActionPreference = 'Stop'
$projectPath = Split-Path -Parent $PSScriptRoot
$versionLine = Get-Content -LiteralPath (Join-Path $projectPath 'gradle.properties') | Where-Object { $_ -match '^mod_version=' } | Select-Object -First 1
$version = ($versionLine -split '=', 2)[1].Trim()
if ($version -notmatch '^[0-9A-Za-z_.-]+$') { throw 'Invalid mod version.' }
$source = Join-Path $projectPath "build\libs\Civitas-$version.jar"
$target = Join-Path $Profile "mods\Civitas-$version.jar"
if (!(Test-Path -LiteralPath $source)) { throw "Build the mod first: $source" }
Add-Type -AssemblyName System.IO.Compression.FileSystem
$archive = [System.IO.Compression.ZipFile]::OpenRead($source)
try {
    foreach ($required in @('com/humanitas/client/TextInput.class', 'com/humanitas/client/TextInput$Snapshot.class', 'com/humanitas/client/NewsEditorScreen.class', 'com/humanitas/client/DiplomacyScreen.class', 'com/humanitas/DiplomacyNet.class', 'com/humanitas/DiplomacyData.class', 'com/humanitas/CitizensData.class', 'com/humanitas/CitizensNet.class', 'com/humanitas/client/StatesScreen.class', 'com/humanitas/client/LawOrder.class', 'com/humanitas/OrganizationsData.class', 'com/humanitas/OrganizationsNet.class', 'com/humanitas/client/OrganizationsScreen.class', 'com/humanitas/client/OrganizationCharterScreen.class')) {
        if ($null -eq $archive.GetEntry($required)) { throw "Incomplete mod archive: $required is missing." }
    }
    foreach ($entry in $archive.Entries) {
        $stream = $entry.Open()
        try { $stream.CopyTo([System.IO.Stream]::Null) } finally { $stream.Dispose() }
    }
} finally { $archive.Dispose() }
$running = Get-CimInstance Win32_Process | Where-Object {
    $_.Name -in @('java.exe', 'javaw.exe') -and $_.CommandLine -and
    $_.CommandLine.IndexOf($Profile, [System.StringComparison]::OrdinalIgnoreCase) -ge 0
}
if ($running) {
    Write-Host 'Minecraft is still using this profile. Close the entire game, then run this installer again.'
    Write-Host "The ready JAR remains at: $source"
    exit 2
}
if (Test-Path -LiteralPath $target) {
    $previousHash = (Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash
    if ($previousHash -ne (Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash) {
        $sameVersionBackup = Join-Path $projectPath ('build\install-backups\Civitas-' + $version + '-' + $previousHash.Substring(0, 12) + '.jar')
        New-Item -ItemType Directory -Path (Split-Path -Parent $sameVersionBackup) -Force | Out-Null
        Copy-Item -LiteralPath $target -Destination $sameVersionBackup -Force
        if ((Get-FileHash -LiteralPath $sameVersionBackup).Hash -ne $previousHash) { throw 'Previous JAR backup verification failed.' }
    }
}
Copy-Item -LiteralPath $source -Destination $target -Force
if ((Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash -ne (Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash) {
    throw 'Installed JAR checksum does not match the build.'
}
# Keep older releases outside mods so NeoForge never sees two copies of the same mod.
$oldReleases = Get-ChildItem -LiteralPath (Join-Path $Profile 'mods') -File -Filter 'Civitas-*.jar' | Where-Object { $_.Name -ne "Civitas-$version.jar" }
foreach ($oldRelease in $oldReleases) {
    $oldArchive = [System.IO.Compression.ZipFile]::OpenRead($oldRelease.FullName)
    $isCivitas = $false
    try {
        $metadata = $oldArchive.GetEntry('META-INF/neoforge.mods.toml')
        if ($metadata) {
            $reader = New-Object System.IO.StreamReader($metadata.Open())
            try { $isCivitas = $reader.ReadToEnd() -match 'modId\s*=\s*"humanitas"' } finally { $reader.Dispose() }
        }
    } finally { $oldArchive.Dispose() }
    if (!$isCivitas) { continue }
    $backupPath = Join-Path $projectPath 'build\install-backups'
    New-Item -ItemType Directory -Path $backupPath -Force | Out-Null
    $hash = (Get-FileHash -LiteralPath $oldRelease.FullName -Algorithm SHA256).Hash.Substring(0, 12)
    $backup = Join-Path $backupPath ($oldRelease.BaseName + '-' + $hash + '.jar')
    if (!(Test-Path -LiteralPath $backup)) { Copy-Item -LiteralPath $oldRelease.FullName -Destination $backup }
    if ((Get-FileHash -LiteralPath $oldRelease.FullName).Hash -ne (Get-FileHash -LiteralPath $backup).Hash) { throw 'Backup verification failed.' }
    Remove-Item -LiteralPath $oldRelease.FullName
}
Write-Host "Installed and verified Civitas $version. Start Minecraft from Modrinth."
