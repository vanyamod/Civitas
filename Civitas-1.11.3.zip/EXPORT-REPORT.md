# Civitas 1.11.3 source export

- Minecraft 1.21.1 / NeoForge 21.1.250 / Java 21; network protocol 15.
- The clean source copy passed `gradlew.bat build --offline --console=plain`,
  including 113 organization checks and all citizen, news, constitution/Senate,
  diplomacy, UI skin, pending action and Watchdog dashboard checks.
- Java sources, tests and game resources match the current working source byte for byte.
- Latest fixes are included: organization documents/forms, role display, live votes,
  responsive news layout and removal of the redundant author caption.
- No Git history, profiles, worlds, player records, live configuration, credentials,
  logs, screenshots, backups, build outputs or caches are included.
- The only bundled JAR is the Gradle Wrapper. Build the release mod JAR locally
  or through the included GitHub Actions workflow.
- Credential-pattern and personal-machine-path scans passed for all exported text files.
- Public CONTEXT and validation notes are portable. The optional installer requires
  an explicit profile path; the build helper does not auto-install into a local profile.
- The Discord-format devblog is `docs/DEVLOG-1.11.3.md`.

`EXPORT-MANIFEST.json` lists SHA-256 hashes for every other file in this export.
The manifest excludes itself. Future additions are not covered by this audit.
