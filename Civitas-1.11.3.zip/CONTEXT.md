# Civitas 1.11.3 — developer context

Minecraft 1.21.1, NeoForge 21.1.250, JDK 21; network protocol 15.
The mod ID/package remains `humanitas` / `com.humanitas` to preserve world data.
Client and server must use the same corrected release. Build with `gradlew.bat build`
or `bash ./gradlew build`. No local modpack/profile is required to compile.

## Modules and authority

- `RepublicData` persists states, leadership, memberships, factions, roles, bills,
  constitutions, news and the private government archive. Original state IDs are
  founder UUIDs; preserve those IDs and existing SavedData keys.
- `CabinetNet` checks authoritative server permissions and returns cabinet snapshots.
  Law proposals require LAW_PROPOSE; private government archive requires ARCHIVE_VIEW.
- `CitizensData` / `CitizensNet` handle consent-based recruitment, invitations,
  applications, state directory and public history. Public projections exclude private
  petitions and moderator notes. Pending invitations expire after seven days.
- `OrganizationsData` / `OrganizationsNet` provide independently saved organizations,
  chair/deputy, scoped roles, invitations, state applications/delegations, charter,
  history and resolutions. Only administrators create/delete organizations; management
  can be delegated to players. States authorize their own representatives. Organization
  authority does not grant diplomacy authority over another state.
- `DiplomacyData` / `DiplomacyNet` handle agreements, trade, ultimatums, peace and
  supervised wars. The optional `WatchdogBridge` is an administration dashboard bridge;
  the anti-cheat itself is not included in this source export.
- `client/WheelScreen` is the main player/admin interface. The left Settings section
  opens the persistent state/organization context picker. Organization views use
  searchable paged lists, shared dark surfaces and a separate charter document.
- `LawInfoScreen` / `LawOrder` display and sort state votes; `billView` is the shared
  permission-preserving projection. One-bill live updates never overwrite HUD or
  publishing permissions. Organization view changes are pushed to expiring subscriptions
  and also refreshed in the background without disabling controls or losing edits.
- `NewsEditorScreen`, `TextInput`, `RichText`, `NewsFormatting`, `NewsDraftStore` provide
  rich editing, drafts, images and a newspaper preview. Author choice is a separate
  header row without a duplicate caption. Short windows use Title/Text/Source sections.
- `MediaStore`, `ImageAttachment`, `AvatarCropScreen` validate and retain media.
  Preserve upload size/type checks and reference-aware cleanup.
- `CivitasSurfaces`, `CivitasEquipmentStyle`, `CivitasSettings` and client configuration
  control shared GUI/HUD styling. Preserve vanilla slot positions and hitboxes.

## Membership and voting invariants

Players may join several states and organizations. Context preferences confer no rights:
every action must revalidate membership and permission. A remembered invalid state falls
back to another valid membership. The active organization is separate from the remembered
state. Recruiting into one state preserves memberships and invitations in others.
A state retains its founder UUID identity, so a second state needs a different founder;
multiple memberships and leadership appointments are supported independently.

Organization resolutions capture their rules and electorate at opening. Personal voting
uses unique player units; state voting uses state IDs, so replacement delegates cannot
create duplicate votes. Valid mandates and current personal voting authority are checked
at casting. Administrators may moderate but do not receive outsider voting units.
Abstentions count for quorum; majority counts yes/no votes. No yes votes cannot adopt a
resolution. Deadlines advance on the server, including when no cabinet is open.

Public organization visitors can read profiles, charters, delegations, completed decisions
and whitelisted public events; internal rosters, active sessions, drafts and invitations
remain permission-gated. Private state archive strings are not converted into public history.

## Validation and limits

The build runs citizen, organization, news formatting, constitution/Senate, diplomacy,
UI skin, pending action and Watchdog dashboard checks. Organization checks cover 300
participants/60 states as persisted model data, not 300 simultaneous connected clients.
Two simultaneous isolated game clients verified live organization and state-law counts,
role assignment through the picker, profile scrolling, compact name fields and documents.
See docs/VALIDATION-1.11.3.md and docs/ORGANIZATIONS.md for details and capacity limits.
The full production modpack was not load-tested by those isolated scenarios.

Fixture and UI harness classes are test sources only; normal release JARs exclude them.
Fixture tasks target only their explicit `build/...` test directories. Development UI
harnesses are opt-in through Gradle properties, not enabled in normal builds.

## Publication and installation

This is a source export. It contains no Git history, worlds, player records, live
configuration, webhooks, profile folders, logs, screenshots, caches or compiled mod JAR.
Only the Gradle Wrapper JAR is bundled. The optional installer requires an explicit profile
path and backs up previous Civitas releases outside mods. Stop the game before replacing
its JAR. Install identical releases on both client and server and back up the world before
upgrading. Do not downgrade newly written multi-state data without its prior backup.

Do not commit new live configuration, credentials, saves or local build outputs.
Keep the current All Rights Reserved metadata and existing third-party asset credits.
