# Civitas 1.11.2 source export

- Network protocol 14; Java 21 / Minecraft 1.21.1 / NeoForge 21.1.250.
- Source export build and regression checks passed in a separate directory.
- Java source files match the working 1.11.2 source byte for byte.
- No Git history, profiles, worlds, player save data, live configs, logs, backups,
  screenshots, build outputs or Gradle cache are included.
- Files were checked for credential patterns, live Discord webhook URLs, personal
  machine paths and embedded player UUIDs; no matches were found.
- The only bundled JAR is the Gradle Wrapper, required to build the project.
- Public README/CONTEXT describe this release; the installer requires an explicit
  profile directory instead of using a machine-specific default.
- This is source code, not an installed modpack. Build as described in README.

See EXPORT-MANIFEST.json for file SHA-256 checksums and CONTEXT.md for known issues.
Future additions to the directory are not covered by this export check.
