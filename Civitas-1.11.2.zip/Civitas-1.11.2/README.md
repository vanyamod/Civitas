# Civitas 1.11.2

Political gameplay and a shared interface for Minecraft Java 1.21.1 / NeoForge 21.1.250.
States, factions, roles and permissions, legislation, constitutions, news, diplomacy,
supervised wars and a configurable HUD.

## Build

Install **JDK 21**. On Windows run:

```powershell
.\gradlew.bat build
```

On Linux/macOS run:

```sh
bash ./gradlew build
```

The first build downloads Gradle, NeoForge and Minecraft dependencies from their
repositories. No Minecraft profile, local server, modpack, or private configuration
is required. Output: `build/libs/Civitas-1.11.2.jar`.

`build` includes checks for news formatting, constitutions and senate access,
recruitment consent and privacy, law ordering, diplomacy, UI skins, queued actions
and the optional Watchdog dashboard integration.

## Install and develop

Install the same release on client and server. Network protocol: **14**.
The mod ID remains `humanitas` to preserve existing world data. Close Minecraft
and the server before replacing a JAR; keep only one Civitas JAR in `mods`.

```powershell
.\gradlew.bat runClient
.\gradlew.bat runServer
```

The optional Windows installer accepts an explicit destination:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File tools/install_mod.ps1 -Profile '<profile directory>'
```

It checks the JAR, refuses to overwrite a running profile, and backs up older
releases outside `mods`. `build_and_install.bat` without arguments only builds;
pass a profile directory as its first argument to install after building.
ClientSort is optional: `-PcivitasClientSortJar='<path to a ClientSort JAR>'`.

## Configuration and documentation

Config files are generated on first launch. The Discord webhook defaults to empty
and is configured on the server. This source export contains no live configuration,
world saves, player databases, logs, screenshots, launcher sessions or credentials.
Never add those to Git. `.gitignore` protects the usual generated/private paths.

See [CONTEXT.md](CONTEXT.md) for architecture and known issues,
[the 1.11.2 devblog](docs/DEVLOG-1.11.2.md),
[the diplomacy guide](docs/DIPLOMACY.md) and
[the editor guide](docs/NEWS_EDITOR.md).

## Licensing

Project metadata remains **All Rights Reserved**; this export does not grant a new
license. `TEMPLATE_LICENSE.txt` applies to the original NeoForged MDK template files.
Third-party resources and dependencies retain their respective terms.
The four included UI audio assets have attribution information in the resource tree.
