# Civitas 1.11.2 — developer context

## Baseline

Minecraft 1.21.1, NeoForge 21.1.250, JDK 21; network protocol 14. Mod ID/package:
`humanitas` / `com.humanitas`. Client and server must run the matching release.
Build with `gradlew.bat build` or `bash ./gradlew build`.

## Modules

- `RepublicData`: persistent states, leadership, factions, roles, bills, constitutions,
  news and the private government archive. Existing data keys are retained.
- `CabinetNet`: authoritative server actions, permission checks and cabinet snapshots.
  `Perms` defines role permissions. The server checks rights for law proposals and
  filters archive contents using ARCHIVE_VIEW (bit 13).
- `CitizensData` / `CitizensNet`: recruitment, consent records and the public state
  directory, stored separately in `civitas_citizens.dat`. Requests are paged and
  bounded. Application bodies are only sent to authorized reviewers; stale client
  responses are rejected using sequence IDs.
- `DiplomacyData` / `DiplomacyNet`: bilateral offers, alliances, trade, ultimatums,
  peace and supervised wars. Moderator notes are private. Public history projects
  public facts and excludes pending private proposal terms and staff notes.
- `WatchdogBridge`: optional administration dashboard integration; the Watchdog
  anti-cheat itself is not part of this source export.
- `client/WheelScreen`: main player/admin navigation and management windows.
  `StatesScreen` provides public state cards, invitations, applications and review.
  The optional classic cabinet uses the same authoritative permission gates.
- `LawInfoScreen` / `LawOrder`: live vote details and sorting. Eligible uncast ballots
  appear first, newest first; cast and completed ballots move lower.
- `NewsEditorScreen`, `TextInput`, `RichText`, `NewsFormatting`, `NewsDraftStore`:
  rich editing, local drafts, formatting, images and live newspaper previews.
- `MediaStore`, `ImageAttachment`, `AvatarCropScreen`: uploaded images and state /
  faction avatars. Preserve validation and upload limits when changing this flow.
- `CivitasSurfaces` / `CivitasEquipmentStyle`: shared dark GUI skin, equipment cells,
  HUD and recipe book styling. Preserve vanilla slot coordinates and hitboxes.
- `CivitasSettings` / `CivitasClientConfig`: personal settings, palettes and HUD choices.
  Reset restores Civitas defaults and saved window positions.

## Recruitment and political rules

Existing states default to closed recruitment. Authorized recruiters (MEMBER_INVITE)
can open recruitment, provide questions/instructions, invite eligible players and
review applications. Invitations require explicit recipient acceptance and expire
in seven real days. Authorized acceptance of an application also works offline,
since submitting that application expresses the applicant's consent. Joining checks
current membership again and clears competing applications/invitations.
Deputies must be existing state members; inviting never directly enrolls a player.

Constitution adoption/amendments retain their captured electorate and two-thirds
threshold. Senate voting uses the explicit LAW_VOTE permission. Preserve faction
weighted voting and existing succession/dissolution rules. New public events are
kept independently of the restricted government archive.

## Validation

`build` runs citizensChecks, constitutionChecks, diplomacyChecks, newsEditorTest,
pendingActionsChecks, uiSkinChecks and watchdogDashboardChecks. `citizensFixture`
optionally creates synthetic development data under `build/citizens-ui-server`;
it is not run by a normal build and contains no real player records.

## Known issues and limits

- Full visual verification in the complete modpack is still outstanding. A Dev client
  connected to an isolated local server; automated window capture failed, so this is
  not evidence that every screen/layout has been visually verified.
- Legacy private archive strings are not converted into public history. Existing
  closed bills and public diplomatic cases are projected from their original stores.
  The explicit public event journal retains 2048 events per state; the private
  archive's existing global 40-entry retention has not been redesigned.
- Recruitment instructions: 1000 characters; application: 2000; maximum 128 pending
  invitations/applications per state and 10 pending applications per applicant.
- War status alone does not change Minecraft PvP rules, claims or block protection.
- Creative inventory and arbitrary custom containers from other mods are not fully
  replaced. Optional compatibility hooks do not imply universal mod compatibility.
- Newspaper article previews intentionally retain paper colours inside the shared
  dark editor frame. Preserve rich text, drafts, publishing modes and image handling.
- Do not replace a JAR while Minecraft/server is running: lazy class loading can crash
  even after returning to the main menu. Restart the process after installation.

## Export scope

This directory contains current source, resources, regression checks, Gradle Wrapper,
build configuration and public documentation. It excludes Git history, IDE state,
build output, development instances, profiles, worlds, logs, databases, backups,
screenshots and live configuration. Runtime config/credentials must remain local.
