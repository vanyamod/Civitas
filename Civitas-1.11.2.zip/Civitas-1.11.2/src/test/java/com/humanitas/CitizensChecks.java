package com.humanitas;

import com.humanitas.client.LawOrder;
import net.minecraft.nbt.*;
import java.util.*;

/** Consent, stale actions, permissions, persistence and the public/private boundary. */
public final class CitizensChecks {
    private static void check(boolean ok,String reason){if(!ok)throw new AssertionError(reason);}
    private static void reject(Runnable task){try{task.run();throw new AssertionError("Action should be rejected");}catch(IllegalArgumentException expected){}}
    public static void main(String[] args){
        UUID leader=UUID.randomUUID(),plain=UUID.randomUUID(),candidate=UUID.randomUUID(),otherChief=UUID.randomUUID();
        RepublicData data=new RepublicData(); var state=data.createPolity("Republic","Test",leader,"Chief");
        state.members.add(plain);state.memberNames.add("Citizen");
        state.roles.add(new RepublicData.Role("official","Official",Perms.LAW_PROPOSE|Perms.MEMBER_INVITE|Perms.ARCHIVE_VIEW));
        check(!CitizensData.canPropose(state,plain,false),"Ordinary citizens cannot propose laws");
        check(CitizensData.canPropose(state,leader,false),"Leader can propose");
        check(CitizensData.canPropose(state,candidate,true),"Admin may manage chosen state");
        check(!CitizensData.permitted(state,plain,false,Perms.ARCHIVE_VIEW),"Private archive denied by default");
        state.memberRoles.put(candidate,"official");
        check(!CitizensData.canPropose(state,candidate,false),"Stale outsider role grants no authority");
        state.memberRoles.put(plain,"official");
        check(CitizensData.canPropose(state,plain,false),"Explicit law right works");
        check(CitizensData.permitted(state,plain,false,Perms.ARCHIVE_VIEW),"Explicit archive right works");
        CitizensData citizens=new CitizensData();long now=1_800_000_000_000L;
        citizens.invite(data,state,candidate,"Candidate",now);
        check(CabinetNet.findPolity(data,candidate)==null,"Invitation must never silently enroll");
        reject(()->citizens.join(data,state,UUID.randomUUID(),true,now));
        reject(()->citizens.invite(data,state,candidate,"Candidate",now));
        var restored=CitizensData.load(citizens.write(new CompoundTag()),null);
        check(restored.state(leader).invites.containsKey(candidate),"Invitation survives restart");
        restored.join(data,state,candidate,true,now+1000);
        check(CabinetNet.findPolity(data,candidate)==state,"Explicit invitation acceptance enrolls");
        reject(()->restored.join(data,state,candidate,true,now+1001));
        UUID late=UUID.randomUUID();restored.invite(data,state,late,"Late",now);
        reject(()->restored.join(data,state,late,true,now+CitizensData.INVITE_TTL));
        restored.prune(data,now+CitizensData.INVITE_TTL);
        check(!restored.state(leader).invites.containsKey(late),"Expired invitation removed");
        var other=data.createPolity("Republic","Other",otherChief,"Other chief");
        UUID applicant=UUID.randomUUID();reject(()->restored.apply(data,state,applicant,"Applicant","Answer",now));
        var recruitment=restored.state(leader);recruitment.open=true;recruitment.instructions="Why would you join?";
        reject(()->restored.apply(data,state,applicant,"Applicant","",now));
        restored.apply(data,state,applicant,"Applicant","I agree to join",now);
        restored.invite(data,other,applicant,"Applicant",now);
        var roundtrip=CitizensData.load(restored.write(new CompoundTag()),null);
        check(roundtrip.state(leader).open&&roundtrip.state(leader).applications.get(applicant).text().equals("I agree to join"),"Application and recruitment persist");
        roundtrip.join(data,state,applicant,false,now+1);
        check(CabinetNet.findPolity(data,applicant)==state&&!roundtrip.state(otherChief).invites.containsKey(applicant),"Accepting application clears competing invitations");
        reject(()->roundtrip.apply(data,other,applicant,"Applicant","Join again",now));
        UUID race=UUID.randomUUID();roundtrip.state(otherChief).open=true;roundtrip.apply(data,other,race,"Race","",now);
        state.members.add(race);state.memberNames.add("Race");
        reject(()->roundtrip.join(data,other,race,false,now));
        roundtrip.event(leader,"Public event","Visible facts",now);
        var historyReload=CitizensData.load(roundtrip.write(new CompoundTag()),null);
        check(historyReload.state(leader).history.stream().anyMatch(event->event.detail().equals("Visible facts")),"Public journal survives restart");
        var buffer=new net.minecraft.network.RegistryFriendlyByteBuf(io.netty.buffer.Unpooled.buffer(),net.minecraft.core.RegistryAccess.EMPTY);
        try {
            var request=new CitizensNet.Request(41,leader.toString(),"history",2);
            CitizensNet.Request.CODEC.encode(buffer,request);
            check(CitizensNet.Request.CODEC.decode(buffer).equals(request),"Request sequence and pagination survive transport");
            buffer.clear();var action=new CitizensNet.Action(42,leader.toString(),"apply","","Application text");
            CitizensNet.Action.CODEC.encode(buffer,action);
            check(CitizensNet.Action.CODEC.decode(buffer).equals(action),"Consent action sequence survives transport");
        }finally{buffer.release();}
        CompoundTag projection=CitizensNet.publicState(state,roundtrip.state(leader));
        check(!projection.contains("archive")&&!projection.contains("applications")&&!projection.contains("invites")&&!projection.contains("memberRoles"),"Public projection cannot leak private records");
        DiplomacyData.Case c=new DiplomacyData.Case();c.kind=DiplomacyData.Kind.TRADE;c.status=DiplomacyData.Status.PENDING;
        check(!CitizensNet.isPublic(c),"Unaccepted diplomatic proposals remain private");c.status=DiplomacyData.Status.ACTIVE;check(CitizensNet.isPublic(c),"Signed treaty is public");
        ListTag bills=new ListTag();
        for(int id:new int[]{1,2,3,4}){CompoundTag b=new CompoundTag();b.putInt("id",id);b.putBoolean("canVote",true);b.putBoolean("closed",id==4);b.putString("mine",id==2?"yes":"");bills.add(b);}
        var sorted=LawOrder.sorted(bills);check(sorted.get(0).getInt("id")==3&&sorted.get(1).getInt("id")==1&&sorted.get(2).getInt("id")==2&&sorted.get(3).getInt("id")==4,"Unvoted newest first; voted and closed last");
        check(!LawOrder.waiting(sorted.get(3)),"Closed vote never actionable");
        System.out.println("Citizens: consent, permission boundaries, offline acceptance, expiry, restart, race rejection, privacy and law ordering passed.");
    }
}
