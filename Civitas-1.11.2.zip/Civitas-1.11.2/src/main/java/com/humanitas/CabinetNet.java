package com.humanitas;

import com.humanitas.RepublicData.Polity;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.network.PacketDistributor;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Network payloads and server-side logic for Civitas. Every rule is checked here, never on the client. */
public final class CabinetNet {
    private CabinetNet() {}

    /** Bumped to 4: the calendar travels with the state, so older clients are refused with a clear message. */
    private static final String PROTOCOL = "14";

    /** What readers see instead of a hidden author or state. Admins always see the real values. */
    static final String HIDDEN = "?????";
    /** Colours of the strip on the left of the Discord embed. Index 0 is gold, the default. */
    public static final int[] STRIPE_COLORS = {0xA88B4A, 0x5C6B3A, 0x8E3B2F, 0x2F4F7F, 0x3B7A4A, 0x6A3D7A, 0x6E6447, 0x2A2619};
    private static final int NEWS_LIST_LIMIT = 40;
    private static final long POST_COOLDOWN_MS = 15_000L;
    private static final Map<UUID, Long> LAST_POST = new HashMap<>();
    private static final Map<UUID, UUID> ADMIN_STATE = new HashMap<>();

    static Polity selectedState(RepublicData data, ServerPlayer player) {
        if (player.hasPermissions(2)) {
            UUID selected = ADMIN_STATE.get(player.getUUID());
            if (selected != null) {
                for (Polity p : data.polities()) if (p.owner.equals(selected)) return p;
                ADMIN_STATE.remove(player.getUUID());
            }
        }
        return findPolity(data, player.getUUID());
    }

    private static boolean controlsState(ServerPlayer player, Polity polity) {
        return polity != null && player.hasPermissions(2)
                && polity.owner.equals(ADMIN_STATE.get(player.getUUID()));
    }

    private static ResourceLocation id(String path) {
        return ResourceLocation.fromNamespaceAndPath(Humanitas.MODID, path);
    }

    /** Client -> server: "open my cabinet". */
    public record RequestCabinet() implements CustomPacketPayload {
        public static final Type<RequestCabinet> TYPE = new Type<>(id("request_cabinet"));
        public static final StreamCodec<RegistryFriendlyByteBuf, RequestCabinet> CODEC =
                StreamCodec.unit(new RequestCabinet());

        @Override
        public Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }

    public record RequestWatchdog() implements CustomPacketPayload {
        public static final Type<RequestWatchdog> TYPE=new Type<>(id("request_watchdog"));
        public static final StreamCodec<RegistryFriendlyByteBuf,RequestWatchdog> CODEC=StreamCodec.unit(new RequestWatchdog());
        public Type<? extends CustomPacketPayload> type(){return TYPE;}
    }
    public record WatchdogSnapshot(CompoundTag data) implements CustomPacketPayload {
        public static final Type<WatchdogSnapshot> TYPE=new Type<>(id("watchdog_snapshot"));
        public static final StreamCodec<RegistryFriendlyByteBuf,WatchdogSnapshot> CODEC=StreamCodec.composite(ByteBufCodecs.COMPOUND_TAG,WatchdogSnapshot::data,WatchdogSnapshot::new);
        public Type<? extends CustomPacketPayload> type(){return TYPE;}
    }
    /** Server -> client: what the player can see. open = true opens the screen, false only refreshes it. */
    public record CabinetSnapshot(CompoundTag data, boolean open) implements CustomPacketPayload {
        public static final Type<CabinetSnapshot> TYPE = new Type<>(id("cabinet_snapshot"));
        public static final StreamCodec<RegistryFriendlyByteBuf, CabinetSnapshot> CODEC =
                StreamCodec.composite(
                        ByteBufCodecs.COMPOUND_TAG, CabinetSnapshot::data,
                        ByteBufCodecs.BOOL, CabinetSnapshot::open,
                        CabinetSnapshot::new);

        @Override
        public Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }

    /** Server -> client: ideology and state name for the buttons, plus the calendar for the hotbar. */
    public record CabinetState(String ideology, String name, long startDay, boolean advance, long ticksPerDay)
            implements CustomPacketPayload {
        public static final Type<CabinetState> TYPE = new Type<>(id("cabinet_state"));
        public static final StreamCodec<RegistryFriendlyByteBuf, CabinetState> CODEC =
                StreamCodec.composite(
                        ByteBufCodecs.STRING_UTF8, CabinetState::ideology,
                        ByteBufCodecs.STRING_UTF8, CabinetState::name,
                        ByteBufCodecs.VAR_LONG, CabinetState::startDay,
                        ByteBufCodecs.BOOL, CabinetState::advance,
                        ByteBufCodecs.VAR_LONG, CabinetState::ticksPerDay,
                        CabinetState::new);

        @Override
        public Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }

    /** Client -> server: owner changes one field. Field: deputy, ideology, parliament, government, member. */
    public record EditCabinet(String field, String value) implements CustomPacketPayload {
        public static final Type<EditCabinet> TYPE = new Type<>(id("edit_cabinet"));
        public static final StreamCodec<RegistryFriendlyByteBuf, EditCabinet> CODEC =
                StreamCodec.composite(
                        ByteBufCodecs.STRING_UTF8, EditCabinet::field,
                        ByteBufCodecs.STRING_UTF8, EditCabinet::value,
                        EditCabinet::new);

        @Override
        public Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }

    public record TrackedEdit(long requestId, String field, String value) implements CustomPacketPayload {
        public static final Type<TrackedEdit> TYPE = new Type<>(id("tracked_edit"));
        public static final StreamCodec<RegistryFriendlyByteBuf, TrackedEdit> CODEC = StreamCodec.composite(
                ByteBufCodecs.VAR_LONG, TrackedEdit::requestId,
                ByteBufCodecs.STRING_UTF8, TrackedEdit::field,
                ByteBufCodecs.STRING_UTF8, TrackedEdit::value, TrackedEdit::new);
        public Type<? extends CustomPacketPayload> type() { return TYPE; }
    }
    public record EditAck(long requestId) implements CustomPacketPayload {
        public static final Type<EditAck> TYPE = new Type<>(id("edit_ack"));
        public static final StreamCodec<RegistryFriendlyByteBuf, EditAck> CODEC = StreamCodec.composite(
                ByteBufCodecs.VAR_LONG, EditAck::requestId, EditAck::new);
        public Type<? extends CustomPacketPayload> type() { return TYPE; }
    }

    /** Client -> server: vote on an open bill. */
    public record VoteBill(int billId, boolean inFavor) implements CustomPacketPayload {
        public static final Type<VoteBill> TYPE = new Type<>(id("vote_bill"));
        public static final StreamCodec<RegistryFriendlyByteBuf, VoteBill> CODEC =
                StreamCodec.composite(
                        ByteBufCodecs.VAR_INT, VoteBill::billId,
                        ByteBufCodecs.BOOL, VoteBill::inFavor,
                        VoteBill::new);

        @Override
        public Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }

    /** Client -> server: close a vote (owner or admin). */
    public record CloseBill(int billId) implements CustomPacketPayload {
        public static final Type<CloseBill> TYPE = new Type<>(id("close_bill"));
        public static final StreamCodec<RegistryFriendlyByteBuf, CloseBill> CODEC =
                StreamCodec.composite(ByteBufCodecs.VAR_INT, CloseBill::billId, CloseBill::new);

        @Override
        public Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }

    /**
     * Client -> server: a form was filled in.
     * kind "bill": a = title. kind "rename": a = type, b = name. kind "leave": a = "ВЫЙТИ".
     * kind "delete" (admin): a = state name. kind "state" (admin): a = type, b = name, c = owner's nickname.
     */
    public record SubmitForm(String kind, String a, String b, String c) implements CustomPacketPayload {
        public static final Type<SubmitForm> TYPE = new Type<>(id("submit_form"));
        public static final StreamCodec<RegistryFriendlyByteBuf, SubmitForm> CODEC =
                StreamCodec.composite(
                        ByteBufCodecs.STRING_UTF8, SubmitForm::kind,
                        ByteBufCodecs.STRING_UTF8, SubmitForm::a,
                        ByteBufCodecs.STRING_UTF8, SubmitForm::b,
                        ByteBufCodecs.STRING_UTF8, SubmitForm::c,
                        SubmitForm::new);

        @Override
        public Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }

    /** Client -> server: publish a news article. Body uses the [b] [i] [u] [s] [c:name] markup. imageId may be empty. */
    public record PublishNews(String title, String body, String footer, String imageId, int options) implements CustomPacketPayload {
        /** Bits of options: the three checkboxes of the editor. */
        static final int HIDE_STATE = 1, HIDE_AUTHOR = 2, DISCORD_EMBED = 4;
        /** The strip colour is stored in bits 3..5 of options. */
        static final int STRIPE_SHIFT = 3;

        /** Builds the packet from the editor's checkboxes. */
        public static PublishNews of(String title, String body, String footer, String imageId,
                                     boolean hideState, boolean hideAuthor, boolean discordEmbed, int stripe) {
            return new PublishNews(title, body, footer, imageId,
                    (hideState ? HIDE_STATE : 0) | (hideAuthor ? HIDE_AUTHOR : 0) | (discordEmbed ? DISCORD_EMBED : 0) | ((stripe & 7) << STRIPE_SHIFT));
        }

        public boolean faction() { return (options & 64) != 0; }

        public boolean hideState() { return (options & HIDE_STATE) != 0; }

        public boolean hideAuthor() { return (options & HIDE_AUTHOR) != 0; }

        public boolean discordEmbed() { return (options & DISCORD_EMBED) != 0; }

        /** Index into STRIPE_COLORS. */
        public int stripe() { return (options >> STRIPE_SHIFT) & 7; }
        public static final Type<PublishNews> TYPE = new Type<>(id("publish_news"));
        public static final StreamCodec<RegistryFriendlyByteBuf, PublishNews> CODEC =
                StreamCodec.composite(
                        ByteBufCodecs.STRING_UTF8, PublishNews::title,
                        ByteBufCodecs.STRING_UTF8, PublishNews::body,
                        ByteBufCodecs.STRING_UTF8, PublishNews::footer,
                        ByteBufCodecs.STRING_UTF8, PublishNews::imageId,
                        ByteBufCodecs.VAR_INT, PublishNews::options,
                        PublishNews::new);

        @Override
        public Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }

    /** Client -> server: delete an article (its state's leaders or an admin). */
    public record DeleteNews(int newsId) implements CustomPacketPayload {
        public static final Type<DeleteNews> TYPE = new Type<>(id("delete_news"));
        public static final StreamCodec<RegistryFriendlyByteBuf, DeleteNews> CODEC =
                StreamCodec.composite(ByteBufCodecs.VAR_INT, DeleteNews::newsId, DeleteNews::new);

        @Override
        public Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }

    /** Client -> server: "send me the full text of this article". The list only carries headlines. */
    public record RequestNews(int newsId) implements CustomPacketPayload {
        public static final Type<RequestNews> TYPE = new Type<>(id("request_news"));
        public static final StreamCodec<RegistryFriendlyByteBuf, RequestNews> CODEC =
                StreamCodec.composite(ByteBufCodecs.VAR_INT, RequestNews::newsId, RequestNews::new);

        @Override
        public Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }

    /** Server -> client: one full article. */
    public record NewsFull(CompoundTag data) implements CustomPacketPayload {
        public static final Type<NewsFull> TYPE = new Type<>(id("news_full"));
        public static final StreamCodec<RegistryFriendlyByteBuf, NewsFull> CODEC =
                StreamCodec.composite(ByteBufCodecs.COMPOUND_TAG, NewsFull::data, NewsFull::new);

        @Override
        public Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }

    /** Client -> server: one piece of an upload. A client packet is limited to 32 KB, so files go in 30 KB chunks. */
    public record UploadChunk(String kind, int index, int total, byte[] data) implements CustomPacketPayload {
        public static final Type<UploadChunk> TYPE = new Type<>(id("upload_chunk"));
        public static final StreamCodec<RegistryFriendlyByteBuf, UploadChunk> CODEC =
                StreamCodec.composite(
                        ByteBufCodecs.stringUtf8(16), UploadChunk::kind,
                        ByteBufCodecs.VAR_INT, UploadChunk::index,
                        ByteBufCodecs.VAR_INT, UploadChunk::total,
                        ByteBufCodecs.byteArray(MediaStore.CHUNK), UploadChunk::data,
                        UploadChunk::new);

        @Override
        public Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }

    /** Server -> client: the upload finished. On success id is the photo id to attach to the news. */
    public record UploadResult(boolean ok, String id, String message) implements CustomPacketPayload {
        public static final Type<UploadResult> TYPE = new Type<>(CabinetNet.id("upload_result"));
        public static final StreamCodec<RegistryFriendlyByteBuf, UploadResult> CODEC =
                StreamCodec.composite(
                        ByteBufCodecs.BOOL, UploadResult::ok,
                        ByteBufCodecs.STRING_UTF8, UploadResult::id,
                        ByteBufCodecs.STRING_UTF8, UploadResult::message,
                        UploadResult::new);

        @Override
        public Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }

    /** Client -> server: "send me this photo". */
    public record RequestMedia(String kind, String id) implements CustomPacketPayload {
        public static final Type<RequestMedia> TYPE = new Type<>(CabinetNet.id("request_media"));
        public static final StreamCodec<RegistryFriendlyByteBuf, RequestMedia> CODEC =
                StreamCodec.composite(
                        ByteBufCodecs.stringUtf8(16), RequestMedia::kind,
                        ByteBufCodecs.stringUtf8(64), RequestMedia::id,
                        RequestMedia::new);

        @Override
        public Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }

    /** Server -> client: the bytes of one photo. */
    public record MediaData(String kind, String id, byte[] data) implements CustomPacketPayload {
        public static final Type<MediaData> TYPE = new Type<>(CabinetNet.id("media_data"));
        public static final StreamCodec<RegistryFriendlyByteBuf, MediaData> CODEC =
                StreamCodec.composite(
                        ByteBufCodecs.stringUtf8(16), MediaData::kind,
                        ByteBufCodecs.stringUtf8(64), MediaData::id,
                        ByteBufCodecs.byteArray(300_000), MediaData::data,
                        MediaData::new);

        @Override
        public Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }

    /** Server -> client: the newest news id and the newest bill id of the player's state. Drives the HUD icons. */
    public record FeedState(int newsLatest, int billsLatest) implements CustomPacketPayload {
        public static final Type<FeedState> TYPE = new Type<>(id("feed_state"));
        public static final StreamCodec<RegistryFriendlyByteBuf, FeedState> CODEC =
                StreamCodec.composite(
                        ByteBufCodecs.VAR_INT, FeedState::newsLatest,
                        ByteBufCodecs.VAR_INT, FeedState::billsLatest,
                        FeedState::new);

        @Override
        public Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }

    public static void register(RegisterPayloadHandlersEvent event) {
        PayloadRegistrar registrar = event.registrar(PROTOCOL);
        DiplomacyNet.register(registrar);
        CitizensNet.register(registrar);

        registrar.playToServer(RequestWatchdog.TYPE,RequestWatchdog.CODEC,(payload,ctx)->
                ctx.enqueueWork(()->{if(ctx.player() instanceof ServerPlayer sp)WatchdogBridge.request(sp);}));
        registrar.playToClient(WatchdogSnapshot.TYPE,WatchdogSnapshot.CODEC,(payload,ctx)->
                ctx.enqueueWork(()->com.humanitas.client.WheelScreen.onWatchdogSnapshot(payload.data())));

        registrar.playToServer(RequestCabinet.TYPE, RequestCabinet.CODEC, (payload, ctx) ->
                ctx.enqueueWork(() -> {
                    if (ctx.player() instanceof ServerPlayer sp) PENDING_SNAPSHOTS.put(sp, true);
                }));

        registrar.playToServer(TrackedEdit.TYPE, TrackedEdit.CODEC, (payload, ctx) -> ctx.enqueueWork(() -> {
            if (ctx.player() instanceof ServerPlayer sp) {
                applyEdit(sp, new EditCabinet(payload.field(), payload.value()));
                refresh(sp);
                PENDING_ACKS.computeIfAbsent(sp, ignored -> new java.util.ArrayList<>()).add(payload.requestId());
            }
        }));
        registrar.playToClient(EditAck.TYPE, EditAck.CODEC, (payload, ctx) -> ctx.enqueueWork(() ->
                com.humanitas.client.CabinetRequests.acknowledge(payload.requestId())));

        registrar.playToServer(EditCabinet.TYPE, EditCabinet.CODEC, (payload, ctx) ->
                ctx.enqueueWork(() -> {
                    if (ctx.player() instanceof ServerPlayer sp) applyEdit(sp, payload);
                }));

        registrar.playToServer(VoteBill.TYPE, VoteBill.CODEC, (payload, ctx) ->
                ctx.enqueueWork(() -> {
                    if (ctx.player() instanceof ServerPlayer sp) applyVote(sp, payload);
                }));

        registrar.playToServer(CloseBill.TYPE, CloseBill.CODEC, (payload, ctx) ->
                ctx.enqueueWork(() -> {
                    if (ctx.player() instanceof ServerPlayer sp) applyClose(sp, payload);
                }));

        registrar.playToServer(SubmitForm.TYPE, SubmitForm.CODEC, (payload, ctx) ->
                ctx.enqueueWork(() -> {
                    if (ctx.player() instanceof ServerPlayer sp) applyForm(sp, payload);
                }));

        registrar.playToServer(PublishNews.TYPE, PublishNews.CODEC, (payload, ctx) ->
                ctx.enqueueWork(() -> {
                    if (ctx.player() instanceof ServerPlayer sp) applyPublish(sp, payload);
                }));

        registrar.playToServer(DeleteNews.TYPE, DeleteNews.CODEC, (payload, ctx) ->
                ctx.enqueueWork(() -> {
                    if (ctx.player() instanceof ServerPlayer sp) applyDeleteNews(sp, payload);
                }));

        registrar.playToServer(RequestNews.TYPE, RequestNews.CODEC, (payload, ctx) ->
                ctx.enqueueWork(() -> {
                    if (ctx.player() instanceof ServerPlayer sp) sendNews(sp, payload.newsId());
                }));

        registrar.playToClient(CabinetSnapshot.TYPE, CabinetSnapshot.CODEC, (payload, ctx) ->
                ctx.enqueueWork(() -> com.humanitas.client.CabinetScreen.onSnapshot(payload.data(), payload.open())));

        registrar.playToClient(CabinetState.TYPE, CabinetState.CODEC, (payload, ctx) ->
                ctx.enqueueWork(() -> {
                    com.humanitas.client.CabinetClientState.setState(payload.ideology(), payload.name());
                    com.humanitas.client.CabinetClientState.setCalendar(payload.startDay(), payload.advance(), payload.ticksPerDay());
                }));

        registrar.playToClient(FeedState.TYPE, FeedState.CODEC, (payload, ctx) ->
                ctx.enqueueWork(() -> com.humanitas.client.CivitasFeed.setLatest(payload.newsLatest(), payload.billsLatest())));

        registrar.playToClient(NewsFull.TYPE, NewsFull.CODEC, (payload, ctx) ->
                ctx.enqueueWork(() -> com.humanitas.client.CabinetScreen.onNewsFull(payload.data())));

        registrar.playToServer(UploadChunk.TYPE, UploadChunk.CODEC, (payload, ctx) ->
                ctx.enqueueWork(() -> {
                    if (ctx.player() instanceof ServerPlayer sp) MediaStore.receive(sp, payload);
                }));

        registrar.playToServer(RequestMedia.TYPE, RequestMedia.CODEC, (payload, ctx) ->
                ctx.enqueueWork(() -> {
                    if (ctx.player() instanceof ServerPlayer sp) MediaStore.sendMedia(sp, payload.kind(), payload.id());
                }));

        registrar.playToClient(UploadResult.TYPE, UploadResult.CODEC, (payload, ctx) ->
                ctx.enqueueWork(() -> com.humanitas.client.ImageAttachment.onResult(
                        payload.ok(), payload.id(), payload.message())));

        registrar.playToClient(MediaData.TYPE, MediaData.CODEC, (payload, ctx) ->
                ctx.enqueueWork(() -> com.humanitas.client.ImageCache.onData(payload.id(), payload.data())));
    }

    // ---------- snapshot ----------

    /** Opens the screen on the client. */
    public static void sendSnapshot(ServerPlayer viewer) {
        sendSnapshot(viewer, true);
    }

    /** Updates the screen if the player has it open, otherwise the client ignores it. */
    private static final Map<ServerPlayer, Boolean> PENDING_SNAPSHOTS = new java.util.LinkedHashMap<>();
    private static final Map<ServerPlayer, java.util.List<Long>> PENDING_ACKS = new java.util.LinkedHashMap<>();
    public static void refresh(ServerPlayer viewer) {
        PENDING_SNAPSHOTS.putIfAbsent(viewer, false);
    }

    private static void flushSnapshots(MinecraftServer server) {
        var updates = new java.util.LinkedHashMap<>(PENDING_SNAPSHOTS);
        var acknowledgements = new java.util.LinkedHashMap<>(PENDING_ACKS);
        PENDING_SNAPSHOTS.clear(); PENDING_ACKS.clear();
        updates.forEach((player, open) -> {
            if (player.getServer() == server && !player.hasDisconnected()) sendSnapshot(player, open);
        });
        acknowledgements.forEach((player, ids) -> {
            if (player.getServer() == server && !player.hasDisconnected())
                for (long id : ids) PacketDistributor.sendToPlayer(player, new EditAck(id));
        });
    }

    /**
     * Everyone can open the screen and read the world news. Members also get their state;
     * admins also get the list of every state. Only the owner gets canEdit.
     */
    private static void sendSnapshot(ServerPlayer viewer, boolean open) {
        MinecraftServer server = viewer.getServer();
        if (server == null) return;

        RepublicData data = RepublicData.get(server);
        Polity polity = selectedState(data, viewer);
        boolean op = viewer.hasPermissions(2);
        boolean owner = polity != null && (RepublicData.leaderOf(polity).equals(viewer.getUUID()) || controlsState(viewer, polity));
        boolean leader = owner || (polity != null && viewer.getUUID().equals(polity.deputy));

        CompoundTag t = new CompoundTag();
if (polity != null) {
            data.tickPower(polity, CivitasConfig.today(server));
        }
        t.putBoolean("noState", polity == null);
        t.putBoolean("noAccess", polity == null && !op);
        t.putBoolean("op", op);
        t.putLong("startDay", CivitasConfig.startDate().toEpochDay());
        t.putBoolean("advance", CivitasConfig.advance());
        t.putLong("ticksPerDay", CivitasConfig.ticksPerDay());
        t.putBoolean("canEdit", owner);
        t.putBoolean("canPropose", CitizensData.canPropose(polity, viewer.getUUID(), op));
        t.putBoolean("canCloseLaws", CitizensData.permitted(polity, viewer.getUUID(), op, Perms.LAW_CLOSE));
        boolean canArchive = CitizensData.permitted(polity, viewer.getUUID(), op, Perms.ARCHIVE_VIEW);
        t.putBoolean("canArchive", canArchive);
        t.putBoolean("canRecruit", CitizensNet.manager(viewer, polity));
        t.putString("stateId", polity == null ? "" : polity.owner.toString());
        CitizensData citizens = CitizensData.get(server);
        citizens.prune(data, System.currentTimeMillis());
        int invitations = 0;
        for (Polity state : data.polities()) if(citizens.state(state.owner).invites.containsKey(viewer.getUUID())) invitations++;
        t.putInt("invitations", invitations);
        if(polity != null) {
            var recruitment = citizens.state(polity.owner);
            t.putBoolean("recruitmentOpen", recruitment.open);
            t.putInt("applications", CitizensNet.manager(viewer,polity) ? recruitment.applications.size() : 0);
            t.putInt("activeInvitations", CitizensNet.manager(viewer,polity) ? recruitment.invites.size() : 0);
        }
        t.putBoolean("senatorsOnly", polity != null && polity.senatorsOnly);
        t.putBoolean("canRename", leader);
        RepublicData.Faction ownFaction = polity == null ? null : RepublicData.factionOf(polity, viewer.getUUID());
        boolean factionNews = ownFaction != null && (viewer.getUUID().equals(ownFaction.leader)
                || Perms.has(RepublicData.factionPermissions(ownFaction, viewer.getUUID()), Perms.NEWS));
        t.putBoolean("canPostFaction", factionNews);
        boolean canPostState = polity != null && (leader || polity.writers.contains(viewer.getUUID())
                || Perms.has(RepublicData.permsOf(polity, viewer.getUUID()), Perms.NEWS)) || op;
        t.putBoolean("canPostState", canPostState);
        t.putBoolean("canPost", factionNews || canPostState);
        t.putString("name", polity == null ? "" : nz(polity.name));
        t.putString("type", polity == null ? "" : nz(polity.type));
        t.putString("constitution", polity == null ? "" : nz(polity.constitution));
        t.putLong("constitutionAdoptedDay", polity == null ? Long.MIN_VALUE : polity.constitutionAdoptedDay);
        t.putLong("constitutionRevisedDay", polity == null ? Long.MIN_VALUE : polity.constitutionRevisedDay);
        t.putString("ownerName", polity == null ? "" : nz(polity.ownerName));
        t.putString("leaderId", polity == null ? "" : RepublicData.leaderOf(polity).toString());
        t.putBoolean("hasDeputy", polity != null && polity.deputy != null);
        t.putString("deputyName", polity == null ? "" : nz(polity.deputyName));
        t.putString("ideology", polity == null ? "" : nz(polity.ideology));
        t.putString("parliament", polity == null ? "" : nz(polity.parliament));
        t.putString("government", polity == null ? "" : nz(polity.government));
        t.putString("leaderName", polity == null ? "" : nz(polity.leaderName.isEmpty() ? polity.ownerName : polity.leaderName));
        t.putString("heirName", polity == null ? "" : nz(polity.heirName));
        t.putLong("termEnd", polity == null ? Long.MIN_VALUE : polity.termEnd);
        t.putLong("electionEnd", polity == null ? Long.MIN_VALUE : polity.electionEnd);
        t.putLong("today", CivitasConfig.today(server));
        t.putBoolean("isMember", polity != null);
        t.putBoolean("isCandidate", polity != null && polity.candidates.contains(viewer.getUUID()));
        UUID myChoice = polity == null ? null : polity.votes.get(viewer.getUUID());
        t.putString("myVote", myChoice == null ? "" : myChoice.toString());
        ListTag cands = new ListTag();
        if (polity != null) {
            for (int i = 0; i < polity.candidates.size(); i++) {
                CompoundTag c = new CompoundTag();
                c.putString("uuid", polity.candidates.get(i).toString());
                c.putString("name", polity.candidateNames.get(i));
                c.putInt("votes", RepublicData.votesFor(polity, polity.candidates.get(i)));
                cands.add(c);
            }
        }
        t.put("candidates", cands);
        ListTag writerList = new ListTag();
        if (polity != null) {
            for (int i = 0; i < polity.writers.size(); i++) {
                CompoundTag w = new CompoundTag();
                w.putString("uuid", polity.writers.get(i).toString());
                w.putString("name", polity.writerNames.get(i));
                writerList.add(w);
            }
        }
        t.put("writers", writerList);
        if (polity != null && polity.roles.isEmpty()) {
            RepublicData.ensureRoles(polity);
            data.setDirty();
        }
        t.putLong("myPerms", polity == null ? 0L : owner ? Perms.ALL : RepublicData.permsOf(polity, viewer.getUUID()));
        t.putInt("myRank", polity == null ? Integer.MAX_VALUE : owner ? -1 : RepublicData.rankOf(polity, viewer.getUUID()));
        ListTag roleList = new ListTag();
        if (polity != null) {
            for (RepublicData.Role r : polity.roles) {
                int count = 0;
                for (String rid : polity.memberRoles.values()) {
                    if (rid.equals(r.id)) count++;
                }
                CompoundTag rt = new CompoundTag();
                rt.putString("id", r.id);
                rt.putString("name", r.name);
                rt.putLong("perms", r.perms);
                rt.putInt("color", r.color);
                rt.putInt("count", count);
                roleList.add(rt);
            }
        }
        t.put("roles", roleList);
        ListTag memberRoleList = new ListTag();
        if (polity != null) {
            for (java.util.Map.Entry<UUID, String> e : polity.memberRoles.entrySet()) {
                String roleName = "";
                for (RepublicData.Role r : polity.roles) {
                    if (r.id.equals(e.getValue())) roleName = r.name;
                }
                CompoundTag mt = new CompoundTag();
                mt.putString("uuid", e.getKey().toString());
                mt.putString("role", roleName);
                memberRoleList.add(mt);
            }
        }
        t.put("memberRoles", memberRoleList);
        ListTag factionList = new ListTag();
        if (polity != null) {
            for (RepublicData.Faction f : polity.factions) {
                boolean manage = owner || viewer.getUUID().equals(f.leader) || Perms.has(RepublicData.factionPermissions(f, viewer.getUUID()), Perms.FACTION_MODERATE);
                CompoundTag ft = new CompoundTag();
                ft.putString("id", f.id);
                ft.putString("name", f.name);
                ft.putInt("color", f.color);
                ft.putString("leaderName", f.leaderName);
                ft.putBoolean("voteOpen", f.dissolutionVote);
                ft.putInt("voteYes", f.dissolutionYes.size());
                ft.putBoolean("votedYes", f.dissolutionYes.contains(viewer.getUUID()));
                ft.putBoolean("protected", System.currentTimeMillis() - f.createdAt >= 14L * 24 * 60 * 60 * 1000);
                ft.putString("deputy", f.deputy == null ? "" : f.deputy.toString());
                ft.putInt("members", f.members.size());
                ft.putInt("seats", polity.seats.getOrDefault(f.id, 0));
                ft.putBoolean("mine", f.members.contains(viewer.getUUID()));
                ft.putBoolean("requested", f.requests.contains(viewer.getUUID()));
                ft.putBoolean("manage", manage);
                ft.putBoolean("manageRoles", owner || viewer.getUUID().equals(f.leader));
                ListTag reqs = new ListTag();
                if (manage) {
                    for (int i = 0; i < f.requests.size(); i++) {
                        CompoundTag q = new CompoundTag();
                        q.putString("uuid", f.requests.get(i).toString());
                        q.putString("name", f.requestNames.get(i));
                        reqs.add(q);
                    }
                }
                ft.put("reqs", reqs);
                ListTag factionMembers = new ListTag();
                if (manage) for (int i = 0; i < f.members.size(); i++) {
                    CompoundTag member = new CompoundTag(); UUID id = f.members.get(i);
                    member.putString("uuid", id.toString()); member.putString("name", f.memberNames.get(i));
                    member.putLong("permissions", f.memberPermissions.getOrDefault(id, 0L));
                    member.putBoolean("leader", id.equals(f.leader)); factionMembers.add(member);
                }
                ft.put("memberDetails", factionMembers);
                ListTag factionRoles = new ListTag();
                f.roles.forEach((name, permissions) -> {
                    CompoundTag role = new CompoundTag(); role.putString("name", name);
                    role.putLong("permissions", permissions); factionRoles.add(role);
                });
                ft.put("roles", factionRoles);
                factionList.add(ft);
            }
        }
        t.put("factions", factionList);
        ListTag allPlayers = new ListTag();
        if (op) {
            for (ServerPlayer sp : server.getPlayerList().getPlayers()) {
                Polity pp = findPolity(data, sp.getUUID());
                allPlayers.add(adminPlayerCard(sp, pp));
            }
        }
        t.put("allPlayers", allPlayers);
        t.putInt("parliamentSeats", polity == null ? 0 : CabinetPresets.seatsFor(polity.parliament));
        t.putBoolean("myVoteSet", polity != null && polity.parliamentVotes.containsKey(viewer.getUUID()));

        ListTag members = new ListTag();
        if (polity != null) {
            for (int i = 0; i < polity.members.size(); i++) {
                CompoundTag m = new CompoundTag();
                m.putString("uuid", polity.members.get(i).toString());
                m.putString("name", polity.memberNames.get(i));
                members.add(m);
            }
        }
        if (polity != null) {
            UUID chief = RepublicData.leaderOf(polity);
            if (!polity.members.contains(chief)) {
                CompoundTag m = new CompoundTag(); m.putString("uuid", chief.toString());
                m.putString("name", polity.leaderName.isEmpty() ? polity.ownerName : polity.leaderName); members.add(m);
            }
            if (polity.deputy != null && !polity.deputy.equals(chief) && !polity.members.contains(polity.deputy)) {
                CompoundTag m = new CompoundTag(); m.putString("uuid", polity.deputy.toString()); m.putString("name", polity.deputyName); members.add(m);
            }
        }
        t.put("members", members);

        ListTag players = new ListTag();
        if (polity != null) {
            for (ServerPlayer other : server.getPlayerList().getPlayers()) {
                if (other.getUUID().equals(polity.owner)) continue;
                CompoundTag e = new CompoundTag();
                e.putString("uuid", other.getUUID().toString());
                e.putString("name", other.getGameProfile().getName());
                e.putBoolean("canInvite", findPolity(data, other.getUUID()) == null);
                players.add(e);
            }
        }
        t.put("players", players);

        ListTag bills = new ListTag();
        String me = viewer.getUUID().toString();
        for (RepublicData.Bill b : data.bills()) {
            if (polity == null || !polity.owner.equals(b.state)) continue;
            CompoundTag e = new CompoundTag();
            e.putInt("id", b.id);
            e.putBoolean("canClose", CitizensData.permitted(polity, viewer.getUUID(), op, Perms.LAW_CLOSE));
            e.putInt("number", b.number);
            e.putString("title", nz(b.title));
            e.putString("summary", nz(b.summary)); e.putString("author", nz(b.author));
            e.putBoolean("constitutional", !b.constitutionText.isEmpty());
            e.putBoolean("senatorsOnly", b.senatorsOnly);
            e.putBoolean("initialConstitution", b.initialConstitution);
            e.putLong("proposedDay", b.proposedDay); e.putLong("adoptedDay", b.adoptedDay);
            e.putInt("required", (b.electorate.values().stream().mapToInt(Integer::intValue).sum() * 2 + 2) / 3);
            e.putBoolean("closed", b.closed);
            boolean bloc = !b.senatorsOnly && (b.constitutionText.isEmpty() ? blocMode(polity) : b.constitutionalBloc);
            int yes = b.yes.size();
            int no = b.no.size();
            String mineVote = b.yes.contains(me) ? "yes" : b.no.contains(me) ? "no" : "";
            if (bloc) {
                yes = 0;
                no = 0;
                for (RepublicData.Faction f : polity.factions) {
                    Boolean vote = b.factionVote.get(f.id);
                    if (vote == null) continue;
                    int seats = b.constitutionText.isEmpty() ? polity.seats.getOrDefault(f.id, 0) : b.electorate.getOrDefault(f.id, 0);
                    if (vote) yes += seats; else no += seats;
                }
                mineVote = "";
                for (RepublicData.Faction f : polity.factions) {
                    if (viewer.getUUID().equals(f.leader) && b.factionVote.containsKey(f.id)) {
                        mineVote = b.factionVote.get(f.id) ? "yes" : "no";
                    }
                }
            }
            boolean canVote = !b.closed && CitizensData.member(polity,viewer.getUUID());
            if (b.senatorsOnly || (!b.constitutionText.isEmpty() && !bloc)) canVote &= b.electorate.containsKey(viewer.getUUID().toString());
            else if (bloc) canVote &= polity.factions.stream().anyMatch(f -> viewer.getUUID().equals(f.leader));
            e.putBoolean("canVote", canVote);
            e.putString("mine", mineVote);
            e.putInt("yes", yes);
            e.putInt("no", no);
            e.putBoolean("bloc", bloc);
            bills.add(e);
        }
        t.put("bills", bills);

        ListTag archive = new ListTag();
        for (String line : canArchive ? data.archiveFor(polity == null ? null : polity.owner) : java.util.List.<String>of()) {
            archive.add(StringTag.valueOf(line));
        }
        t.put("archive", archive);

        // Headlines only. The full text is requested when an article is opened.
        ListTag news = new ListTag();
        int count = 0;
        for (RepublicData.News n : data.news()) {
            if (count++ >= NEWS_LIST_LIMIT) break;
            CompoundTag e = new CompoundTag();
            e.putInt("id", n.id);
            e.putString("title", nz(n.title));
            e.putString("stateName", !op && n.hideState ? HIDDEN : nz(n.stateName));
            e.putLong("day", n.day);
            e.putBoolean("image", !nz(n.imageId).isEmpty());
            news.add(e);
        }
        t.put("news", news);

        if (op) {
            Map<UUID, Integer> billCounts = new HashMap<>(), newsCounts = new HashMap<>();
            for (RepublicData.Bill b : data.bills()) if (b.state != null) billCounts.merge(b.state, 1, Integer::sum);
            for (RepublicData.News n : data.news()) if (n.state != null) newsCounts.merge(n.state, 1, Integer::sum);
            ListTag states = new ListTag();
            for (Polity p : data.polities()) {
                CompoundTag e = new CompoundTag();
                e.putString("name", nz(p.name));
                e.putString("ownerId", p.owner.toString());
                e.putString("type", nz(p.type));
                e.putString("ownerName", nz(p.ownerName));
                e.putString("deputyName", nz(p.deputyName));
                e.putString("ideology", nz(p.ideology));
                e.putString("parliament", nz(p.parliament));
                e.putString("government", nz(p.government));
                e.putString("members", p.memberNames.isEmpty() ? "нет" : String.join(", ", p.memberNames));
                e.putInt("bills", billCounts.getOrDefault(p.owner, 0));
                e.putString("leader", nz(p.leaderName.isEmpty() ? p.ownerName : p.leaderName));
                e.putString("heir", nz(p.heirName));
                e.putInt("memberCount", p.members.size());
                e.putString("writers", String.join(", ", p.writerNames));
                e.putString("roles", joinRoles(p));
                e.putString("factions", joinFactions(p));
                e.putInt("candidates", p.candidates.size());
                e.putInt("seats", CabinetPresets.seatsFor(p.parliament));
                e.putLong("termEnd", p.termEnd);
                e.putLong("electionEnd", p.electionEnd);
                e.putInt("news", newsCounts.getOrDefault(p.owner, 0));
                e.putString("alliances", DiplomacyNet.summary(server, p.owner, false));
                e.putString("wars", DiplomacyNet.summary(server, p.owner, true));
                states.add(e);
            }
            t.put("states", states);
        }

        PacketDistributor.sendToPlayer(viewer, new CabinetSnapshot(t, open));
    }

    /** Admin-only: the full record of one online player, for the player card. */
    private static CompoundTag adminPlayerCard(ServerPlayer sp, Polity pp) {
        UUID id = sp.getUUID();
        boolean leader = pp != null && RepublicData.leaderOf(pp).equals(id);
        boolean deputy = pp != null && id.equals(pp.deputy);
        CompoundTag e = new CompoundTag();
        e.putString("uuid", id.toString());
        e.putString("name", sp.getGameProfile().getName());
        e.putString("state", pp == null ? "" : nz(pp.name));
        e.putString("stateType", pp == null ? "" : nz(pp.type));
        e.putString("alliances", DiplomacyNet.summary(sp.getServer(), pp == null ? null : pp.owner, false));
        e.putString("wars", DiplomacyNet.summary(sp.getServer(), pp == null ? null : pp.owner, true));
        e.putString("status", pp == null ? "без государства" : leader ? "глава государства"
                : deputy ? "заместитель" : pp.members.contains(id) ? "участник" : "вне состава");
        e.putString("role", roleOf(pp, id));
        RepublicData.Faction f = pp == null ? null : RepublicData.factionOf(pp, id);
        e.putString("faction", f == null ? "" : nz(f.name));
        e.putBoolean("writer", pp != null && pp.writers.contains(id));
        e.putBoolean("candidate", pp != null && pp.candidates.contains(id));
        e.putBoolean("op", sp.hasPermissions(2));
        e.putString("curatedWars", DiplomacyNet.curated(sp.getServer(), id));
        e.putString("gameMode", sp.gameMode.getGameModeForPlayer().getName());
        e.putInt("health", Math.round(sp.getHealth()));
        e.putInt("food", sp.getFoodData().getFoodLevel());
        e.putInt("xp", sp.experienceLevel);
        return e;
    }

    private static String roleOf(Polity p, UUID id) {
        if (p == null) return "";
        String roleId = p.memberRoles.get(id);
        if (roleId == null) return "";
        for (RepublicData.Role r : p.roles) {
            if (r.id.equals(roleId)) return r.name;
        }
        return "";
    }

    private static String joinRoles(Polity p) {
        StringBuilder sb = new StringBuilder();
        for (RepublicData.Role r : p.roles) {
            if (sb.length() > 0) sb.append(", ");
            sb.append(r.name);
        }
        return sb.toString();
    }

    private static String joinFactions(Polity p) {
        StringBuilder sb = new StringBuilder();
        for (RepublicData.Faction f : p.factions) {
            if (sb.length() > 0) sb.append(", ");
            sb.append(f.name).append(" (мест ").append(p.seats.getOrDefault(f.id, 0))
                    .append(", членов ").append(f.members.size()).append(")");
        }
        return sb.toString();
    }

    /** Sends only the ideology and the name of the player's state (empty if they have none). */
    public static void sendState(ServerPlayer player) {
        MinecraftServer server = player.getServer();
        if (server == null) return;
        Polity polity = findPolity(RepublicData.get(server), player.getUUID());
        String ideology = polity == null ? "" : nz(polity.ideology);
        String stateName = polity == null ? "" : nz(polity.name);
        PacketDistributor.sendToPlayer(player, new CabinetState(ideology, stateName,
                CivitasConfig.startDate().toEpochDay(), CivitasConfig.advance(),
                CivitasConfig.ticksPerDay()));
    }

    /** Sends one player the newest news id and the newest bill id of their state. */
    public static void pushFeed(ServerPlayer player) {
        MinecraftServer server = player.getServer();
        if (server == null) return;
        RepublicData data = RepublicData.get(server);
        int newsLatest = data.news().isEmpty() ? 0 : data.news().get(0).id;
        Polity mine = findPolity(data, player.getUUID());
        int billsLatest = 0;
        if (mine != null) {
            for (RepublicData.Bill b : data.bills()) {
                if (mine.owner.equals(b.state)) billsLatest = Math.max(billsLatest, b.id);
            }
        }
        PacketDistributor.sendToPlayer(player, new FeedState(newsLatest, billsLatest));
    }

    /** Refreshes the HUD icons of every online player after news or a bill was added. */
    static void pushFeedAll(MinecraftServer server) {
        for (ServerPlayer p : server.getPlayerList().getPlayers()) {
            pushFeed(p);
        }
    }

    /** Keeps the inventory button in sync for everyone who logs in. */
    public static void onPlayerLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity() instanceof ServerPlayer sp) {
            sendState(sp);
            pushFeed(sp);
            DiplomacyNet.pushFeed(sp);
        }
    }

    // ---------- news ----------

    private static boolean canDeleteNews(ServerPlayer player, RepublicData data, RepublicData.News n) {
        if (player.hasPermissions(2)) return true;
        Polity mine = findPolity(data, player.getUUID());
        if (mine == null || n.state == null || !mine.owner.equals(n.state)) return false;
        return mine.owner.equals(player.getUUID()) || player.getUUID().equals(mine.deputy);
    }

    private static void sendNews(ServerPlayer viewer, int newsId) {
        MinecraftServer server = viewer.getServer();
        if (server == null) return;

        RepublicData data = RepublicData.get(server);
        RepublicData.News n = data.news(newsId);
        if (n == null) return;

        CompoundTag t = new CompoundTag();
        t.putInt("id", n.id);
        t.putString("title", nz(n.title));
        boolean admin = viewer.hasPermissions(2);
        t.putBoolean("hideState", n.hideState);
        t.putBoolean("hideAuthor", n.hideAuthor);
        t.putString("stateName", !admin && n.hideState ? HIDDEN : nz(n.stateName));
        t.putString("author", !admin && n.hideAuthor ? HIDDEN : nz(n.author));
        t.putLong("day", n.day);
        t.putString("body", nz(n.body));
        t.putString("footer", nz(n.footer));
        t.putString("imageId", nz(n.imageId));
        t.putString("modelId", nz(n.modelId));
        t.putBoolean("canDelete", canDeleteNews(viewer, data, n));
        PacketDistributor.sendToPlayer(viewer, new NewsFull(t));
    }

    /** Owner, deputy or admin publishes. One article per 15 seconds per player. */
    static void applyPublish(ServerPlayer sender, PublishNews msg) {
        MinecraftServer server = sender.getServer();
        if (server == null) return;

        RepublicData data = RepublicData.get(server);
        Polity mine = selectedState(data, sender);
        boolean leader = mine != null
                && (controlsState(sender, mine) || RepublicData.leaderOf(mine).equals(sender.getUUID()) || sender.getUUID().equals(mine.deputy)
                || mine.writers.contains(sender.getUUID()) || Perms.has(RepublicData.permsOf(mine, sender.getUUID()), Perms.NEWS));
        RepublicData.Faction faction = mine == null ? null : RepublicData.factionOf(mine, sender.getUUID());
        boolean canFaction = faction != null && (sender.getUUID().equals(faction.leader)
                || Perms.has(RepublicData.factionPermissions(faction, sender.getUUID()), Perms.NEWS));
        if (msg.faction() ? !canFaction : (!leader && !sender.hasPermissions(2))) return;

        long now = System.currentTimeMillis();
        Long last = LAST_POST.get(sender.getUUID());
        if (last != null && now - last < POST_COOLDOWN_MS) {
            sender.displayClientMessage(Component.literal("Подождите немного перед следующей новостью."), true);
            return;
        }

        String title = clean(msg.title(), 80, false);
        String body = clean(msg.body(), 2000, true);
        String footer = clean(msg.footer(), 120, false);
        if (title.isEmpty() || body.isEmpty()) return;

        String imageId = msg.imageId() == null ? "" : msg.imageId().trim();
        if (!imageId.isEmpty() && !MediaStore.exists(server, imageId)) {
            sender.displayClientMessage(Component.literal("Фото не найдено на сервере. Загрузите его ещё раз."), true);
            return;
        }

        LAST_POST.put(sender.getUUID(), now);
        UUID state = msg.faction() ? mine.owner : leader ? mine.owner : null;
        String stateName = msg.faction() ? nz(faction.name) : leader ? nz(mine.name) : "";
        RepublicData.News item = data.addNews(state, stateName, sender.getGameProfile().getName(),
                title, body, footer, CivitasConfig.today(server));
        item.imageId = imageId;
        item.hideState = msg.hideState();
        item.hideAuthor = msg.hideAuthor();
        data.setDirty();
        broadcast(server, "Новости · " + (msg.hideState() ? HIDDEN : stateName.isEmpty() ? "Администрация" : stateName) + ": " + title);
        java.util.regex.Matcher inline = java.util.regex.Pattern.compile("\\[img:([0-9a-f]{32})]").matcher(body);
        String hookImage = !imageId.isEmpty() ? imageId : (inline.find() ? inline.group(1) : "");
        DiscordWebhook.news(msg.hideState() ? HIDDEN : stateName, title, body, footer,
                msg.hideAuthor() ? HIDDEN : sender.getGameProfile().getName(), item.day,
                server.overworld().getDayTime(), msg.discordEmbed(), STRIPE_COLORS[msg.stripe()], MediaStore.bytes(server, hookImage),
                avatarForNews(msg.hideState(), msg.faction() || leader, msg.faction() ? MediaStore.bytes(server, faction.avatarId) : leader ? MediaStore.bytes(server, mine.avatarId) : null));
        pushFeedAll(server);
        refresh(sender);
    }

    static byte[] avatarForNews(boolean hidden, boolean hasState, byte[] avatar) {
        return hidden || !hasState ? null : avatar;
    }

    static void applyDeleteNews(ServerPlayer sender, DeleteNews msg) {
        MinecraftServer server = sender.getServer();
        if (server == null) return;

        RepublicData data = RepublicData.get(server);
        RepublicData.News n = data.news(msg.newsId());
        if (n == null || !canDeleteNews(sender, data, n)) return;

        RepublicData.News removed = data.removeNews(n.id);
        if (removed != null) {
            MediaStore.deleteIfUnused(server, data, removed.imageId);
        }
        refresh(sender);
    }

    /** Strips control characters and cuts to the limit. Newlines survive only in multi-line text. */
    private static String clean(String s, int max, boolean multiline) {
        String t = s.replace("\r\n", "\n").replace('\r', '\n');
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < t.length(); i++) {
            char c = t.charAt(i);
            if (c == '\n') {
                if (multiline) sb.append(c);
            } else if (c >= 32 && c != 127) {
                sb.append(c);
            }
        }
        String out = sb.toString().strip();
        return out.length() > max ? out.substring(0, max) : out;
    }

    // ---------- cabinet actions ----------

    /** Owner-only edits. */
    static void applyEdit(ServerPlayer sender, EditCabinet edit) {
        MinecraftServer server = sender.getServer();
        if (server == null) return;

        RepublicData data = RepublicData.get(server);
        if (edit.field().equals("admin_select_state")) {
            if (!sender.hasPermissions(2)) return;
            UUID chosen = parseUuid(edit.value());
            if (chosen == null) { ADMIN_STATE.remove(sender.getUUID()); refresh(sender); return; }
            for (Polity candidate : data.polities()) {
                if (candidate.owner.equals(chosen)) {
                    ADMIN_STATE.put(sender.getUUID(), chosen);
                    refresh(sender);
                    return;
                }
            }
            return;
        }
        if (edit.field().equals("admin_leadership")) {
            if (!sender.hasPermissions(2)) return;
            Polity state = selectedState(data, sender);
            if (state == null) return;
            String[] values = edit.value().split("\\|", -1);
            if (values.length != 3) return;
            UUID target = parseUuid(values[1]);
            boolean remove = values[1].equals("-");
            if (values[0].startsWith("state")) {
                if (!remove && (target == null || !(state.members.contains(target) || target.equals(RepublicData.leaderOf(state)) || target.equals(state.deputy)))) return;
                String name = target == null ? "" : target.equals(RepublicData.leaderOf(state)) ? (state.leaderName.isEmpty() ? state.ownerName : state.leaderName)
                        : target.equals(state.deputy) ? state.deputyName : state.memberNames.get(state.members.indexOf(target));
                if (values[0].equals("stateLeader")) {
                    if (remove) return;
                    state.leader = target; state.leaderName = name;
                    if (target.equals(state.deputy)) { state.deputy = null; state.deputyName = ""; }
                } else if (values[0].equals("stateDeputy")) {
                    if (!remove && target.equals(RepublicData.leaderOf(state))) return;
                    state.deputy = target; state.deputyName = name;
                } else return;
            } else {
                RepublicData.Faction f = RepublicData.factionById(state, values[2]);
                if (f == null || (!remove && (target == null || !f.members.contains(target)))) return;
                if (values[0].equals("factionLeader")) {
                    if (remove) return;
                    f.leader = target; f.leaderName = f.memberNames.get(f.members.indexOf(target));
                    if (target.equals(f.deputy)) f.deputy = null;
                } else if (values[0].equals("factionDeputy")) {
                    if (!remove && target.equals(f.leader)) return;
                    f.deputy = target;
                } else return;
            }
            data.setDirty(); refresh(sender); return;
        }
        if (edit.field().equals("member")) {
            Polity state = selectedState(data, sender); UUID target = parseUuid(edit.value());
            if (state == null || target == null) return;
            if (CitizensData.member(state, target)) applyMembers(sender, data, new EditCabinet("kick", edit.value()));
            else CitizensNet.invite(sender, state, target);
            return;
        }
        if (edit.field().equals("faction")) {
            applyFactions(sender, data, edit);
            return;
        }
        if (edit.field().equals("role") || edit.field().equals("assign") || edit.field().equals("kick")) {
            applyMembers(sender, data, edit);
            return;
        }
        if (edit.field().equals("vote") || edit.field().equals("candidacy")) {
            applyPower(sender, data, edit);
            return;
        }
        Polity polity = selectedState(data, sender);
        if (polity != null && !controlsState(sender, polity) && !RepublicData.leaderOf(polity).equals(sender.getUUID())) return;
        if (polity == null) return;

        String field = edit.field();
        String value = edit.value();

        if (field.equals("votingAccess")) {
            if (!value.equals("senators") && !value.equals("default")) return;
            polity.senatorsOnly = value.equals("senators");
        } else if (field.equals("constitution")) {
            if (value.isBlank() || value.length() > 16000) return;
            for (RepublicData.Bill b : data.bills()) if (polity.owner.equals(b.state) && !b.closed && !b.constitutionText.isEmpty()) return;
            if (polity.senatorsOnly && RepublicData.senators(polity).isEmpty()) {
                sender.displayClientMessage(Component.literal("Сначала назначьте роль с правом голосования хотя бы одному сенатору."), true); return;
            }
            RepublicData.Bill proposal = data.createBill(polity.constitution.isBlank() ? "Проект конституции" : "Поправки к конституции", value, sender.getGameProfile().getName(), polity.owner);
            proposal.initialConstitution = polity.constitution.isBlank();
            proposal.proposedDay = CivitasConfig.today(server);
            proposal.constitutionText = value;
            proposal.senatorsOnly = polity.senatorsOnly;
            proposal.constitutionalBloc = !polity.senatorsOnly && blocMode(polity);
            if (proposal.constitutionalBloc) {
                polity.seats.forEach((id, seats) -> { if (seats > 0) proposal.electorate.put(id, seats); });
            } else if (polity.senatorsOnly) {
                for (UUID id : RepublicData.senators(polity)) proposal.electorate.put(id.toString(), 1);
            } else {
                for (UUID id : polity.members) proposal.electorate.put(id.toString(), 1);
                proposal.electorate.put(RepublicData.leaderOf(polity).toString(), 1);
                if (polity.deputy != null) proposal.electorate.put(polity.deputy.toString(), 1);
            }
            data.setDirty(); pushFeedAll(server); refreshState(server, polity.owner); return;
        } else if (field.equals("deputy")) {
            if (value.isEmpty()) {
                polity.deputy = null;
                polity.deputyName = "";
            } else {
                UUID id;
                try {
                    id = UUID.fromString(value);
                } catch (IllegalArgumentException e) {
                    return;
                }
                if (id.equals(RepublicData.leaderOf(polity)) || !CitizensData.member(polity, id)) return;
                int memberIndex = polity.members.indexOf(id);
                if(memberIndex < 0) return;
                polity.deputy = id;
                polity.deputyName = polity.memberNames.get(memberIndex);
            }
        } else if (field.equals("heir")) {
            if (!"Монархия".equals(polity.government)) return;
            if (value.isEmpty()) {
                polity.heir = null;
                polity.heirName = "";
            } else {
                UUID id;
                try {
                    id = UUID.fromString(value);
                } catch (IllegalArgumentException e) {
                    return;
                }
                int idx = polity.members.indexOf(id);
                if (idx < 0) return;
                polity.heir = id;
                polity.heirName = polity.memberNames.get(idx);
            }
        } else if (field.equals("writer")) {
            UUID id;
            try {
                id = UUID.fromString(value);
            } catch (IllegalArgumentException e) {
                return;
            }
            int writerIdx = polity.writers.indexOf(id);
            if (writerIdx >= 0) {
                polity.writers.remove(writerIdx);
                polity.writerNames.remove(writerIdx);
            } else {
                int idx = polity.members.indexOf(id);
                if (idx < 0) return;
                polity.writers.add(id);
                polity.writerNames.add(polity.memberNames.get(idx));
            }
        } else if (field.equals("ideology") && CabinetPresets.IDEOLOGIES.contains(value)) {
            applyIdeology(sender, data, polity, value);
        } else if (field.equals("parliament") && CabinetPresets.PARLIAMENTS.contains(value)) {
            polity.parliament = value;
        } else if (field.equals("government") && CabinetPresets.GOVERNMENTS.contains(value)) {
            if (!data.setGovernment(polity, value, CivitasConfig.today(server))) return;
        } else {
            return;
        }

        data.setDirty(); // SavedData: this is what makes the change survive a restart
        refresh(sender);
        sendState(sender);
        if (polity.deputy != null) {
            ServerPlayer deputyOnline = server.getPlayerList().getPlayer(polity.deputy);
            if (deputyOnline != null) {
                sendState(deputyOnline);
            }
        }
    }

    /** Any member can vote, once per bill. */
    static void applyVote(ServerPlayer voter, VoteBill vote) {
        MinecraftServer server = voter.getServer();
        if (server == null) return;

        RepublicData data = RepublicData.get(server);
        Polity mine = findPolity(data, voter.getUUID());
        RepublicData.Bill bill = data.bill(vote.billId());
        if (bill == null || mine == null || !mine.owner.equals(bill.state)) return;
        boolean constitutional = !bill.constitutionText.isEmpty();
        if ((bill.senatorsOnly || constitutional && !bill.constitutionalBloc) && !bill.electorate.containsKey(voter.getUUID().toString())) return;
        if (!bill.senatorsOnly && (constitutional ? bill.constitutionalBloc : blocMode(mine))) {
            // Parliament: only faction leaders vote, and each faction casts the seats it holds.
            if (bill.closed) return;
            RepublicData.Faction led = null;
            for (RepublicData.Faction f : mine.factions) {
                if (voter.getUUID().equals(f.leader)) led = f;
            }
            if (led == null) {
                voter.displayClientMessage(Component.literal("В этом государстве голос решает фракция: голосуют только лидеры фракций."), false);
                return;
            }
            if (constitutional && !bill.electorate.containsKey(led.id)) return;
            bill.factionVote.put(led.id, vote.inFavor());
        } else if (!bill.vote(voter.getUUID(), vote.inFavor())) return;

        if (constitutional) {
            int total = bill.electorate.values().stream().mapToInt(Integer::intValue).sum();
            int yes = 0;
            for (java.util.Map.Entry<String, Integer> e : bill.electorate.entrySet()) {
                if (bill.constitutionalBloc ? Boolean.TRUE.equals(bill.factionVote.get(e.getKey())) : bill.yes.contains(e.getKey())) yes += e.getValue();
            }
            if (bill.constitutionPassed()) {
                long accepted = CivitasConfig.today(server);
                if (mine.constitution.isBlank()) mine.constitutionAdoptedDay = accepted;
                mine.constitutionRevisedDay = accepted;
                bill.adoptedDay = accepted;
                mine.constitution = bill.constitutionText; bill.closed = true;
                data.logFor(mine.owner, "Конституция принята: " + yes + " из " + total + ".");
            }
        }
        data.logFor(bill.state, voter.getGameProfile().getName() + " голосует " + (vote.inFavor() ? "ЗА" : "ПРОТИВ")
                + " по законопроекту #" + bill.number + ".");
        data.setDirty();
        refreshState(server, bill.state);
    }

    /** Candidacy (members, during an election) and votes (members, for a candidate). */
    static void applyPower(ServerPlayer sender, RepublicData data, EditCabinet edit) {
        Polity p = findPolity(data, sender.getUUID());
        if (p == null) return;
        data.tickPower(p, CivitasConfig.today(sender.getServer()));
        if (p.electionEnd == Long.MIN_VALUE) return;
        if (edit.field().equals("candidacy")) {
            int idx = p.candidates.indexOf(sender.getUUID());
            if (idx >= 0) {
                p.candidates.remove(idx);
                p.candidateNames.remove(idx);
                p.votes.values().removeIf(c -> c.equals(sender.getUUID()));
            } else {
                p.candidates.add(sender.getUUID());
                p.candidateNames.add(sender.getGameProfile().getName());
            }
        } else {
            UUID target;
            try {
                target = UUID.fromString(edit.value());
            } catch (IllegalArgumentException e) {
                return;
            }
            if (!p.candidates.contains(target)) return;
            p.votes.put(sender.getUUID(), target);
        }
        data.setDirty();
        refresh(sender);
    }

    private static UUID parseUuid(String s) {
        try {
            return UUID.fromString(s);
        } catch (IllegalArgumentException e) {
            return null;
        }
    }

    private static int roleIndex(Polity p, String id) {
        for (int i = 0; i < p.roles.size(); i++) {
            if (p.roles.get(i).id.equals(id)) return i;
        }
        return -1;
    }

    private static void swapRoles(Polity p, int a, int b) {
        RepublicData.Role first = p.roles.get(a);
        p.roles.set(a, p.roles.get(b));
        p.roles.set(b, first);
    }

    /**
     * Roles and members: move, delete roles, assign roles, kick members.
     * A player may only act on places below their own, and may only hand out permissions they hold.
     */
    static void applyMembers(ServerPlayer sender, RepublicData data, EditCabinet edit) {
        Polity p = selectedState(data, sender);
        if (p == null) return;
        UUID me = sender.getUUID();
        boolean leader = me.equals(RepublicData.leaderOf(p)) || controlsState(sender, p);
        long mine = leader ? Perms.ALL : RepublicData.permsOf(p, me);
        int myRank = RepublicData.rankOf(p, me);
        String value = edit.value();

        switch (edit.field()) {
            case "role" -> {
                int sep = value.indexOf('|');
                if (sep < 0 || !Perms.has(mine, Perms.ROLE_MANAGE)) return;
                String op = value.substring(0, sep);
                String rest = value.substring(sep + 1);
                int second = rest.indexOf('|');
                String roleId = second < 0 ? rest : rest.substring(0, second);
                String extra = second < 0 ? "" : rest.substring(second + 1);
                int idx = roleIndex(p, roleId);
                if (idx < 0 || (!leader && idx <= myRank)) return;
                switch (op) {
                    case "up" -> {
                        if (idx == 0 || (!leader && idx - 1 <= myRank)) return;
                        swapRoles(p, idx, idx - 1);
                    }
                    case "down" -> {
                        if (idx >= p.roles.size() - 1 || (!leader && idx + 1 <= myRank)) return;
                        swapRoles(p, idx, idx + 1);
                    }
                    case "color" -> {
                        int colour;
                        try {
                            colour = Integer.parseInt(extra);
                        } catch (NumberFormatException e) {
                            return;
                        }
                        if (!CabinetPresets.ROLE_COLORS.contains(colour)) return;
                        p.roles.get(idx).color = colour;
                    }
                    case "perm" -> {
                        int bit;
                        try {
                            bit = Integer.parseInt(extra);
                        } catch (NumberFormatException e) {
                            return;
                        }
                        if (bit < 0 || bit >= Perms.NAMES.length) return;
                        long flag = 1L << bit;
                        // You can only toggle a permission you hold yourself.
                        if (!leader && (mine & flag) == 0) return;
                        RepublicData.Role target = p.roles.get(idx);
                        target.perms ^= flag;
                    }
                    case "delete" -> {
                        String removedId = p.roles.get(idx).id;
                        p.roles.remove(idx);
                        p.memberRoles.values().removeIf(rid -> rid.equals(removedId));
                    }
                    default -> {
                        return;
                    }
                }
            }
            case "assign" -> {
                int sep = value.indexOf('|');
                if (sep < 0 || !Perms.has(mine, Perms.ROLE_ASSIGN)) return;
                UUID target = parseUuid(value.substring(0, sep));
                String roleId = value.substring(sep + 1);
                if (target == null || !(p.members.contains(target) || target.equals(RepublicData.leaderOf(p)) || target.equals(p.deputy))) return;
                if (!leader && RepublicData.rankOf(p, target) <= myRank) return;
                if (roleId.isEmpty()) {
                    p.memberRoles.remove(target);
                } else {
                    int idx = roleIndex(p, roleId);
                    if (idx < 0 || (!leader && idx <= myRank)) return;
                    if (!leader && (p.roles.get(idx).perms & ~mine) != 0) return;
                    p.memberRoles.put(target, roleId);
                }
            }
            case "kick" -> {
                UUID target = parseUuid(value);
                if (target == null || !Perms.has(mine, Perms.MEMBER_KICK)) return;
                if (target.equals(RepublicData.leaderOf(p))) return;
                int idx = p.members.indexOf(target);
                if (idx < 0 || (!leader && RepublicData.rankOf(p, target) <= myRank)) return;
                String name = p.memberNames.get(idx);
                p.members.remove(idx);
                p.memberNames.remove(idx);
                p.memberRoles.remove(target);
                if(target.equals(p.deputy)) { p.deputy=null; p.deputyName=""; }
                dropFromFaction(p, target);
                int w = p.writers.indexOf(target);
                if (w >= 0) {
                    p.writers.remove(w);
                    p.writerNames.remove(w);
                }
                int c = p.candidates.indexOf(target);
                if (c >= 0) {
                    p.candidates.remove(c);
                    p.candidateNames.remove(c);
                }
                p.votes.remove(target);
                p.votes.values().removeIf(v -> v.equals(target));
                if (target.equals(p.heir)) {
                    p.heir = null;
                    p.heirName = "";
                }
                data.logFor(p.owner, sender.getGameProfile().getName() + " исключил из государства: " + name + ".");
                ServerPlayer gone = sender.getServer().getPlayerList().getPlayer(target);
                if (gone != null) { sendState(gone); refresh(gone); }
            }
            default -> {
                return;
            }
        }
        data.setDirty();
        refreshState(sender.getServer(), p.owner);
    }

    /** True when the state has a parliament: then bills are decided by faction seats, not by individual votes. */
    static boolean blocMode(Polity p) {
        return p != null && !p.seats.isEmpty();
    }

    /** Takes a player out of their faction. A leader's place goes to the first member; an empty faction is removed. */
    static void dropFromFaction(Polity p, UUID who) {
        RepublicData.Faction f = RepublicData.factionOf(p, who);
        if (f == null) return;
        int idx = f.members.indexOf(who);
        f.memberPermissions.remove(who);
        f.memberRoles.remove(who);
        f.dissolutionYes.remove(who);
        if (who.equals(f.deputy)) f.deputy = null;
        f.members.remove(idx);
        f.memberNames.remove(idx);
        if (who.equals(f.leader)) {
            if (f.members.isEmpty()) {
                String fid = f.id;
                p.factions.remove(f);
                p.seats.remove(fid);
                p.parliamentVotes.values().removeIf(v -> v.equals(fid));
                return;
            }
            int successor = f.deputy == null ? 0 : Math.max(0, f.members.indexOf(f.deputy));
            f.leader = f.members.get(successor);
            f.leaderName = f.memberNames.get(successor);
            f.deputy = null;
        }
    }

    /**
     * Factions and parliament votes. Members join by request; the faction leader (or the state leader)
     * accepts or declines; during an election any member votes for a faction.
     */
    static void applyFactions(ServerPlayer sender, RepublicData data, EditCabinet edit) {
        Polity p = selectedState(data, sender);
        if (p == null) return;
        UUID me = sender.getUUID();
        boolean stateLeader = me.equals(RepublicData.leaderOf(p)) || controlsState(sender, p);
        String[] parts = edit.value().split("\\|");
        switch (parts[0]) {
            case "join" -> {
                RepublicData.Faction f = parts.length > 1 ? RepublicData.factionById(p, parts[1]) : null;
                if (f == null || RepublicData.factionOf(p, me) != null || f.requests.contains(me)) return;
                f.requests.add(me);
                f.requestNames.add(sender.getGameProfile().getName());
            }
            case "leave" -> {
                if (RepublicData.factionOf(p, me) == null) return;
                dropFromFaction(p, me);
            }
            case "accept", "decline" -> {
                if (parts.length < 3) return;
                RepublicData.Faction f = RepublicData.factionById(p, parts[1]);
                UUID target = parseUuid(parts[2]);
                if (f == null || target == null || !(me.equals(f.leader) || stateLeader || Perms.has(RepublicData.factionPermissions(f, me), Perms.FACTION_MODERATE))) return;
                int ri = f.requests.indexOf(target);
                if (ri < 0) return;
                String targetName = f.requestNames.get(ri);
                f.requests.remove(ri);
                f.requestNames.remove(ri);
                if (parts[0].equals("accept") && RepublicData.factionOf(p, target) == null && p.members.indexOf(target) >= 0) {
                    f.members.add(target);
                    f.memberNames.add(targetName);
                }
            }
            case "roleAssign", "roleToggle", "roleDelete" -> {
                if (parts.length < 3) return;
                RepublicData.Faction f = RepublicData.factionById(p, parts[1]);
                if (f == null || !(me.equals(f.leader) || stateLeader)) return;
                if (parts[0].equals("roleAssign")) {
                    if (parts.length != 4) return;
                    UUID member = parseUuid(parts[2]);
                    if (member == null || !f.members.contains(member) || member.equals(f.leader)) return;
                    if (parts[3].equals("-")) f.memberRoles.remove(member);
                    else if (f.roles.containsKey(parts[3])) f.memberRoles.put(member, parts[3]);
                    else return;
                } else {
                    if (!f.roles.containsKey(parts[2])) return;
                    if (parts[0].equals("roleDelete")) {
                        f.roles.remove(parts[2]); f.memberRoles.values().removeIf(parts[2]::equals);
                    } else {
                        if (parts.length != 4) return;
                        long flag = parts[3].equals("news") ? Perms.NEWS : parts[3].equals("moderate") ? Perms.FACTION_MODERATE : 0;
                        if (flag == 0) return;
                        f.roles.put(parts[2], f.roles.get(parts[2]) ^ flag);
                    }
                }
            }
            case "permission" -> {
                if (parts.length != 4) return;
                RepublicData.Faction f = RepublicData.factionById(p, parts[1]);
                UUID target = parseUuid(parts[2]);
                if (f == null || target == null || !f.members.contains(target)
                        || target.equals(f.leader) || !(me.equals(f.leader) || stateLeader)) return;
                long flag;
                if (parts[3].equals("news")) flag = Perms.NEWS;
                else if (parts[3].equals("moderate")) flag = Perms.FACTION_MODERATE;
                else return;
                long changed = f.memberPermissions.getOrDefault(target, 0L) ^ flag;
                if (changed == 0) f.memberPermissions.remove(target);
                else f.memberPermissions.put(target, changed);
            }
            case "deputy", "disbandVote" -> {
                if (parts.length != 3) return;
                RepublicData.Faction f = RepublicData.factionById(p, parts[1]);
                if (f == null) return;
                if (parts[0].equals("deputy")) {
                    if (!(me.equals(f.leader) || stateLeader)) return;
                    UUID target = parseUuid(parts[2]);
                    if (target == null || !f.members.contains(target) || target.equals(f.leader)) return;
                    f.deputy = target;
                } else {
                    if (!f.dissolutionVote || !f.members.contains(me)) return;
                    if (parts[2].equals("yes")) f.dissolutionYes.add(me);
                    else if (parts[2].equals("no")) f.dissolutionYes.remove(me);
                    else return;
                    if (f.dissolutionYes.size() > f.members.size() / 2) {
                        p.factions.remove(f); p.seats.remove(f.id);
                        p.parliamentVotes.values().removeIf(f.id::equals);
                    }
                }
            }
            case "disband" -> {
                RepublicData.Faction f = parts.length > 1 ? RepublicData.factionById(p, parts[1]) : null;
                if (f == null || !(me.equals(f.leader) || stateLeader)) return;
                if (System.currentTimeMillis() - f.createdAt >= 14L * 24 * 60 * 60 * 1000) {
                    if (!me.equals(f.leader) || f.dissolutionVote) return;
                    f.dissolutionVote = true;
                    f.dissolutionYes.clear();
                } else {
                    String fid = f.id;
                    p.factions.remove(f); p.seats.remove(fid);
                    p.parliamentVotes.values().removeIf(v -> v.equals(fid));
                }
            }
            case "pvote" -> {
                if (parts.length < 2 || p.electionEnd == Long.MIN_VALUE || CabinetPresets.seatsFor(p.parliament) <= 0) return;
                if (RepublicData.factionById(p, parts[1]) == null) return;
                p.parliamentVotes.put(me, parts[1]);
            }
            default -> {
                return;
            }
        }
        data.setDirty();
        refresh(sender);
    }

    /** Changes the ideology. A form of government the new ideology does not allow moves to the first one it allows. */
    static void applyIdeology(ServerPlayer sender, RepublicData data, Polity polity, String ideology) {
        polity.ideology = ideology;
        java.util.List<String> allowed = CabinetPresets.governmentsFor(ideology);
        if (!allowed.contains(polity.government)) {
            String fallback = allowed.get(0);
            data.setGovernment(polity, fallback, CivitasConfig.today(sender.getServer()));
            // The government changes quietly: no chat message, the cabinet shows the new form.
        }
    }

    /**
     * Serverside election clock: every 10 seconds the terms and elections of all states are checked,
     * so nobody can stall an election by not opening the cabinet.
     */
    public static void onServerTick(net.neoforged.neoforge.event.tick.ServerTickEvent.Post event) {
        MinecraftServer server = net.neoforged.neoforge.server.ServerLifecycleHooks.getCurrentServer();
        if (server == null) return;
        flushSnapshots(server);
        DiplomacyNet.tick(server);
        if (server.getTickCount() % 200 != 0) return;
        RepublicData data = RepublicData.get(server);
        long today = CivitasConfig.today(server);
        for (Polity p : data.polities()) {
            data.tickPower(p, today);
        }
    }

    /** Owner or admin closes a vote. */
    static void applyClose(ServerPlayer sender, CloseBill msg) {
        MinecraftServer server = sender.getServer();
        if (server == null) return;

        RepublicData data = RepublicData.get(server);
        Polity owned = selectedState(data, sender);
        RepublicData.Bill bill = data.bill(msg.billId());
        if (bill == null || bill.closed || owned == null || !owned.owner.equals(bill.state)
                || !CitizensData.permitted(owned, sender.getUUID(), sender.hasPermissions(2), Perms.LAW_CLOSE)) return;

        bill.closed = true;
        data.logFor(bill.state, "Голосование по законопроекту #" + bill.number + " «" + bill.title + "» закрыто: "
                + bill.yes.size() + " за, " + bill.no.size() + " против.");
        data.setDirty();
        refreshState(server, bill.state);
    }

    /** Creates a bill, renames a state, leaves a state, or (admin only) creates or deletes a state. */
    static void applyForm(ServerPlayer sender, SubmitForm msg) {
        MinecraftServer server = sender.getServer();
        if (server == null) return;

        String a = msg.a().trim();
        String b = msg.b().trim();
        String c = msg.c().trim();
        if (a.isEmpty() || a.length() > 120 || b.length() > (msg.kind().equals("bill") ? 4000 : 120) || c.length() > 120) return;

        RepublicData data = RepublicData.get(server);
        String author = sender.getGameProfile().getName();
        switch (msg.kind()) {
            case "bill" -> {
                Polity mine = selectedState(data, sender);
                if (!CitizensData.canPropose(mine, sender.getUUID(), sender.hasPermissions(2))) return;
                if (mine.senatorsOnly && RepublicData.senators(mine).isEmpty()) {
                    sender.displayClientMessage(Component.literal("Сначала назначьте сенаторов: роль с правом голосовать по законам."), true); return;
                }
                RepublicData.Bill bill = data.createBill(a, b.isBlank() ? a : b, author, mine.owner);
                bill.senatorsOnly = mine.senatorsOnly;
                if (bill.senatorsOnly) for (UUID id : RepublicData.senators(mine)) bill.electorate.put(id.toString(), 1);
                bill.proposedDay = CivitasConfig.today(server);
                broadcast(server, "Новый законопроект #" + bill.id + ": «" + a + "»");
                pushFeedAll(server);
                refreshState(server, mine.owner);
            }
            case "rename" -> {
                Polity own = selectedState(data, sender);
                boolean allowed = own != null && (controlsState(sender, own) || RepublicData.leaderOf(own).equals(sender.getUUID()) || sender.getUUID().equals(own.deputy));
                if (!allowed || b.isEmpty()) return;
                own.type = a;
                own.name = b;
                CitizensData.get(server).event(own.owner,"Новое название государства",b+" · "+a,System.currentTimeMillis());
                data.logFor(own.owner, "Страна переименована: «" + b + "» (" + a + ").");
                sendState(sender);
            }
            case "leave" -> {
                if (!a.equals("ВЫЙТИ")) return;
                Polity own = findPolity(data, sender.getUUID());
                if (own == null) return;
                if (RepublicData.leaderOf(own).equals(sender.getUUID())) {
                    if (own.deputy == null) return;
                    own.leader = own.deputy;
                    own.leaderName = own.deputyName;
                    own.deputy = null; own.deputyName = "";
                }
                dropFromFaction(own, sender.getUUID());
                own.memberRoles.remove(sender.getUUID());
                int writer = own.writers.indexOf(sender.getUUID());
                if(writer >= 0) { own.writers.remove(writer); own.writerNames.remove(writer); }
                own.votes.remove(sender.getUUID());
                int candidate = own.candidates.indexOf(sender.getUUID());
                if(candidate >= 0) { own.candidates.remove(candidate); own.candidateNames.remove(candidate); }
                if(sender.getUUID().equals(own.heir)) { own.heir=null; own.heirName=""; }
                int idx = own.members.indexOf(sender.getUUID());
                if (idx >= 0) {
                    own.members.remove(idx);
                    own.memberNames.remove(idx);
                }
                if (sender.getUUID().equals(own.deputy)) {
                    own.deputy = null;
                    own.deputyName = "";
                }
                CitizensData.get(server).event(own.owner,"Выход из государства",sender.getGameProfile().getName()+" покинул состав",System.currentTimeMillis());
                refreshState(server,own.owner);
                data.logFor(own.owner, sender.getGameProfile().getName() + " покинул государство «" + own.name + "».");
                sendState(sender);
            }
            case "abdicate" -> {
                Polity own = data.ledBy(sender.getUUID());
                if (own == null || !"Монархия".equals(own.government) || own.heir == null
                        || !a.equals("ОТРЕЧЬСЯ")) return;
                own.leader = own.heir;
                own.leaderName = own.heirName;
                own.heir = null;
                own.heirName = "";
                data.logFor(own.owner, sender.getGameProfile().getName() + " отрёкся от престола. Новый монарх: " + own.leaderName + ".");
                ServerPlayer successor = server.getPlayerList().getPlayer(own.leader);
                if (successor != null) sendState(successor);
            }
            case "delete" -> {
                if (!sender.hasPermissions(2)) return;
                Polity target = null;
                for (Polity p : data.polities()) {
                    if (p.name.equals(a)) {
                        target = p;
                        break;
                    }
                }
                if (target == null) return;
                data.deleteState(target);
                broadcast(server, "Государство «" + a + "» удалено");
                ServerPlayer ownerOnline = server.getPlayerList().getPlayer(target.owner);
                if (ownerOnline != null) sendState(ownerOnline);
            }
            case "role" -> {
                Polity mine = selectedState(data, sender);
                if (mine == null || (!controlsState(sender, mine) && !Perms.has(RepublicData.permsOf(mine, sender.getUUID()), Perms.ROLE_MANAGE)) || a.isEmpty()) return;
                mine.roles.add(new RepublicData.Role(UUID.randomUUID().toString(), a, 0L));
            }
            case "faction" -> {
                Polity mine = findPolity(data, sender.getUUID());
                if (mine == null || RepublicData.factionOf(mine, sender.getUUID()) != null) return;
                int colour = CabinetPresets.ROLE_COLORS.get(mine.factions.size() % CabinetPresets.ROLE_COLORS.size());
                try {
                    int chosen = Integer.parseInt(b);
                    if (CabinetPresets.ROLE_COLORS.contains(chosen)) colour = chosen;
                } catch (NumberFormatException ignored) {
                    // keep the default colour
                }
                RepublicData.Faction f = new RepublicData.Faction(UUID.randomUUID().toString().substring(0, 8), a, colour);
                f.leader = sender.getUUID();
                f.leaderName = sender.getGameProfile().getName();
                f.members.add(sender.getUUID());
                f.memberNames.add(sender.getGameProfile().getName());
                mine.factions.add(f);
            }
            case "factionRole" -> {
                Polity state = selectedState(data, sender);
                RepublicData.Faction f = state == null ? null : RepublicData.factionById(state, b);
                if (f == null || a.contains("|") || a.equals("-") || f.roles.size() >= 32
                        || !(sender.getUUID().equals(f.leader) || sender.getUUID().equals(RepublicData.leaderOf(state)) || controlsState(sender, state))) return;
                f.roles.putIfAbsent(a, 0L);
            }
            case "roleRename" -> {
                Polity mine = selectedState(data, sender);
                if (mine == null || b.isEmpty()) return;
                UUID me = sender.getUUID();
                boolean leader = me.equals(RepublicData.leaderOf(mine)) || controlsState(sender, mine);
                int idx = roleIndex(mine, b);
                if (idx < 0 || (!leader && !Perms.has(RepublicData.permsOf(mine, me), Perms.ROLE_MANAGE))) return;
                if (!leader && idx <= RepublicData.rankOf(mine, me)) return;
                mine.roles.get(idx).name = a;
            }
            case "state" -> {
                if (!sender.hasPermissions(2) || b.isEmpty() || c.isEmpty()) return;
                ServerPlayer owner = server.getPlayerList().getPlayerByName(c);
                if (owner == null) return;
                if(findPolity(data,owner.getUUID())!=null)return;
                data.createPolity(a, b, owner.getUUID(), owner.getGameProfile().getName());
                CitizensData.get(server).event(owner.getUUID(),"Основание государства",b+" · "+a,System.currentTimeMillis());
                broadcast(server, "Создано государство «" + b + "» (" + a + ")");
                sendState(owner);
            }
            default -> {
                return;
            }
        }
        data.setDirty();
        refresh(sender);
    }

    private static void broadcast(MinecraftServer server, String text) {
        Humanitas.LOGGER.info("[Civitas] {}", text);
    }

    /** Owner first, then deputy, then listed members. Returns null if the player has no role. */
    public static Polity findPolity(RepublicData data, UUID playerId) {
        for (Polity p : data.polities()) {
            if (playerId.equals(RepublicData.leaderOf(p))) return p;
        }
        for (Polity p : data.polities()) {
            if (playerId.equals(p.deputy)) return p;
        }
        for (Polity p : data.polities()) {
            if (p.members.contains(playerId)) return p;
        }
        return null;
    }

    static void refreshState(MinecraftServer server, UUID state) {
        for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            Polity viewed = selectedState(RepublicData.get(server), player);
            if (viewed != null && viewed.owner.equals(state)) refresh(player);
        }
    }

    private static String nz(String s) {
        return s == null ? "" : s;
    }
}
