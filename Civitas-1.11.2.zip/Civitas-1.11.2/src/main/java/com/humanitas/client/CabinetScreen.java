package com.humanitas.client;

import com.humanitas.CabinetNet;
import com.humanitas.CabinetPresets;
import com.humanitas.Perms;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.neoforged.neoforge.network.PacketDistributor;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static com.humanitas.client.CivitasUi.*;

/**
 * Civitas cabinet.
 * Left strip: navigation, always on screen. Right panel: the chosen section.
 * Every player can read the world news; members also see their state; admins also see every state.
 */
public class CabinetScreen extends Screen {
    private final ImageAttachment stateAvatar = new ImageAttachment(true);
    /** The newest open cabinet, so snapshots can refresh it even while a child screen is on top. */
    private static CabinetScreen latest;

    private static final int STRIP_X = 12;
    private static final int STRIP_W = 56;
    private static final int STRIP_TOP = 56;
    private static final int STRIP_ITEM_H = 34;
    private static final int STRIP_GAP = 38;

    private static final int PANEL_X = STRIP_X + STRIP_W + 8;
    private static final int PANEL_W = 320;
    private static final int PANEL_MAX_H = 270;
    private static final int HEADER_H = 40;
    private static final int CONTENT_Y = 46;
    private static final int FOOTER_H = 20;
    private static final int ROW_H = 40;
    private static final int CARD_H = 34;
    private static final int SCROLLBAR_W = 4;

    private static final int S_OVERVIEW = 0;
    private static final int S_MANAGE = 1;
    private static final int S_LAWS = 2;
    private static final int S_NEWS = 3;
    private static final int S_ARCHIVE = 4;
    private static final int S_STATES = 5;
    private static final String[] NAMES = {"ОБЗОР", "УПРАВЛЕНИЕ", "ЗАКОНЫ", "НОВОСТИ", "АРХИВ", "ГОСУДАРСТВА"};
    private static final String[] ICONS = {"⌂", "✎", "✒", "✉", "☰", "⚑"};

    private static final String[] FIELDS = {"deputy", "ideology", "parliament", "government", "member", "writer", "heir", "-", "assign", "kick", "role", "role", "role", "faction", "faction", "faction"};
    private static final String[] LABELS = {"ЗАМЕСТИТЕЛЬ", "ИДЕОЛОГИЯ", "ПАРЛАМЕНТ", "ФОРМА ПРАВЛЕНИЯ"};
    private static final String[] PICKER_TITLES = {
            "Выберите заместителя", "Выберите идеологию", "Выберите парламент",
            "Выберите форму правления", "Члены государства", "Писатели новостей", "Наследник престола",
            "Назначение ролей", "Роль участника", "Исключение", "Управление ролью", "Цвет роли", "Права роли", "Фракция", "Заявки в фракцию", "Голосование в парламент"};

    /** Form ids of action rows. 0 bill, 1 create state, 2 rename, 3 delete state, 4 leave, 5 news editor. */
    private static final String[] FORM_KINDS = {"bill", "state", "rename", "delete", "leave", "abdicate", "role", "faction"};
    private static final int ACTION_NEWS = 9;

    /** kind: 0 plain, 1 open bill (vote buttons), 3 action card, 4 close-vote, 5 news headline, 6 state card. */
    private record Row(String title, String value, int field, int kind, int id, String mine) {
        Row(String title, String value, int field) {
            this(title, value, field, 0, 0, "");
        }
    }

    private CompoundTag data;
    private final Screen parent;
    private final List<String[]> pickerRows = new ArrayList<>(); // [value, label]
    private int pickerIndex = -1;
    /** The member or role the current picker is about. */
    private String pickerTarget = "";
    private int detailIndex = -1;
    private boolean expanded = false;
    private int section = S_OVERVIEW;
    private double scroll = 0;

    /** Opens the classic menu on one section. Used by the wheel windows to jump into the full actions. */
    public static CabinetScreen at(CompoundTag data, Screen parent, int sectionIndex) {
        CabinetScreen screen = new CabinetScreen(data, parent);
        screen.section = sectionIndex;
        screen.expanded = true;
        return screen;
    }

    public CabinetScreen(CompoundTag data, Screen parent) {
        super(Component.literal("Civitas"));
        this.data = data;
        this.parent = parent;
        latest = this;
    }

    // ---------- messages from the server ----------

    /** A snapshot arrived. open = true opens the screen; false only refreshes an open one. */
    public static void onSnapshot(CompoundTag data, boolean open) {
        open = CabinetRequests.received(data, open);
        LawInfoScreen.receive(data);
        CabinetClientState.setState(data.getString("ideology"), data.getString("name"));
        CabinetClientState.canPostFaction = data.getBoolean("canPostFaction");
        CabinetClientState.canPostState = data.getBoolean("canPostState");
        if (data.contains("startDay")) {
            CabinetClientState.setCalendar(data.getLong("startDay"), data.getBoolean("advance"),
                    data.getLong("ticksPerDay"));
        }
        Minecraft mc = Minecraft.getInstance();
        if (mc.screen instanceof WheelScreen wheel) {
            wheel.updateSnapshot(data);
            return;
        }
        if (mc.screen instanceof CabinetScreen cs) {
            cs.data = data;
            if (cs.expanded) {
                cs.markSeenFor(cs.section);
            }
            if (cs.pickerIndex == 12) {
                cs.openPicker(12);
            } else {
                cs.pickerIndex = -1;
            }
            latest = cs;
            return;
        }
        if (open) {
            if (com.humanitas.CivitasClientConfig.wheelGui()) {
                mc.setScreen(new WheelScreen(data, mc.screen));
                return;
            }
            CabinetScreen created = new CabinetScreen(data, mc.screen);
            int unread = CivitasFeed.preferredSection();
            if (unread >= 0) {
                created.section = unread;
                created.expanded = true;
                created.markSeenFor(unread);
            }
            mc.setScreen(created);
            return;
        }
        if (latest != null) {
            latest.data = data;
        }
        if (WheelScreen.latest != null) {
            WheelScreen.latest.data = data;
        }
    }

    /** A full article arrived. Opens the reader on top of the cabinet. */
    public static void onNewsFull(CompoundTag tag) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.screen != null) {
            mc.setScreen(new NewsReaderScreen(mc.screen, NewsItem.fromTag(tag)));
        }
    }

    // ---------- sections ----------

    private List<Integer> sections() {
        List<Integer> list = new ArrayList<>();
        if (data.getBoolean("noAccess")) {
            list.add(S_NEWS);
            list.add(S_STATES);
            return list;
        }
        boolean noState = data.getBoolean("noState");
        list.add(S_OVERVIEW);
        if (!noState) {
            list.add(S_MANAGE);
            list.add(S_LAWS);
        }
        list.add(S_NEWS);
        if (!noState && data.getBoolean("canArchive")) {
            list.add(S_ARCHIVE);
        }
        list.add(S_STATES);
        return list;
    }

    private void normalizeSection() {
        List<Integer> list = sections();
        if (!list.contains(section)) {
            section = list.get(0);
        }
    }

    private int stripH() {
        return Math.min(height - 24, STRIP_TOP + sections().size() * STRIP_GAP + 6);
    }

    private int stripY() {
        return (height - stripH()) / 2;
    }

    private int itemY(int index) {
        return stripY() + STRIP_TOP + index * STRIP_GAP;
    }

    private int panelH() {
        return Math.min(height - 24, PANEL_MAX_H);
    }

    private int panelY() {
        return (height - panelH()) / 2;
    }

    private boolean overlayOpen() {
        return pickerIndex >= 0 || detailIndex >= 0;
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    /** Nothing here: the backdrop is painted in render so it isn't blurred twice. */
    @Override
    public void renderBackground(GuiGraphics g, int mx, int my, float partialTick) {
    }

    // ---------- drawing ----------

    @Override
    public void render(GuiGraphics g, int mx, int my, float partialTick) {
        normalizeSection();
        // Next to the inventory the strip sits over it; with the panel open, the inventory is not drawn.
        if (!expanded && parent != null) {
            parent.render(g, -1, -1, partialTick);
        }
        if (expanded) {
            g.fill(0, 0, width, height, BACKDROP);
        }
        renderStrip(g, mx, my);
        if (expanded) {
            renderPanel(g, mx, my);
        }
        if (pickerIndex >= 0) {
            drawPicker(g, mx, my);
        }
        if (detailIndex >= 0) {
            drawDetail(g);
        }
    }

    private void renderStrip(GuiGraphics g, int mx, int my) {
        List<Integer> list = sections();
        boolean free = !overlayOpen();
        int x = STRIP_X;
        int y = stripY();
        panel(g, x, y, STRIP_W, stripH());

        boolean plaqueHot = free && inside(mx, my, x + 4, y + 4, STRIP_W - 8, 36);
        if (free) {
            CivitasSounds.register(x + 4, y + 4, STRIP_W - 8, 36, CivitasUi.Style.PRIMARY);
        }
        g.fill(x + 4, y + 4, x + STRIP_W - 4, y + 40, plaqueHot ? OLIVE : HEADER);
        g.fill(x + 5, y + 4, x + STRIP_W - 5, y + 5, CivitasColors.alpha(TEXT_LIGHT, 0x22));
        g.fill(x + 8, y + 40, x + STRIP_W - 8, y + 41, CivitasColors.alpha(GOLD_DEEP, 0x60));
        drawIcon(g, CabinetPresets.icon(data.getString("ideology")), x + STRIP_W / 2f, y + 14, 2.0f, GOLD);
        g.fill(x + 8, y + 48, x + STRIP_W - 8, y + 49, GOLD);

        for (int i = 0; i < list.size(); i++) {
            int iy = itemY(i);
            int sec = list.get(i);
            boolean active = expanded && sec == section;
            boolean hot = free && inside(mx, my, x + 4, iy, STRIP_W - 8, STRIP_ITEM_H);
            if (free) {
                CivitasSounds.register(x + 4, iy, STRIP_W - 8, STRIP_ITEM_H, CivitasUi.Style.SECONDARY);
            }
            CivitasSurfaces.surface(g,x+4,iy,STRIP_W-8,STRIP_ITEM_H,active,hot);
            drawIcon(g, ICONS[sec], x + STRIP_W / 2f, iy + 10, 1.6f, active ? GOLD : TEXT_LIGHT);
            // Section short label under the icon.
            String shortName = NAMES[sec].length() > 6 ? NAMES[sec].substring(0, 5) : NAMES[sec];
            g.drawString(font, font.plainSubstrByWidth(shortName, STRIP_W - 10),
                    x + (STRIP_W - font.width(shortName)) / 2, iy + 22, active ? GOLD : DIM, false);
        }
    }

    private void renderPanel(GuiGraphics g, int mx, int my) {
        int x = PANEL_X;
        int y = panelY();
        panel(g, x, y, PANEL_W, panelH());
        g.fill(x + 2, y + 2, x + PANEL_W - 2, y + HEADER_H, HEADER);
        g.fill(x + 2, y + 2, x + PANEL_W - 2, y + 3, CivitasColors.alpha(TEXT_LIGHT, 0x1A));
        g.fill(x + 2, y + HEADER_H - 1, x + PANEL_W - 2, y + HEADER_H, GOLD_DEEP);
        g.fill(x + 2, y + HEADER_H, x + PANEL_W - 2, y + HEADER_H + 1, CivitasColors.alpha(GOLD, 0x40));

        drawIcon(g, ICONS[section], x + 20, y + 14, 1.6f, GOLD);
        g.drawString(font, Component.literal(NAMES[section]).withStyle(ChatFormatting.BOLD),
                x + 36, y + 9, TEXT_LIGHT, false);
        String subtitle = data.getBoolean("noAccess") ? "для всех игроков"
                : data.getBoolean("noState") ? "нет страны" : data.getString("name");
        g.drawString(font, font.plainSubstrByWidth(subtitle, PANEL_W - 70), x + 36, y + 24, GOLD, false);

        boolean closeHot = !overlayOpen() && inside(mx, my, closeX(), closeY(), 14, 14);
        if (!overlayOpen()) {
            CivitasSounds.register(closeX(), closeY(), 14, 14, CivitasUi.Style.SECONDARY);
        }
        g.drawString(font, "×", closeX() + 3, closeY() + 3, closeHot ? GOLD : TEXT_LIGHT, false);

        List<Row> rows = buildRows();
        int cx = contentX();
        int cy = contentY();
        int cw = contentW();
        int ch = viewH();
        double maxScroll = Math.max(0, rows.size() * ROW_H - ch);
        scroll = clamp(scroll, 0, maxScroll);

        g.enableScissor(cx, cy, cx + cw, cy + ch);
        for (int i = 0; i < rows.size(); i++) {
            int ry = cy + i * ROW_H - (int) scroll;
            if (ry + ROW_H < cy || ry > cy + ch) continue;
            drawCard(g, rows.get(i), cx, ry, cw, mx, my);
        }
        g.disableScissor();

        drawScrollbar(g, cx + cw + 4, cy, ch, rows.size() * ROW_H, scroll, maxScroll);

        if (section == S_MANAGE) {
            String note = data.getBoolean("canEdit")
                    ? "Нажмите карточку, чтобы изменить"
                    : "Только просмотр: редактирует владелец";
            g.drawString(font, note, x + 12, y + panelH() - 14, DIM, false);
        }
    }

    private void drawCard(GuiGraphics g, Row row, int x, int y, int w, int mx, int my) {
        boolean free = !overlayOpen();
        boolean cardHot = free && inside(mx, my, x, y, w, CARD_H);
        if (free && cardActionable(row)) {
            boolean dangerAction = row.kind() == 3 && (row.id() == 3 || row.id() == 4);
            CivitasSounds.register(x, y, w, CARD_H,
                    dangerAction ? CivitasUi.Style.DANGER : CivitasUi.Style.SECONDARY);
        }

        if (row.kind() == 3) {
            boolean danger = row.id() == 3 || row.id() == 4;
            CivitasSurfaces.surface(g,x,y,w,CARD_H,false,cardHot);
            if(danger)g.fill(x+1,y+6,x+3,y+CARD_H-6,mix(GOLD,HEART,0.42F));
            g.drawString(font, row.value(), x + 10, y + 13, danger ? GOLD : TEXT_LIGHT, false);
            g.drawString(font, "›", x + w - 12, y + 13, cardHot ? GOLD : OLIVE, false);
            return;
        }

        boolean editable = row.field() >= 0 && data.getBoolean("canEdit");
        boolean clickable = editable || row.kind() == 5 || row.kind() == 6 || row.kind() == 14;
        boolean hot = clickable && cardHot;
        CivitasSurfaces.surface(g,x,y,w,CARD_H,false,hot);
        if (row.kind() == 10 || row.kind() == 11) {
            // Role and faction cards carry their colour as a wide strip on the left.
            g.fill(x+1, y+5, x + 4, y + CARD_H-5, row.id() != 0 ? row.id() : GOLD);
        }
        if (hot) {
            g.fill(x + 3, y, x + w, y + 1, CivitasColors.alpha(GOLD, 0x30));
        }

        if (row.kind() == 4) {
            g.drawString(font, font.plainSubstrByWidth(row.value(), w - 90), x + 10, y + 13, TEXT_LIGHT, false);
            button(g, font, x + w - 70, y + 11, 60, 12, "ЗАКРЫТЬ",
                    free && inside(mx, my, x + w - 70, y + 11, 60, 12), Style.SECONDARY);
            return;
        }

        if (row.title().isEmpty()) {
            g.drawString(font, font.plainSubstrByWidth(row.value(), w - 24), x + 10, y + 13, TEXT_LIGHT, false);
        } else {
            g.drawString(font, font.plainSubstrByWidth(row.title(), w - 24), x + 10, y + 7, OLIVE, false);
            g.drawString(font, font.plainSubstrByWidth(row.value(), w - 30), x + 10, y + 19, TEXT_LIGHT, false);
        }
        if (row.kind() == 1) {
            boolean open = row.mine().isEmpty();
            button(g, font, x + w - 100, y + 4, 44, 12, "ЗА",
                    free && open && inside(mx, my, x + w - 100, y + 4, 44, 12),
                    row.mine().equals("yes") ? Style.CHOSEN : open ? Style.PRIMARY : Style.DISABLED);
            button(g, font, x + w - 52, y + 4, 44, 12, "ПРОТИВ",
                    free && open && inside(mx, my, x + w - 52, y + 4, 44, 12),
                    row.mine().equals("no") ? Style.CHOSEN : open ? Style.PRIMARY : Style.DISABLED);
        }
        if (clickable) {
            g.drawString(font, "›", x + w - 12, y + 13, hot ? GOLD : OLIVE, false);
        }
    }

    /** Whether a click anywhere on the card performs an action, not only on its small buttons. */
    private boolean cardActionable(Row row) {
        if (row.kind() == 3 || row.kind() == 5 || row.kind() == 6 || row.kind() == 14
                || row.kind() == 7 || row.kind() == 8 || row.kind() == 10
                || row.kind() == 11 || row.kind() == 12) {
            return true;
        }
        return row.field() >= 0 && (row.field() == 7
                ? (data.getLong("myPerms") & (Perms.ROLE_ASSIGN | Perms.MEMBER_KICK)) != 0
                : data.getBoolean("canEdit"));
    }

    private void drawScrollbar(GuiGraphics g, int x, int y, int trackH, int contentH, double pos, double maxScroll) {
        g.fill(x, y, x + SCROLLBAR_W, y + trackH, CREAM_DEEP);
        if (maxScroll <= 0) return;
        int thumbH = Math.max(18, (int) ((double) trackH * trackH / contentH));
        int thumbY = y + (int) ((trackH - thumbH) * (pos / maxScroll));
        g.fill(x, thumbY, x + SCROLLBAR_W, thumbY + thumbH, OLIVE);
    }

    // ---------- overlays ----------

    private void drawPicker(GuiGraphics g, int mx, int my) {
        g.fill(0, 0, width, height, SCRIM);
        int x = pickerX();
        int y = pickerY();
        int h = pickerH();
        panel(g, x, y, 230, h);
        g.fill(x + 2, y + 2, x + 228, y + 26, HEADER);
        g.fill(x + 2, y + 2, x + 228, y + 3, CivitasColors.alpha(TEXT_LIGHT, 0x1A));
        g.fill(x + 2, y + 26, x + 228, y + 27, GOLD_DEEP);
        g.drawString(font, PICKER_TITLES[pickerIndex], x + 10, y + 9, TEXT_LIGHT, false);

        int visible = Math.min(pickerRows.size(), 12);
        for (int r = 0; r < visible; r++) {
            int ry = y + 26 + r * 18;
            CivitasSounds.register(x + 2, ry - 1, 226, 18, CivitasUi.Style.CHOSEN);
            boolean hover = inside(mx, my, x + 2, ry - 1, 226, 18);
            CivitasSurfaces.surface(g,x+6,ry,218,16,pickerRows.get(r)[1].startsWith("✓"),hover);
            g.drawString(font, font.plainSubstrByWidth(pickerRows.get(r)[1], 200), x + 12, ry + 4, TEXT_LIGHT, false);
        }
    }

    /** Read-only card with everything about one state. Admin only. */
    private void drawDetail(GuiGraphics g) {
        ListTag states = data.getList("states", Tag.TAG_COMPOUND);
        if (detailIndex < 0 || detailIndex >= states.size()) {
            detailIndex = -1;
            return;
        }
        CompoundTag s = states.getCompound(detailIndex);
        String[][] lines = {
                {"НАЗВАНИЕ", s.getString("name")},
                {"ТИП", s.getString("type")},
                {"ВЛАДЕЛЕЦ", s.getString("ownerName")},
                {"ЗАМЕСТИТЕЛЬ", s.getString("deputyName").isEmpty() ? "не назначен" : s.getString("deputyName")},
                {"ИДЕОЛОГИЯ", CabinetPresets.icon(s.getString("ideology")) + "  " + s.getString("ideology")},
                {"ПАРЛАМЕНТ", s.getString("parliament")},
                {"ФОРМА ПРАВЛЕНИЯ", s.getString("government")},
                {"ЧЛЕНЫ", s.getString("members")},
                {"ЗАКОНОПРОЕКТОВ", String.valueOf(s.getInt("bills"))}
        };
        g.fill(0, 0, width, height, SCRIM);
        int w = 280;
        int h = 34 + lines.length * 18 + 30;
        int x = (width - w) / 2;
        int y = (height - h) / 2;
        panel(g, x, y, w, h);
        g.fill(x + 2, y + 2, x + w - 2, y + 26, HEADER);
        g.fill(x + 2, y + 2, x + w - 2, y + 3, CivitasColors.alpha(TEXT_LIGHT, 0x1A));
        g.fill(x + 2, y + 26, x + w - 2, y + 27, GOLD_DEEP);
        g.drawString(font, "ГОСУДАРСТВО", x + 12, y + 9, TEXT_LIGHT, false);
        for (int i = 0; i < lines.length; i++) {
            int ly = y + 34 + i * 18;
            g.drawString(font, lines[i][0], x + 12, ly, OLIVE, false);
            g.drawString(font, font.plainSubstrByWidth(lines[i][1], w - 130), x + 118, ly, TEXT_LIGHT, false);
        }
        g.drawString(font, "Нажмите, чтобы закрыть", x + 12, y + h - 14, DIM, false);
    }

    // ---------- input ----------

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (button != 0) return false;
        normalizeSection();

        if (detailIndex >= 0) {
            detailIndex = -1;
            return true;
        }
        if (pickerIndex >= 0) {
            clickPicker(mx, my);
            return true;
        }

        if (inside(mx, my, STRIP_X, stripY(), STRIP_W, stripH())) {
            return clickStrip(mx, my);
        }
        if (expanded) {
            if (inside(mx, my, PANEL_X, panelY(), PANEL_W, panelH())) {
                return clickPanel(mx, my) || super.mouseClicked(mx, my, button);
            }
            expanded = false; // click on empty space closes the panel, the strip stays
            return true;
        }
        return super.mouseClicked(mx, my, button);
    }

    private void clickPicker(double mx, double my) {
        int visible = Math.min(pickerRows.size(), 12);
        int x = pickerX();
        int y = pickerY();
        for (int r = 0; r < visible; r++) {
            int ry = y + 26 + r * 18;
            if (inside(mx, my, x + 2, ry - 1, 226, 18)) {
                String chosen = pickerRows.get(r)[0];
                if (pickerIndex == 7) {
                    pickerTarget = chosen;
                    openPicker(8);
                    return;
                }
                if (pickerIndex == 8 && chosen.equals("__kick__")) {
                    openPicker(9);
                    return;
                }
                if (chosen.equals("__rename__")) {
                    pickerIndex = -1;
                    Minecraft.getInstance().setScreen(new FormScreen(this, "roleRename").withExtra(pickerTarget));
                    return;
                }
                if (chosen.equals("__color__")) {
                    openPicker(11);
                    return;
                }
                if (chosen.equals("__perms__")) {
                    openPicker(12);
                    return;
                }
                if (chosen.equals("__requests__")) {
                    openPicker(14);
                    return;
                }
                String sent = pickerIndex == 8 ? pickerTarget + "|" + chosen : chosen;
                PacketDistributor.sendToServer(
                        new CabinetNet.EditCabinet(FIELDS[pickerIndex], sent));
                if (pickerIndex != 12) pickerIndex = -1;
                return;
            }
        }
        if (!inside(mx, my, x, y, 230, pickerH())) {
            pickerIndex = -1; // click outside closes the picker
        }
    }

    private boolean clickStrip(double mx, double my) {
        List<Integer> list = sections();
        if (inside(mx, my, STRIP_X + 4, stripY() + 4, STRIP_W - 8, 36)) {
            return openSection(list.get(0));
        }
        for (int i = 0; i < list.size(); i++) {
            if (inside(mx, my, STRIP_X + 4, itemY(i), STRIP_W - 8, STRIP_ITEM_H)) {
                return openSection(list.get(i));
            }
        }
        return true;
    }

    /** Marks the news or the laws as seen while their section is on screen. */
    private void markSeenFor(int sec) {
        if (sec == S_NEWS) {
            CivitasFeed.markNewsSeen();
        } else if (sec == S_LAWS) {
            CivitasFeed.markLawsSeen();
        }
    }

    /** Opens a section in the panel; clicking the section that is already open closes the panel. */
    private boolean openSection(int sec) {
        if (expanded && section == sec) {
            expanded = false;
        } else {
            section = sec;
            markSeenFor(sec);
            scroll = 0;
            expanded = true;
        }
        return true;
    }

    private boolean clickPanel(double mx, double my) {
        if (inside(mx, my, closeX(), closeY(), 14, 14)) {
            expanded = false;
            return true;
        }
        return clickRows(mx, my);
    }

    private boolean clickRows(double mx, double my) {
        int cx = contentX();
        int cy = contentY();
        int cw = contentW();
        int ch = viewH();
        if (!inside(mx, my, cx, cy, cw, ch)) return false;

        List<Row> rows = buildRows();
        for (int i = 0; i < rows.size(); i++) {
            Row row = rows.get(i);
            int ry = cy + i * ROW_H - (int) scroll;
            if (ry + CARD_H <= cy || ry >= cy + ch) continue;

            if (row.kind() == 1 && row.mine().isEmpty()) {
                if (inside(mx, my, cx + cw - 100, ry + 4, 44, 12)) {
                    PacketDistributor.sendToServer(new CabinetNet.VoteBill(row.id(), true));
                    return true;
                }
                if (inside(mx, my, cx + cw - 52, ry + 4, 44, 12)) {
                    PacketDistributor.sendToServer(new CabinetNet.VoteBill(row.id(), false));
                    return true;
                }
            } else if (row.kind() == 4) {
                if (inside(mx, my, cx + cw - 70, ry + 11, 60, 12)) {
                    PacketDistributor.sendToServer(new CabinetNet.CloseBill(row.id()));
                    return true;
                }
            } else if (inside(mx, my, cx, ry, cw, CARD_H)) {
                if (row.kind() == 3) {
                    if (row.id() == ACTION_NEWS) {
                        Minecraft.getInstance().setScreen(new NewsEditorScreen(this));
                    } else if (row.id() == 11 || row.id() == 12) {
                        Minecraft.getInstance().setScreen(new DiplomacyScreen(this,row.id() == 12));
                    } else if (row.id() == 13) {
                        Minecraft.getInstance().setScreen(new StatesScreen(this));
                    } else if (row.id() == 10) {
                        stateAvatar.choose();
                    } else {
                        Minecraft.getInstance().setScreen(new FormScreen(this, FORM_KINDS[row.id()]));
                    }
                    return true;
                }
                if (row.kind() == 14) {
                    var bills=data.getList("bills",Tag.TAG_COMPOUND);
                    for(int j=0;j<bills.size();j++)if(bills.getCompound(j).getInt("id")==row.id())minecraft.setScreen(new LawInfoScreen(this,bills.getCompound(j)));
                    return true;
                }
                if (row.kind() == 7) {
                    PacketDistributor.sendToServer(new CabinetNet.EditCabinet("vote", row.mine()));
                    return true;
                }
                if (row.kind() == 8) {
                    PacketDistributor.sendToServer(new CabinetNet.EditCabinet("candidacy", "toggle"));
                    return true;
                }
                if (row.kind() == 11) {
                    pickerTarget = row.mine();
                    openPicker(13);
                    return true;
                }
                if (row.kind() == 12) {
                    openPicker(15);
                    return true;
                }
                if (row.kind() == 10) {
                    pickerTarget = row.mine();
                    openPicker(10);
                    return true;
                }
                if (row.kind() == 5) {
                    PacketDistributor.sendToServer(new CabinetNet.RequestNews(row.id()));
                    return true;
                }
                if (row.kind() == 6) {
                    detailIndex = row.id();
                    return true;
                }
                if (row.field() >= 0 && (row.field() == 7
                        ? (data.getLong("myPerms") & (Perms.ROLE_ASSIGN | Perms.MEMBER_KICK)) != 0
                        : data.getBoolean("canEdit"))) {
                    openPicker(row.field());
                    return true;
                }
            }
        }
        return false;
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double scrollX, double scrollY) {
        if (expanded && !overlayOpen() && inside(mx, my, contentX(), contentY(), contentW(), viewH())) {
            scroll -= scrollY * ROW_H;
            return true;
        }
        return super.mouseScrolled(mx, my, scrollX, scrollY);
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (key != GLFW.GLFW_KEY_UNKNOWN && CabinetKeys.OPEN.matches(key, scan)) {
            // The same key that opened the cabinet closes it: close the open overlay first, then the cabinet.
            if (detailIndex >= 0) {
                detailIndex = -1;
            } else if (pickerIndex >= 0) {
                pickerIndex = -1;
            } else {
                onClose();
            }
            return true;
        }
        if (key == GLFW.GLFW_KEY_ESCAPE) {
            if (detailIndex >= 0) {
                detailIndex = -1;
                return true;
            }
            if (pickerIndex >= 0) {
                pickerIndex = -1;
                return true;
            }
            if (expanded) {
                expanded = false;
                return true;
            }
        }
        return super.keyPressed(key, scan, mods);
    }

    @Override
    public void onClose() {
        latest = null;
        Minecraft.getInstance().setScreen(parent);
    }

    // ---------- data ----------

    private List<Row> buildRows() {
        List<Row> rows = new ArrayList<>();
        boolean noState = data.getBoolean("noState");
        boolean op = data.getBoolean("op");
        switch (section) {
            case S_OVERVIEW -> {
                rows.add(action("ДИПЛОМАТИЯ · ДОГОВОРЫ И ПРЕДЛОЖЕНИЯ",11));
                if(op)rows.add(action("ВОЙНЫ · КУРАТОРСТВО",12));
                if (noState) {
                    rows.add(new Row("СТРАНА", "У вас пока нет страны", -1));
                } else {
                    rows.add(new Row("НАЗВАНИЕ", data.getString("name"), -1));
                    rows.add(new Row("ТИП", data.getString("type"), -1));
                    rows.add(new Row("ВЛАДЕЛЕЦ", data.getString("ownerName"), -1));
                    rows.add(new Row("ЗАМЕСТИТЕЛЬ", value(0), -1));
                    rows.add(new Row("ЧЛЕНЫ", membersText(), -1));
                    rows.add(new Row("ИДЕОЛОГИЯ", CabinetPresets.icon(data.getString("ideology")) + "  " + value(1), -1));
                    rows.add(new Row("ПАРЛАМЕНТ", value(2), -1));
                    rows.add(new Row("ФОРМА ПРАВЛЕНИЯ", value(3), -1));
                    rows.add(new Row("ЗАКОНОПРОЕКТОВ", String.valueOf(data.getList("bills", Tag.TAG_COMPOUND).size()), -1));
                    if (!data.getBoolean("canEdit")) {
                        rows.add(action("ВЫЙТИ ИЗ ГОСУДАРСТВА", 4));
                    }
                    if (data.getBoolean("canRename")) {
                        rows.add(action("ИЗМЕНИТЬ НАЗВАНИЕ И ТИП", 2));
                        rows.add(action("ФЛАГ ГОСУДАРСТВА · PNG/JPG", 10));
                    }
                }
                if (op) {
                    rows.add(action(noState ? "СОЗДАТЬ СТРАНУ" : "СОЗДАТЬ ДРУГУЮ СТРАНУ", 1));
                    rows.add(action("УДАЛИТЬ ГОСУДАРСТВО", 3));
                }
            }
            case S_MANAGE -> {
                for (int i = 0; i < 4; i++) {
                    rows.add(new Row(LABELS[i], value(i), i));
                }
                rows.add(new Row("ЧЛЕНЫ ГОСУДАРСТВА", membersText(), 4));
                rows.add(new Row("ЛИДЕР", leaderText(), -1));
                rows.add(new Row("ПИСАТЕЛИ НОВОСТЕЙ", writersText(), 5));
                rows.add(new Row("РОЛИ УЧАСТНИКОВ", "назначить и исключить", 7));
                ListTag roleList = data.getList("roles", Tag.TAG_COMPOUND);
                for (int k = 0; k < roleList.size(); k++) {
                    CompoundTag rt = roleList.getCompound(k);
                    rows.add(new Row(rt.getString("name"), "участников: " + rt.getInt("count"), -1, 10, rt.getInt("color"), rt.getString("id")));
                }
                if ((data.getLong("myPerms") & Perms.ROLE_MANAGE) != 0) {
                    rows.add(action("СОЗДАТЬ РОЛЬ", 6));
                }
                rows.add(new Row("ФРАКЦИИ", "создать, вступить, голосовать", -1));
                rows.add(action("СОЗДАТЬ ФРАКЦИЮ", 7));
                ListTag facs = data.getList("factions", Tag.TAG_COMPOUND);
                for (int k = 0; k < facs.size(); k++) {
                    CompoundTag fc = facs.getCompound(k);
                    String status = fc.getBoolean("mine") ? " · вы в ней" : fc.getBoolean("requested") ? " · заявка" : "";
                    rows.add(new Row(fc.getString("name"),
                            "членов: " + fc.getInt("members") + " · мест: " + fc.getInt("seats") + status,
                            -1, 11, fc.getInt("color"), fc.getString("id")));
                }
                if (data.getLong("electionEnd") != Long.MIN_VALUE && data.getInt("parliamentSeats") > 0
                        && !data.getBoolean("myVoteSet")) {
                    rows.add(new Row("", "ГОЛОСОВАТЬ ЗА ФРАКЦИЮ", -1, 12, 0, ""));
                }
                String gov = data.getString("government");
                if ("Монархия".equals(gov)) {
                    rows.add(new Row("НАСЛЕДНИК", heirText(), 6));
                    if (data.getBoolean("canEdit") && !data.getString("heirName").isEmpty()) {
                        rows.add(action("ОТРЕЧЬСЯ ОТ ПРЕСТОЛА", 5));
                    }
                }
                long electionEnd = data.getLong("electionEnd");
                if (electionEnd != Long.MIN_VALUE) {
                    rows.add(new Row("ВЫБОРЫ ДО", dateOf(electionEnd), -1));
                    ListTag cands = data.getList("candidates", Tag.TAG_COMPOUND);
                    for (int k = 0; k < cands.size(); k++) {
                        CompoundTag c = cands.getCompound(k);
                        String uuid = c.getString("uuid");
                        String mark = uuid.equals(data.getString("myVote")) ? " · ваш голос" : "";
                        rows.add(new Row(c.getString("name"), "голосов: " + c.getInt("votes") + mark, -1, 7, 0, uuid));
                    }
                    if (data.getBoolean("isMember")) {
                        rows.add(new Row("", data.getBoolean("isCandidate") ? "СНЯТЬ КАНДИДАТУРУ" : "БАЛЛОТИРОВАТЬСЯ", -1, 8, 0, ""));
                    }
                } else if (CabinetPresets.hasElections(gov)) {
                    rows.add(new Row("СЛЕДУЮЩИЕ ВЫБОРЫ", dateOf(data.getLong("termEnd")), -1));
                } else {
                    rows.add(new Row("СРОК ВЛАСТИ", "бессрочно", -1));
                }
            }
            case S_LAWS -> {
                if(data.getBoolean("canPropose"))rows.add(action("ПРЕДЛОЖИТЬ ЗАКОН", 0));
                var bills=LawOrder.sorted(data.getList("bills",Tag.TAG_COMPOUND));
                if(bills.isEmpty())rows.add(new Row("","Законопроектов пока нет",-1));
                for(var b:bills)rows.add(new Row("#"+b.getInt("number")+" · "+(LawOrder.waiting(b)?"ВАШ ГОЛОС":b.getBoolean("closed")?"ЗАВЕРШЕНО":"ГОЛОСОВАНИЕ"),b.getString("title"),-1,14,b.getInt("id"),b.getString("mine")));
            }

            case S_NEWS -> {
                if (data.getBoolean("canPost")) {
                    rows.add(action("НАПИСАТЬ НОВОСТЬ", ACTION_NEWS));
                }
                ListTag news = data.getList("news", Tag.TAG_COMPOUND);
                if (news.isEmpty()) rows.add(new Row("", "Новостей пока нет", -1));
                for (int i = 0; i < news.size(); i++) {
                    CompoundTag n = news.getCompound(i);
                    NewsItem item = NewsItem.fromTag(n);
                    String who = item.stateName().isEmpty() ? "Администрация" : item.stateName();
                    rows.add(new Row(who + " · " + item.whenShort() + (n.getBoolean("image") ? " · ФОТО" : ""),
                            item.title(), -1, 5, item.id(), ""));
                }
            }
            case S_ARCHIVE -> {
                ListTag archive = data.getList("archive", Tag.TAG_STRING);
                if (archive.isEmpty()) rows.add(new Row("", "Архив пока пуст", -1));
                for (int i = 0; i < archive.size(); i++) {
                    rows.add(new Row("", archive.getString(i), -1));
                }
            }
            default -> {
                rows.add(action("КАТАЛОГ ГОСУДАРСТВ И ПРИГЛАШЕНИЯ", 13));
                if(!op) break;
                rows.add(action("СОЗДАТЬ СТРАНУ", 1));
                rows.add(action("УДАЛИТЬ ГОСУДАРСТВО", 3));
                ListTag states = data.getList("states", Tag.TAG_COMPOUND);
                if (states.isEmpty()) rows.add(new Row("", "Государств пока нет", -1));
                for (int i = 0; i < states.size(); i++) {
                    CompoundTag s = states.getCompound(i);
                    rows.add(new Row(s.getString("name") + " · " + s.getString("type"),
                            s.getString("ownerName") + " · " + CabinetPresets.icon(s.getString("ideology"))
                                    + " " + s.getString("ideology"), -1, 6, i, ""));
                }
            }
        }
        return rows;
    }

    private static Row action(String text, int formIndex) {
        return new Row("", text, -1, 3, formIndex, "");
    }

    private String leaderText() {
        String name = data.getString("leaderName");
        return name.isEmpty() ? data.getString("ownerName") : name;
    }

    private String heirText() {
        String name = data.getString("heirName");
        return name.isEmpty() ? "не назначен" : name;
    }

    private String writersText() {
        ListTag writers = data.getList("writers", Tag.TAG_COMPOUND);
        if (writers.isEmpty()) return "никто";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < writers.size(); i++) {
            if (i > 0) sb.append(", ");
            sb.append(writers.getCompound(i).getString("name"));
        }
        return sb.toString();
    }

    private static String dateOf(long epochDay) {
        if (epochDay == Long.MIN_VALUE) return "—";
        return java.time.LocalDate.ofEpochDay(epochDay)
                .format(java.time.format.DateTimeFormatter.ofPattern("dd.MM.yyyy"));
    }

    private String roleNameOf(String uuid) {
        ListTag entries = data.getList("memberRoles", Tag.TAG_COMPOUND);
        for (int k = 0; k < entries.size(); k++) {
            CompoundTag e = entries.getCompound(k);
            if (e.getString("uuid").equals(uuid)) {
                String role = e.getString("role");
                return role.isEmpty() ? "без роли" : role;
            }
        }
        return "без роли";
    }

    private String membersText() {
        ListTag members = data.getList("members", Tag.TAG_COMPOUND);
        if (members.isEmpty()) return "нет";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < members.size(); i++) {
            if (i > 0) sb.append(", ");
            sb.append(members.getCompound(i).getString("name"));
        }
        return sb.toString();
    }

    private void openPicker(int i) {
        pickerRows.clear();
        if (i == 0) {
            pickerRows.add(new String[]{"", "— без заместителя —"});
            ListTag players = data.getList("players", Tag.TAG_COMPOUND);
            for (int k = 0; k < players.size(); k++) {
                CompoundTag e = players.getCompound(k);
                pickerRows.add(new String[]{e.getString("uuid"), e.getString("name")});
            }
        } else if (i == 1) {
            for (String o : CabinetPresets.IDEOLOGIES) {
                pickerRows.add(new String[]{o, CabinetPresets.icon(o) + "  " + o});
            }
        } else if (i == 7) {
            ListTag members = data.getList("members", Tag.TAG_COMPOUND);
            for (int k = 0; k < members.size(); k++) {
                CompoundTag e = members.getCompound(k);
                String uuid = e.getString("uuid");
                pickerRows.add(new String[]{uuid, e.getString("name") + "  ·  " + roleNameOf(uuid)});
            }
        } else if (i == 8) {
            pickerRows.add(new String[]{"", "— без роли —"});
            ListTag roles = data.getList("roles", Tag.TAG_COMPOUND);
            for (int k = 0; k < roles.size(); k++) {
                CompoundTag rt = roles.getCompound(k);
                pickerRows.add(new String[]{rt.getString("id"), rt.getString("name")});
            }
            pickerRows.add(new String[]{"__kick__", "× Исключить из государства"});
        } else if (i == 9) {
            pickerRows.add(new String[]{pickerTarget, "Да, исключить из государства"});
        } else if (i == 10) {
            pickerRows.add(new String[]{"up|" + pickerTarget, "Поднять выше"});
            pickerRows.add(new String[]{"down|" + pickerTarget, "Опустить ниже"});
            pickerRows.add(new String[]{"delete|" + pickerTarget, "Удалить роль"});
            pickerRows.add(new String[]{"__rename__", "Переименовать"});
            pickerRows.add(new String[]{"__color__", "Цвет"});
            pickerRows.add(new String[]{"__perms__", "Права"});
        } else if (i == 11) {
            for (int k = 0; k < CabinetPresets.ROLE_COLORS.size(); k++) {
                pickerRows.add(new String[]{"color|" + pickerTarget + "|" + CabinetPresets.ROLE_COLORS.get(k),
                        CabinetPresets.ROLE_COLOR_NAMES[k]});
            }
        } else if (i == 12) {
            ListTag roles = data.getList("roles", Tag.TAG_COMPOUND);
            long perms = 0L;
            for (int k = 0; k < roles.size(); k++) {
                if (roles.getCompound(k).getString("id").equals(pickerTarget)) {
                    perms = roles.getCompound(k).getLong("perms");
                }
            }
            for (int bit = 0; bit < Perms.NAMES.length; bit++) {
                boolean on = (perms & (1L << bit)) != 0;
                pickerRows.add(new String[]{"perm|" + pickerTarget + "|" + bit,
                        (on ? "✔ " : "✖ ") + Perms.NAMES[bit]});
            }
        } else if (i == 13 || i == 14) {
            ListTag facs = data.getList("factions", Tag.TAG_COMPOUND);
            boolean inAny = false;
            for (int k = 0; k < facs.size(); k++) {
                if (facs.getCompound(k).getBoolean("mine")) inAny = true;
            }
            for (int k = 0; k < facs.size(); k++) {
                CompoundTag fc = facs.getCompound(k);
                if (!fc.getString("id").equals(pickerTarget)) continue;
                if (i == 13) {
                    if (!inAny && !fc.getBoolean("requested")) {
                        pickerRows.add(new String[]{"join|" + pickerTarget, "Подать заявку"});
                    }
                    if (fc.getBoolean("mine")) {
                        pickerRows.add(new String[]{"leave", "Выйти из фракции"});
                    }
                    if (fc.getBoolean("manage")) {
                        pickerRows.add(new String[]{"__requests__", "Заявки в фракцию"});
                        pickerRows.add(new String[]{"disband|" + pickerTarget, "Распустить фракцию"});
                    }
                } else {
                    ListTag reqs = fc.getList("reqs", Tag.TAG_COMPOUND);
                    for (int r = 0; r < reqs.size(); r++) {
                        CompoundTag q = reqs.getCompound(r);
                        pickerRows.add(new String[]{"accept|" + pickerTarget + "|" + q.getString("uuid"),
                                "Принять: " + q.getString("name")});
                        pickerRows.add(new String[]{"decline|" + pickerTarget + "|" + q.getString("uuid"),
                                "Отклонить: " + q.getString("name")});
                    }
                }
            }
        } else if (i == 15) {
            ListTag facs = data.getList("factions", Tag.TAG_COMPOUND);
            for (int k = 0; k < facs.size(); k++) {
                CompoundTag fc = facs.getCompound(k);
                pickerRows.add(new String[]{"pvote|" + fc.getString("id"), fc.getString("name")});
            }
        } else if (i == 5 || i == 6) {
            ListTag members = data.getList("members", Tag.TAG_COMPOUND);
            Set<String> writers = new HashSet<>();
            ListTag saved = data.getList("writers", Tag.TAG_COMPOUND);
            for (int k = 0; k < saved.size(); k++) {
                writers.add(saved.getCompound(k).getString("uuid"));
            }
            if (i == 6) {
                pickerRows.add(new String[]{"", "— без наследника —"});
            }
            for (int k = 0; k < members.size(); k++) {
                CompoundTag e = members.getCompound(k);
                String uuid = e.getString("uuid");
                String label = e.getString("name");
                if (i == 5) {
                    label = (writers.contains(uuid) ? "− " : "+ ") + label;
                }
                pickerRows.add(new String[]{uuid, label});
            }
        } else if (i == 4) {
            Set<String> members = new HashSet<>();
            ListTag saved = data.getList("members", Tag.TAG_COMPOUND);
            for (int k = 0; k < saved.size(); k++) {
                members.add(saved.getCompound(k).getString("uuid"));
            }
            ListTag players = data.getList("players", Tag.TAG_COMPOUND);
            for (int k = 0; k < players.size(); k++) {
                CompoundTag e = players.getCompound(k);
                String uuid = e.getString("uuid");
                String prefix = members.contains(uuid) ? "− " : "+ ";
                pickerRows.add(new String[]{uuid, prefix + e.getString("name")});
            }
        } else {
            List<String> options = i == 2 ? CabinetPresets.PARLIAMENTS : CabinetPresets.governmentsFor(data.getString("ideology"));
            for (String o : options) {
                pickerRows.add(new String[]{o, o});
            }
        }
        pickerIndex = i;
    }

    private String value(int i) {
        String v = switch (i) {
            case 0 -> data.getBoolean("hasDeputy") ? data.getString("deputyName") : "";
            case 1 -> data.getString("ideology");
            case 2 -> data.getString("parliament");
            default -> data.getString("government");
        };
        if (!v.isEmpty()) return v;
        return i == 0 ? "не назначен" : "не задано";
    }

    // ---------- geometry ----------

    private void drawIcon(GuiGraphics g, String icon, float centerX, float y, float scale, int color) {
        CivitasUi.icon(g, font, icon, centerX, y + 4f * scale, scale, color);
    }

    private int closeX() {
        return PANEL_X + PANEL_W - 18;
    }

    private int closeY() {
        return panelY() + 12;
    }

    private int contentX() {
        return PANEL_X + 12;
    }

    private int contentY() {
        return panelY() + CONTENT_Y;
    }

    private int contentW() {
        return PANEL_W - 24 - 8;
    }

    private int viewH() {
        return panelH() - CONTENT_Y - FOOTER_H;
    }

    private int pickerH() {
        return 30 + Math.min(pickerRows.size(), 12) * 18;
    }

    private int pickerX() {
        return (width - 230) / 2;
    }

    private int pickerY() {
        return (height - pickerH()) / 2;
    }

    private static double clamp(double v, double lo, double hi) {
        return Math.max(lo, Math.min(hi, v));
    }
}
