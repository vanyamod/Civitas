package com.humanitas.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import static com.humanitas.client.CivitasUi.*;

public final class LawInfoScreen extends Screen {
    private final Screen parent;
    private final CompoundTag law;
    private DocumentPanel panel;
    private boolean pending;
    public static void receive(CompoundTag snapshot) {
        if(!(net.minecraft.client.Minecraft.getInstance().screen instanceof LawInfoScreen screen))return;
        var list=snapshot.getList("bills",10);
        for(int i=0;i<list.size();i++)if(list.getCompound(i).getInt("id")==screen.law.getInt("id")) {
            screen.law.merge(list.getCompound(i));screen.pending=false;return;
        }
        screen.law.putBoolean("closed",true);screen.pending=false;
    }
    private boolean waiting(){return !pending&&LawOrder.waiting(law);}
    private void vote(boolean yes){if(!waiting())return;pending=true;net.neoforged.neoforge.network.PacketDistributor.sendToServer(new com.humanitas.CabinetNet.VoteBill(law.getInt("id"),yes));}

    private final TextInput body = new TextInput(true, 18000, "Описание не указано");
    public LawInfoScreen(Screen parent, CompoundTag law) {
        super(Component.literal("Законопроект")); this.parent = parent; this.law = law.copy();
        body.setValue(law.getString("summary")); body.scrollToStart();
    }
    @Override protected void init() {
        panel = new DocumentPanel(width, height);
        body.setBounds(panel.x + 16, panel.y + 107, panel.w - 32, Math.max(24, panel.h - 161));
    }
    @Override public void render(GuiGraphics g,int mx,int my,float partial) {
        g.fill(0,0,width,height,BACKDROP);
        String type = !law.getBoolean("constitutional") ? "ЗАКОНОПРОЕКТ" : law.getBoolean("initialConstitution") ? "ПРОЕКТ КОНСТИТУЦИИ" : "ПОПРАВКИ К КОНСТИТУЦИИ";
        String subtitle = law.getBoolean("constitutional") ? (law.getBoolean("initialConstitution") ? "Первое принятие основного закона" : "Изменение действующей конституции") : law.getString("title");
        panel.draw(g,font,type + " #" + law.getInt("number"),subtitle,95);
        int x = panel.x + 16;
        String author = "Автор: " + law.getString("author") + " · Предложен: " + DocumentPanel.date(law.getLong("proposedDay"));
        g.drawString(font,font.plainSubstrByWidth(author,panel.w-32),x,panel.y+49,DIM,false);
        String status = law.getLong("adoptedDay") != Long.MIN_VALUE ? "Принят: " + DocumentPanel.date(law.getLong("adoptedDay"))
                : law.getBoolean("closed") ? "Голосование завершено" : "Идёт голосование";
        g.drawString(font,font.plainSubstrByWidth(status,panel.w-32),x,panel.y+63,TEXT_LIGHT,false);
        String votes = "За: " + law.getInt("yes") + " · Против: " + law.getInt("no") + (law.getBoolean("bloc") ? " · по местам" : "");
        if(law.getBoolean("constitutional")) votes += " · Нужно за: " + law.getInt("required");
        g.drawString(font,font.plainSubstrByWidth(votes,panel.w-32),x,panel.y+77,GOLD,false);
        body.render(g,mx,my);
        if(waiting()) {
            button(g,font,panel.x+16,panel.footer(),70,20,"ЗА",inside(mx,my,panel.x+16,panel.footer(),70,20),Style.PRIMARY);
            button(g,font,panel.x+92,panel.footer(),78,20,"ПРОТИВ",inside(mx,my,panel.x+92,panel.footer(),78,20),Style.SECONDARY);
        } else if(!law.getBoolean("closed") && law.getBoolean("canClose") && !pending)
            button(g,font,panel.x+16,panel.footer(),130,20,"ЗАКРЫТЬ ГОЛОСОВАНИЕ",inside(mx,my,panel.x+16,panel.footer(),130,20),Style.SECONDARY);
        else if(pending)g.drawString(font,"Ожидание сервера…",panel.x+16,panel.footer()+6,DIM,false);

        button(g,font,panel.x+panel.w-114,panel.footer(),100,20,"НАЗАД",inside(mx,my,panel.x+panel.w-114,panel.footer(),100,20),Style.SECONDARY);
    }
    @Override public boolean mouseClicked(double x,double y,int b) {
        if(b==0 && waiting() && inside(x,y,panel.x+16,panel.footer(),70,20)){vote(true);return true;}
        if(b==0 && waiting() && inside(x,y,panel.x+92,panel.footer(),78,20)){vote(false);return true;}
        if(b==0 && !waiting() && !pending && !law.getBoolean("closed") && law.getBoolean("canClose") && inside(x,y,panel.x+16,panel.footer(),130,20)){
            pending=true;net.neoforged.neoforge.network.PacketDistributor.sendToServer(new com.humanitas.CabinetNet.CloseBill(law.getInt("id")));return true;
        }
        if(b==0 && inside(x,y,panel.x+panel.w-114,panel.footer(),100,20)) { onClose(); return true; }
        return b==0 && body.mouseClicked(x,y);
    }
    @Override public boolean mouseDragged(double x,double y,int b,double dx,double dy) { return body.mouseDragged(x,y); }
    @Override public boolean mouseScrolled(double x,double y,double dx,double dy) { return body.mouseScrolled(x,y,dy); }
    @Override public void renderBackground(GuiGraphics g,int x,int y,float p) {}
    @Override public boolean isPauseScreen() { return false; }
    @Override public void onClose() { minecraft.setScreen(parent); }
}
