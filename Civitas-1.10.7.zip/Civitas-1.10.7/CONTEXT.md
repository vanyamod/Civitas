# Civitas development context

Snapshot: version 1.10.7, 2026-11-12.

## Environment

- Java 21, Minecraft 1.21.1, NeoForge 21.1.250.
- Gradle wrapper and ModDevGradle are included; build with `gradlew.bat build` or `bash ./gradlew build`.
- Mod id / Java package: `humanitas` / `com.humanitas`. Preserve them for save compatibility.
- Client/server network protocol: 12. Update both sides together.

## Main components

- `RepublicData`: SavedData/NBT for states, roles, factions, news, bills and constitution metadata.
- `CabinetNet`: authoritative server actions, payloads, per-tick snapshot batching and acknowledgements.
- `WheelScreen`, `CabinetScreen`: radial and classic cabinet interfaces.
- `CabinetRequests`, `PendingActions`: connection-scoped cached opening and duplicate pending command control.
- `NewsEditorScreen`, `NewsDraftStore`, `NewsFormatting`, `RichText`: editor, local drafts and formatted news.
- `MediaStore`, `ImageAttachment`, `AvatarCropScreen`: bounded image uploads and square avatar cropping.
- `DiscordWebhook`: server-side Discord delivery; runtime credentials are not part of this export.
- `WatchdogBridge`: optional bounded asynchronous integration with an installed Watchdog mod.
- `CivitasHud`, `CivitasStatusStyle`, `CivitasPaletteScreen`: themed bars, icons or vanilla indicators;
  the palette wheel centre cycles indicator styles.

## Governance behavior

State administrators can select a state and perform supported leadership actions.
Factions have named roles, permissions, deputies, avatars and news publishing.
Constitution proposals and amendments require a two-thirds vote of a captured electorate.
Optional senate mode uses explicit role membership with the law-voting permission;
leadership alone does not create a senate seat. Existing votes keep their captured electorate.
Faction protection begins after 14 real days. Older saves without a creation timestamp are
conservatively treated as protected. Majority support is required for protected dissolution.
Leadership succession is triggered by leaving membership, not ordinary disconnects.

## Known issues and verification limits

- GUI layout, indicators and animation have received iterative changes. Automated checks do
  not replace visual testing at different GUI scales, resolutions and resource packs.
- The faction/state administrator and succession paths need broader multiplayer tests,
  including offline members, faction removal during elections and repeated leadership changes.
- Protected-faction dissolution currently has no voting deadline or quorum beyond a majority
  of members; it is not a full parliamentary procedure simulation.
- Senate and constitution eligibility is captured when proposed. Later role/roster changes
  do not rewrite that electorate. Migration behavior must be preserved intentionally.
- Documents created by older versions can lack dates; UI says the date was not recorded.
- Cached cabinet data can briefly be stale. Server permissions remain authoritative.
  UI responsiveness improvements do not eliminate low TPS or network delays.
- Exact duplicate pending cabinet edits are suppressed until acknowledgement. Forms,
  publishing and voting still use their existing authoritative request paths.
- An isolated dedicated-server startup passed for the recent networking changes. Full
  load testing and all multi-mod client interactions have not been completed.
- Do not replace a live JAR: lazy class loading can fail even when the new archive is valid.
  The Windows installer guards against this and keeps older releases outside `mods`.
- Watchdog is optional and not bundled. Its restart/anti-cheat implementation belongs to
  a separate project. The source export contains only the Civitas integration.
- Runtime server configs, KubeJS scripts, resource packs and other modpack-specific files
  are intentionally outside this source export.

## Regression checks

`build` includes `newsEditorTest`, `constitutionChecks`, `pendingActionsChecks` and
`watchdogDashboardChecks`. Tests cover formatting, electorate thresholds/persistence,
explicit senate roles, pending request deduplication and bounded dashboard parsing.
They do not establish complete in-game correctness.

## Export hygiene

The GitHub archive is assembled from source/resources, build scripts, documentation and
Gradle wrapper files. It excludes `.git`, `.gradle`, build output, backups, test instances,
worlds, logs, live configs, databases, player identifiers and credentials from game profiles.
It preserves existing licensing metadata; it is not a new license grant.
