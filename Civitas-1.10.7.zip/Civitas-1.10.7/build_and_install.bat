@echo off
chcp 65001 >nul
cd /d "%~dp0"
call gradlew.bat build
if errorlevel 1 exit /b 1
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\install_mod.ps1"
if errorlevel 1 (
    echo Installation was not completed. See the message above.
    pause
    exit /b 1
)
pause
