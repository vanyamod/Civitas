package com.humanitas;

/**
 * Permission bits of a role. A holder can only grant permissions they have themselves.
 * The leader has every permission; the deputy has the fixed set in {@link #DEPUTY}.
 */
public final class Perms {
    private Perms() {}

    public static final long NEWS = 1L;
    public static final long NEWS_DELETE = 1L << 1;
    public static final long LAW_PROPOSE = 1L << 2;
    public static final long LAW_CLOSE = 1L << 3;
    public static final long MEMBER_INVITE = 1L << 4;
    public static final long MEMBER_KICK = 1L << 5;
    public static final long ROLE_MANAGE = 1L << 6;
    public static final long ROLE_ASSIGN = 1L << 7;
    public static final long STATE_RENAME = 1L << 8;
    public static final long ELECTIONS = 1L << 9;
    public static final long FACTION_MODERATE = 1L << 10;

    public static final long LAW_VOTE = 1L << 11;

    /** Every permission above, for the leader. */
    public static final long ALL = (1L << 12) - 1;

    /** Fixed permissions of the deputy. */
    public static final long DEPUTY = NEWS | LAW_PROPOSE | LAW_CLOSE | MEMBER_INVITE | STATE_RENAME | ELECTIONS;

    /** Names of the permissions, in bit order. Shown in the role editor. */
    public static final String[] NAMES = {
            "писать новости", "удалять новости", "вносить законы", "закрывать голосования",
            "принимать членов", "исключать из государства", "управлять ролями", "назначать роли",
            "переименовывать страну", "участвовать в выборах", "модерировать фракции", "голосовать по законам"
    };

    public static boolean has(long set, long permission) {
        return (set & permission) == permission;
    }
}
