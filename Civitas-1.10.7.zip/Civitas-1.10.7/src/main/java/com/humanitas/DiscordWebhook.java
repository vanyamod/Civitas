package com.humanitas;

import java.io.ByteArrayOutputStream;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import java.util.Base64;
import java.util.concurrent.*;
import com.google.gson.JsonParser;
import java.util.regex.Pattern;

/**
 * Posts news to a Discord channel as a rich embed, with the photo attached as a file.
 * Server side only: the URL is read from config/civitas/server.toml and never leaves the server.
 * Sending is asynchronous, so a slow or dead Discord never stalls the server tick.
 */
public final class DiscordWebhook {
    private DiscordWebhook() {}

    private static final int TITLE_MAX = 256;
    private static final int DESCRIPTION_MAX = 4000;
    private static final int FOOTER_MAX = 2000;
    /** Plain Discord message content limit. */
    private static final int CONTENT_MAX = 2000;
    // Public, neutral Discord avatar. Never fall back to the webhook's last state avatar:
    // it could reveal the origin of a hidden-state post.
    private static final String FALLBACK_AVATAR_URL = "https://cdn.discordapp.com/embed/avatars/0.png";
    /** Gold of the Civitas palette, shown as the strip on the left of the embed. */
    private static final int COLOR_GOLD = 0xA88B4A;

    /** Civitas markup that must not reach Discord as text: colour and style tags, photos, structures. */
    private static final Pattern MARKUP = Pattern.compile(
            "\\[/?(?:[bius]|c(?::[a-z]+)?)]|\\[img:[^\\]]+]|\\[nbt:[^\\]]+]");
    private static final DateTimeFormatter DATE = DateTimeFormatter.ofPattern("dd.MM.yyyy");
    private static final HttpClient CLIENT = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(5))
            .build();
    private static final ExecutorService SENDER = new ThreadPoolExecutor(1, 1, 0L, TimeUnit.SECONDS,
            new ArrayBlockingQueue<>(64), r -> { Thread t = new Thread(r, "Civitas-discord"); t.setDaemon(true); return t; });
    private static final java.util.Map<String, String> AVATAR_URLS = new java.util.HashMap<>();

    /**
     * Posts one news article.
     * image is the raw bytes of the photo, or null for a text-only article.
     */
    public static void news(String state, String title, String body, String footer, String author, long day, long dayTime, boolean asEmbed, int color, byte[] image, byte[] avatar) {
        String url = CivitasConfig.webhookUrl();
        if (url.isEmpty()) {
            return;
        }
        if (!isDiscordWebhook(url)) {
            Humanitas.LOGGER.warn(
                    "Discord webhook in config/civitas/server.toml is not a Discord webhook URL. Message not sent.");
            return;
        }

        String stateName = webhookName(state);
        String date = DATE.format(LocalDate.ofEpochDay(day));
        String clock = clockText(dayTime);
        String description = excerpt(body, footer);
        String fileName = image == null ? "" : imageName(image);

        StringBuilder embed = new StringBuilder("{");
        embed.append("\"title\":").append(quote(clip(title, TITLE_MAX))).append(',');
        if (!description.isEmpty()) {
            embed.append("\"description\":").append(quote(description)).append(',');
        }
        embed.append("\"color\":").append(color).append(',');
        embed.append("\"footer\":{\"text\":")
                .append(quote(clip("Civitas · " + date + " " + clock + " · автор: " + author, FOOTER_MAX))).append("}");
        if (image != null) {
            embed.append(",\"image\":{\"url\":\"attachment://").append(fileName).append("\"}");
        }
        embed.append('}');

        String payload = asEmbed
                ? "\"embeds\":[" + embed + "]"
                : "\"content\":"
                        + quote(plainMessage(title, body, footer, author, date, clock));

        try {
            SENDER.execute(() -> {
                String avatarUrl = ensureAvatar(url, avatar);
                if (avatarUrl == null) {
                    Humanitas.LOGGER.warn("Discord avatar unavailable; sending the news with a neutral fallback avatar");
                }
                avatarUrl = avatarOrFallback(avatarUrl);
                String json = messageJson(stateName, avatarUrl, payload);
                HttpRequest request;
        if (image == null) {
            request = builder(url)
                    .header("Content-Type", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString(json, StandardCharsets.UTF_8))
                    .build();
        } else {
            String boundary = "civitas" + Long.toHexString(System.nanoTime());
            byte[] multipart = multipart(boundary, json, image, fileName);
            request = builder(url)
                    .header("Content-Type", "multipart/form-data; boundary=" + boundary)
                    .POST(HttpRequest.BodyPublishers.ofByteArray(multipart))
                    .build();
        }
                send(request);
            });
        } catch (RejectedExecutionException e) {
            Humanitas.LOGGER.warn("Discord news queue is full");
        }
    }

    /** Discord stores the selected image; each message uses its own CDN URL override. */
    private static String ensureAvatar(String webhook, byte[] requested) {
        try {
            byte[] bytes = requested;
            if (bytes == null) {
                try (var input = DiscordWebhook.class.getResourceAsStream("/assets/humanitas/textures/hidden_state.png")) {
                    if (input == null) return null;
                    bytes = input.readAllBytes();
                }
            }
            String hash = webhook + ":" + java.util.HexFormat.of().formatHex(java.security.MessageDigest.getInstance("SHA-256").digest(bytes));
            String cached = AVATAR_URLS.get(hash);
            if (cached != null) return cached;
            String type = (bytes[0] & 255) == 0x89 ? "image/png" : "image/jpeg";
            String body = "{\"avatar\":" + quote("data:" + type + ";base64," + Base64.getEncoder().encodeToString(bytes)) + "}";
            HttpRequest request = builder(webhook).header("Content-Type", "application/json")
                    .method("PATCH", HttpRequest.BodyPublishers.ofString(body, StandardCharsets.UTF_8)).build();
            HttpResponse<String> response = CLIENT.send(request, HttpResponse.BodyHandlers.ofString());
            if (response.statusCode() == 429) {
                double delay = JsonParser.parseString(response.body()).getAsJsonObject().get("retry_after").getAsDouble();
                if (delay > 0 && delay <= 30) {
                    Thread.sleep((long) (delay * 1000) + 100);
                    response = CLIENT.send(request, HttpResponse.BodyHandlers.ofString());
                }
            }
            if (response.statusCode() / 100 != 2) {
                Humanitas.LOGGER.warn("Discord avatar update answered HTTP {}", response.statusCode());
                return null;
            }
            var json = JsonParser.parseString(response.body()).getAsJsonObject();
            String id = json.get("id").getAsString(), avatar = json.get("avatar").getAsString();
            if (!id.matches("[0-9]+") || !avatar.matches("[a-zA-Z0-9_]+")) return null;
            String result = "https://cdn.discordapp.com/avatars/" + id + "/" + avatar + ".png";
            if (AVATAR_URLS.size() >= 256) AVATAR_URLS.clear();
            AVATAR_URLS.put(hash, result);
            return result;
        } catch (Exception e) {
            if (e instanceof InterruptedException) Thread.currentThread().interrupt();
            Humanitas.LOGGER.warn("Discord avatar preparation failed");
            return null;
        }
    }

    /** In-game clock as HH:mm, the same way the hotbar shows it (0 ticks = 06:00). */
    static String clockText(long dayTime) {
        long t = Math.floorMod(dayTime, 24000L);
        long minutes = ((t * 1440L) / 24000L + 360L) % 1440L;
        return String.format(Locale.ROOT, "%02d:%02d", minutes / 60L, minutes % 60L);
    }

    private static HttpRequest.Builder builder(String url) {
        return HttpRequest.newBuilder(URI.create(url)).timeout(Duration.ofSeconds(15));
    }

    private static void send(HttpRequest request) {
        try {
            HttpResponse<String> response = CLIENT.send(request, HttpResponse.BodyHandlers.ofString());
            if (response.statusCode() == 429) {
                double delay = JsonParser.parseString(response.body()).getAsJsonObject().get("retry_after").getAsDouble();
                if (delay > 0 && delay <= 30) {
                    Thread.sleep((long) (delay * 1000) + 100);
                    response = CLIENT.send(request, HttpResponse.BodyHandlers.ofString());
                }
            }
            if (response.statusCode() / 100 != 2) {
                int code = 0;
                String field = "unknown";
                try {
                    var error = JsonParser.parseString(response.body()).getAsJsonObject();
                    if (error.has("code")) code = error.get("code").getAsInt();
                    if (error.has("errors") && error.get("errors").isJsonObject()) {
                        var errors = error.getAsJsonObject("errors");
                        for (String name : new String[]{"username", "avatar_url", "content", "embeds", "files", "allowed_mentions"}) {
                            if (errors.has(name)) { field = name; break; }
                        }
                    }
                }
                catch (RuntimeException ignored) { /* The response need not be JSON. */ }
                Humanitas.LOGGER.warn("Discord webhook rejected news: HTTP {}, Discord code {}, field {}", response.statusCode(), code, field);
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            Humanitas.LOGGER.warn("Discord webhook request was interrupted");
        } catch (Exception e) {
            Humanitas.LOGGER.warn("Discord webhook request failed: {}", e.getClass().getSimpleName());
        }
    }

    /** multipart/form-data: the embed as payload_json, the photo as files[0]. */
    private static byte[] multipart(String boundary, String json, byte[] image, String fileName) {
        ByteArrayOutputStream out = new ByteArrayOutputStream(image.length + json.length() + 512);
        String type = fileName.endsWith(".png") ? "image/png" : "image/jpeg";
        put(out, "--" + boundary + "\r\n");
        put(out, "Content-Disposition: form-data; name=\"payload_json\"\r\n");
        put(out, "Content-Type: application/json\r\n\r\n");
        put(out, json + "\r\n");
        put(out, "--" + boundary + "\r\n");
        put(out, "Content-Disposition: form-data; name=\"files[0]\"; filename=\"" + fileName + "\"\r\n");
        put(out, "Content-Type: " + type + "\r\n\r\n");
        out.writeBytes(image);
        put(out, "\r\n--" + boundary + "--\r\n");
        return out.toByteArray();
    }

    private static void put(ByteArrayOutputStream out, String s) {
        out.writeBytes(s.getBytes(StandardCharsets.UTF_8));
    }

    /** PNG starts with 0x89; anything else is sent as JPEG. */
    private static String imageName(byte[] image) {
        return (image.length > 0 && (image[0] & 0xFF) == 0x89) ? "news.png" : "news.jpg";
    }

    static boolean isDiscordWebhook(String url) {
        return url.startsWith("https://discord.com/api/webhooks/")
                || url.startsWith("https://discordapp.com/api/webhooks/");
    }

    /** Plain-message version of the article: bold headline, the body in Discord markdown, a small footer line. */
    static String plainContent(String title, String body, String footer, String author, String date, String clock) {
        String text = MARKUP.matcher(body).replaceAll("").strip();
        return "**" + title + "**\n\n" + text + (footer.isEmpty() ? "" : "\n\n-# " + footer) + "\n\n-# " + author + " · " + date + " " + clock;
    }

    static String plainMessage(String title, String body, String footer, String author, String date, String clock) {
        return clip(plainContent(title, body, footer, author, date, clock), CONTENT_MAX);
    }

    static String messageJson(String stateName, String avatarUrl, String payload) {
        return "{\"username\":" + quote(stateName) + ",\"avatar_url\":" + quote(avatarUrl)
                + ",\"allowed_mentions\":{\"parse\":[]}," + payload + "}";
    }

    static String avatarOrFallback(String avatarUrl) {
        return avatarUrl == null || avatarUrl.isBlank() ? FALLBACK_AVATAR_URL : avatarUrl;
    }

    static String webhookName(String state) {
        String value = state == null ? "" : state.strip();
        if (value.isEmpty()) return "Администрация";
        if (value.equals(CabinetNet.HIDDEN)) return "?????";
        value = clip(value.replaceAll("[\\p{Cntrl}]", " ").strip(), 80);
        if (value.isBlank()) return "Государство";
        // Discord does not allow these reserved names in webhook usernames.
        value = value.replaceAll("(?i)discord", "Dіscord").replaceAll("(?i)clyde", "Clydе");
        return value;
    }

    /** Plain excerpt of the article: no Civitas markup, no photo tags, cut to the limit. */
    private static String excerpt(String body, String footer) {
        String plain = MARKUP.matcher(body).replaceAll("").strip() + (footer.isEmpty() ? "" : "\n\n-# " + footer);
        return clip(plain, DESCRIPTION_MAX);
    }

    private static String clip(String s, int max) {
        return s.length() > max ? s.substring(0, max - 1) + "…" : s;
    }

    private static String quote(String s) {
        return "\"" + escape(s) + "\"";
    }

    /**
     * JSON string escape. Mention delivery is disabled through allowed_mentions in the payload.
     */
    private static String escape(String s) {
        StringBuilder sb = new StringBuilder(s.length() + 16);
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '"' -> sb.append("\\\"");
                case '\\' -> sb.append("\\\\");
                case '\n' -> sb.append("\\n");
                case '\r' -> sb.append("\\r");
                case '\t' -> sb.append("\\t");
                default -> {
                    if (c < 0x20) {
                        sb.append(String.format("\\u%04x", (int) c));
                    } else {
                        sb.append(c);
                    }
                }
            }
        }
        return sb.toString();
    }
}
