package com.humanitas.client;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import static com.humanitas.client.CivitasUi.*;

/** Shared document proportions keep the footer inside the panel at every GUI scale. */
final class DocumentPanel {
    final int x, y, w, h;
    DocumentPanel(int width, int height) {
        w = Math.min(560, width - 24); h = Math.min(360, height - 24);
        x = (width - w) / 2; y = (height - h) / 2;
    }
    int footer() { return y + h - 34; }
    void draw(GuiGraphics g, Font font, String heading, String meta, int header) {
        g.fill(x + 3, y + 4, x + w + 3, y + h + 4, 0x60000000);
        panel(g, x, y, w, h);
        g.fill(x + 2, y + 2, x + w - 2, y + header, HEADER);
        g.fill(x + 12, y + 12, x + 15, y + 28, GOLD);
        g.drawString(font, font.plainSubstrByWidth(heading, w - 44), x + 23, y + 14, TEXT_LIGHT, false);
        g.drawString(font, font.plainSubstrByWidth(meta, w - 32), x + 16, y + 34, GOLD, false);
        g.fill(x + 12, y + header, x + w - 12, y + header + 1, LINE);
        g.fill(x + 12, footer() - 9, x + w - 12, footer() - 8, LINE);
    }
    static String date(long value) {
        if (value == Long.MIN_VALUE) return "не записана";
        try { return LocalDate.ofEpochDay(value).format(DateTimeFormatter.ofPattern("dd.MM.yyyy")); }
        catch (RuntimeException e) { return "не записана"; }
    }
}
