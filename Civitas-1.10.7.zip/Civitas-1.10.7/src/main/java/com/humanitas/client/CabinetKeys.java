package com.humanitas.client;

import com.humanitas.CabinetNet;
import com.humanitas.Humanitas;
import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import net.neoforged.neoforge.network.PacketDistributor;

/**
 * Hotkeys for the Civitas GUI and the palette wheel.
 */
public final class CabinetKeys {
    private CabinetKeys() {}

    public static final String CATEGORY = "key.categories.civitas";

    public static final KeyMapping OPEN = new KeyMapping(
            "key.civitas.open", InputConstants.Type.KEYSYM, InputConstants.UNKNOWN.getValue(), CATEGORY);

    public static final KeyMapping PALETTE = new KeyMapping(
            "key.civitas.palette", InputConstants.Type.KEYSYM, InputConstants.KEY_H, CATEGORY);

    /** Registers the key mappings with the game. */
    @EventBusSubscriber(modid = Humanitas.MODID, value = Dist.CLIENT, bus = EventBusSubscriber.Bus.MOD)
    public static final class ModBus {
        private ModBus() {}

        @SubscribeEvent
        public static void register(RegisterKeyMappingsEvent event) {
            event.register(OPEN);
            event.register(PALETTE);
        }
    }

    /** Checks the keys once per client tick. Does nothing while a screen or chat is open. */
    @EventBusSubscriber(modid = Humanitas.MODID, value = Dist.CLIENT)
    public static final class GameBus {
        private GameBus() {}

        @SubscribeEvent
        public static void onClientTick(ClientTickEvent.Post event) {
            Minecraft mc = Minecraft.getInstance();
            while (OPEN.consumeClick()) {
                if (mc.player != null && mc.screen == null) {
                    CabinetRequests.open();
                }
            }
            while (PALETTE.consumeClick()) {
                if (mc.player != null && mc.screen == null) {
                    mc.setScreen(new CivitasPaletteScreen(true));
                }
            }
        }
    }
}
