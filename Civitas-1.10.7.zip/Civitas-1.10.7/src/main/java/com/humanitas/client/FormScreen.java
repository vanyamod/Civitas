package com.humanitas.client;

import com.humanitas.CabinetNet;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.neoforged.neoforge.network.PacketDistributor;
import org.lwjgl.glfw.GLFW;

import static com.humanitas.client.CivitasUi.*;

/**
 * Small form: a bill title, a new name for a state, leaving a state, or (admin) creating or deleting one.
 * Submitting sends one SubmitForm payload; the server validates it.
 */
public class FormScreen extends Screen {
    private static final int PW = 300;
    private static final int ROW = 42;

    private final Screen parent;
    private final String kind;
    private final String title;
    private final String[] labels;
    private final TextInput[] inputs;
    /** Extra value sent with the form, for example the id of the role being renamed. */
    private String extra = "";
    private int px;
    private int py;
    private int ph;

    public FormScreen(Screen parent, String kind) {
        super(Component.literal("Civitas form"));
        this.parent = parent;
        this.kind = kind;
        switch (kind) {
            case "bill" -> {
                title = "ПРЕДЛОЖИТЬ ЗАКОН";
                labels = new String[]{"НАЗВАНИЕ ЗАКОНА", "ОПИСАНИЕ"};
            }
            case "rename" -> {
                title = "ИЗМЕНИТЬ СТРАНУ";
                labels = new String[]{"ТИП", "НАЗВАНИЕ"};
            }
            case "leave" -> {
                title = "ВЫЙТИ ИЗ ГОСУДАРСТВА";
                labels = new String[]{"НАПИШИТЕ: ВЫЙТИ"};
            }
            case "abdicate" -> {
                title = "ОТРЕЧЬСЯ ОТ ПРЕСТОЛА";
                labels = new String[]{"НАПИШИТЕ: ОТРЕЧЬСЯ"};
            }
            case "faction" -> {
                title = "СОЗДАТЬ ФРАКЦИЮ";
                labels = new String[]{"НАЗВАНИЕ ФРАКЦИИ"};
            }
            case "roleRename" -> {
                title = "ПЕРЕИМЕНОВАТЬ РОЛЬ";
                labels = new String[]{"НОВОЕ НАЗВАНИЕ"};
            }
            case "role", "factionRole" -> {
                title = "НОВАЯ РОЛЬ";
                labels = new String[]{"НАЗВАНИЕ РОЛИ"};
            }
            case "delete" -> {
                title = "УДАЛИТЬ ГОСУДАРСТВО";
                labels = new String[]{"НАЗВАНИЕ ГОСУДАРСТВА (точно)"};
            }
            default -> {
                title = "СОЗДАТЬ СТРАНУ";
                labels = new String[]{"ТИП (республика, монархия...)", "НАЗВАНИЕ", "НИК ВЛАДЕЛЬЦА"};
            }
        }
        inputs = new TextInput[labels.length];
        for (int i = 0; i < labels.length; i++) {
            inputs[i] = new TextInput(kind.equals("bill") && i == 1, kind.equals("bill") && i == 1 ? 4000 : 120, "");
        }
        inputs[0].focused = true;
    }

    @Override
    protected void init() {
        ph = 36 + labels.length * ROW + 44 + (kind.equals("bill") ? 70 : 0);
        px = (width - PW) / 2;
        py = (height - ph) / 2;
        for (int i = 0; i < inputs.length; i++) {
            inputs[i].setBounds(px + 12, py + 56 + i * ROW, PW - 24, kind.equals("bill") && i == 1 ? 88 : 18);
        }
    }

    /** Sets the value sent as the second field, for forms that act on one item. Returns this. */
    public FormScreen withExtra(String value) {
        this.extra = value == null ? "" : value;
        return this;
    }

    /** Pre-fills one field, so an admin action can carry the name of the state or the player it targets. */
    public FormScreen withPrefill(int index, String value) {
        if (index >= 0 && index < inputs.length) {
            inputs[index].setValue(value == null ? "" : value);
        }
        return this;
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    /** Nothing here: the dim is painted in render so the blur isn't applied twice. */
    @Override
    public void renderBackground(GuiGraphics g, int mx, int my, float partialTick) {
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float partialTick) {
        g.fill(0, 0, width, height, BACKDROP);
        panel(g, px, py, PW, ph);
        g.fill(px + 2, py + 2, px + PW - 2, py + 36, HEADER);
        g.fill(px + 2, py + 2, px + PW - 2, py + 3, CivitasColors.alpha(TEXT_LIGHT, 0x1A));
        g.fill(px + 2, py + 36, px + PW - 2, py + 37, GOLD_DEEP);
        g.fill(px - 2 + 12, py + 10, px + 10, py + 18, GOLD);
        g.drawString(font, title, px + 16, py + 14, TEXT_LIGHT, false);
        for (int i = 0; i < labels.length; i++) {
            g.drawString(font, labels[i], px + 12, py + 44 + i * ROW, GOLD, false);
            inputs[i].render(g, mx, my);
        }
        button(g, font, cancelX(), buttonY(), 130, 20, "ОТМЕНА",
                inside(mx, my, cancelX(), buttonY(), 130, 20), Style.SECONDARY);
        button(g, font, sendX(), buttonY(), 130, 20, "ОТПРАВИТЬ",
                inside(mx, my, sendX(), buttonY(), 130, 20), Style.PRIMARY);
    }

    private int cancelX() {
        return px + 12;
    }

    private int sendX() {
        return px + PW - 142;
    }

    private int buttonY() {
        return py + ph - 30;
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        for (TextInput input : inputs) {
            input.mouseDragged(mx, my);
        }
        return true;
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (button != 0) return false;
        if (inside(mx, my, sendX(), buttonY(), 130, 20)) {
            submit();
            return true;
        }
        if (inside(mx, my, cancelX(), buttonY(), 130, 20)) {
            cancel();
            return true;
        }
        for (TextInput input : inputs) {
            input.mouseClicked(mx, my);
        }
        return true;
    }

    @Override
    public boolean charTyped(char c, int mods) {
        for (TextInput input : inputs) {
            if (input.charTyped(c)) return true;
        }
        return super.charTyped(c, mods);
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if ((key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER) && !(kind.equals("bill") && inputs.length > 1 && inputs[1].focused)) {
            submit();
            return true;
        }
        if (key == GLFW.GLFW_KEY_TAB) {
            focusNext();
            return true;
        }
        for (TextInput input : inputs) {
            if (input.keyPressed(key, mods)) return true;
        }
        return super.keyPressed(key, scan, mods);
    }

    private void focusNext() {
        int current = 0;
        for (int i = 0; i < inputs.length; i++) {
            if (inputs[i].focused) current = i;
            inputs[i].focused = false;
        }
        inputs[(current + 1) % inputs.length].focused = true;
    }

    @Override
    public void onClose() {
        cancel();
    }

    private void submit() {
        String a = inputs.length > 0 ? inputs[0].value() : "";
        String b = inputs.length > 1 ? inputs[1].value() : extra;
        String c = inputs.length > 2 ? inputs[2].value() : "";
        PacketDistributor.sendToServer(new CabinetNet.SubmitForm(kind, a, b, c));
        Minecraft.getInstance().setScreen("leave".equals(kind) ? null : parent);
    }

    private void cancel() {
        Minecraft.getInstance().setScreen(parent);
    }
}
