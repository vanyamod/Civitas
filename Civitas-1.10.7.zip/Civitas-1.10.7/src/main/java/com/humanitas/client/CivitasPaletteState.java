package com.humanitas.client;

import com.humanitas.CivitasClientConfig;
import com.humanitas.Humanitas;

/**
 * Holds the palette the player chose and whether the whole HUD is visible. Persisted through
 * {@link CivitasClientConfig}; safe to call before the config has loaded.
 */
public final class CivitasPaletteState {
    private CivitasPaletteState() {}

    private static volatile CivitasPalette current = CivitasPalette.GRAPHITE;
    private static volatile boolean hudVisible = true;

    public static void load() {
        CivitasPalette palette = CivitasPalette.GRAPHITE;
        boolean visible = true;
        try {
            String[] colors = CivitasClientConfig.CUSTOM_COLORS.get().split(",");
            if (colors.length == 4) setCustom(colors, false);
            palette = CivitasPalette.byId(CivitasClientConfig.PALETTE.get());
            visible = CivitasClientConfig.HUD_VISIBLE.get();
        } catch (RuntimeException e) {
            Humanitas.LOGGER.warn("Civitas palette config not yet loaded: {}", e.toString());
        }
        if (palette == CivitasPalette.CUSTOM) palette = CivitasPalette.GRAPHITE;
        current = palette;
        hudVisible = visible;
        CivitasUi.applyPalette(palette);
    }

    public static void setCustom(String[] colors, boolean save) {
        int[] parsed = new int[4];
        if (colors.length != 4) throw new IllegalArgumentException("Four colors required");
        for (int i = 0; i < 4; i++) {
            String hex = colors[i].trim().replace("#", "");
            if (!hex.matches("[0-9a-fA-F]{6}")) throw new IllegalArgumentException("Use RRGGBB");
            parsed[i] = 0xFF000000 | Integer.parseInt(hex, 16);
        }
        CivitasPalette.configureCustom(parsed[0], parsed[1], parsed[2], parsed[3]);
        if (save) {
            CivitasClientConfig.CUSTOM_COLORS.set(String.join(",", colors));
            select(CivitasPalette.CUSTOM);
        }
    }

    public static CivitasPalette current() { return current; }

    public static boolean hudVisible() { return hudVisible; }

    public static void select(CivitasPalette palette) {
        if (palette == null) return;
        current = palette;
        CivitasUi.applyPalette(palette);
        savePalette(palette.id());
    }

    public static void setHudVisible(boolean visible) {
        hudVisible = visible;
        saveHud(visible);
    }

    public static void toggleHud() {
        setHudVisible(!hudVisible);
    }

    private static void savePalette(String id) {
        try {
            CivitasClientConfig.PALETTE.set(id);
            CivitasClientConfig.SPEC.save();
        } catch (RuntimeException ignored) {}
    }

    private static void saveHud(boolean visible) {
        try {
            CivitasClientConfig.HUD_VISIBLE.set(visible);
            CivitasClientConfig.SPEC.save();
        } catch (RuntimeException ignored) {}
    }
}
