package com.humanitas.client;

import com.humanitas.CivitasClientConfig;

public enum CivitasStatusStyle {
    BARS("Полосы"), ICONS("Иконки"), VANILLA("Стандартный");
    public final String label;
    CivitasStatusStyle(String label) { this.label = label; }
    public static CivitasStatusStyle current() {
        try { return valueOf(CivitasClientConfig.STATUS_STYLE.get().toUpperCase(java.util.Locale.ROOT)); }
        catch (RuntimeException e) { return BARS; }
    }
    public static void cycle() {
        CivitasStatusStyle next = values()[(current().ordinal() + 1) % values().length];
        CivitasClientConfig.STATUS_STYLE.set(next.name().toLowerCase(java.util.Locale.ROOT));
        CivitasClientConfig.SPEC.save();
    }
}
