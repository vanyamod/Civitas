package com.humanitas.client;

import java.util.LinkedHashMap;
import java.util.Map;

/** Exact pending commands only: unrelated actions remain usable under server latency. */
public final class PendingActions {
    private record Command(String field, String value) {}
    private record Entry(Command command, long since) {}
    private final Map<Long, Entry> entries = new LinkedHashMap<>();
    private long sequence;
    public long begin(String field, String value, long now) {
        Command command = new Command(field, value);
        if (entries.size() >= 64 || entries.values().stream().anyMatch(e -> e.command.equals(command))) return 0;
        long id = ++sequence; entries.put(id, new Entry(command, now)); return id;
    }
    public void complete(long id) { entries.remove(id); }
    public int count() { return entries.size(); }
    public long age(long now) { return entries.isEmpty() ? 0 : Math.max(0, now - entries.values().iterator().next().since); }
    public void clear() { entries.clear(); }
}
