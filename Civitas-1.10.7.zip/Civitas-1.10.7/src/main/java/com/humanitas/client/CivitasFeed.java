package com.humanitas.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ServerData;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/**
 * Tracks what the player has already seen: the newest news article and the newest bill of their state.
 * The server pushes the latest ids; anything newer than the seen id lights up the HUD icons.
 * The seen ids are kept per server in config/civitas-seen.properties, so they survive a restart.
 * On the very first connection to a server everything counts as seen, so nothing lights up at once.
 */
public final class CivitasFeed {
    private CivitasFeed() {}

    /** Section numbers, the same as in CabinetScreen. */
    public static final int SECTION_LAWS = 2;
    public static final int SECTION_NEWS = 3;

    private static volatile long lawsNoticeStarted = 0, lawsNoticeUntil = 0;
    private static volatile long newsNoticeStarted = 0;
    private static volatile long newsNoticeUntil = 0;
    private static volatile int newsLatest = 0;
    private static volatile int billsLatest = 0;
    private static int newsSeen = 0;
    private static int billsSeen = 0;
    private static String loadedKey = null;
    private static final Properties SEEN = new Properties();

    /** Called when the server sends the latest ids. Runs on the client thread. */
    public static void setLatest(int news, int bills) {
        String key = currentKey();
        boolean newPublication = key.equals(loadedKey) && news > newsLatest;
        boolean newBill = key.equals(loadedKey) && bills > billsLatest;
        newsLatest = news;
        billsLatest = bills;
        if (newBill) {
            lawsNoticeStarted = net.minecraft.Util.getMillis();
            lawsNoticeUntil = lawsNoticeStarted + 7000L;
        }
        if (newPublication) {
            newsNoticeStarted = net.minecraft.Util.getMillis();
            newsNoticeUntil = newsNoticeStarted + 7000L;
        }
        if (newPublication || newBill) {
            Minecraft.getInstance().getSoundManager().play(net.minecraft.client.resources.sounds.SimpleSoundInstance.forUI(
                    net.minecraft.sounds.SoundEvents.EXPERIENCE_ORB_PICKUP, 1.3F));
        }
        if (!key.equals(loadedKey)) {
            newsNoticeStarted = newsNoticeUntil = 0;
            lawsNoticeStarted = lawsNoticeUntil = 0;
            loadedKey = key;
            readFile();
        }
        String newsKey = key + ".news";
        String billsKey = key + ".bills";
        if (!SEEN.containsKey(newsKey) || !SEEN.containsKey(billsKey)) {
            SEEN.setProperty(newsKey, Integer.toString(news));
            SEEN.setProperty(billsKey, Integer.toString(bills));
            writeFile();
        }
        newsSeen = parse(SEEN.getProperty(newsKey), news);
        billsSeen = parse(SEEN.getProperty(billsKey), bills);
    }

    public static float newsNoticeOpacity() {
        long now = net.minecraft.Util.getMillis();
        float enter = net.minecraft.util.Mth.clamp((now - newsNoticeStarted) / 280.0F, 0.0F, 1.0F);
        float exit = net.minecraft.util.Mth.clamp((newsNoticeUntil - now) / 350.0F, 0.0F, 1.0F);
        float t = Math.min(enter, exit);
        return t * t * (3.0F - 2.0F * t);
    }

    public static float lawsNoticeOpacity() {
        long now = net.minecraft.Util.getMillis();
        float enter = net.minecraft.util.Mth.clamp((now - lawsNoticeStarted) / 280.0F, 0.0F, 1.0F);
        float exit = net.minecraft.util.Mth.clamp((lawsNoticeUntil - now) / 350.0F, 0.0F, 1.0F);
        float t = Math.min(enter, exit);
        return t * t * (3.0F - 2.0F * t);
    }

    public static boolean newsNoticeVisible() { return newsNoticeOpacity() >= 0.02F; }

    public static boolean newsUnread() {
        return newsLatest > newsSeen;
    }

    public static boolean lawsUnread() {
        return billsLatest > billsSeen;
    }

    public static void markNewsSeen() {
        if (newsSeen == newsLatest) return;
        newsSeen = newsLatest;
        newsNoticeUntil = Math.min(newsNoticeUntil, net.minecraft.Util.getMillis() + 350L);
        SEEN.setProperty(currentKey() + ".news", Integer.toString(newsSeen));
        writeFile();
    }

    public static void markLawsSeen() {
        if (billsSeen == billsLatest) return;
        billsSeen = billsLatest;
        lawsNoticeUntil = Math.min(lawsNoticeUntil, net.minecraft.Util.getMillis() + 350L);
        SEEN.setProperty(currentKey() + ".bills", Integer.toString(billsSeen));
        writeFile();
    }

    /** Which section to open first: unread news, then unread laws, otherwise -1 (no preference). */
    public static int preferredSection() {
        if (newsUnread()) return SECTION_NEWS;
        if (lawsUnread()) return SECTION_LAWS;
        return -1;
    }

    private static int parse(String value, int fallback) {
        try {
            return value == null ? fallback : Integer.parseInt(value.trim());
        } catch (NumberFormatException e) {
            return fallback;
        }
    }

    private static String currentKey() {
        ServerData server = Minecraft.getInstance().getCurrentServer();
        return server == null ? "local" : server.ip.replace(':', '_').replace('.', '_');
    }

    private static Path file() {
        return Minecraft.getInstance().gameDirectory.toPath().resolve("config").resolve("civitas-seen.properties");
    }

    private static void readFile() {
        Path path = file();
        if (!Files.isRegularFile(path)) return;
        try (InputStream in = Files.newInputStream(path)) {
            SEEN.load(in);
        } catch (IOException e) {
            // unreadable file: start from scratch
        }
    }

    private static void writeFile() {
        Path path = file();
        try {
            Files.createDirectories(path.getParent());
            try (OutputStream out = Files.newOutputStream(path)) {
                SEEN.store(out, "Civitas: last seen news and bills per server");
            }
        } catch (IOException e) {
            // not critical: the highlight may come back after a restart
        }
    }
}
