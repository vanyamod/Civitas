package com.humanitas.client;

import com.humanitas.CivitasClientConfig;
import com.humanitas.Humanitas;
import net.minecraft.client.AttackIndicatorStatus;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.PlayerFaceRenderer;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.Mth;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.GameType;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RegisterGuiLayersEvent;
import net.neoforged.neoforge.client.event.RenderGuiLayerEvent;
import net.neoforged.neoforge.client.gui.VanillaGuiLayers;

import java.util.Set;

import static com.humanitas.client.CivitasUi.*;

/**
 * The Civitas hotbar and status bars.
 */
@EventBusSubscriber(modid = Humanitas.MODID, value = Dist.CLIENT)
public final class CivitasHud {
    private CivitasHud() {}

    private static final ResourceLocation LAYER = ResourceLocation.fromNamespaceAndPath(Humanitas.MODID, "hotbar");
    private static final ResourceLocation APPLESKIN_SATURATION = ResourceLocation.fromNamespaceAndPath("appleskin", "saturation_level");
    private static final ResourceLocation APPLESKIN_EXHAUSTION = ResourceLocation.fromNamespaceAndPath("appleskin", "exhaustion_level");

    private static final Set<ResourceLocation> REPLACED = Set.of(
            VanillaGuiLayers.HOTBAR,
            VanillaGuiLayers.EXPERIENCE_BAR,
            VanillaGuiLayers.EXPERIENCE_LEVEL,
            VanillaGuiLayers.PLAYER_HEALTH,
            VanillaGuiLayers.ARMOR_LEVEL,
            VanillaGuiLayers.FOOD_LEVEL,
            VanillaGuiLayers.VEHICLE_HEALTH,
            VanillaGuiLayers.AIR_LEVEL);

    private static final Set<ResourceLocation> HIDDEN_WITH_HUD = Set.of(
            VanillaGuiLayers.HOTBAR,
            VanillaGuiLayers.EXPERIENCE_BAR,
            VanillaGuiLayers.EXPERIENCE_LEVEL,
            VanillaGuiLayers.PLAYER_HEALTH,
            VanillaGuiLayers.ARMOR_LEVEL,
            VanillaGuiLayers.FOOD_LEVEL,
            VanillaGuiLayers.VEHICLE_HEALTH,
            VanillaGuiLayers.AIR_LEVEL,
            VanillaGuiLayers.SELECTED_ITEM_NAME,
            VanillaGuiLayers.EFFECTS);

    // Seven-pixel silhouettes leave a clear gap between adjacent eight-pixel slots.
    // Each row is a separate palette, preserving the same status semantics in every theme.
    private static final String[] LIFE_SHAPE = {
        ".XX..XX.", "XXXXXXXX", "XXXXXXXX", "XXXXXXXX",
        ".XXXXXX.", "..XXXX..", "...XX...", "........"
    };
    private static final String[] APPLE_SHAPE = {
        "....XX..", "...XX...", ".XX..XX.", "XXXXXXXX",
        "XXXXXXXX", "XXXXXXXX", ".XXXXXX.", "..XXXX.."
    };
    private static final int[][] SATURATION_RIM = {
        {1,5}, {1,6}, {2,6}, {2,7}, {3,7}, {4,7}, {5,7}, {5,6}, {6,6}, {6,5}
    };

    private static final String[] ARMOR_SHAPE = {
        "XX....XX", "XXX..XXX", "XXXXXXXX", ".XXXXXX.",
        ".XXXXXX.", ".XXXXXX.", ".XXXXXX.", "..XXXX.."
    };

    private static final String[][] HEARTS = {
        {".XX.XX.","XXXXXXX","XXXXXXX",".XXXXX.",".XXXXX.","..XXX..","...X..."},
        {".XX.XX.","XXXXXXX","XXXXXXX","XXXXXXX",".XXXXX.","..XXX..","...X..."},
        {".X...X.","XXX.XXX","XXXXXXX","XXXXXXX",".XXXXX.","..XXX..","...X..."},
        {".XX.XX.","XXXXXXX","XXXXXXX",".XXXXX.","..XXX..","..XXX..","...X..."},
        {".XX.XX.","XXXXXXX","XXXXXXX",".XXXXX.",".XXXXX.","..XXX..","..XXX.."},
        {".X...X.","XXX.XXX","XXXXXXX",".XXXXX.",".XXXXX.","..XXX..","...X..."},
        {".XX.XX.","XXXXXXX","XXXXXXX",".XXXXX.","..XXX..","...X...","...X..."},
        {".XX.XX.","XXXXXXX","XXXXXXX",".XXXXX.","..XXX..","..XXX..","...X..."}
    };
    private static final String[][] SHIELDS = {
        {"XXXXXXX","XXXXXXX","XXXXXXX","XXXXXXX",".XXXXX.","..XXX..","...X..."},
        {"XXXXXXX","XXXXXXX","XXXXXXX","XXXXXXX",".XXXXX.","..XXX..","...X..."},
        {"XXXXXXX","XXXXXXX","XXXXXXX","XXXXXXX",".XXXXX.","..XXX..","...X..."},
        {".XXXXX.","XXXXXXX","XXXXXXX","XXXXXXX",".XXXXX.","..XXX..","...X..."},
        {"XXXXXXX","XXXXXXX","XXXXXXX","XXXXXXX",".XXXXX.","..XXX..","...X..."},
        {"XXXXXXX","XXXXXXX","XXXXXXX","XXXXXXX",".XXXXX.","..XXX..","...X..."},
        {".XXXXX.","XXXXXXX","XXXXXXX","XXXXXXX",".XXXXX.","..XXX..","...X..."},
        {"XXXXXXX","XXXXXXX","XXXXXXX","XXXXXXX",".XXXXX.","..XXX..","...X..."}
    };
    private static final String[][] FOODS = {
        {"...X...",".XX.XX.","XXXXXXX","XXXXXXX","XXXXXXX",".XXXXX.","..XXX.."},
        {"..XX...",".XXXXX.","XXXXXXX","XXXXXXX",".XXXXX.",".XXXXX.","..XXX.."},
        {"...XX..","..XXX..",".XXXXX.","XXXXXXX","XXXXXXX",".XXXXX.","..XXX.."},
        {"....XX.","...XX..",".XXXXX.","XXXXXXX","XXXXXXX",".XXXXX.","..XXX.."},
        {"...X...","..XXX..",".XXXXX.","XXXXXXX",".XXXXX.",".XXXXX.","..XXX.."},
        {"...XX..",".XXXXX.","XXXXXXX","XXXXXXX","XXXXXXX","..XXX..","...X..."},
        {"...X...","..XXX..",".XXXXX.","XXXXXXX",".XXXXX.","..XXX..","...X..."},
        {"...X...",".XX.XX.","XXXXXXX","XXXXXXX",".XXXXX.","..XXX..","...X..."}
    };
    private static final String[][] HEART_INSETS = makeInsets(HEARTS);
    private static final String[][] SHIELD_INSETS = makeInsets(SHIELDS);
    private static final String[][] FOOD_INSETS = makeInsets(FOODS);

    private static String[][] makeInsets(String[][] silhouettes) {
        String[][] result = new String[silhouettes.length][];
        for (int i = 0; i < silhouettes.length; i++) {
            String[] shape = silhouettes[i];
            result[i] = new String[shape.length];
            for (int y = 0; y < shape.length; y++) {
                StringBuilder row = new StringBuilder();
                for (int x = 0; x < shape[y].length(); x++) {
                    boolean inside = x > 0 && x + 1 < shape[y].length() && y > 0 && y + 1 < shape.length
                            && shape[y].charAt(x) == 'X' && shape[y].charAt(x - 1) == 'X'
                            && shape[y].charAt(x + 1) == 'X' && shape[y - 1].charAt(x) == 'X'
                            && shape[y + 1].charAt(x) == 'X';
                    row.append(inside ? 'X' : '.');
                }
                result[i][y] = row.toString();
            }
        }
        return result;
    }

    private static int hudStyle() {
        return switch (CivitasPaletteState.current()) {
            case FROST, MIDNIGHT -> 6;
            case AMETHYST, MALACHITE -> 3;
            default -> 0;
        };
    }

    /** 9 x 8 air bubble. */
    private static final String[] BUBBLE_MASK = {
            "...XXX...",
            "..XXXXX..",
            ".XXXXXXX.",
            "XXXXXXXXX",
            "XXXXXXXXX",
            ".XXXXXXX.",
            "..XXXXX..",
            "...XXX..."
    };

    @SubscribeEvent
    public static void registerLayer(RegisterGuiLayersEvent event) {
        event.registerAbove(VanillaGuiLayers.HOTBAR, LAYER, CivitasHud::render);
    }

    /** Hides the vanilla layers that the Civitas hotbar redraws. Off-palette: vanilla HUD comes back. */
    @SubscribeEvent
    public static void hideVanillaLayers(RenderGuiLayerEvent.Pre event) {
        if (CivitasStatusStyle.current() == CivitasStatusStyle.VANILLA && !VanillaGuiLayers.HOTBAR.equals(event.getName())) return;
        if ((REPLACED.contains(event.getName()) || APPLESKIN_SATURATION.equals(event.getName())
                || APPLESKIN_EXHAUSTION.equals(event.getName())) && paletteOn() && canDraw()) {
            event.setCanceled(true);
        }
    }

    /** The Civitas style for the hotbar and status bars: palette switched on and the config allows it. */
    private static boolean paletteOn() {
        return CivitasPaletteState.hudVisible() && customHotbar();
    }

    private static boolean customHotbar() {
        try {
            return CivitasClientConfig.CUSTOM_HOTBAR.get();
        } catch (RuntimeException e) {
            return false;
        }
    }

    private static boolean canDraw() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.gameMode == null || mc.options.hideGui) {
            return false;
        }
        if (mc.gameMode.getPlayerMode() == GameType.SPECTATOR) {
            return false;
        }
        return true;
    }

    private static void render(GuiGraphics g, DeltaTracker deltaTracker) {
        if (!canDraw()) {
            return;
        }
        boolean palette = paletteOn();
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        Font font = mc.font;
        int left = g.guiWidth() / 2 - 91;
        int top = g.guiHeight() - 22;

        if (palette) {
            if (CivitasStatusStyle.current() != CivitasStatusStyle.VANILLA) drawStatusBars(g, font, mc, player, left, top);

            drawHotbar(g, font, deltaTracker, player, left, top);
        }

        ItemStack offhand = player.getOffhandItem();
        if (palette && !offhand.isEmpty()) {
            int ox = left + 182 + 7;
            plate(g, ox, top, 22, 22);
            renderSlot(g, font, deltaTracker, player, ox + 3, top + 3, offhand, 10);
        }

        int platesX = left + 182 + (palette && !offhand.isEmpty() ? 34 : 6);
        drawSidePanel(g, font, player, platesX, top);
    }

    // ---------- status bars ----------

    private static void drawStatusBars(GuiGraphics g, Font font, Minecraft mc, LocalPlayer player, int left, int top) {
        int heartsY = top - 19;
        boolean canHurt = mc.gameMode.canHurtPlayer();
        int healthRows = 1;
        int armourRows = 1;
        int foodRows = 1;
        boolean airShown = false;
        LivingEntity mount = mountWithHealth(player);

        if (canHurt) {
            int maxHealth = Mth.ceil(Math.max(player.getMaxHealth(), player.getHealth()));
            int maxHearts = Mth.ceil(maxHealth / 2.0F);
            int absorbHearts = Mth.ceil(player.getAbsorptionAmount() / 2.0F);
            int totalHearts = Math.max(1, maxHearts + absorbHearts);
            healthRows = CivitasStatusStyle.current() == CivitasStatusStyle.ICONS ? (totalHearts + 9) / 10 : 1;
            drawHearts(g, player, left, heartsY, maxHearts, totalHearts, player.getHealth(),
                    player.getAbsorptionAmount());

            int armour = player.getArmorValue();
            armourRows = armour > 0 ? (CivitasStatusStyle.current() == CivitasStatusStyle.ICONS ? Math.max(1, (Mth.ceil(armour / 2.0F) + 9) / 10) : 1) : 0;
            drawArmour(g, left, heartsY - (CivitasStatusStyle.current() == CivitasStatusStyle.ICONS ? healthRows * 10 : 12), armour, armourRows);

            if (mount != null) {
                int mountMax = Mth.ceil(Math.min(mount.getMaxHealth(), 60.0F) / 2.0F);
                int mountRows = Math.max(1, (mountMax + 9) / 10);
                drawMountHearts(g, left, heartsY, mount.getHealth(), mountRows);
                foodRows = mountRows;
            } else {
                int food = player.getFoodData().getFoodLevel();
                foodRows = Math.max(1, (Mth.ceil(food / 2.0F) + 9) / 10);
                drawFood(g, player, left, heartsY, food, foodRows);
            }

            int maxAir = player.getMaxAirSupply();
            int air = Math.min(player.getAirSupply(), maxAir);
            if (maxAir > 0 && (player.isEyeInFluid(FluidTags.WATER) || air < maxAir)) {
                drawAir(g, left, heartsY - foodRows * 10, air, maxAir);
                airShown = true;
            }
        }

        drawExperience(g, font, mc, player, left, top);

        Gui gui = mc.gui;
        if (canHurt) {
            gui.leftHeight = 59 + Math.max(0, healthRows - 1) * 10 + Math.max(0, armourRows - 1) * 10;
            gui.rightHeight = 39 + foodRows * 10 + (airShown ? 10 : 0);
        } else {
            gui.leftHeight = 39;
            gui.rightHeight = 39;
        }
    }

    private static void drawHearts(GuiGraphics g, LocalPlayer player, int left, int y,
                                   int maxHearts, int totalHearts, float health, float absorption) {
        int color = heartColour(player);
        if (CivitasStatusStyle.current() == CivitasStatusStyle.ICONS) {
            for (int i = 0; i < totalHearts; i++) {
                boolean absorbed = i >= maxHearts;
                int index = absorbed ? i - maxHearts : i;
                int points = Mth.ceil(absorbed ? absorption : health);
                int columns = index * 2 + 2 <= points ? 8 : index * 2 + 1 == points ? 4 : 0;
                int fill = absorbed ? HEART_ABSORB : color;
                if (player.hurtTime > 0 && (player.tickCount / 3) % 2 == 0) fill = mix(fill, TEXT_LIGHT, 0.5F);
                int iy = y - i / 10 * 10;
                if (player.hasEffect(MobEffects.REGENERATION) && i == player.tickCount % Mth.ceil(player.getMaxHealth() + 5)) iy -= 1;
                int ix = left + i % 10 * 9;
                drawStatusIcon(g, LIFE_SHAPE, ix, iy, columns, fill);
                if (columns > 0) g.fill(ix + 1, iy + 1, ix + 3, iy + 2, mix(fill, TEXT_LIGHT, 0.58F));
            }
            return;
        }
        if (player.hurtTime > 0 && (player.tickCount / 3) % 2 == 0) color = mix(color, TEXT_LIGHT, 0.50F);
        float capacity = Math.max(1, player.getMaxHealth());
        drawGauge(g, left, y, 88, health / capacity, color, LIFE_SHAPE,
                absorption / capacity, HEART_ABSORB);
    }

    /** Raised frame, recessed track and a matching end medallion for every status gauge. */
    private static void drawGauge(GuiGraphics g, int x, int y, int width, float progress,
                                  int color, String[] icon, float reserve, int reserveColor) {
        int track = width - 12;
        int interior = track - 4;
        g.fill(x + 2, y + 1, x + width - 1, y + 10, 0x66000000);
        g.fill(x + 2, y, x + track, y + 9, GOLD_DEEP);
        g.fill(x, y + 2, x + track, y + 7, GOLD_DEEP);
        g.fill(x + 2, y + 1, x + track, y + 2, GOLD);
        g.fill(x + 1, y + 2, x + track, y + 7, PLATE_DEEP);
        g.fill(x + 2, y + 7, x + track, y + 8, mix(GOLD_DEEP, PLATE_DEEP, 0.40F));
        int fill = Mth.clamp(Math.round(interior * progress), 0, interior);
        if (fill > 0) {
            g.fill(x + 2, y + 2, x + 2 + fill, y + 7, color);
            g.fill(x + 2, y + 2, x + 2 + fill, y + 3, mix(color, TEXT_LIGHT, 0.42F));
            g.fill(x + 2, y + 6, x + 2 + fill, y + 7, mix(color, PLATE_DEEP, 0.32F));
        }
        // Quiet divisions read in two-point steps, without turning the rail into disconnected blocks.
        for (int i = 1; i < 10; i++) {
            int tick = x + 2 + i * interior / 10;
            g.fill(tick, y + 3, tick + 1, y + 6, alpha(PLATE_DEEP, 0x55));
        }
        int stored = Mth.clamp(Math.round(interior * reserve), 0, interior);
        if (stored > 0) {
            g.fill(x + 2, y + 5, x + 2 + stored, y + 7, mix(reserveColor, PLATE_DEEP, 0.22F));
            g.fill(x + 2, y + 5, x + 2 + stored, y + 6, mix(reserveColor, TEXT_LIGHT, 0.25F));
        }
        int cap = x + track - 1;
        g.fill(cap + 2, y - 1, cap + 10, y + 11, GOLD_DEEP);
        g.fill(cap, y + 1, cap + 12, y + 9, GOLD_DEEP);
        g.fill(cap + 2, y, cap + 10, y + 1, GOLD);
        g.fill(cap + 1, y + 2, cap + 11, y + 8, PLATE);
        g.fill(cap + 2, y + 1, cap + 10, y + 10, PLATE);
        drawStatusIcon(g, icon, cap + 2, y + 1, 8, color);
    }

    /** Eight-pixel sprites on a nine-pixel grid: each has a gap and a bevel of its own. */
    private static void drawStatusIcon(GuiGraphics g, String[] shape, int x, int y, int filled, int color) {
        mask(g, shape, x, y + 1, 8, 0x88000000);
        mask(g, shape, x, y, 8, mix(PLATE_DEEP, color, 0.18F));
        for (int row = 0; row < shape.length; row++) {
            int shade = row < 3 ? mix(color, 0xFFFFFFFF, (3 - row) * 0.055F)
                    : mix(color, PLATE_DEEP, (row - 2) * 0.055F);
            for (int col = 0; col < filled; col++) {
                if (shape[row].charAt(col) != 'X') continue;
                boolean edge = col == 0 || col == 7 || row == 0 || row + 1 == shape.length
                        || shape[row].charAt(Math.max(0, col - 1)) != 'X'
                        || shape[row].charAt(Math.min(7, col + 1)) != 'X'
                        || shape[Math.min(shape.length - 1, row + 1)].charAt(col) != 'X';
                g.fill(x + col, y + row, x + col + 1, y + row + 1,
                        edge ? mix(shade, PLATE_DEEP, 0.24F) : shade);
            }
        }
    }

    private static int heartColour(LocalPlayer player) {
        if (player.hasEffect(MobEffects.WITHER)) {
            return HEART_WITHER;
        }
        if (player.hasEffect(MobEffects.POISON)) {
            return HEART_POISON;
        }
        if (player.getTicksFrozen() > 0) {
            return HEART_FROZEN;
        }
        return HEART;
    }

    /**
     * Armour in the current palette: shields in the palette's shield colour, a metal rim,
     * and a dark plate for the empty cells.
     */
    private static void drawArmour(GuiGraphics g, int left, int y, int armour, int rows) {
        if (armour <= 0) return;
        if (CivitasStatusStyle.current() == CivitasStatusStyle.ICONS) {
            for (int i = 0; i < rows * 10; i++) {
                int columns = i * 2 + 2 <= armour ? 8 : i * 2 + 1 == armour ? 4 : 0;
                int ix = left + i % 10 * 9, iy = y - i / 10 * 10;
                drawStatusIcon(g, ARMOR_SHAPE, ix, iy, columns, SHIELD);
                if (columns > 0) g.fill(ix, iy, ix + 2, iy + 1, mix(SHIELD, TEXT_LIGHT, 0.62F));
            }
            return;
        }
        // Vanilla armour protection is capped at twenty points.
        drawGauge(g, left, y, 88, armour / 20.0F, SHIELD, ARMOR_SHAPE, 0, SHIELD);
    }

    private static void drawFood(GuiGraphics g, LocalPlayer player, int left, int y, int food, int rows) {
        float saturation = Mth.clamp(player.getFoodData().getSaturationLevel(), 0, food);
        int colour = player.hasEffect(MobEffects.HUNGER) ? FOOD_HUNGER : mix(FOOD_COLOR, GOLD, 0.25F);
        if (CivitasStatusStyle.current() == CivitasStatusStyle.ICONS) {
            for (int i = 0; i < 10; i++) {
                int ix = left + 93 + i * 9, iy = y - 1;
                int columns = i * 2 + 2 <= food ? 8 : i * 2 + 1 == food ? 4 : 0;
                drawStatusIcon(g, APPLE_SHAPE, ix, iy, columns, colour);
                if (columns > 0) {
                    if (columns == 8) g.fill(ix + 4, iy, ix + 6, iy + 1, OLIVE);
                    g.fill(ix + 1, iy + 3, ix + 3, iy + 4, mix(colour, TEXT_LIGHT, 0.55F));
                }
                int lit = Mth.clamp(Mth.ceil((saturation - i * 2) * SATURATION_RIM.length / 2), 0, SATURATION_RIM.length);
                for (int n = 0; n < lit; n++) {
                    int rx = SATURATION_RIM[n][0], ry = SATURATION_RIM[n][1];
                    if (rx < columns) g.fill(ix + rx, iy + ry, ix + rx + 1, iy + ry + 1, mix(GOLD, TEXT_LIGHT, 0.55F));
                }
            }
            return;
        }
        drawGauge(g, left + 94, y, 88, food / 20.0F, colour, APPLE_SHAPE,
                saturation / 20.0F, GOLD);
    }

    private static void drawMountHearts(GuiGraphics g, int left, int y, float health, int rows) {
        int points = Mth.ceil(health);
        for (int i = 0; i < rows * 10; i++) {
            int row = i / 10;
            int column = i % 10;
            int x = left + 182 - 9 - column * 8;
            int iconY = y - row * 10;
            mask(g, HEARTS[hudStyle()], x, iconY, 7, ICON_EMPTY);
            if (i * 2 + 2 <= points) {
                mask(g, HEARTS[hudStyle()], x, iconY, 7, HEART_MOUNT);
                highlight(g, x + 2, iconY + 1, 2, 1);
            } else if (i * 2 + 1 == points) {
                mask(g, HEARTS[hudStyle()], x, iconY, 4, HEART_MOUNT);
                highlight(g, x + 1, iconY + 1, 1, 1);
            }
        }
    }

    private static final String[] AIR_SHAPE = {
        "..XXXX..", ".XXXXXX.", "XXXXXXXX", "XXXXXXXX",
        "XXXXXXXX", "XXXXXXXX", ".XXXXXX.", "..XXXX.."
    };

    private static void drawAir(GuiGraphics g, int left, int y, int air, int maxAir) {
        float fraction = Mth.clamp(air / (float)Math.max(1, maxAir), 0, 1);
        if (CivitasStatusStyle.current() == CivitasStatusStyle.BARS) {
            drawGauge(g, left + 94, y - 2, 88, fraction, AIR_COLOR, AIR_SHAPE, 0, AIR_COLOR);
            return;
        }
        float points = fraction * 20;
        for (int i = 0; i < 10; i++) {
            // Same eight-pixel width and nine-pixel pitch as the food icons.
            int x = left + 93 + i * 9;
            int columns = points >= i * 2 + 2 ? 8 : points > i * 2 ? 4 : 0;
            mask(g, AIR_SHAPE, x, y + 1, 8, 0x66000000);
            mask(g, AIR_SHAPE, x, y, 8, mix(PLATE_DEEP, AIR_COLOR, 0.18F));
            if (columns > 0) {
                mask(g, AIR_SHAPE, x, y, columns, mix(AIR_COLOR, PLATE_DEEP, 0.15F));
                g.fill(x + 2, y + 1, x + 4, y + 2, mix(AIR_COLOR, TEXT_LIGHT, 0.65F));
                g.fill(x + 1, y + 2, x + 2, y + 4, mix(AIR_COLOR, TEXT_LIGHT, 0.45F));
            }
        }
    }

    private static LivingEntity mountWithHealth(LocalPlayer player) {
        return player.getVehicle() instanceof LivingEntity living && living.showVehicleHealth() ? living : null;
    }

    private static void drawExperience(GuiGraphics g, Font font, Minecraft mc, LocalPlayer player, int left, int top) {
        if (player.jumpableVehicle() != null || !mc.gameMode.hasExperience()) {
            return;
        }

        int y = top - 7;
        int width = 182;
        int inner = width - 2;
        // Recessed rail with cut corners and a palette-coloured metallic rim.
        g.fill(left + 2, y, left + width - 2, y + 5, GOLD_DEEP);
        g.fill(left + 1, y + 1, left + width - 1, y + 4, GOLD_DEEP);
        g.fill(left + 2, y + 1, left + width - 2, y + 4, PLATE_DEEP);

        int filled = Mth.clamp((int) (player.experienceProgress * (width - 4)), 0, width - 4);
        if (filled > 0) {
            g.fill(left + 2, y + 1, left + 2 + filled, y + 4, OLIVE);
            g.fill(left + 2, y + 1, left + 2 + filled, y + 2, mix(OLIVE, TEXT_LIGHT, 0.38F));
            g.fill(left + 2, y + 3, left + 2 + filled, y + 4, mix(OLIVE, PLATE_DEEP, 0.35F));
        }

        for (int i = 1; i < 10; i++) {
            int tickX = left + 1 + i * inner / 10;
            g.fill(tickX, y + 1, tickX + 1, y + 4, LINE);
        }

        int level = player.experienceLevel;
        if (level > 0) {
            String text = Integer.toString(level);
            int textX = Math.max(3, left - font.width(text) - 5);
            g.drawString(font, text, textX, y - 2, TEXT_LIGHT, true);
        }
    }

    // ---------- hotbar ----------

    private static void plate(GuiGraphics g, int x, int y, int w, int h) {
        g.fill(x + 2, y + h, x + w + 1, y + h + 1, 0x55000000);
        g.fill(x + w, y + 2, x + w + 1, y + h, 0x55000000);
        g.fill(x + 1, y, x + w - 1, y + h, GOLD);
        g.fill(x, y + 1, x + w, y + h - 1, GOLD);
        g.fill(x + 2, y + 1, x + w - 2, y + h - 1, PLATE);
        g.fill(x + 1, y + 2, x + w - 1, y + h - 2, PLATE);
        g.fill(x + 3, y + 2, x + w - 3, y + 3, LINE);
    }

    private static void drawHotbar(GuiGraphics g, Font font, DeltaTracker dt, LocalPlayer player, int left, int top) {
        plate(g, left, top, 182, 22);
        for (int i = 1; i < 9; i++) {
            int x = left + 1 + i * 20;
            g.fill(x, top + 4, x + 1, top + 18, CELL_LINE);
        }

        int sx = left + 1 + player.getInventory().selected * 20;
        g.fill(sx + 1, top + 2, sx + 19, top + 20, SELECT_FILL);
        g.fill(sx + 1, top + 2, sx + 19, top + 3, GOLD);
        g.fill(sx + 1, top + 19, sx + 19, top + 20, GOLD);
        g.fill(sx + 1, top + 3, sx + 2, top + 19, GOLD);
        g.fill(sx + 18, top + 3, sx + 19, top + 19, GOLD);

        if (Minecraft.getInstance().options.attackIndicator().get() == AttackIndicatorStatus.HOTBAR) {
            float strength = player.getAttackStrengthScale(0.0F);
            if (strength < 1.0F) {
                int length = (int) (strength * 14.0F);
                g.fill(sx + 16 - length, top + 18, sx + 16, top + 19, GOLD);
            }
        }

        int seed = 1;
        for (int i = 0; i < 9; i++) {
            renderSlot(g, font, dt, player, left + 3 + i * 20, top + 3, player.getInventory().items.get(i), seed++);
        }
    }

    /** Same item drawing as vanilla, including the small "pop" when an item is picked up. */
    private static void renderSlot(GuiGraphics g, Font font, DeltaTracker dt, LocalPlayer player,
                                   int x, int y, ItemStack stack, int seed) {
        if (stack.isEmpty()) {
            return;
        }
        float pop = stack.getPopTime() - dt.getGameTimeDeltaPartialTick(false);
        if (pop > 0.0F) {
            float f = 1.0F + pop / 5.0F;
            g.pose().pushPose();
            g.pose().translate(x + 8, y + 12, 0);
            g.pose().scale(1.0F / f, (f + 1.0F) / 2.0F, 1.0F);
            g.pose().translate(-(x + 8), -(y + 12), 0);
        }
        g.renderItem(player, stack, x, y, seed);
        if (pop > 0.0F) {
            g.pose().popPose();
        }
        g.renderItemDecorations(font, stack, x, y);
    }

    // ---------- right-hand plates ----------

    /** Both plates (state above, player below) live on the right of the hotbar. */
    private static void drawRightPlates(GuiGraphics g, Font font, LocalPlayer player, int x, int top) {
        boolean hasState = CabinetClientState.hasState();
        String state = hasState ? CabinetClientState.stateName() : "Без государства";
        String date = CabinetClientState.dateText();
        String icon = CabinetClientState.ideologyIcon();
        String nick = player.getGameProfile().getName();
        String time = CabinetClientState.clockText();
        String day = "День " + CabinetClientState.gameDay();
        String weather = CabinetClientState.weatherText();
        String phase = CabinetClientState.phaseText();

        String meta = day + " · " + weather;
        String infoLine1 = icon + "  " + state;
        String infoLine2 = date + " · " + phase;
        String playerLine1 = nick + "   " + time;

        int maxW = g.guiWidth() - x - 4;
        if (maxW < 72) {
            return;
        }
        int wanted = Math.max(
                Math.max(font.width(playerLine1) + 30, font.width(meta) + 30),
                Math.max(font.width(infoLine1) + 24, font.width(infoLine2) + 24));
        int w = Math.min(maxW, Math.min(214, Math.max(96, wanted)));
        if (w < 72) {
            return;
        }

        // Flush the plates into the bottom-right corner, but never over the hotbar.
        int px = Math.max(x, g.guiWidth() - w - 4);
        if (px + w > g.guiWidth() - 2) {
            px = g.guiWidth() - w - 2;
        }

        // The two plates form one connected panel: no gap, shared rim, a clasp at the seam.
        int infoY = top - 22;
        if (infoY >= 2) {
            drawInfoPlate(g, font, px, infoY, w, hasState, icon, state, infoLine2);
        }
        drawPlayerPlate(g, font, player, px, top, w, nick, time, meta);

        // Seam clasp, tying the two halves together.
        int mid = px + w / 2;
        g.fill(mid - 3, top - 1, mid + 4, top, GOLD);
        g.fill(mid - 2, top - 2, mid + 3, top - 1, GOLD_DEEP);
    }

    private static void drawInfoPlate(GuiGraphics g, Font font, int x, int y, int w,
                                     boolean hasState, String icon, String state, String line2) {
        plate(g, x, y, w, 22);
        g.fill(x + 1, y + 1, x + 3, y + 21, OLIVE);

        int stateColor = hasState ? GOLD : DIM;
        g.drawString(font, icon, x + 7, y + 4, stateColor, false);
        g.drawString(font, font.plainSubstrByWidth(state, w - 24), x + 19, y + 4, stateColor, false);
        g.drawString(font, font.plainSubstrByWidth(line2, w - 24), x + 19, y + 13,
                hasState ? TEXT_LIGHT : DIM, false);
    }

    private static void drawPlayerPlate(GuiGraphics g, Font font, LocalPlayer player, int x, int top,
                                       int w, String nick, String time, String meta) {
        plate(g, x, top, w, 22);
        g.fill(x + 1, top + 1, x + 3, top + 21, OLIVE);
        g.fill(x + 3, top + 1, x + w - 3, top + 2, GOLD_DEEP);
        g.fill(x + 25, top + 11, x + w - 5, top + 12, mix(PLATE, GOLD, 0.18F));

        g.fill(x + 3, top + 3, x + 19, top + 19, GOLD);
        PlayerFaceRenderer.draw(g, player.getSkin(), x + 4, top + 4, 14);

        int textX = x + 23;
        int timeX = x + w - 7 - font.width(time);
        int nickMax = Math.max(10, timeX - textX - 6);
        g.drawString(font, font.plainSubstrByWidth(nick, nickMax), textX, top + 4, TEXT_LIGHT, false);
        g.drawString(font, time, timeX, top + 4, GOLD, false);
        g.drawString(font, font.plainSubstrByWidth(meta, w - 28), textX, top + 13, DIM, false);
    }

    // ---------- side panel: three icons above, player card below ----------

    private static final int ICON_W = 24;
    private static final int ICON_H = 20;
    private static final int ICON_GAP = 4;
    private static final String[] SIDE_ICONS = {"✉", "✒", "⌂"};

    /**
     * Right of the hotbar: an icon row above (news, laws, state), the day and weather beside it,
     * and the player card below, level with the hotbar: head, nickname, time, state, date.
     */
    private static void drawSidePanel(GuiGraphics g, Font font, LocalPlayer player, int x, int top) {
        int avail = g.guiWidth() - x - 6;
        int w = Math.min(Math.max(100, avail), Math.max(132, Math.min(210, cardWidth(font, player))));
        w = Math.min(w, g.guiWidth() - 12);
        x = g.guiWidth() - w - 6;
        if (avail < 100) top -= 64;

        int iconY = top - ICON_H - 4;
        boolean hasState = CabinetClientState.hasState();
        for (int i = 0; i < SIDE_ICONS.length; i++) {
            boolean unread = (i == 0 && CivitasFeed.newsUnread()) || (i == 1 && CivitasFeed.lawsUnread());
            boolean enabled = i != 1 || hasState;
            drawSideIcon(g, font, x + i * (ICON_W + ICON_GAP), iconY, SIDE_ICONS[i], unread, enabled);
        }

        String meta = "День " + CabinetClientState.gameDay() + " · " + CabinetClientState.weatherText();
        int metaX = x + SIDE_ICONS.length * (ICON_W + ICON_GAP) + 2;
        int metaW = x + w - metaX;
        if (metaW > 24) {
            g.drawString(font, font.plainSubstrByWidth(meta, metaW), metaX, iconY + 6, DIM, false);
        }

        drawPlayerCard(g, font, player, x, top, w);
        int noticeRow = 0;
        for (int kind = 0; kind < 2; kind++) {
            float visibility = kind == 0 ? CivitasFeed.newsNoticeOpacity() : CivitasFeed.lawsNoticeOpacity();
            if (visibility < 0.02F) continue;
            int opacity = Mth.clamp(Math.round(255 * visibility), 5, 255);
            int noticeWidth = Math.min(188, g.guiWidth() - 12);
            int nx = g.guiWidth() - noticeWidth - 6;
            float offset = CivitasSettings.reducedMotion() ? 0 : 9 * (1 - visibility);
            int ny = iconY - 35 - noticeRow++ * 34;
            int accent = alpha(GOLD, opacity);
            int border = alpha(GOLD_DEEP, opacity);
            int background = alpha(PLATE, opacity);
            g.pose().pushPose();
            g.pose().translate(0, offset, 0);
            g.fill(nx + 2, ny, nx + noticeWidth - 2, ny + 29, border);
            g.fill(nx, ny + 2, nx + noticeWidth, ny + 27, border);
            g.fill(nx + 1, ny + 2, nx + noticeWidth - 1, ny + 27, background);
            g.fill(nx + 2, ny + 2, nx + 4, ny + 27, accent);
            g.drawString(font, kind == 0 ? "Новая публикация" : "Новый законопроект", nx + 10, ny + 5, accent, false);
            g.drawString(font, kind == 0 ? "Откройте раздел новостей" : "Откройте раздел законов", nx + 10, ny + 16, alpha(TEXT_LIGHT, opacity), false);
            g.pose().popPose();
        }
    }

    /** The unread state belongs to the tile: a brighter letter and inset accent. */
    private static void drawSideIcon(GuiGraphics g, Font font, int x, int y, String glyph,
                                     boolean unread, boolean enabled) {
        boolean active = enabled && unread;
        int accent = mix(GOLD, 0xFFF0B987, 0.38F);
        int face = active ? mix(PLATE, GOLD, 0.08F) : PLATE;
        int edge = enabled ? mix(PLATE, TEXT_LIGHT, active ? 0.30F : 0.15F) : PLATE_DEEP;
        // Two-pixel corners, a recessed face and one highlight along the top edge.
        g.fill(x + 2, y + 1, x + ICON_W - 2, y + ICON_H + 1, 0x50000000);
        g.fill(x + 2, y, x + ICON_W - 2, y + ICON_H, edge);
        g.fill(x, y + 2, x + ICON_W, y + ICON_H - 2, edge);
        g.fill(x + 2, y + 1, x + ICON_W - 2, y + ICON_H - 1, face);
        g.fill(x + 1, y + 2, x + ICON_W - 1, y + ICON_H - 2, face);
        g.fill(x + 3, y + 1, x + ICON_W - 3, y + 2, mix(face, TEXT_LIGHT, 0.09F));
        int color = !enabled ? DIM : active ? mix(TEXT_LIGHT, accent, 0.22F) : mix(TEXT_LIGHT, PLATE, 0.18F);
        String[] icon = glyph.equals("✉") ? new String[]{
            "...........", "...........", "XXXXXXXXXXX", "XX.......XX",
            "X.X.....X.X", "X..X...X..X", "X...XXX...X", "X.........X", "XXXXXXXXXXX"}
            : glyph.equals("✒") ? new String[]{"...........", "..XXXXXXX..", "..X.....X..",
            "..X.XXX.X..", "..X.....X..", "..X.XXX.X..", "..X.....X..", "..XXXXXXX..", "..........."}
            : new String[]{"...........", ".....X.....", "....XXX....", "...XXXXX...",
            "..XXXXXXX..", "...X...X...", "...X.X.X...", "...XXXXX...", "..........."};
        mask(g, icon, x + (ICON_W - 11) / 2, y + 4, 11, color);
        if (active) {
            // A quiet status rule inside the tile replaces the protruding marker.
            g.fill(x + 7, y + ICON_H - 4, x + ICON_W - 7, y + ICON_H - 3, accent);
        }
    }

    /** Width the player card needs so nothing is cut: the longer of its two lines. */
    private static int cardWidth(Font font, LocalPlayer player) {
        String state = CabinetClientState.hasState()
                ? CabinetClientState.ideologyIcon() + " " + CabinetClientState.stateName()
                : "Без государства";
        int stateLine = 26 + font.width(state) + 8 + font.width(CabinetClientState.dateText()) + 6;
        int nickLine = 26 + font.width(player.getGameProfile().getName()) + 8
                + font.width(CabinetClientState.clockText()) + 6;
        return Math.max(stateLine, nickLine);
    }

    /** Cuts text to the width and adds an ellipsis, so a cut is always visible. */
    private static String fit(Font font, String text, int maxWidth) {
        if (font.width(text) <= maxWidth) {
            return text;
        }
        return font.plainSubstrByWidth(text, Math.max(0, maxWidth - font.width("…"))) + "…";
    }

    private static void drawPlayerCard(GuiGraphics g, Font font, LocalPlayer player, int x, int top, int w) {
        plate(g, x, top, w, 22);
        g.fill(x + 1, top + 1, x + 3, top + 21, OLIVE);
        g.fill(x + 3, top + 1, x + w - 3, top + 2, GOLD_DEEP);
        g.fill(x + 25, top + 11, x + w - 5, top + 12, mix(PLATE, GOLD, 0.18F));

        // Head: 14 px inside a gold frame.
        g.fill(x + 6, top + 4, x + 22, top + 20, GOLD);
        PlayerFaceRenderer.draw(g, player.getSkin(), x + 7, top + 5, 14);

        String nick = player.getGameProfile().getName();
        String time = CabinetClientState.clockText();
        int textX = x + 26;
        int timeX = x + w - 6 - font.width(time);
        g.drawString(font, fit(font, nick, Math.max(20, timeX - textX - 4)), textX, top + 3,
                TEXT_LIGHT, false);
        g.drawString(font, time, timeX, top + 3, GOLD, false);

        boolean hasState = CabinetClientState.hasState();
        String state = hasState
                ? CabinetClientState.ideologyIcon() + " " + CabinetClientState.stateName()
                : "Без государства";
        String date = CabinetClientState.dateText();
        int dateX = x + w - 6 - font.width(date);
        g.drawString(font, fit(font, state, Math.max(20, dateX - textX - 4)), textX, top + 12,
                hasState ? GOLD : DIM, false);
        g.drawString(font, date, dateX, top + 12, TEXT_LIGHT, false);
    }

    // ---------- pixel icons ----------

    private static void mask(GuiGraphics g, String[] rows, int x, int y, int maxColumns, int colour) {
        for (int row = 0; row < rows.length; row++) {
            String line = rows[row];
            int start = -1;
            for (int col = 0; col <= line.length(); col++) {
                boolean on = col < line.length() && col < maxColumns && line.charAt(col) == 'X';
                if (on && start < 0) {
                    start = col;
                } else if (!on && start >= 0) {
                    g.fill(x + start, y + row, x + col, y + row + 1, colour);
                    start = -1;
                }
            }
        }
    }

    private static void highlight(GuiGraphics g, int x, int y, int w, int h) {
        g.fill(x, y, x + w, y + h, HIGHLIGHT);
    }
}
