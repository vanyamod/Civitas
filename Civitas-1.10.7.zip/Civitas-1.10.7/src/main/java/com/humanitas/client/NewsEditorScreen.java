package com.humanitas.client;

import com.humanitas.CabinetNet;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.neoforged.neoforge.network.PacketDistributor;
import org.lwjgl.glfw.GLFW;
import java.util.ArrayList;
import java.util.List;
import static com.humanitas.client.CivitasUi.*;

/** A responsive writing desk with the real newspaper renderer and local, recoverable drafts. */
public class NewsEditorScreen extends Screen {
    private static final int BODY_MAX = 1940;
    private static final String[] COLORS = {"Чернила", "Оливковый", "Золото", "Красный", "Синий", "Серый", "Графит"};
    private static final String[] STRIPE_NAMES = {"Золото", "Оливковый", "Красный", "Синий", "Зелёный", "Фиолетовый", "Серый", "Чернила"};
    private static final String[] FORMAT_IDS = {"bold", "italic", "underline", "strike", "link", "colors", "code", "codeblock", "spoiler"};
    private static final String[] FORMAT_NAMES = {"Ж", "К", "Ч", "З", "Сс", "A", "`", "{}", "||"};
    private static final String[] FORMAT_HINTS = {"Жирный · Ctrl+B", "Курсив · Ctrl+I", "Подчёркнутый · Ctrl+U", "Зачёркнутый", "Вставить ссылку · Ctrl+K", "Цвет выделенного текста", "Код в строке", "Блок кода", "Скрытый текст"};
    private final Screen parent;
    private final TextInput title = new TextInput(false, 80, "О чём эта новость?");
    private final TextInput body = new TextInput(true, BODY_MAX, "Начните с главного. Что произошло?");
    private final TextInput footer = new TextInput(false, 120, "Источник или подпись · необязательно");
    private final TextInput linkText = new TextInput(false, 200, "Текст ссылки");
    private final TextInput linkUrl = new TextInput(false, 800, "https://example.com");
    private final ImageAttachment photo = new ImageAttachment();
    private final NewsDraftStore drafts = new NewsDraftStore();
    private NewsDraftStore.Draft saved;
    private final List<Control> controls = new ArrayList<>(), popups = new ArrayList<>();
    private record Control(String id, int x, int y, int w, int h, String hint, boolean enabled) {
        boolean contains(double mx, double my) { return inside(mx, my, x, y, w, h); }
    }
    private int px, py, pw, ph, left, top, lw, right, rw, bottom, toolbarY, bodyY, bodyH;
    private int toolbarRows, toolbarBw;
    private int previewY, previewH, previewScroll, previewHeight, ticks;
    private int menuX, menuY, menuW, menuH, noticeTicks;
    private boolean wide, previewOnly, finished, saveFailed, linkOpen;
    private boolean hideState, hideAuthor, discordEmbed = true, factionAuthor;
    private int stripe;
    private String menu = "", notice = "", insertedImage = "";
    private TextInput dragInput;

    public NewsEditorScreen(Screen parent) {
        super(Component.literal("Редакция Civitas")); this.parent = parent;
        factionAuthor = CabinetClientState.canPostFaction && !CabinetClientState.canPostState;
        body.setLineGap(3);
        saved = drafts.load(); restore(saved);
    }
    private void restore(NewsDraftStore.Draft d) {
        title.setValue(d.title()); body.setValue(d.body()); footer.setValue(d.footer());
        photo.restore(d.imageId(), d.imageName());
        insertedImage = "";
        if (photo.ready()) {
            String marker = "[img:" + photo.serverId() + "]";
            if (body.value().contains(marker)) {
                insertedImage = photo.serverId();
            } else {
                body.setValue(body.value().isBlank() ? marker + "\n\n" : body.value().stripTrailing() + "\n\n" + marker + "\n\n");
                insertedImage = photo.serverId();
            }
        }
        focus(title); previewScroll = 0;
    }
    /** One row of all tools, or two rows when they would be too narrow to use. */
    private void layoutToolbar() {
        int n = FORMAT_IDS.length;
        boolean single = n * 31 <= lw;
        toolbarRows = single ? 1 : 2;
        if (single) {
            toolbarBw = Math.max(16, Math.min(30, (lw - 16) / n));
        } else {
            int first = (n + 1) / 2, second = n - first;
            int fitFirst = lw / first - 1;
            int fitSecond = lw / second - 1;
            toolbarBw = Math.max(16, Math.min(30, Math.min(fitFirst, fitSecond)));
        }
        toolbarY = top + 44;
        bodyY = toolbarY + toolbarRows * 20 + (toolbarRows - 1) * 3 + 4;
        bodyH = Math.max(24, bottom - 44 - bodyY);
    }
    @Override protected void init() {
        pw = Math.min(980, width - 16); ph = Math.min(590, height - 16);
        px = (width - pw) / 2; py = (height - ph) / 2;
        left = px + 12; top = py + 47; bottom = py + ph - 48;
        wide = pw >= 560 && ph >= 270;
        lw = wide ? (pw - 40) / 2 : pw - 24;
        right = left + lw + 16; rw = pw - 24 - lw - 16;
        title.setBounds(left, top + 13, lw, 24);
        layoutToolbar();
        body.setBounds(left, bodyY, lw, bodyH); footer.setBounds(left, bottom - 23, lw, 21);
        previewY = top; previewH = bottom - previewY - 2;
        int dw = Math.min(340, pw - 24), dx = (width - dw) / 2, dy = (height - 160) / 2;
        linkText.setBounds(dx + 12, dy + 42, dw - 24, 22); linkUrl.setBounds(dx + 12, dy + 83, dw - 24, 22);
        menu = "";
    }
    @Override public boolean isPauseScreen() { return false; }
    @Override public void renderBackground(GuiGraphics g, int mx, int my, float partial) {}
    private boolean editing() { return !previewOnly; }
    private boolean previewing() { return wide || previewOnly; }
    private int previewX() { return wide && !previewOnly ? right : left; }
    private int previewW() { return wide && !previewOnly ? rw : pw - 24; }
    private int dim() { return mix(TEXT_LIGHT, PLATE, .40f); }
    private void label(GuiGraphics g, String text, int x, int y) { g.drawString(font, text, x, y, dim(), false); }
    private NewsDraftStore.Draft draft() {
        return new NewsDraftStore.Draft(title.value(), body.value(), footer.value(), photo.ready() ? photo.serverId() : "", photo.fileName());
    }
    private void saveDraft() {
        NewsDraftStore.Draft current = draft();
        if (current.equals(saved) && !saveFailed) return;
        saveFailed = !drafts.save(current); if (!saveFailed) saved = current;
    }
    /** Puts the uploaded photo straight into the article text, where the cursor is. */
    private void insertPhoto(String id) {
        if (id == null || id.isEmpty()) return;
        String marker = "[img:" + id + "]";
        if (!insertedImage.isEmpty() && !insertedImage.equals(id)) {
            body.setValue(body.value().replace("[img:" + insertedImage + "]", ""));
        }
        insertedImage = id;
        if (body.value().contains(marker)) return;
        if (!body.value().isEmpty() && body.value().length() + marker.length() + 2 > BODY_MAX) return;
        body.insert(marker + "\n\n");
    }
    private void removePhoto() {
        String id = photo.serverId();
        photo.clear();
        insertedImage = "";
        if (!id.isEmpty() && body.value().contains("[img:" + id + "]")) {
            body.setValue(body.value().replace("[img:" + id + "]", "").replaceAll("\\n{3,}", "\n\n").strip());
        }
    }
    @Override public void tick() {
        if (photo.ready() && !photo.serverId().equals(insertedImage)) insertPhoto(photo.serverId());
        if (++ticks % 20 == 0 && !finished) saveDraft();
        if (noticeTicks > 0) noticeTicks--;
    }
    @Override public void removed() { if (!finished) saveDraft(); photo.clear(); }

    @Override public void render(GuiGraphics g, int mx, int my, float partial) {
        controls.clear(); popups.clear();
        g.fill(0, 0, width, height, 0xDA070A0C);
        g.fill(px + 3, py + 4, px + pw + 3, py + ph + 4, 0x70000000);
        g.fill(px, py, px + pw, py + ph, PLATE);
        g.fill(px, py, px + pw, py + 2, GOLD); g.fill(px, py + ph - 1, px + pw, py + ph, GOLD_DEEP);
        g.fill(px + 1, py + 40, px + pw - 1, py + 41, LINE);
        g.drawString(font, Component.literal("РЕДАКЦИЯ").withStyle(ChatFormatting.BOLD), left, py + 10, TEXT_LIGHT, false);
        if (pw > 400) label(g, "CIVITAS", left, py + 24);
        else if (noticeTicks > 0 || saveFailed) label(g, font.plainSubstrByWidth(saveFailed ? "Ошибка сохранения" : notice, pw - 24), left, py + 30);
        if (CabinetClientState.canPostFaction && CabinetClientState.canPostState && pw > 480) {
            control(g, "author", left + 72, py + 11, 105, 21,
                    factionAuthor ? "От фракции" : "От страны", "Выбрать автора новости", true, factionAuthor, false, mx, my);
        }
        if (discordEmbed) {
            int sx = px + pw - 247;
            control(g, "stripe", sx, py + 11, 21, 21, "", "Цвет полоски слева в Discord-карточке (Embed)", true, false, false, mx, my);
            g.fill(sx + 5, py + 16, sx + 16, py + 27, LINE);
            g.fill(sx + 6, py + 17, sx + 15, py + 26, 0xFF000000 | CabinetNet.STRIPE_COLORS[stripe]);
        }
        control(g, "discord", px + pw - 226, py + 11, 104, 21, discordEmbed ? "Discord: Embed" : "Discord: текст", "Как отправить новость в Discord: карточкой Embed или обычным текстом", true, false, false, mx, my);
        control(g, "view", px + pw - 114, py + 11, 102, 21, previewOnly ? "К редактированию" : "Предпросмотр", "Развернуть предпросмотр · Ctrl+P", true, previewOnly, false, mx, my);
        if (editing()) renderEditor(g, mx, my);
        if (previewing()) renderPreview(g);
        renderFooter(g, mx, my);
        if (!menu.isEmpty()) renderMenu(g, mx, my);
        if (linkOpen) renderLink(g, mx, my);
        if (menu.isEmpty() && !linkOpen) for (Control c : controls) {
            if (c.contains(mx, my) && !c.hint().isBlank()) { g.renderTooltip(font, Component.literal(c.hint()), mx, my); break; }
        }
    }
    private void renderEditor(GuiGraphics g, int mx, int my) {
        label(g, "ЗАГОЛОВОК", left, top);
        String count = title.value().length() + " / 80"; label(g, count, left + lw - font.width(count), top);
        title.render(g, mx, my);
        g.fill(left - 1, toolbarY - 2, left + lw + 1, bodyY - 2, mix(PLATE, TEXT_LIGHT, .06f));
        int x = left + 2, y = toolbarY;
        int perRow = toolbarRows == 1 ? FORMAT_IDS.length : (FORMAT_IDS.length + 1) / 2;
        for (int i = 0; i < FORMAT_IDS.length; i++) {
            if (toolbarRows == 2 && i == perRow) { x = left + 2; y += 23; }
            control(g, FORMAT_IDS[i], x, y, toolbarBw, 20, FORMAT_NAMES[i], FORMAT_HINTS[i], true, false, false, mx, my);
            x += toolbarBw + 1;
        }
        body.render(g, mx, my);
        String plain = RichText.plain(body.value()).strip(); int words = plain.isEmpty() ? 0 : plain.split("\\s+").length;
        label(g, words + " слов  ·  " + body.value().length() + " / " + BODY_MAX, left, bottom - 36);
        g.fill(left, bottom - 27, left + lw, bottom - 26, LINE); footer.render(g, mx, my);
    }
    private void renderPreview(GuiGraphics g) {
        int x = previewX(), w = previewW();
        g.fill(x + 3, previewY + 3, x + w + 3, previewY + previewH + 3, 0x55000000);
        g.fill(x, previewY, x + w, previewY + previewH, CREAM);
        String author = Minecraft.getInstance().player == null ? "" : Minecraft.getInstance().player.getGameProfile().getName();
        NewsItem n = new NewsItem(0, title.value().isBlank() ? "Здесь будет ваш заголовок" : title.value().trim(), hideState ? "?????" : CabinetClientState.hasState() ? CabinetClientState.stateName() : "", hideAuthor ? "?????" : author, CabinetClientState.today(), body.value().isBlank() ? "Текст появится здесь, как только вы начнёте писать." : body.value().trim(), footer.value().trim(), photo.previewKey(), "", false, false, false);
        previewScroll = Math.max(0, Math.min(Math.max(0, previewHeight - previewH), previewScroll));
        g.enableScissor(x, previewY, x + w, previewY + previewH);
        previewHeight = NewsView.draw(g, font, x, previewY, w - 5, n, previewScroll); g.disableScissor();
        if (previewHeight > previewH) {
            int thumb = Math.max(16, previewH * previewH / previewHeight);
            int sy = previewY + (previewH - thumb) * previewScroll / Math.max(1, previewHeight - previewH);
            g.fill(x + w - 3, previewY + 2, x + w - 1, previewY + previewH - 2, CREAM_DEEP);
            g.fill(x + w - 3, sy, x + w - 1, sy + thumb, GOLD_DEEP);
        }
    }
    private String reason() {
        if (title.value().isBlank()) return "Добавьте заголовок";
        if (body.value().isBlank()) return "Добавьте текст новости";
        if (photo.busy()) return "Дождитесь загрузки фото";
        if (photo.state() == ImageAttachment.State.FAILED) return "Повторите загрузку или уберите фото";
        return "";
    }
    private void renderFooter(GuiGraphics g, int mx, int my) {
        int y = py + ph - 36; g.fill(px + 1, y - 8, px + pw - 1, y - 7, LINE);
        control(g, "close", left, y, 62, 23, "Закрыть", "Закрыть редакцию · Esc", true, false, false, mx, my);
        control(g, "photo", left + 68, y, 58, 23, photo.busy() ? "Фото…" : photo.ready() ? "Фото +" : "+ Фото", "Прикрепить фото или заменить его", true, photo.ready(), false, mx, my);
        control(g, "hideAuthor", left + 132, y, 118, 23, "Скрыть автора", "Вместо ника автора будет ????? · админы видят настоящий ник", true, hideAuthor, false, mx, my);
        control(g, "hideState", left + 254, y, 118, 23, "Скрыть государство", "Вместо государства будет ????? · админы видят его", true, hideState, false, mx, my);
        int publishW = pw < 390 ? 108 : 120, publishX = px + pw - 12 - publishW;
        control(g, "publish", publishX, y, publishW, 23, "Опубликовать", reason().isEmpty() ? "Отправить новость · Ctrl+Enter" : reason(), reason().isEmpty(), false, true, mx, my);
        int available = publishX - (left + 380) - 8;
        String hint = noticeTicks > 0 ? notice : photo.busy() ? photo.message() : saveFailed ? "Ошибка сохранения" : "Ctrl+Enter — опубликовать";
        String shown = font.width(hint) <= available ? hint : hint.startsWith("Ctrl") && font.width("Ctrl+Enter") <= available ? "Ctrl+Enter" : "";
        if (!shown.isEmpty()) label(g, shown, left + 380, y + 8);
    }
    private void control(GuiGraphics g, String id, int x, int y, int w, int h, String text, String hint, boolean enabled, boolean selected, boolean primary, int mx, int my) {
        boolean hot = inside(mx, my, x, y, w, h) && enabled;
        int fill = primary && enabled ? (hot ? CREAM : GOLD) : selected ? mix(PLATE, GOLD, .22f) : hot ? mix(PLATE, TEXT_LIGHT, .14f) : mix(PLATE, TEXT_LIGHT, .055f);
        g.fill(x, y, x + w, y + h, fill);
        if (selected || primary) g.fill(x, y + h - 1, x + w, y + h, enabled ? GOLD : LINE);
        int color = primary && enabled ? INK : enabled ? TEXT_LIGHT : mix(TEXT_LIGHT, PLATE, .65f);
        Component label = Component.literal(font.plainSubstrByWidth(text, w - 6));
        label = switch (id) { case "bold" -> label.copy().withStyle(ChatFormatting.BOLD); case "italic" -> label.copy().withStyle(ChatFormatting.ITALIC); case "underline" -> label.copy().withStyle(ChatFormatting.UNDERLINE); case "strike" -> label.copy().withStyle(ChatFormatting.STRIKETHROUGH); default -> label; };
        g.drawString(font, label, x + (w - font.width(label)) / 2, y + (h - 8) / 2, color, false);
        CivitasSounds.register(x, y, w, h, enabled ? Style.SECONDARY : Style.DISABLED);
        (id.startsWith("menu:") || id.startsWith("dialog:") ? popups : controls).add(new Control(id, x, y, w, h, hint, enabled));
    }
    private void openMenu(String kind, Control source) {
        if (menu.equals(kind)) { menu = ""; return; }
        menu = kind; menuW = Math.min(208, pw - 24);
        int rows = switch (kind) { case "colors" -> 7; case "photo" -> 3; case "stripe" -> 8; default -> 0; };
        menuH = rows * 20 + 8; menuX = Math.max(px + 8, Math.min(px + pw - menuW - 8, source.x()));
        menuY = source.y() >= toolbarY && source.y() < bodyY ? bodyY + 3 : source.y() + source.h() + 3;
        if (menuY + menuH > py + ph - 8) menuY = Math.max(py + 8, source.y() - menuH - 3);
    }
    private void renderMenu(GuiGraphics g, int mx, int my) {
        g.pose().pushPose(); g.pose().translate(0, 0, 450);
        g.fill(menuX + 3, menuY + 3, menuX + menuW + 3, menuY + menuH + 3, 0x99000000);
        g.fill(menuX - 1, menuY - 1, menuX + menuW + 1, menuY + menuH + 1, GOLD_DEEP);
        g.fill(menuX, menuY, menuX + menuW, menuY + menuH, PLATE_DEEP);
        String[] labels = switch (menu) {
            case "photo" -> new String[]{photo.ready() ? "Заменить фото…" : "Выбрать PNG / JPG…", "Убрать фото", photo.busy() ? "Идёт загрузка…" : photo.ready() ? "Фото готово" : "Фото необязательно"};
            case "stripe" -> STRIPE_NAMES;
            default -> COLORS;
        };
        for (int i = 0; i < labels.length; i++) {
            boolean enabled = true;
            if (menu.equals("photo")) enabled = i == 0 ? !photo.busy() : i == 1 && photo.ready() && !photo.busy();
            control(g, "menu:" + i, menuX + 4, menuY + 4 + i * 20, menuW - 8, 19, labels[i], "", enabled, false, false, mx, my);
            if (menu.equals("colors")) g.fill(menuX + 10, menuY + 9 + i * 20, menuX + 18, menuY + 17 + i * 20, 0xFF000000 | RichText.COLOR_VALUES[i]);
            if (menu.equals("stripe")) g.fill(menuX + 10, menuY + 9 + i * 20, menuX + 18, menuY + 17 + i * 20, 0xFF000000 | CabinetNet.STRIPE_COLORS[i]);
        }
        g.flush(); g.pose().popPose();
    }
    private void openLink() { menu = ""; linkOpen = true; linkText.setValue(body.selectedText()); linkUrl.setValue(""); linkText.focused = body.selectedText().isBlank(); linkUrl.focused = !linkText.focused; }
    private void renderLink(GuiGraphics g, int mx, int my) {
        int w = Math.min(340, pw - 24), x = (width - w) / 2, y = (height - 160) / 2;
        g.pose().pushPose(); g.pose().translate(0, 0, 500); dialog(g, x, y, w, 160, "ВСТАВИТЬ ССЫЛКУ");
        label(g, "Текст", x + 12, y + 31); linkText.render(g, mx, my);
        label(g, "Адрес · http или https", x + 12, y + 72); linkUrl.render(g, mx, my);
        if (!linkUrl.value().isEmpty() && !NewsFormatting.validUrl(linkUrl.value())) label(g, "Укажите полный адрес сайта", x + 12, y + 111);
        else if (noticeTicks > 0) label(g, font.plainSubstrByWidth(notice, w - 24), x + 12, y + 111);
        control(g, "dialog:cancel", x + 12, y + 129, 90, 21, "Отмена", "", true, false, false, mx, my);
        control(g, "dialog:link", x + w - 112, y + 129, 100, 21, "Вставить", "", validLink(), false, true, mx, my);
        g.flush(); g.pose().popPose();
    }
    private boolean validLink() { return !linkText.value().isBlank() && !linkText.value().contains("]") && NewsFormatting.validUrl(linkUrl.value()); }
    private void insertLink() {
        if (!validLink()) return;
        String s = "[" + linkText.value().strip() + "](" + linkUrl.value().strip() + ")";
        if (body.value().length() - body.selectedText().length() + s.length() > BODY_MAX) { message("Ссылка не помещается: достигнут лимит текста"); return; }
        body.insert(s); linkOpen = false; focus(body);
    }
    private void dialog(GuiGraphics g, int x, int y, int w, int h, String text) {
        g.fill(0, 0, width, height, 0xBB000000); g.fill(x, y, x + w, y + h, PLATE); g.fill(x, y, x + w, y + 2, GOLD);
        g.drawString(font, text, x + 12, y + 14, TEXT_LIGHT, false);
    }
    private void message(String text) { notice = text; noticeTicks = 100; }
    private void focus(TextInput input) { title.focused = input == title; body.focused = input == body; footer.focused = input == footer; }
    private void format(String open, String close) { focus(body); if (!body.format(open, close)) message("Достигнут лимит текста"); }
    private void action(Control c) {
        switch (c.id()) {
            case "author" -> factionAuthor = !factionAuthor;
            case "view" -> { previewOnly = !previewOnly; menu = ""; }
            case "close" -> onClose(); case "publish" -> publish(); case "discord" -> discordEmbed = !discordEmbed; case "stripe" -> openMenu(c.id(), c); case "hideAuthor" -> hideAuthor = !hideAuthor; case "hideState" -> hideState = !hideState;
            case "colors" -> openMenu(c.id(), c);
            case "photo" -> { if (photo.busy()) message(photo.message()); else if (!photo.ready()) photo.choose(); else openMenu("photo", c); }
            case "bold" -> format("**", "**"); case "italic" -> format("*", "*"); case "underline" -> format("__", "__"); case "strike" -> format("~~", "~~");
            case "link" -> openLink();
            case "code" -> format("`", "`"); case "codeblock" -> format("\n```\n", "\n```\n"); case "spoiler" -> format("||", "||");
            case "dialog:cancel" -> { linkOpen = false; focus(body); }
            case "dialog:link" -> insertLink();
            default -> { if (c.id().startsWith("menu:")) menuAction(Integer.parseInt(c.id().substring(5))); }
        }
    }
    private void menuAction(int i) {
        String kind = menu; menu = "";
        switch (kind) {
            case "colors" -> format("[c:" + RichText.COLOR_NAMES[i] + "]", "[/c]");
            case "stripe" -> stripe = i;
            case "photo" -> { if (i == 0) photo.choose(); else if (i == 1) removePhoto(); }
            default -> { }
        }
    }
    @Override public boolean mouseClicked(double mx, double my, int button) {
        if (button != 0) return false; dragInput = null;
        if (linkOpen || !menu.isEmpty()) {
            for (Control c : List.copyOf(popups)) if (c.contains(mx, my)) { if (c.enabled()) action(c); return true; }
            if (linkOpen) { linkText.mouseClicked(mx, my); linkUrl.mouseClicked(mx, my); dragInput = linkText.focused ? linkText : linkUrl.focused ? linkUrl : null; }
            else menu = "";
            return true;
        }
        for (Control c : List.copyOf(controls)) if (c.contains(mx, my)) { if (c.enabled()) action(c); return true; }
        if (editing()) { title.mouseClicked(mx, my); body.mouseClicked(mx, my); footer.mouseClicked(mx, my); dragInput = title.focused ? title : body.focused ? body : footer.focused ? footer : null; }
        return true;
    }
    @Override public boolean mouseDragged(double mx, double my, int button, double dx, double dy) { return button == 0 && dragInput != null && dragInput.mouseDragged(mx, my); }
    @Override public boolean mouseReleased(double mx, double my, int button) { dragInput = null; return true; }
    @Override public boolean mouseScrolled(double mx, double my, double sx, double sy) {
        if (linkOpen || !menu.isEmpty()) return true;
        if (editing() && body.mouseScrolled(mx, my, sy)) return true;
        if (previewing() && inside(mx, my, previewX(), previewY, previewW(), previewH)) { previewScroll = Math.max(0, Math.min(Math.max(0, previewHeight - previewH), previewScroll - (int) (sy * 24))); return true; }
        return false;
    }
    @Override public boolean charTyped(char c, int mods) {
        if (linkOpen) return linkText.charTyped(c) || linkUrl.charTyped(c);
        if (!menu.isEmpty() || !editing()) return true;
        return title.charTyped(c) || body.charTyped(c) || footer.charTyped(c);
    }
    @Override public boolean keyPressed(int key, int scan, int mods) {
        boolean ctrl = (mods & GLFW.GLFW_MOD_CONTROL) != 0, shift = (mods & GLFW.GLFW_MOD_SHIFT) != 0;
        if (key == GLFW.GLFW_KEY_ESCAPE) {
            if (linkOpen || !menu.isEmpty()) { linkOpen = false; menu = ""; }
            else if (previewOnly) previewOnly = false; else onClose(); return true;
        }
        if (linkOpen) {
            if (key == GLFW.GLFW_KEY_TAB) { linkText.focused = !linkText.focused; linkUrl.focused = !linkText.focused; return true; }
            if (key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER) { insertLink(); return true; }
            return linkText.keyPressed(key, mods) || linkUrl.keyPressed(key, mods);
        }
        if (!menu.isEmpty()) return true;
        if (ctrl) {
            if (key == GLFW.GLFW_KEY_S) { saveDraft(); if (saveFailed) message("Не удалось сохранить черновик"); return true; }
            if (key == GLFW.GLFW_KEY_P) { previewOnly = !previewOnly; return true; }
            if (key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER) { publish(); return true; }
            if (editing() && body.focused) switch (key) {
                case GLFW.GLFW_KEY_B -> { format("**", "**"); return true; } case GLFW.GLFW_KEY_I -> { format("*", "*"); return true; }
                case GLFW.GLFW_KEY_U -> { format("__", "__"); return true; } case GLFW.GLFW_KEY_K -> { openLink(); return true; }
            }
        }
        if (!editing()) return true;
        if (key == GLFW.GLFW_KEY_TAB) { TextInput[] inputs = {title, body, footer}; int i = title.focused ? 0 : body.focused ? 1 : 2; focus(inputs[Math.floorMod(i + (shift ? -1 : 1), 3)]); return true; }
        return title.keyPressed(key, mods) || body.keyPressed(key, mods) || footer.keyPressed(key, mods) || super.keyPressed(key, scan, mods);
    }
    private void publish() {
        if (!reason().isEmpty()) { message(reason()); return; }
        if (Minecraft.getInstance().getConnection() == null) { message("Нет соединения с сервером"); return; }
        saveDraft();
        // The previous submission remains recoverable if the server rejects it (permissions/cooldown).
        if (!drafts.rememberSubmission(draft())) { message("Не удалось сохранить резервную копию"); return; }
        String image = photo.ready() ? photo.serverId() : "";
        if (!image.isEmpty()) insertPhoto(image);
        CabinetNet.PublishNews packet = CabinetNet.PublishNews.of(title.value().trim(), body.value().trim(), footer.value().trim(), image, hideState, hideAuthor, discordEmbed, stripe);
        if (factionAuthor) packet = new CabinetNet.PublishNews(packet.title(), packet.body(), packet.footer(), packet.imageId(), packet.options() | 64);
        PacketDistributor.sendToServer(packet);
        drafts.save(NewsDraftStore.Draft.EMPTY); finished = true; Minecraft.getInstance().setScreen(parent);
    }
    @Override public void onClose() {
        saveDraft(); if (saveFailed) { message("Не удалось сохранить. Проверьте доступ к папке игры."); return; }
        finished = true; Minecraft.getInstance().setScreen(parent);
    }
}
