package com.humanitas.client;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;

import static com.humanitas.client.CivitasUi.*;

/**
 * Radial palette wheel, modelled on the quick-menu of Effortless Building. Six sectors hold the
 * palettes; the centre disc cycles status display modes. Hold the bound key to keep it open, release
 * to close; left click selects a palette or a status display mode.
 */
public final class CivitasPaletteScreen extends Screen {
    private static final CivitasPalette[] PALETTES = java.util.Arrays.stream(CivitasPalette.values()).filter(p -> p != CivitasPalette.CUSTOM).toArray(CivitasPalette[]::new);
    private static final double HIT_HALF = 180.0 / PALETTES.length;
    private static final double DRAW_HALF = HIT_HALF - 2.0;
    private static double center(int i) { return -90.0 + i * 360.0 / PALETTES.length; }

    private final boolean holdToClose;
    private final Screen parent;
    private final long openedAt;

    private int hovered = -1;
    private boolean centerHover;
    private double lastInner;
    private double lastOuter;

    public CivitasPaletteScreen(boolean holdToClose) { this(holdToClose, null); }

    public CivitasPaletteScreen(boolean holdToClose, Screen parent) {
        super(Component.translatable("screen.civitas.palette"));
        this.holdToClose = holdToClose;
        this.parent = parent;
        this.openedAt = Util.getMillis();
    }

    @Override
    public void renderBackground(GuiGraphics g, int mx, int my, float partialTick) {
        // The screen draws its own dim background before the wheel.
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    private double[] layout() {
        double horizontal = Math.min(this.width, this.height) * 0.40;
        double vertical = Math.min(this.height / 2.0 - 56.0, this.height / 2.0 - 52.0);
        double easeT = Mth.clamp((Util.getMillis() - this.openedAt) / 150.0F, 0.0F, 1.0F);
        float ease = 1.0F - (1.0F - (float) easeT) * (1.0F - (float) easeT) * (1.0F - (float) easeT);
        double baseOuter = Math.max(58.0, Math.min(126.0, Math.min(horizontal, vertical)));
        double outer = baseOuter * (0.88 + 0.12 * ease);
        double inner = Math.max(36.0, outer * 0.44);
        return new double[]{inner, outer};
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        double[] layout = layout();
        this.lastInner = layout[0];
        this.lastOuter = layout[1];
        double inner = this.lastInner;
        double outer = this.lastOuter;
        int cx = this.width / 2;
        int cy = this.height / 2;

        this.hovered = sectorAt(mouseX, mouseY, cx, cy, inner, outer);
        this.centerHover = Math.hypot(mouseX - cx, mouseY - cy) <= inner - 4;

        g.fillGradient(0, 0, this.width, this.height, 0x99101012, 0xE008090B);

        fillDisc(g, cx, cy, outer + 14, 0x301E1F22);
        fillDisc(g, cx, cy, outer + 6, 0xD0121315);
        fillRing(g, cx, cy, outer + 6, outer + 7, alpha(GOLD, 0x90));

        for (int i = 0; i < PALETTES.length; i++) {
            boolean selected = PALETTES[i] == CivitasPaletteState.current();
            boolean hot = i == this.hovered;
            int fill = PLATE_SOLID;
            if (selected) fill = mix(fill, GOLD, 0.18F);
            if (hot) fill = mix(fill, TEXT_LIGHT, 0.14F);
            fillSector(g, cx, cy, inner, outer, center(i), DRAW_HALF, fill);
            if (selected || hot) {
                fillSector(g, cx, cy, outer - 3, outer, center(i), DRAW_HALF,
                        selected ? PALETTES[i].metal() : TEXT_LIGHT);
            }
        }

        fillRing(g, cx, cy, inner - 2, inner - 1, alpha(GOLD, 0xB0));
        fillRing(g, cx, cy, outer, outer + 2, GOLD);

        double mid = (inner + outer) / 2.0;
        for (int i = 0; i < PALETTES.length; i++) {
            boolean selected = PALETTES[i] == CivitasPaletteState.current();
            boolean hot = i == this.hovered;
            double rad = Math.toRadians(center(i));
            int lx = cx + (int) Math.round(Math.cos(rad) * mid);
            int ly = cy + (int) Math.round(Math.sin(rad) * mid);
            String name = font.plainSubstrByWidth(PALETTES[i].displayName(), Math.max(28, (int)(outer * 0.44)));
            int colour = selected ? GOLD : (hot ? TEXT_LIGHT : mix(TEXT_LIGHT, PLATE_SOLID, 0.18F));
            g.drawString(this.font, name, lx - this.font.width(name) / 2, ly - 11, colour, selected);

            int sw = 24;
            int sx = lx - sw / 2;
            int sy = ly + 1;
            g.fill(sx, sy, sx + 10, sy + 3, alpha(CREAM_ACTIVE, 0xC0));
            g.fill(sx + 10, sy, sx + 17, sy + 3, PALETTES[i].metal());
            g.fill(sx + 17, sy, sx + sw, sy + 3, PALETTES[i].accent());
            if (selected) {
                g.fill(sx - 2, sy + 5, sx + sw + 2, sy + 6, GOLD);
            }
        }

        int centerFill = this.centerHover ? mix(PLATE_SOLID, OLIVE, 0.45F) : HEADER;
        fillDisc(g, cx, cy, inner - 3, centerFill);
        fillRing(g, cx, cy, inner - 4, inner - 3, alpha(GOLD, 0x80));

        CivitasStatusStyle hudStyle = CivitasStatusStyle.current();
        String heading = "ВИД HUD";
        g.drawString(font, heading, cx - font.width(heading) / 2, cy - 25, TEXT_LIGHT, false);
        String name = switch (hudStyle) {
            case BARS -> "ПОЛОСЫ";
            case ICONS -> "ИКОНКИ";
            case VANILLA -> "КЛАССИКА";
        };
        g.drawString(font, name, cx - font.width(name) / 2, cy - 13, GOLD, false);
        drawStatusPreview(g, cx, cy, hudStyle);
        String hint = "ЛКМ";
        g.drawString(font, hint, cx - font.width(hint) / 2, cy + 22, DIM, false);

        int titleY = (int) (cy - outer) - 44;
        if (titleY > 4) {
            String title = hovered >= 0 ? PALETTES[hovered].displayName() : "ПАЛИТРА";
            g.drawString(this.font, title, cx - this.font.width(title) / 2, titleY, GOLD, true);
        }
        int bottomY = (int) (cy + outer) + 20;
        if (bottomY + 14 < this.height - 30) {
            String h1 = this.holdToClose ? "Отпустите клавишу, чтобы закрыть" : "Esc — закрыть";
            g.drawString(this.font, h1, cx - this.font.width(h1) / 2, bottomY, DIM, false);
        }
        if (bottomY + 30 < this.height - 30) {
            String h2 = "ЛКМ — палитра · центр — вид индикаторов";
            g.drawString(this.font, h2, cx - this.font.width(h2) / 2, bottomY + 13, alpha(TEXT_LIGHT, 0xAA), false);
        }
        super.render(g, mouseX, mouseY, partialTick);
    }

    private static void drawStatusPreview(GuiGraphics g, int cx, int cy, CivitasStatusStyle style) {
        int[] colors = style == CivitasStatusStyle.VANILLA
                ? new int[]{0xFFDB5151, 0xFFC7CDD1, 0xFFB58549}
                : new int[]{HEART, SHIELD, FOOD_COLOR};
        String[][] shapes = {
            {".X.X.", "XXXXX", ".XXX.", "..X.."},
            {"XX.XX", "XXXXX", ".XXX.", ".XXX."},
            {"...X.", ".XXXX", "XXXXX", ".XXX."}
        };
        for (int row = 0; row < 3; row++) {
            int y = cy + row * 6;
            if (style == CivitasStatusStyle.BARS) {
                g.fill(cx - 20, y, cx + 20, y + 4, GOLD_DEEP);
                g.fill(cx - 19, y + 1, cx + 19, y + 3, PLATE_DEEP);
                int fill = row == 0 ? 30 : row == 1 ? 20 : 34;
                g.fill(cx - 19, y + 1, cx - 19 + fill, y + 3, colors[row]);
                g.fill(cx - 19, y + 1, cx - 19 + fill, y + 2, mix(colors[row], TEXT_LIGHT, 0.30F));
            } else {
                for (int icon = 0; icon < 5; icon++) {
                    int color = icon < (row == 1 ? 3 : 4) ? colors[row] : mix(colors[row], PLATE_DEEP, 0.75F);
                    int x = cx - 18 + icon * 8;
                    for (int yy = 0; yy < 4; yy++) for (int xx = 0; xx < 5; xx++)
                        if (shapes[row][yy].charAt(xx) == 'X') g.fill(x + xx, y + yy, x + xx + 1, y + yy + 1, color);
                }
            }
        }
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button != 0) {
            return super.mouseClicked(mouseX, mouseY, button);
        }
        int cx = this.width / 2;
        int cy = this.height / 2;
        double[] bounds = layout(); this.lastInner = bounds[0]; this.lastOuter = bounds[1];
        if (Math.hypot(mouseX - cx, mouseY - cy) <= this.lastInner - 4) {
            CivitasStatusStyle.cycle();
            if (!CivitasPaletteState.hudVisible()) CivitasPaletteState.setHudVisible(true);
            click(1.1F);
            return true;
        }
        int sector = sectorAt(mouseX, mouseY, cx, cy, this.lastInner, this.lastOuter);
        if (sector >= 0) {
            CivitasPaletteState.select(PALETTES[sector]);
            click(1.25F);
            return true;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public void tick() {
        super.tick();
        if (this.holdToClose && !paletteKeyDown()) {
            onClose();
        }
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == InputConstants.KEY_ESCAPE) {
            onClose();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void onClose() {
        if (this.minecraft != null) {
            this.minecraft.setScreen(this.parent);
        }
    }

    private static boolean paletteKeyDown() {
        InputConstants.Key key = CabinetKeys.PALETTE.getKey();
        if (key == null || key.getValue() == InputConstants.UNKNOWN.getValue()) {
            return false;
        }
        if (key.getType() != InputConstants.Type.KEYSYM) {
            return true;
        }
        return InputConstants.isKeyDown(Minecraft.getInstance().getWindow().getWindow(), key.getValue());
    }

    private static int sectorAt(double mx, double my, int cx, int cy, double inner, double outer) {
        double dist = Math.hypot(mx - cx, my - cy);
        if (dist < inner || dist > outer) {
            return -1;
        }
        double deg = Math.toDegrees(Math.atan2(my - cy, mx - cx));
        for (int i = 0; i < PALETTES.length; i++) {
            double rel = (deg - center(i) + 540.0) % 360.0 - 180.0;
            if (Math.abs(rel) <= HIT_HALF) {
                return i;
            }
        }
        return -1;
    }

    private static void click(float pitch) {
        Minecraft.getInstance().getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.UI_BUTTON_CLICK, pitch));
    }

    private static void fillDisc(GuiGraphics g, int cx, int cy, double r, int colour) {
        if (r <= 0) return;
        double r2 = r * r;
        int y0 = (int) Math.floor(cy - r);
        int y1 = (int) Math.ceil(cy + r);
        for (int py = y0; py < y1; py++) {
            double dy = py + 0.5 - cy;
            double dy2 = dy * dy;
            if (dy2 > r2) continue;
            double xo = Math.sqrt(r2 - dy2);
            int left = (int) Math.round(cx - xo);
            int right = (int) Math.round(cx + xo);
            if (left < right) {
                g.fill(left, py, right, py + 1, colour);
            }
        }
    }

    private static void fillRing(GuiGraphics g, int cx, int cy, double rIn, double rOut, int colour) {
        if (rOut <= 0) return;
        double rIn2 = Math.max(0.0, rIn * rIn);
        double rOut2 = rOut * rOut;
        int y0 = (int) Math.floor(cy - rOut);
        int y1 = (int) Math.ceil(cy + rOut);
        for (int py = y0; py < y1; py++) {
            double dy = py + 0.5 - cy;
            double dy2 = dy * dy;
            if (dy2 > rOut2) continue;
            double xo = Math.sqrt(rOut2 - dy2);
            double xi = dy2 < rIn2 ? Math.sqrt(rIn2 - dy2) : 0.0;
            int left = (int) Math.floor(cx - xo);
            int right = (int) Math.ceil(cx + xo);
            if (xi <= 0) {
                if (left < right) g.fill(left, py, right, py + 1, colour);
            } else {
                int innerLeft = (int) Math.ceil(cx - xi);
                int innerRight = (int) Math.floor(cx + xi);
                if (left < innerLeft) g.fill(left, py, innerLeft, py + 1, colour);
                if (innerRight < right) g.fill(innerRight, py, right, py + 1, colour);
            }
        }
    }

    private static void fillSector(GuiGraphics g, int cx, int cy, double rIn, double rOut,
                                   double centerDeg, double halfDeg, int colour) {
        double directionX = Math.cos(Math.toRadians(centerDeg));
        double directionY = Math.sin(Math.toRadians(centerDeg));
        double limit = Math.cos(Math.toRadians(halfDeg));
        double limit2 = limit * limit;
        double min2 = rIn * rIn, max2 = rOut * rOut;
        int radius = (int) Math.ceil(rOut);
        for (int y = -radius; y < radius; y++) {
            int run = Integer.MIN_VALUE;
            double dy = y + 0.5;
            for (int x = -radius; x <= radius; x++) {
                double dx = x + 0.5;
                double distance2 = dx * dx + dy * dy;
                double dot = dx * directionX + dy * directionY;
                boolean inside = x < radius && distance2 >= min2 && distance2 <= max2
                        && dot >= 0 && dot * dot >= distance2 * limit2;
                if (inside && run == Integer.MIN_VALUE) run = x;
                else if (!inside && run != Integer.MIN_VALUE) {
                    g.fill(cx + run, cy + y, cx + x, cy + y + 1, colour);
                    run = Integer.MIN_VALUE;
                }
            }
        }
    }
}
