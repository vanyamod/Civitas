package com.humanitas.client;

import com.humanitas.CivitasClientConfig;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.network.chat.Component;
import static com.humanitas.client.CivitasUi.*;

public final class CustomPaletteScreen extends Screen {
    private final Screen parent;
    private final EditBox[] fields = new EditBox[4];
    private static final String[] LABELS = {"Фон", "Текст", "Рамки", "Акцент"};
    private String error = "";
    public CustomPaletteScreen(Screen parent) { super(Component.literal("Своя палитра")); this.parent = parent; }
    @Override protected void init() {
        String[] saved = CivitasClientConfig.CUSTOM_COLORS.get().split(",");
        for (int i = 0; i < 4; i++) {
            fields[i] = new EditBox(font, width / 2, height / 2 - 64 + i * 28, 90, 20, Component.literal(LABELS[i]));
            fields[i].setMaxLength(7); fields[i].setValue(saved.length == 4 ? saved[i] : "FFFFFF"); addRenderableWidget(fields[i]);
        }
        addRenderableWidget(Button.builder(Component.literal("Сохранить"), b -> {
            try { String[] colors = new String[4]; for (int i = 0; i < 4; i++) colors[i] = fields[i].getValue();
                CivitasPaletteState.setCustom(colors, true); onClose();
            } catch (IllegalArgumentException e) { error = "Введите 6 HEX-цифр, например 86CBD4"; }
        }).bounds(width / 2 - 100, height / 2 + 62, 96, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Назад"), b -> onClose()).bounds(width / 2 + 4, height / 2 + 62, 96, 20).build());
    }
    @Override public void render(GuiGraphics g, int mx, int my, float partial) {
        g.fill(0, 0, width, height, 0xF00A0D13);
        g.drawCenteredString(font, "СВОЯ ПАЛИТРА · HEX", width / 2, height / 2 - 94, TEXT_LIGHT);
        for (int i = 0; i < 4; i++) g.drawString(font, LABELS[i], width / 2 - 95, height / 2 - 58 + i * 28, TEXT_LIGHT, false);
        if (!error.isEmpty()) g.drawCenteredString(font, error, width / 2, height / 2 + 49, 0xFFFF8080);
        super.render(g, mx, my, partial);
    }
    @Override public void onClose() { minecraft.setScreen(parent); }
    @Override public void renderBackground(GuiGraphics g, int mx, int my, float partial) {}
    @Override public boolean isPauseScreen() { return false; }
}
