package com.humanitas.client;

import java.util.Locale;

/**
 * The six colour themes the player can switch between through the radial wheel.
 * The first entry is the original graphite / cream / gold / olive look; the other five are
 * original variations of it. A palette stores only a handful of key colours and derives the
 * rest (cards, fields, slots, hearts, ...) from them, so every screen keeps a consistent look.
 */
public enum CivitasPalette {
    GRAPHITE("ГРАФИТ", 0xFF16171A, 0xFF0D0E10, 0xFFF2EAD6, 0xFFD4AF37, 0xFF8A6F2E, 0xFF6B7F3A, 0xFFB04030, 0xFF7FA04A, 0xFFB0CDD0),
    BORDEAUX("БОРДО", 0xFF241016, 0xFF150A0E, 0xFFF3E5D0, 0xFFD4A05A, 0xFF955A2E, 0xFF8A2F3A, 0xFFB8433C, 0xFF9A8A3B, 0xFFB0CDD2),
    MIDNIGHT("ПОЛНОЧЬ", 0xFF101626, 0xFF080C18, 0xFFEAE6D8, 0xFFD0B870, 0xFF8E7A40, 0xFF4A6A90, 0xFFB04A4A, 0xFF7AA07A, 0xFFA8C8D4),
    MALACHITE("МАЛАХИТ", 0xFF0E1C16, 0xFF06100C, 0xFFECead8, 0xFFD0B860, 0xFF8E7830, 0xFF3A7A5A, 0xFFB0463C, 0xFF7AA04A, 0xFFA8CCC4),
    TERRACOTTA("ТЕРРАКОТА", 0xFF241812, 0xFF160E0A, 0xFFF4E6CE, 0xFFD08A4A, 0xFF95502A, 0xFF9A4A32, 0xFFBA4A38, 0xFF9A8A3E, 0xFFAEC8CC),
    ASH("ПЕПЕЛ", 0xFF161719, 0xFF0C0D0E, 0xFFE8E4DC, 0xFFB8B098, 0xFF7E7868, 0xFF5A6268, 0xFFA0453F, 0xFF808858, 0xFFA0B4BE),
    FROST("ИНЕЙ", 0xFF122334, 0xFF09131F, 0xFFE7F4F4, 0xFF86CBD4, 0xFF487C99, 0xFF448BA5, 0xFF86CFE1, 0xFF7BAFA4, 0xFFB5E9F2),
    AMETHYST("АМЕТИСТ", 0xFF211728, 0xFF100B18, 0xFFF2E6EF, 0xFFC6A4DA, 0xFF76538A, 0xFF8B69AA, 0xFFD187A4, 0xFF91A67D, 0xFFB7CFE6),
    CUSTOM("СВОЯ", 0xFF16171A, 0xFF0D0E10, 0xFFF2EAD6, 0xFFD4AF37, 0xFF8A6F2E, 0xFF6B7F3A, 0xFFB04030, 0xFF7FA04A, 0xFFB0CDD0);

    private final String displayName;
    private int plate;
    private int plateDeep;
    private int paper;
    private int metal;
    private int metalDeep;
    private int accent;
    private int life;
    private int lifeAlt;
    private int air;

    CivitasPalette(String displayName, int plate, int plateDeep, int paper, int metal, int metalDeep,
                   int accent, int life, int lifeAlt, int air) {
        this.displayName = displayName;
        this.plate = plate;
        this.plateDeep = plateDeep;
        this.paper = paper;
        this.metal = metal;
        this.metalDeep = metalDeep;
        this.accent = accent;
        this.life = life;
        this.lifeAlt = lifeAlt;
        this.air = air;
    }

    public static void configureCustom(int background, int foreground, int trim, int highlight) {
        CUSTOM.plate = background; CUSTOM.plateDeep = CivitasColors.darken(background, 0.35F);
        CUSTOM.paper = foreground; CUSTOM.metal = trim; CUSTOM.metalDeep = CivitasColors.darken(trim, 0.35F);
        CUSTOM.accent = highlight; CUSTOM.life = CivitasColors.mix(highlight, 0xFFFF6479, 0.45F);
        CUSTOM.lifeAlt = highlight; CUSTOM.air = CivitasColors.mix(foreground, 0xFF76D9EF, 0.5F);
    }

    public String displayName() { return displayName; }
    public String id() { return name().toLowerCase(Locale.ROOT); }
    public int plate() { return plate; }
    public int plateDeep() { return plateDeep; }
    public int paper() { return paper; }
    public int metal() { return metal; }
    public int metalDeep() { return metalDeep; }
    public int accent() { return accent; }
    public int life() { return life; }
    public int lifeAlt() { return lifeAlt; }
    public int air() { return air; }

    public int paperCard() { return CivitasColors.darken(paper, 0.055F); }
    public int paperDeep() { return CivitasColors.darken(paper, 0.09F); }
    public int paperHover() { return CivitasColors.lighten(paper, 0.055F); }
    public int paperActive() { return CivitasColors.lighten(paper, 0.11F); }
    public int field() { return CivitasColors.lighten(paper, 0.075F); }
    public int text() { return paper; }
    public int ink() { return CivitasColors.mix(CivitasColors.darken(paper, 0.84F), accent, 0.12F); }
    public int muted() { return CivitasColors.mix(ink(), paper, 0.40F); }
    public int shield() { return CivitasColors.mix(0xFFB6C6D5, air, 0.18F); }
    public int food() { return CivitasColors.mix(accent, metal, 0.38F); }
    public int foodBad() { return CivitasColors.mix(metal, metalDeep, 0.45F); }
    public int lifeWither() { return CivitasColors.mix(plate, muted(), 0.45F); }
    public int lifeAbsorb() { return CivitasColors.lighten(metal, 0.18F); }
    public int lifeCold() { return CivitasColors.mix(paper, air, 0.52F); }
    public int lifeMount() { return CivitasColors.mix(life, metalDeep, 0.35F); }
    public int slot() { return CivitasColors.mix(plate, paper, 0.03F); }
    public int slotEdge() { return CivitasColors.mix(plate, metalDeep, 0.35F); }
    public int slotResult() { return CivitasColors.mix(plate, metalDeep, 0.30F); }
    public int portrait() { return CivitasColors.darken(plateDeep, 0.35F); }

    public static CivitasPalette byId(String id) {
        if (id == null) return GRAPHITE;
        String needle = id.trim().toLowerCase(Locale.ROOT);
        for (CivitasPalette palette : values()) {
            if (palette.id().equals(needle)) {
                return palette;
            }
        }
        return GRAPHITE;
    }
}
