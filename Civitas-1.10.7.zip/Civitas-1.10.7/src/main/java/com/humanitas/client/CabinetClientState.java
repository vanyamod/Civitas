package com.humanitas.client;

import com.humanitas.CabinetPresets;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

/**
 * Client-side copy of the player's state (ideology, name) and the in-world calendar.
 * The server sends the start date and whether the date advances. The client works out today's
 * date itself from the world time, so the hotbar shows a live date without any extra packets.
 */
public final class CabinetClientState {
    private CabinetClientState() {}

    private static final DateTimeFormatter HUD_DATE = DateTimeFormatter.ofPattern("yyyy / MM / dd");

    public static volatile boolean canPostFaction = false, canPostState = false;
    private static volatile String ideology = "";
    private static volatile String name = "";
    private static volatile long startDay = LocalDate.of(1940, 1, 1).toEpochDay();
    private static volatile boolean advance = false;
    private static volatile long ticksPerDay = 24000L;

    public static void setState(String ideologyValue, String nameValue) {
        ideology = ideologyValue == null ? "" : ideologyValue;
        name = nameValue == null ? "" : nameValue;
    }

    public static void setCalendar(long startEpochDay, boolean advanceWithWorldTime) {
        setCalendar(startEpochDay, advanceWithWorldTime, ticksPerDay);
    }

    /** ticks is how many game ticks make one in-world day. Values below 20 fall back to 24000. */
    public static void setCalendar(long startEpochDay, boolean advanceWithWorldTime, long ticks) {
        startDay = startEpochDay;
        advance = advanceWithWorldTime;
        ticksPerDay = ticks >= 20L ? ticks : 24000L;
    }

    /** Kept so older code still compiles: a fixed date. */
    public static void setToday(long epochDay) {
        setCalendar(epochDay, false);
    }

    /** The in-world calendar day, as an epoch day. */
    public static long today() {
        long day = startDay;
        if (advance) {
            ClientLevel level = Minecraft.getInstance().level;
            if (level != null) {
                day += Math.max(0L, level.getGameTime() / ticksPerDay);
            }
        }
        return day;
    }

    /** The date as shown in the hotbar: year / month / day. */
    public static String dateText() {
        return HUD_DATE.format(LocalDate.ofEpochDay(today()));
    }

    /** Symbol for the current ideology; the neutral flag if none is set. */
    public static String ideologyIcon() {
        return CabinetPresets.icon(ideology);
    }

    /** Name of the player's state, or the mod name when they have none. */
    public static String stateName() {
        return name.isEmpty() ? "Civitas" : name;
    }

    public static boolean hasState() {
        return !name.isEmpty();
    }

    // ---------- extra information for the right-hand plate ----------

    /** In-world day number, counting from 1. */
    public static long gameDay() {
        ClientLevel level = Minecraft.getInstance().level;
        if (level == null) return 1L;
        return level.getDayTime() / ticksPerDay + 1L;
    }

    /** Exact in-game clock, HH:mm (Minecraft time: 0 ticks = 06:00). */
    public static String clockText() {
        ClientLevel level = Minecraft.getInstance().level;
        if (level == null) return "--:--";
        long t = Math.floorMod(level.getDayTime(), 24000L);
        long minutes = ((t * 1440L) / 24000L + 360L) % 1440L;
        return String.format(Locale.ROOT, "%02d:%02d", minutes / 60L, minutes % 60L);
    }

    /** Weather in one short word. */
    public static String weatherText() {
        ClientLevel level = Minecraft.getInstance().level;
        if (level == null) return "Ясно";
        if (level.isThundering()) return "Гроза";
        if (level.isRaining()) return "Дождь";
        return "Ясно";
    }

    /** Day / night phase from the in-game clock. */
    public static String phaseText() {
        ClientLevel level = Minecraft.getInstance().level;
        if (level == null) return "День";
        long t = Math.floorMod(level.getDayTime(), 24000L);
        return (t >= 13000L && t < 23000L) ? "Ночь" : "День";
    }
}
