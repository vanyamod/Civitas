package com.humanitas.client;

import com.humanitas.CabinetNet;
import net.minecraft.client.Minecraft;
import net.minecraft.nbt.CompoundTag;
import net.neoforged.neoforge.network.PacketDistributor;
import net.minecraft.client.gui.screens.Screen;

/** Connection-scoped last-known data and explicit acknowledgements; no fake server success. */
public final class CabinetRequests {
    private static Object connection;
    private static CompoundTag cached;
    private static boolean opening;
    private static Screen parent;
    private static final PendingActions pending = new PendingActions();
    private static void syncConnection() {
        Object current = Minecraft.getInstance().getConnection();
        if (connection != current) { connection = current; cached = null; opening = false; pending.clear(); }
    }
    public static void open() {
        syncConnection();
        Minecraft mc = Minecraft.getInstance();
        if (connection == null || opening) return;
        parent = mc.screen;
        opening = cached == null;
        if (cached != null) { opening = true; CabinetScreen.onSnapshot(cached.copy(), true); }
        PacketDistributor.sendToServer(new CabinetNet.RequestCabinet());
    }
    public static boolean received(CompoundTag data, boolean open) {
        syncConnection(); cached = data.copy();
        boolean requested = opening; if (open) opening = false;
        return open && requested && Minecraft.getInstance().screen == parent;
    }
    public static void edit(String field, String value) {
        syncConnection(); if (connection == null) return;
        long id = pending.begin(field, value, net.minecraft.Util.getMillis());
        if (id != 0) PacketDistributor.sendToServer(new CabinetNet.TrackedEdit(id, field, value));
    }
    public static void acknowledge(long id) { syncConnection(); pending.complete(id); }
    public static String status() {
        syncConnection();
        if (pending.count() == 0) return "";
        long seconds = pending.age(net.minecraft.Util.getMillis()) / 1000;
        return "Ожидание сервера: " + pending.count() + (seconds >= 2 ? " · " + seconds + " с" : "");
    }
    private CabinetRequests() {}
}
