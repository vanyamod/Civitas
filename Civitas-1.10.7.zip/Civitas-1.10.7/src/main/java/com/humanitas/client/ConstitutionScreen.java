package com.humanitas.client;

import com.humanitas.CabinetNet;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.neoforged.neoforge.network.PacketDistributor;
import static com.humanitas.client.CivitasUi.*;

public final class ConstitutionScreen extends Screen {
    private final Screen parent;
    private final boolean allowed, initial;
    private final long adopted, revised;
    private boolean editing;
    private DocumentPanel panel;
    private final TextInput text = new TextInput(true, 16000, "Конституция ещё не принята");
    public ConstitutionScreen(Screen parent, String content, boolean allowed) {
        this(parent, content, allowed, Long.MIN_VALUE, Long.MIN_VALUE);
    }
    public ConstitutionScreen(Screen parent, String content, boolean allowed, long adopted, long revised) {
        super(Component.literal("Конституция")); this.parent = parent; this.allowed = allowed;
        this.initial = content.isBlank(); this.adopted = adopted; this.revised = revised; text.setValue(content);
    }
    @Override protected void init() {
        panel = new DocumentPanel(width, height);
        text.setBounds(panel.x + 16, panel.y + 78, panel.w - 32, Math.max(24, panel.h - 132));
    }
    private int actionX() { return panel.x + panel.w - 148; }
    @Override public void render(GuiGraphics g, int mx, int my, float partial) {
        g.fill(0, 0, width, height, BACKDROP);
        String heading = editing ? (initial ? "ПРОЕКТ КОНСТИТУЦИИ" : "ПРОЕКТ ПОПРАВОК") : "КОНСТИТУЦИЯ";
        String meta = initial ? "Основной закон ещё не принят" : "Принята: " + DocumentPanel.date(adopted);
        panel.draw(g, font, heading, meta, 66);
        String detail = editing ? "Принятие: 2/3 голосов · предложение от " + DocumentPanel.date(CabinetClientState.today())
                : initial ? "Первый проект также проходит голосование" : "Последняя редакция: " + DocumentPanel.date(revised);
        g.drawString(font, font.plainSubstrByWidth(detail, panel.w - 32), panel.x + 16, panel.y + 49, DIM, false);
        text.render(g, mx, my);
        button(g, font, panel.x + 14, panel.footer(), 100, 20, "НАЗАД", inside(mx,my,panel.x+14,panel.footer(),100,20), Style.SECONDARY);
        if (allowed) button(g, font, actionX(), panel.footer(), 134, 20,
                editing ? "НА ГОЛОСОВАНИЕ" : initial ? "СОЗДАТЬ ПРОЕКТ" : "ПОПРАВКИ",
                inside(mx,my,actionX(),panel.footer(),134,20), editing && text.value().isBlank() ? Style.DISABLED : Style.PRIMARY);
    }
    @Override public boolean mouseClicked(double x,double y,int b) {
        if (b != 0) return false;
        if (inside(x,y,panel.x+14,panel.footer(),100,20)) { onClose(); return true; }
        if (allowed && inside(x,y,actionX(),panel.footer(),134,20)) {
            if (editing) {
                if (!text.value().isBlank()) { PacketDistributor.sendToServer(new CabinetNet.EditCabinet("constitution",text.value())); onClose(); }
            } else { editing = true; text.focused = true; }
            return true;
        }
        return text.mouseClicked(x,y);
    }
    @Override public boolean mouseDragged(double x,double y,int b,double dx,double dy) { return text.mouseDragged(x,y); }
    @Override public boolean mouseScrolled(double x,double y,double dx,double dy) { return text.mouseScrolled(x,y,dy); }
    @Override public boolean charTyped(char c,int mods) { return editing && text.charTyped(c); }
    @Override public boolean keyPressed(int key,int scan,int mods) { return editing && text.keyPressed(key,mods) || super.keyPressed(key,scan,mods); }
    @Override public void onClose() { minecraft.setScreen(parent); }
    @Override public void renderBackground(GuiGraphics g,int x,int y,float p) {}
    @Override public boolean isPauseScreen() { return false; }
}
