package com.humanitas;

import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public final class RepublicData extends SavedData {
    private static final String STORAGE_KEY = "humanitas_res_publica";
    /** Date given to news saved before the in-world calendar existed. */
    private static final long LEGACY_DAY = java.time.LocalDate.of(1940, 1, 1).toEpochDay();
    private int nextBillId = 1;
    private int nextTreatyId = 1;
    private final List<Polity> polities = new ArrayList<>();
    private final List<Bill> bills = new ArrayList<>();
    private final List<Treaty> treaties = new ArrayList<>();
    private final List<String> archive = new ArrayList<>();
    private final List<UUID> archiveOwner = new ArrayList<>();
    private final List<News> news = new ArrayList<>();
    private int nextNewsId = 1;

    public static RepublicData get(MinecraftServer server) {
        return server.overworld().getDataStorage().computeIfAbsent(new SavedData.Factory<>(RepublicData::new, RepublicData::load, null), STORAGE_KEY);
    }

    public Bill createBill(String title, String summary, String author, UUID state) {
        Bill bill = new Bill(nextBillId++, title, summary, author);
        bill.state = state;
        int number = 0;
        for (Bill other : bills) {
            if (state != null && state.equals(other.state)) number = Math.max(number, other.number);
        }
        bill.number = number + 1;
        bills.add(bill);
        logFor(state, "В палату внесён законопроект #" + bill.number + ": «" + title + "».");
        setDirty();
        return bill;
    }

    public Treaty createTreaty(String title, String sideA, String sideB, String summary, String author) {
        Treaty treaty = new Treaty(nextTreatyId++, title, sideA, sideB, summary, author);
        treaties.add(treaty);
        log("Подготовлен договор #" + treaty.id + ": «" + title + "».");
        setDirty();
        return treaty;
    }

    public Bill bill(int id) { return bills.stream().filter(bill -> bill.id == id).findFirst().orElse(null); }
    public Treaty treaty(int id) { return treaties.stream().filter(treaty -> treaty.id == id).findFirst().orElse(null); }
    public List<Bill> bills() { return List.copyOf(bills); }
    public List<Treaty> treaties() { return List.copyOf(treaties); }
    public List<String> archive() { return List.copyOf(archive); }
    /** Leader of a state: the owner, unless power has passed on since. */
    public static UUID leaderOf(Polity p) {
        return p.leader != null ? p.leader : p.owner;
    }

    /** The state this player leads, or null. */
    public Polity ledBy(UUID playerId) {
        for (Polity p : polities) {
            if (playerId.equals(leaderOf(p))) return p;
        }
        return null;
    }

    public static int votesFor(Polity p, UUID candidate) {
        int n = 0;
        for (UUID c : p.votes.values()) {
            if (candidate.equals(c)) n++;
        }
        return n;
    }

    private static void clearElection(Polity p) {
        p.electionEnd = Long.MIN_VALUE;
        p.electionStart = Long.MIN_VALUE;
        p.candidates.clear();
        p.candidateNames.clear();
        p.votes.clear();
        p.parliamentVotes.clear();
    }

    /**
     * Runs the election calendar of one state: starts an election when a term ends,
     * closes it when its days are over and gives power to the candidate with the most votes.
     * The current leader wins a tie. Called whenever the state is shown or changed.
     */
    /** Recomputes the term and election end days from the start days and the current config. */
    private static void refreshSchedule(Polity p) {
        if (p.termStart != Long.MIN_VALUE) {
            p.termEnd = p.termStart + CabinetPresets.termDays(p.government);
        }
        if (p.electionStart != Long.MIN_VALUE) {
            p.electionEnd = p.electionStart + CabinetPresets.electionDays(p.government);
        }
    }

    public void tickPower(Polity p, long today) {
        refreshSchedule(p);
        String gov = p.government;
        if (!CabinetPresets.hasElections(gov)) {
            clearElection(p);
            return;
        }
        if (p.termStart == Long.MIN_VALUE) {
            p.termStart = today;
            setDirty();
            return;
        }
        if (p.electionEnd == Long.MIN_VALUE) {
            if (today >= p.termEnd) {
                clearElection(p);
                p.electionStart = today;
                logFor(p.owner, "Начались выборы в государстве «" + p.name + "».");
                setDirty();
            }
            return;
        }
        if (today < p.electionEnd) return;

        UUID current = leaderOf(p);
        UUID winner = current;
        String winnerName = p.leaderName.isEmpty() ? p.ownerName : p.leaderName;
        int best = votesFor(p, current);
        for (int i = 0; i < p.candidates.size(); i++) {
            int n = votesFor(p, p.candidates.get(i));
            if (n > best) {
                best = n;
                winner = p.candidates.get(i);
                winnerName = p.candidateNames.get(i);
            }
        }
        p.leader = winner;
        p.leaderName = winnerName;
        p.termStart = today;
        logFor(p.owner, "Выборы завершены. Новый лидер: " + winnerName + " (голосов: " + best + ").");
        tallySeats(p);
        clearElection(p);
        setDirty();
    }

    /** Changes the form of government. Returns false if the ideology does not allow it. */
    public boolean setGovernment(Polity p, String gov, long today) {
        if (!CabinetPresets.governmentsFor(p.ideology).contains(gov)) return false;
        p.government = gov;
        clearElection(p);
        p.termStart = CabinetPresets.hasElections(gov) ? today : Long.MIN_VALUE;
        logFor(p.owner, "Форма правления изменена: " + gov + ".");
        setDirty();
        return true;
    }

    /** A role inside a state. Ordered by place: the first role in the list is the highest. */
    public static final class Role {
        final String id;
        String name;
        long perms;
        /** ARGB colour, one of CabinetPresets.ROLE_COLORS. */
        int color = 0xFFA88B4A;

        Role(String id, String name, long perms) {
            this.id = id;
            this.name = name;
            this.perms = perms;
        }
    }

    /** Creates the default roles once, for a state that has none yet. */
    public static void ensureRoles(Polity p) {
        if (!p.roles.isEmpty()) return;
        p.roles.add(new Role(UUID.randomUUID().toString(), "Совет",
                Perms.NEWS | Perms.LAW_PROPOSE | Perms.LAW_CLOSE | Perms.MEMBER_INVITE));
        p.roles.add(new Role(UUID.randomUUID().toString(), "Служащий", 0L));
    }

    /** Permissions of a player in a state: the leader has all, the deputy the fixed set, others their role. */
    public static long permsOf(Polity p, UUID who) {
        if (who.equals(leaderOf(p))) return Perms.ALL;
        if (who.equals(p.deputy)) return Perms.DEPUTY;
        String roleId = p.memberRoles.get(who);
        if (roleId != null) {
            for (Role r : p.roles) {
                if (r.id.equals(roleId)) return r.perms;
            }
        }
        return 0L;
    }

    /** Explicit role membership: leadership alone does not grant a senate seat. */
    static java.util.Set<UUID> senators(Polity p) {
        java.util.Set<UUID> result = new java.util.HashSet<>();
        p.memberRoles.forEach((member, roleId) -> {
            if (!p.members.contains(member) && !member.equals(leaderOf(p)) && !member.equals(p.deputy)) return;
            for (Role role : p.roles) if (role.id.equals(roleId) && Perms.has(role.perms, Perms.LAW_VOTE)) result.add(member);
        });
        return result;
    }

    /** Place of a player: leader and deputy are -1, a role is its index, no role is Integer.MAX_VALUE. */
    public static int rankOf(Polity p, UUID who) {
        if (who.equals(leaderOf(p)) || who.equals(p.deputy)) return -1;
        String roleId = p.memberRoles.get(who);
        if (roleId != null) {
            for (int i = 0; i < p.roles.size(); i++) {
                if (p.roles.get(i).id.equals(roleId)) return i;
            }
        }
        return Integer.MAX_VALUE;
    }

    /** A faction: a group of members of one state, with a leader, a colour and a list of join requests. */
    public static final class Faction {
        final String id;
        String name;
        int color;
        UUID leader;
        UUID deputy;
        String avatarId = "";
        long createdAt = System.currentTimeMillis();
        boolean dissolutionVote;
        final java.util.Set<UUID> dissolutionYes = new java.util.HashSet<>();
        String leaderName = "";
        final List<UUID> members = new ArrayList<>();
        final List<String> memberNames = new ArrayList<>();
        final java.util.Map<UUID, Long> memberPermissions = new java.util.HashMap<>();
        final java.util.Map<String, Long> roles = new java.util.LinkedHashMap<>();
        final java.util.Map<UUID, String> memberRoles = new java.util.HashMap<>();
        final List<UUID> requests = new ArrayList<>();
        final List<String> requestNames = new ArrayList<>();

        Faction(String id, String name, int color) {
            this.id = id;
            this.name = name;
            this.color = color;
        }
    }

    public static long factionPermissions(Faction f, UUID member) {
        return f.memberPermissions.getOrDefault(member, 0L)
                | f.roles.getOrDefault(f.memberRoles.getOrDefault(member, ""), 0L);
    }

    public static Faction factionOf(Polity p, UUID who) {
        for (Faction f : p.factions) {
            if (f.members.contains(who)) return f;
        }
        return null;
    }

    public static Faction factionById(Polity p, String id) {
        for (Faction f : p.factions) {
            if (f.id.equals(id)) return f;
        }
        return null;
    }

    private static ListTag uuidList(List<UUID> ids, List<String> names) {
        ListTag list = new ListTag();
        for (int i = 0; i < ids.size(); i++) {
            CompoundTag t = new CompoundTag();
            t.putUUID("uuid", ids.get(i));
            t.putString("name", names.get(i));
            list.add(t);
        }
        return list;
    }

    private static void readUuidList(ListTag list, List<UUID> ids, List<String> names) {
        for (int i = 0; i < list.size(); i++) {
            ids.add(list.getCompound(i).getUUID("uuid"));
            names.add(list.getCompound(i).getString("name"));
        }
    }

    /**
     * Distributes the parliament seats of a state by the votes of the closed election.
     * Largest remainder method: each faction gets whole quotas first, then the leftover seats
     * go to the largest remainders. A faction with few votes can still win a seat.
     */
    static void tallySeats(Polity p) {
        p.seats.clear();
        int total = CabinetPresets.seatsFor(p.parliament);
        java.util.Map<String, Integer> votes = new java.util.HashMap<>();
        int cast = 0;
        for (String fid : p.parliamentVotes.values()) {
            if (factionById(p, fid) == null) continue;
            votes.merge(fid, 1, Integer::sum);
            cast++;
        }
        p.parliamentVotes.clear();
        if (total <= 0 || cast == 0) return;

        double quota = (double) cast / total;
        int given = 0;
        java.util.Map<String, Double> remainders = new java.util.HashMap<>();
        for (java.util.Map.Entry<String, Integer> e : votes.entrySet()) {
            int whole = (int) (e.getValue() / quota);
            p.seats.put(e.getKey(), whole);
            given += whole;
            remainders.put(e.getKey(), e.getValue() - whole * quota);
        }
        while (given < total && !remainders.isEmpty()) {
            String best = null;
            double bestRemainder = -1;
            for (java.util.Map.Entry<String, Double> e : remainders.entrySet()) {
                if (e.getValue() > bestRemainder) {
                    bestRemainder = e.getValue();
                    best = e.getKey();
                }
            }
            p.seats.merge(best, 1, Integer::sum);
            remainders.remove(best);
            given++;
        }
    }

    public List<Polity> polities() { return polities; }

    public List<News> news() { return news; }

    public News news(int id) {
        for (News item : news) {
            if (item.id == id) return item;
        }
        return null;
    }

    /** Newest first. Keeps the last 100 so the save file stays small. */
    public News addNews(UUID state, String stateName, String author, String title, String body, String footer, long day) {
        News item = new News(nextNewsId++, state, stateName, author, title, body, footer, System.currentTimeMillis(), day);
        news.add(0, item);
        while (news.size() > 100) {
            news.removeLast();
        }
        setDirty();
        return item;
    }

    /** Removes an article and returns it, or null if there was none. */
    public News removeNews(int id) {
        News found = news(id);
        if (found != null) {
            news.remove(found);
            setDirty();
        }
        return found;
    }
    public Polity polityFor(UUID playerId) { return polities.stream().filter(polity -> polity.owner.equals(playerId) || (polity.deputy != null && polity.deputy.equals(playerId))).findFirst().orElse(null); }
    public Polity createPolity(String type, String name, UUID owner, String ownerName) {
        Polity polity = new Polity(type, name, owner, ownerName); polities.add(polity); log("Создан субъект «" + name + "» (" + type + ")."); setDirty(); return polity;
    }

    public void log(String entry) {
        logFor(null, entry);
    }

    /** Archive entry that belongs to one state (null = shared). */
    public void logFor(UUID state, String entry) {
        archive.add(0, entry);
        archiveOwner.add(0, state);
        if (archive.size() > 40) {
            archive.removeLast();
            archiveOwner.removeLast();
        }
        setDirty();
    }

    public List<String> archiveFor(UUID state) {
        List<String> out = new ArrayList<>();
        if (state == null) return out;
        for (int i = 0; i < archive.size(); i++) {
            if (state.equals(archiveOwner.get(i))) out.add(archive.get(i));
        }
        return out;
    }

    /** Removes a state together with its bills and its archive entries. */
    public void deleteState(Polity target) {
        polities.remove(target);
        bills.removeIf(bill -> target.owner.equals(bill.state));
        news.removeIf(item -> target.owner.equals(item.state));
        for (int i = archive.size() - 1; i >= 0; i--) {
            if (target.owner.equals(archiveOwner.get(i))) {
                archive.remove(i);
                archiveOwner.remove(i);
            }
        }
        setDirty();
    }

    public static RepublicData load(CompoundTag tag, HolderLookup.Provider registries) {
        RepublicData data = new RepublicData();
        data.nextBillId = tag.getInt("nextBillId");
        data.nextTreatyId = tag.getInt("nextTreatyId");
        ListTag savedPolities = tag.getList("polities", CompoundTag.TAG_COMPOUND);
        for (int i = 0; i < savedPolities.size(); i++) data.polities.add(Polity.load(savedPolities.getCompound(i)));
        ListTag savedBills = tag.getList("bills", CompoundTag.TAG_COMPOUND);
        for (int i = 0; i < savedBills.size(); i++) data.bills.add(Bill.load(savedBills.getCompound(i)));
        ListTag savedTreaties = tag.getList("treaties", CompoundTag.TAG_COMPOUND);
        for (int i = 0; i < savedTreaties.size(); i++) data.treaties.add(Treaty.load(savedTreaties.getCompound(i)));
        ListTag archiveOwners = tag.getList("archiveOwners", StringTag.valueOf("").getId());
        int ownerIndex = 0;
        for (var entry : tag.getList("archive", StringTag.valueOf("").getId())) {
            data.archive.add(entry.getAsString());
            String owner = ownerIndex < archiveOwners.size() ? archiveOwners.get(ownerIndex).getAsString() : "";
            data.archiveOwner.add(owner.isEmpty() ? null : UUID.fromString(owner));
            ownerIndex++;
        }
        data.nextNewsId = Math.max(1, tag.getInt("nextNewsId"));
        ListTag savedNews = tag.getList("news", CompoundTag.TAG_COMPOUND);
        for (int i = 0; i < savedNews.size(); i++) data.news.add(News.load(savedNews.getCompound(i)));
        return data;
    }

    @Override
    public CompoundTag save(CompoundTag tag, HolderLookup.Provider registries) {
        tag.putInt("nextBillId", nextBillId);
        tag.putInt("nextTreatyId", nextTreatyId);
        ListTag savedPolities = new ListTag(); polities.forEach(polity -> savedPolities.add(polity.save())); tag.put("polities", savedPolities);
        ListTag savedBills = new ListTag(); bills.forEach(bill -> savedBills.add(bill.save())); tag.put("bills", savedBills);
        ListTag savedTreaties = new ListTag(); treaties.forEach(treaty -> savedTreaties.add(treaty.save())); tag.put("treaties", savedTreaties);
        ListTag savedArchive = new ListTag(); archive.forEach(entry -> savedArchive.add(StringTag.valueOf(entry))); tag.put("archive", savedArchive);
        ListTag savedOwners = new ListTag(); archiveOwner.forEach(owner -> savedOwners.add(StringTag.valueOf(owner == null ? "" : owner.toString()))); tag.put("archiveOwners", savedOwners);
        tag.putInt("nextNewsId", nextNewsId);
        ListTag savedNews = new ListTag(); news.forEach(item -> savedNews.add(item.save())); tag.put("news", savedNews);
        return tag;
    }

    /** A world-news article. imageId and modelId are reserved for photos and 3D models. */
    public static final class News {
        final int id; final UUID state; final String stateName, author, title, body, footer; final long time, day;
        String imageId = "", modelId = ""; boolean hideState, hideAuthor;
        News(int id, UUID state, String stateName, String author, String title, String body, String footer, long time, long day) {
            this.id = id; this.state = state; this.stateName = stateName; this.author = author;
            this.title = title; this.body = body; this.footer = footer; this.time = time; this.day = day;
        }
        CompoundTag save() {
            CompoundTag t = new CompoundTag();
            t.putInt("id", id); if (state != null) t.putUUID("state", state);
            t.putString("stateName", stateName); t.putString("author", author); t.putString("title", title);
            t.putString("body", body); t.putString("footer", footer); t.putLong("time", time); t.putLong("day", day);
            t.putString("imageId", imageId); t.putString("modelId", modelId); t.putBoolean("hideState", hideState); t.putBoolean("hideAuthor", hideAuthor);
            return t;
        }
        static News load(CompoundTag t) {
            News n = new News(t.getInt("id"), t.hasUUID("state") ? t.getUUID("state") : null, t.getString("stateName"),
                    t.getString("author"), t.getString("title"), t.getString("body"), t.getString("footer"), t.getLong("time"),
                    t.contains("day") ? t.getLong("day") : LEGACY_DAY);
            n.imageId = t.getString("imageId"); n.modelId = t.getString("modelId"); n.hideState = t.getBoolean("hideState"); n.hideAuthor = t.getBoolean("hideAuthor");
            return n;
        }
    }

    public static final class Bill {
        final int id; final String title, summary, author; final List<String> yes = new ArrayList<>(), no = new ArrayList<>(); boolean closed; UUID state; int number;
        /** Parliament: the position of each faction (id -> for). Filled only when the state has seats. */
        final java.util.Map<String, Boolean> factionVote = new java.util.HashMap<>();
        long proposedDay = Long.MIN_VALUE, adoptedDay = Long.MIN_VALUE;
        boolean initialConstitution;
        boolean senatorsOnly;
        String constitutionText = "";
        boolean constitutionalBloc;
        final java.util.Map<String, Integer> electorate = new java.util.HashMap<>();
        boolean constitutionPassed() {
            long total = 0, approved = 0;
            for (java.util.Map.Entry<String, Integer> e : electorate.entrySet()) {
                total += e.getValue();
                if (constitutionalBloc ? Boolean.TRUE.equals(factionVote.get(e.getKey())) : yes.contains(e.getKey())) approved += e.getValue();
            }
            return !constitutionText.isEmpty() && total > 0 && approved * 3 >= total * 2;
        }
        Bill(int id, String title, String summary, String author) { this.id = id; this.title = title; this.summary = summary; this.author = author; }
        boolean vote(UUID voter, boolean inFavor) {
            String id = voter.toString(); if (closed || yes.contains(id) || no.contains(id)) return false;
            (inFavor ? yes : no).add(id); return true;
        }
        CompoundTag save() { CompoundTag t = base(id, title, summary, author); t.putLong("proposedDay", proposedDay); t.putLong("adoptedDay", adoptedDay); t.putBoolean("initialConstitution", initialConstitution); t.putBoolean("senatorsOnly", senatorsOnly); t.putString("constitutionText", constitutionText); t.putBoolean("constitutionalBloc", constitutionalBloc); CompoundTag electors = new CompoundTag(); electorate.forEach(electors::putInt); t.put("electorate", electors); t.putBoolean("closed", closed); if (state != null) t.putUUID("state", state); t.putInt("number", number); t.put("yes", strings(yes)); t.put("no", strings(no)); ListTag fv = new ListTag(); for (java.util.Map.Entry<String, Boolean> e : factionVote.entrySet()) { CompoundTag f = new CompoundTag(); f.putString("faction", e.getKey()); f.putBoolean("yes", e.getValue()); fv.add(f); } t.put("factionVote", fv); return t; }
        static Bill load(CompoundTag t) { Bill b = new Bill(t.getInt("id"), t.getString("title"), t.getString("summary"), t.getString("author")); b.proposedDay = t.contains("proposedDay") ? t.getLong("proposedDay") : Long.MIN_VALUE; b.adoptedDay = t.contains("adoptedDay") ? t.getLong("adoptedDay") : Long.MIN_VALUE; b.initialConstitution = t.getBoolean("initialConstitution"); b.senatorsOnly = t.getBoolean("senatorsOnly"); b.constitutionText = t.getString("constitutionText"); b.constitutionalBloc = t.getBoolean("constitutionalBloc"); CompoundTag electors = t.getCompound("electorate"); for (String key : electors.getAllKeys()) b.electorate.put(key, electors.getInt(key)); b.closed = t.getBoolean("closed"); if (t.hasUUID("state")) b.state = t.getUUID("state"); b.number = t.contains("number") ? t.getInt("number") : b.id; ListTag fv = t.getList("factionVote", CompoundTag.TAG_COMPOUND); for (int i = 0; i < fv.size(); i++) { b.factionVote.put(fv.getCompound(i).getString("faction"), fv.getCompound(i).getBoolean("yes")); } read(t.getList("yes", StringTag.valueOf("").getId()), b.yes); read(t.getList("no", StringTag.valueOf("").getId()), b.no); return b; }
    }

    public static final class Treaty {
        final int id; final String title, sideA, sideB, summary, author; boolean ratified;
        Treaty(int id, String title, String sideA, String sideB, String summary, String author) { this.id=id; this.title=title; this.sideA=sideA; this.sideB=sideB; this.summary=summary; this.author=author; }
        CompoundTag save() { CompoundTag t = base(id, title, summary, author); t.putString("sideA", sideA); t.putString("sideB", sideB); t.putBoolean("ratified", ratified); return t; }
        static Treaty load(CompoundTag t) { Treaty treaty = new Treaty(t.getInt("id"), t.getString("title"), t.getString("sideA"), t.getString("sideB"), t.getString("summary"), t.getString("author")); treaty.ratified = t.getBoolean("ratified"); return treaty; }
    }

    public static final class Polity {
        boolean senatorsOnly;
        String constitution = "";
        long constitutionAdoptedDay = Long.MIN_VALUE, constitutionRevisedDay = Long.MIN_VALUE;
        String type, name; final UUID owner; final String ownerName; UUID deputy = null; String deputyName = "";
        String avatarId = "";
        String ideology = "Нейтральная", parliament = "Однопалатный", government = "Республика";
        final List<UUID> members = new ArrayList<>();
        final List<String> memberNames = new ArrayList<>();
        /** Who holds power. Null means the owner. The owner key stays fixed: bills and archive use it. */
        UUID leader; String leaderName = "";
        UUID heir; String heirName = "";
        /** Game day the current term ends; Long.MIN_VALUE until first calculated. */
        long termEnd = Long.MIN_VALUE;
        /** Game day the open election ends; Long.MIN_VALUE when there is no election. */
        long electionEnd = Long.MIN_VALUE;
        /** Game day the current term began (the end is computed from the config every time). */
        long termStart = Long.MIN_VALUE;
        /** Game day the open election began (the end is computed from the config every time). */
        long electionStart = Long.MIN_VALUE;
        final List<UUID> candidates = new ArrayList<>();
        final List<String> candidateNames = new ArrayList<>();
        final java.util.Map<UUID, UUID> votes = new java.util.HashMap<>();
        final List<UUID> writers = new ArrayList<>();
        final List<String> writerNames = new ArrayList<>();
        /** Roles in order of place: index 0 is the highest. */
        final List<Role> roles = new ArrayList<>();
        /** Role of each member, by role id. Members without an entry have no role. */
        final java.util.Map<UUID, String> memberRoles = new java.util.HashMap<>();
        /** Factions of this state. Any member can found one; one faction per member. */
        final List<Faction> factions = new ArrayList<>();
        /** Parliament seats per faction id, from the last election. */
        final java.util.Map<String, Integer> seats = new java.util.HashMap<>();
        /** Parliament votes of the open election: voter -> faction id. */
        final java.util.Map<UUID, String> parliamentVotes = new java.util.HashMap<>();
        Polity(String type, String name, UUID owner, String ownerName) { this.type=type; this.name=name; this.owner=owner; this.ownerName=ownerName; }
        void assignNextDeputy(List<net.minecraft.server.level.ServerPlayer> players, UUID excluded) {
            List<net.minecraft.server.level.ServerPlayer> options = players.stream().filter(player -> !player.getUUID().equals(excluded)).toList();
            if (options.isEmpty()) { deputy = null; deputyName = ""; return; }
            int current = -1; for (int i = 0; i < options.size(); i++) if (deputy != null && options.get(i).getUUID().equals(deputy)) current = i;
            net.minecraft.server.level.ServerPlayer selected = options.get((current + 1) % options.size()); deputy = selected.getUUID(); deputyName = selected.getGameProfile().getName();
        }
        CompoundTag save() { CompoundTag tag = new CompoundTag(); tag.putBoolean("senatorsOnly", senatorsOnly); tag.putString("constitution", constitution); tag.putLong("constitutionAdoptedDay", constitutionAdoptedDay); tag.putLong("constitutionRevisedDay", constitutionRevisedDay); tag.putString("type", type); tag.putString("name", name); tag.putUUID("owner", owner); tag.putString("ownerName", ownerName); if (deputy != null) tag.putUUID("deputy", deputy); tag.putString("deputyName", deputyName); tag.putString("ideology", ideology); tag.putString("parliament", parliament); tag.putString("government", government); ListTag mem = new ListTag(); for (int i = 0; i < members.size(); i++) { CompoundTag m = new CompoundTag(); m.putUUID("uuid", members.get(i)); m.putString("name", memberNames.get(i)); mem.add(m); } tag.put("members", mem);
        tag.putString("avatarId", avatarId);
        CompoundTag pw = new CompoundTag();
        if (leader != null) pw.putUUID("leader", leader);
        pw.putString("leaderName", leaderName);
        if (heir != null) pw.putUUID("heir", heir);
        pw.putString("heirName", heirName);
        pw.putLong("termEnd", termEnd);
        pw.putLong("termStart", termStart);
        pw.putLong("electionStart", electionStart);
        pw.putLong("electionEnd", electionEnd);
        ListTag cand = new ListTag();
        for (int i = 0; i < candidates.size(); i++) {
            CompoundTag c = new CompoundTag();
            c.putUUID("uuid", candidates.get(i));
            c.putString("name", candidateNames.get(i));
            cand.add(c);
        }
        pw.put("candidates", cand);
        ListTag vt = new ListTag();
        for (java.util.Map.Entry<UUID, UUID> e : votes.entrySet()) {
            CompoundTag v = new CompoundTag();
            v.putUUID("voter", e.getKey());
            v.putUUID("for", e.getValue());
            vt.add(v);
        }
        pw.put("votes", vt);
        ListTag wr = new ListTag();
        for (int i = 0; i < writers.size(); i++) {
            CompoundTag w = new CompoundTag();
            w.putUUID("uuid", writers.get(i));
            w.putString("name", writerNames.get(i));
            wr.add(w);
        }
        pw.put("writers", wr);
        ListTag rl = new ListTag();
        for (Role r : roles) {
            CompoundTag rt = new CompoundTag();
            rt.putString("id", r.id);
            rt.putString("name", r.name);
            rt.putLong("perms", r.perms);
            rt.putInt("color", r.color);
            rl.add(rt);
        }
        tag.put("roles", rl);
        ListTag mr = new ListTag();
        for (java.util.Map.Entry<UUID, String> e : memberRoles.entrySet()) {
            CompoundTag mt = new CompoundTag();
            mt.putUUID("uuid", e.getKey());
            mt.putString("role", e.getValue());
            mr.add(mt);
        }
        ListTag fl = new ListTag();
        for (Faction f : factions) {
            CompoundTag ft = new CompoundTag();
            ft.putString("id", f.id);
            ft.putString("name", f.name);
            ft.putInt("color", f.color);
            if (f.leader != null) ft.putUUID("leader", f.leader);
            ft.putString("leaderName", f.leaderName);
            ft.putString("avatarId", f.avatarId);
            if (f.deputy != null) ft.putUUID("deputy", f.deputy);
            ft.putLong("createdAt", f.createdAt);
            ft.putBoolean("dissolutionVote", f.dissolutionVote);
            ListTag yesVotes = new ListTag();
            for (UUID voter : f.dissolutionYes) yesVotes.add(StringTag.valueOf(voter.toString()));
            ft.put("dissolutionYes", yesVotes);
            ft.put("members", uuidList(f.members, f.memberNames));
            ft.put("requests", uuidList(f.requests, f.requestNames));
            ListTag factionPerms = new ListTag();
            for (java.util.Map.Entry<UUID, Long> entry : f.memberPermissions.entrySet()) {
                CompoundTag value = new CompoundTag(); value.putUUID("member", entry.getKey());
                value.putLong("permissions", entry.getValue()); factionPerms.add(value);
            }
            ft.put("memberPermissions", factionPerms);
            ListTag rolesTag = new ListTag();
            f.roles.forEach((name, permissions) -> {
                CompoundTag role = new CompoundTag(); role.putString("name", name);
                role.putLong("permissions", permissions); rolesTag.add(role);
            });
            ft.put("roles", rolesTag);
            ListTag assigned = new ListTag();
            f.memberRoles.forEach((member, role) -> {
                CompoundTag value = new CompoundTag(); value.putUUID("member", member);
                value.putString("role", role); assigned.add(value);
            });
            ft.put("assignedRoles", assigned);
            fl.add(ft);
        }
        tag.put("factions", fl);
        CompoundTag seatTag = new CompoundTag();
        for (java.util.Map.Entry<String, Integer> e : seats.entrySet()) {
            seatTag.putInt(e.getKey(), e.getValue());
        }
        tag.put("seats", seatTag);
        ListTag pv = new ListTag();
        for (java.util.Map.Entry<UUID, String> e : parliamentVotes.entrySet()) {
            CompoundTag v = new CompoundTag();
            v.putUUID("voter", e.getKey());
            v.putString("faction", e.getValue());
            pv.add(v);
        }
        tag.put("parliamentVotes", pv);
        tag.put("memberRoles", mr);
        tag.put("power", pw);
        return tag; }
        static Polity load(CompoundTag tag) { Polity polity = new Polity(tag.getString("type"), tag.getString("name"), tag.getUUID("owner"), tag.getString("ownerName")); polity.senatorsOnly = tag.getBoolean("senatorsOnly"); polity.constitution = tag.getString("constitution"); polity.constitutionAdoptedDay = tag.contains("constitutionAdoptedDay") ? tag.getLong("constitutionAdoptedDay") : Long.MIN_VALUE; polity.constitutionRevisedDay = tag.contains("constitutionRevisedDay") ? tag.getLong("constitutionRevisedDay") : Long.MIN_VALUE; polity.deputy = tag.hasUUID("deputy") ? tag.getUUID("deputy") : null; polity.deputyName = tag.getString("deputyName"); polity.ideology = tag.getString("ideology"); polity.parliament = tag.getString("parliament"); polity.government = tag.getString("government"); ListTag mem = tag.getList("members", CompoundTag.TAG_COMPOUND); for (int i = 0; i < mem.size(); i++) { polity.members.add(mem.getCompound(i).getUUID("uuid")); polity.memberNames.add(mem.getCompound(i).getString("name")); }
        polity.avatarId = tag.getString("avatarId");
        CompoundTag pw = tag.getCompound("power");
        polity.leader = pw.hasUUID("leader") ? pw.getUUID("leader") : null;
        polity.leaderName = pw.getString("leaderName");
        if (pw.hasUUID("heir")) polity.heir = pw.getUUID("heir");
        polity.heirName = pw.getString("heirName");
        polity.termEnd = pw.contains("termEnd") ? pw.getLong("termEnd") : Long.MIN_VALUE;
        polity.termStart = pw.contains("termStart") ? pw.getLong("termStart") : Long.MIN_VALUE;
        polity.electionStart = pw.contains("electionStart") ? pw.getLong("electionStart") : Long.MIN_VALUE;
        polity.electionEnd = pw.contains("electionEnd") ? pw.getLong("electionEnd") : Long.MIN_VALUE;
        ListTag cand = pw.getList("candidates", CompoundTag.TAG_COMPOUND);
        for (int i = 0; i < cand.size(); i++) {
            polity.candidates.add(cand.getCompound(i).getUUID("uuid"));
            polity.candidateNames.add(cand.getCompound(i).getString("name"));
        }
        ListTag vt = pw.getList("votes", CompoundTag.TAG_COMPOUND);
        for (int i = 0; i < vt.size(); i++) {
            polity.votes.put(vt.getCompound(i).getUUID("voter"), vt.getCompound(i).getUUID("for"));
        }
        ListTag wr = pw.getList("writers", CompoundTag.TAG_COMPOUND);
        for (int i = 0; i < wr.size(); i++) {
            polity.writers.add(wr.getCompound(i).getUUID("uuid"));
            polity.writerNames.add(wr.getCompound(i).getString("name"));
        }
        ListTag rl = tag.getList("roles", CompoundTag.TAG_COMPOUND);
        for (int i = 0; i < rl.size(); i++) {
            CompoundTag rt = rl.getCompound(i);
            Role loaded = new Role(rt.getString("id"), rt.getString("name"), rt.getLong("perms"));
            loaded.color = rt.contains("color") ? rt.getInt("color") : 0xFFA88B4A;
            polity.roles.add(loaded);
        }
        ListTag mr = tag.getList("memberRoles", CompoundTag.TAG_COMPOUND);
        for (int i = 0; i < mr.size(); i++) {
            polity.memberRoles.put(mr.getCompound(i).getUUID("uuid"), mr.getCompound(i).getString("role"));
        }
        ListTag fl = tag.getList("factions", CompoundTag.TAG_COMPOUND);
        for (int i = 0; i < fl.size(); i++) {
            CompoundTag ft = fl.getCompound(i);
            Faction f = new Faction(ft.getString("id"), ft.getString("name"), ft.getInt("color"));
            if (ft.hasUUID("leader")) f.leader = ft.getUUID("leader");
            f.leaderName = ft.getString("leaderName");
            f.avatarId = ft.getString("avatarId");
            f.deputy = ft.hasUUID("deputy") ? ft.getUUID("deputy") : null;
            f.createdAt = ft.contains("createdAt") ? ft.getLong("createdAt") : 0L;
            f.dissolutionVote = ft.getBoolean("dissolutionVote");
            ListTag yesVotes = ft.getList("dissolutionYes", StringTag.TAG_STRING);
            for (int j = 0; j < yesVotes.size(); j++) {
                try { f.dissolutionYes.add(UUID.fromString(yesVotes.getString(j))); } catch (IllegalArgumentException ignored) {}
            }
            readUuidList(ft.getList("members", CompoundTag.TAG_COMPOUND), f.members, f.memberNames);
            readUuidList(ft.getList("requests", CompoundTag.TAG_COMPOUND), f.requests, f.requestNames);
            ListTag factionPerms = ft.getList("memberPermissions", CompoundTag.TAG_COMPOUND);
            for (int j = 0; j < factionPerms.size(); j++) {
                CompoundTag value = factionPerms.getCompound(j);
                if (value.hasUUID("member") && f.members.contains(value.getUUID("member")))
                    f.memberPermissions.put(value.getUUID("member"), value.getLong("permissions"));
            }
            ListTag rolesTag = ft.getList("roles", CompoundTag.TAG_COMPOUND);
            for (int j = 0; j < rolesTag.size(); j++) {
                CompoundTag role = rolesTag.getCompound(j);
                f.roles.put(role.getString("name"), role.getLong("permissions"));
            }
            ListTag assigned = ft.getList("assignedRoles", CompoundTag.TAG_COMPOUND);
            for (int j = 0; j < assigned.size(); j++) {
                CompoundTag value = assigned.getCompound(j);
                if (value.hasUUID("member") && f.members.contains(value.getUUID("member")) && f.roles.containsKey(value.getString("role")))
                    f.memberRoles.put(value.getUUID("member"), value.getString("role"));
            }
            polity.factions.add(f);
        }
        CompoundTag seatTag = tag.getCompound("seats");
        for (String key : seatTag.getAllKeys()) {
            polity.seats.put(key, seatTag.getInt(key));
        }
        ListTag pv = tag.getList("parliamentVotes", CompoundTag.TAG_COMPOUND);
        for (int i = 0; i < pv.size(); i++) {
            polity.parliamentVotes.put(pv.getCompound(i).getUUID("voter"), pv.getCompound(i).getString("faction"));
        }
        return polity; }
    }

    private static CompoundTag base(int id, String title, String summary, String author) { CompoundTag t = new CompoundTag(); t.putInt("id", id); t.putString("title", title); t.putString("summary", summary); t.putString("author", author); return t; }
    private static ListTag strings(List<String> values) { ListTag tag = new ListTag(); values.forEach(value -> tag.add(StringTag.valueOf(value))); return tag; }
    private static void read(ListTag tag, List<String> destination) { tag.forEach(value -> destination.add(value.getAsString())); }
}
