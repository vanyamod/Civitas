package com.humanitas;

public final class ConstitutionChecks {
    private static void check(boolean condition) { if (!condition) throw new AssertionError("Constitution check failed"); }
    public static void main(String[] args) {
        RepublicData.Bill b = new RepublicData.Bill(1, "Amendment", "Full text", "Author");
        b.constitutionText = "New constitution";
        b.initialConstitution = true; b.proposedDay = 123; b.adoptedDay = 125;
        b.electorate.put("a", 1); b.electorate.put("b", 1); b.electorate.put("c", 1);
        b.yes.add("outsider"); check(!b.constitutionPassed());
        b.yes.add("a"); check(!b.constitutionPassed());
        b.yes.add("b"); check(b.constitutionPassed());
        RepublicData.Bill restored = RepublicData.Bill.load(b.save());
        check(restored.constitutionPassed()); check(restored.constitutionText.equals(b.constitutionText));
        check(restored.initialConstitution && restored.proposedDay == 123 && restored.adoptedDay == 125);
        b.constitutionalBloc = true; b.electorate.clear(); b.electorate.put("partyA", 6); b.electorate.put("partyB", 4);
        b.factionVote.put("partyA", true); check(!b.constitutionPassed());
        b.factionVote.put("partyB", true); check(b.constitutionPassed());
        restored = RepublicData.Bill.load(b.save()); check(restored.constitutionalBloc && restored.constitutionPassed());
        b.electorate.clear(); check(!b.constitutionPassed());
        java.util.UUID chief = java.util.UUID.randomUUID();
        java.util.UUID senator = java.util.UUID.randomUUID();
        java.util.UUID outsider = java.util.UUID.randomUUID();
        RepublicData.Polity state = new RepublicData.Polity("republic", "Test", chief, "Chief");
        state.senatorsOnly = true;
        state.members.add(senator); state.memberNames.add("Senator");
        state.roles.add(new RepublicData.Role("senate", "Senator", Perms.LAW_VOTE));
        state.memberRoles.put(senator, "senate"); state.memberRoles.put(outsider, "senate");
        check(RepublicData.senators(state).contains(senator));
        check(!RepublicData.senators(state).contains(chief));
        check(!RepublicData.senators(state).contains(outsider));
        state.memberRoles.put(chief, "senate"); check(RepublicData.senators(state).contains(chief));
        RepublicData.Polity loadedState = RepublicData.Polity.load(state.save());
        check(loadedState.senatorsOnly && RepublicData.senators(loadedState).equals(RepublicData.senators(state)));
        b.senatorsOnly = true; b.electorate.put(senator.toString(), 1);
        restored = RepublicData.Bill.load(b.save());
        check(restored.senatorsOnly && restored.electorate.containsKey(senator.toString()));
        System.out.println("Senate access, explicit roles and persistence checks passed.");
        System.out.println("Constitution: threshold, eligibility, weighted votes and persistence checks passed.");
    }
}
