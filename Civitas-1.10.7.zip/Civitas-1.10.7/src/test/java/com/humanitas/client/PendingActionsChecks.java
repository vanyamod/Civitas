package com.humanitas.client;

public final class PendingActionsChecks {
    private static void check(boolean ok) { if (!ok) throw new AssertionError("Pending action check failed"); }
    public static void main(String[] args) {
        PendingActions p = new PendingActions();
        long first = p.begin("role", "perm|a|1", 1000);
        check(first != 0 && p.begin("role", "perm|a|1", 1100) == 0);
        long second = p.begin("role", "perm|b|1", 1100);
        check(second != 0 && p.count() == 2 && p.age(3000) == 2000);
        p.complete(second); check(p.count() == 1);
        p.complete(999); check(p.count() == 1);
        check(p.begin("role", "perm|a|1", 3000) == 0);
        p.complete(first); check(p.begin("role", "perm|a|1", 4000) != 0);
        p.clear(); check(p.count() == 0);
        long newSession = p.begin("role", "perm|a|1", 5000);
        p.complete(first); check(p.count() == 1 && newSession != first);
        for (int i = 0; i < 100; i++) p.begin("field", "v" + i, 5000);
        check(p.count() == 64); p.clear(); check(p.age(9000) == 0);
        System.out.println("Pending actions: duplicate clicks, distinct commands, out-of-order acknowledgements, reconnects and limits passed.");
    }
}
