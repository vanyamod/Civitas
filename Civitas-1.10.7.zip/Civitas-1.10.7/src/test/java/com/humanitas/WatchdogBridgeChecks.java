package com.humanitas;
import java.nio.file.Path;
import java.util.Map;
import net.minecraft.nbt.Tag;
public final class WatchdogBridgeChecks {
    public static void main(String[] args) {
        var polity = new RepublicData.Polity("Republic", "Test", java.util.UUID.randomUUID(), "Tester");
        polity.avatarId = "0123456789abcdef0123456789abcdef";
        if (!RepublicData.Polity.load(polity.save()).avatarId.equals(polity.avatarId)) throw new AssertionError("State avatar lost on save/load");
        byte[] avatar = {1, 2, 3};
        if (CabinetNet.avatarForNews(true, true, avatar) != null || CabinetNet.avatarForNews(false, false, avatar) != null || CabinetNet.avatarForNews(false, true, avatar) != avatar) throw new AssertionError("Hidden state avatar must never be sent");
        if (!DiscordWebhook.webhookName("Humanitas").equals("Humanitas") || !DiscordWebhook.webhookName(CabinetNet.HIDDEN).equals("?????") || !DiscordWebhook.webhookName("").equals("Администрация")) throw new AssertionError("Discord sender name is incorrect");
        if (DiscordWebhook.webhookName("A".repeat(120)).length() > 80 || DiscordWebhook.webhookName("Discord").toLowerCase(java.util.Locale.ROOT).contains("discord")) throw new AssertionError("Discord sender name is not valid");
        if (DiscordWebhook.plainContent("title", "body", "", "author", "date", "clock").contains("Humanitas")) throw new AssertionError("State name should only appear as sender");
        String longPlain = DiscordWebhook.plainMessage("title", "@".repeat(2500), "", "author", "date", "clock");
        if (longPlain.length() > 2000) throw new AssertionError("Discord plain content exceeds its limit");
        var payload = com.google.gson.JsonParser.parseString(DiscordWebhook.messageJson("Test", "https://example.invalid/a.png", "\"content\":" + new com.google.gson.JsonPrimitive(longPlain))).getAsJsonObject();
        if (!payload.get("content").getAsString().equals(longPlain) || payload.getAsJsonObject("allowed_mentions").getAsJsonArray("parse").size() != 0) throw new AssertionError("Discord plain message content or mention policy is invalid");
        if (CabinetNet.PublishNews.of("t", "b", "", "", false, false, false, 0).discordEmbed() || !CabinetNet.PublishNews.of("t", "b", "", "", false, false, true, 0).discordEmbed()) throw new AssertionError("Discord format toggle failed");
        if (!DiscordWebhook.avatarOrFallback(null).equals("https://cdn.discordapp.com/embed/avatars/0.png") || !DiscordWebhook.avatarOrFallback("https://example.invalid/state.png").equals("https://example.invalid/state.png")) throw new AssertionError("Avatar failure must use a neutral fallback without blocking news");
        String legacy="{\"event\":\"pack_enforcement\",\"outcome\":\"geometry_detected_100_percent\",\"player\":\"p\"}";
        String incident="{\"event\":\"watchdog_incident\",\"player\":\"p\",\"player_name\":\"Tester\",\"time\":\"2026-11-08T10:12:13Z\",\"reason\":\"Geometry: thin faces on 13/13 terrain blocks (<=20%); stone\",\"trust_change\":-7,\"trust_score\":54,\"sanction\":\"KICK\"}";
        var rows=WatchdogBridge.parseEvents(Path.of("."),Map.of("p","Tester"),legacy+"\n"+incident+"\n{bad}");
        if(rows.size()!=1)throw new AssertionError("Expected one detailed incident");
        var row=rows.getCompound(0);
        if(!row.getString("name").equals("Tester") || row.getInt("trustChange")!=-7 || row.getInt("trustScore")!=54 || !row.getString("reason").contains("stone") || !row.getString("message").contains("Кик"))throw new AssertionError("Incident details lost");
        String banned=incident.replace("\"sanction\":\"KICK\"", "\"sanction\":\"BAN\",\"ban_days\":3");
        var banRow=WatchdogBridge.parseEvents(Path.of("."),Map.of("p","Tester"),banned).getCompound(0);
        if(banRow.getInt("banDays")!=3 || !banRow.getString("message").contains("Бан"))throw new AssertionError("Ban details lost");
        var old=WatchdogBridge.parseEvents(Path.of("."),Map.of("p","Tester"),legacy);
        if(old.size()!=1 || old.getCompound(0).contains("trustChange"))throw new AssertionError("Legacy incidents must not invent trust changes");
        System.out.println("Watchdog dashboard checks passed.");
    }
}
