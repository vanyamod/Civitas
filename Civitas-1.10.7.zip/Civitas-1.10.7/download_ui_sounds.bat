@echo off
setlocal EnableExtensions EnableDelayedExpansion
chcp 65001 >nul
cd /d "%~dp0"

set "DEST=src\main\resources\assets\humanitas\sounds\ui"
set "BASE=https://raw.githubusercontent.com/romainsimon/uisfx/main/packages/uisfx/sounds/minimal"
set "TMP=%TEMP%\civitas-uisfx"

echo === Civitas UI sounds (CC0 audio, romainsimon/uisfx) ===
if not exist "%DEST%" mkdir "%DEST%"
if not exist "%TMP%" mkdir "%TMP%"

where ffprobe >nul 2>nul
if errorlevel 1 (
    echo ffprobe was not found in PATH. Install ffmpeg first.
    pause
    exit /b 1
)
where ffmpeg >nul 2>nul
if errorlevel 1 (
    echo ffmpeg was not found in PATH. Install ffmpeg first.
    pause
    exit /b 1
)

for %%S in (press open close select) do (
    set "FILE=%DEST%\%%S.ogg"
    set "CODEC="
    set "SOURCE="

    if exist "!FILE!" (
        for /f "delims=" %%C in ('ffprobe -v error -select_streams a:0 -show_streams "!FILE!" ^| findstr /i "vorbis"') do set "CODEC=vorbis"
    )

    if /i "!CODEC!"=="vorbis" (
        echo %%S.ogg is already Ogg Vorbis - keeping it.
    ) else (
        if not exist "!FILE!" (
            echo Downloading %%S.ogg...
            powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -Uri '%BASE%/%%S.ogg' -OutFile '%TMP%\%%S-source.ogg' -UseBasicParsing"
            if errorlevel 1 (
                echo FAILED to download %%S.ogg
                pause
                exit /b 1
            )
            set "SOURCE=%TMP%\%%S-source.ogg"
        ) else (
            echo Converting %%S.ogg from !CODEC! to Ogg Vorbis...
            set "SOURCE=!FILE!"
        )

        ffmpeg -y -hide_banner -loglevel error -i "!SOURCE!" -c:a libvorbis -q:a 5 -ar 44100 "%TMP%\%%S-vorbis.ogg"
        if errorlevel 1 (
            echo FAILED to convert %%S.ogg to Ogg Vorbis.
            del /q "%TMP%\%%S-source.ogg" >nul 2>nul
            pause
            exit /b 1
        )
        move /Y "%TMP%\%%S-vorbis.ogg" "!FILE!" >nul
        del /q "%TMP%\%%S-source.ogg" >nul 2>nul
        echo %%S.ogg is ready.
    )
)

echo.
echo DONE: four Ogg Vorbis sounds are in %DEST%
pause
