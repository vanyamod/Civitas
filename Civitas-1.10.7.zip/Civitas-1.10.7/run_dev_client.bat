@echo off
chcp 65001 >nul
cd /d "%~dp0"

echo === Starting DEV client (runClient) ===
call gradlew.bat runClient
if errorlevel 1 (
    echo.
    echo DEV CLIENT FAILED. Scroll up for the error.
    pause
    exit /b 1
)
pause
