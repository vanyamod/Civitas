package com.humanitas;

import net.minecraft.server.MinecraftServer;
import net.neoforged.neoforge.common.ModConfigSpec;

import java.time.LocalDate;

/**
 * Civitas server config, file config/civitas/server.toml.
 * News are dated with an in-world calendar, not with the real date.
 * The Discord webhook URL is read only here, on the server; it is never sent to a client.
 */
public final class CivitasConfig {
    private CivitasConfig() {}

    public static final String DEFAULT_START = "1940-01-01";
    public static final int DEFAULT_TICKS_PER_DAY = 24000;
    public static final ModConfigSpec SPEC;

    private static final ModConfigSpec.ConfigValue<String> START_DATE;
    private static final ModConfigSpec.BooleanValue ADVANCE;
    private static final ModConfigSpec.IntValue TICKS_PER_DAY;
    private static final ModConfigSpec.ConfigValue<String> WEBHOOK_URL;
    private static final ModConfigSpec.IntValue PRESIDENT_TERM;
    private static final ModConfigSpec.IntValue PARLIAMENT_TERM;
    private static final ModConfigSpec.IntValue DIRECTORATE_TERM;
    private static final ModConfigSpec.IntValue ELECTION_DAYS;

    static {
        ModConfigSpec.Builder b = new ModConfigSpec.Builder();

        b.comment("In-world calendar used to date news").push("calendar");
        START_DATE = b.comment("Calendar date of the first world day, as YYYY-MM-DD")
                .define("startDate", DEFAULT_START, CivitasConfig::validDate);
        ADVANCE = b.comment("false: every news item shows startDate.",
                        "true: the date moves forward by one day every ticksPerDay ticks.")
                .define("advanceWithWorldTime", false);
        TICKS_PER_DAY = b.comment("Game ticks in one in-world day. 24000 = one Minecraft day. Minimum 20.")
                .defineInRange("ticksPerDay", DEFAULT_TICKS_PER_DAY, 20, 10_000_000);
        b.pop();

        b.comment("Discord webhook. Server only: the URL is never sent to players.").push("discord");
        WEBHOOK_URL = b.comment("Webhook URL from the channel settings in Discord. Empty = off.",
                        "Must start with https://discord.com/api/webhooks/")
                .define("webhookUrl", "");
        b.pop();

        b.comment("Politics. Days are in-world days from the calendar above.").push("politics");
        PRESIDENT_TERM = b.comment("Presidential republic: days of one term before the next election.")
                .defineInRange("presidentialTermDays", 14, 1, 3650);
        PARLIAMENT_TERM = b.comment("Parliamentary republic: days of one term.")
                .defineInRange("parliamentaryTermDays", 10, 1, 3650);
        DIRECTORATE_TERM = b.comment("Directorate: days of one term.")
                .defineInRange("directorateTermDays", 7, 1, 3650);
        ELECTION_DAYS = b.comment("Days an election stays open for votes.")
                .defineInRange("electionDays", 3, 1, 30);
        b.pop();

        SPEC = b.build();
    }

    private static boolean validDate(Object o) {
        if (!(o instanceof String s)) {
            return false;
        }
        try {
            LocalDate.parse(s.trim());
            return true;
        } catch (RuntimeException e) {
            return false;
        }
    }

    public static LocalDate startDate() {
        try {
            return LocalDate.parse(START_DATE.get().trim());
        } catch (RuntimeException e) {
            return LocalDate.parse(DEFAULT_START);
        }
    }

    /** True if the date moves forward with world time. */
    public static boolean advance() {
        try {
            return ADVANCE.get();
        } catch (RuntimeException e) {
            return false;
        }
    }

    /** Game ticks in one in-world day. */
    public static int ticksPerDay() {
        try {
            return TICKS_PER_DAY.get();
        } catch (RuntimeException e) {
            return DEFAULT_TICKS_PER_DAY;
        }
    }

    /** The Discord webhook URL, trimmed. Empty if none is set. */
    public static String webhookUrl() {
        try {
            return WEBHOOK_URL.get().trim();
        } catch (RuntimeException e) {
            return "";
        }
    }

    public static int presidentTermDays() {
        return read(PRESIDENT_TERM, 14);
    }

    public static int parliamentTermDays() {
        return read(PARLIAMENT_TERM, 10);
    }

    public static int directorateTermDays() {
        return read(DIRECTORATE_TERM, 7);
    }

    public static int electionDays() {
        return read(ELECTION_DAYS, 3);
    }

    private static int read(ModConfigSpec.IntValue value, int fallback) {
        try {
            return value.get();
        } catch (RuntimeException e) {
            return fallback; // config not loaded (for example on a remote client)
        }
    }

    /** Today's calendar day as an epoch day. */
    public static long today(MinecraftServer server) {
        long day = startDate().toEpochDay();
        try {
            if (advance()) {
                day += Math.max(0L, server.overworld().getGameTime() / ticksPerDay());
            }
        } catch (RuntimeException ignored) {
            // config not loaded yet: keep the start date
        }
        return day;
    }
}
