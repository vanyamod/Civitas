package com.humanitas;

import com.google.gson.*;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.fml.loading.FMLPaths;
import net.neoforged.fml.ModList;
import net.neoforged.neoforge.network.PacketDistributor;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.io.RandomAccessFile;
import java.time.LocalDate;
import java.util.*;
import java.util.concurrent.*;

/** Admin-only, bounded asynchronous view of Watchdog's server-owned files. */
public final class WatchdogBridge {
    private record Player(UUID id,String name) {}
    private static final ExecutorService WORKER=new ThreadPoolExecutor(1,1,30,TimeUnit.SECONDS,new ArrayBlockingQueue<>(8),r->{var t=new Thread(r,"Civitas-watchdog-dashboard");t.setDaemon(true);return t;},new ThreadPoolExecutor.DiscardPolicy());
    private static final Map<UUID,Long> LAST=new HashMap<>();
    private WatchdogBridge() {}
    public static void request(ServerPlayer viewer) {
        if(!viewer.hasPermissions(2))return;
        long now=System.nanoTime();Long last=LAST.get(viewer.getUUID());
        if(last!=null && now-last<TimeUnit.MILLISECONDS.toNanos(1500))return;
        if(LAST.size()>1024)LAST.clear();LAST.put(viewer.getUUID(),now);
        var players=viewer.server.getPlayerList().getPlayers().stream().map(p->new Player(p.getUUID(),p.getGameProfile().getName())).toList();
        boolean available=ModList.get().isLoaded("watchdog");
        var server=viewer.server;
        WORKER.execute(()->{
            CompoundTag snapshot=read(available,players);
            server.execute(()->{
                var current=server.getPlayerList().getPlayer(viewer.getUUID());
                if(current==viewer && !current.hasDisconnected() && current.hasPermissions(2))PacketDistributor.sendToPlayer(current,new CabinetNet.WatchdogSnapshot(snapshot));
            });
        });
    }
    private static CompoundTag read(boolean available,List<Player> players) {
        var result=new CompoundTag();result.putBoolean("available",available);
        var scores=new ListTag();var events=new ListTag();result.put("scores",scores);result.put("events",events);
        if(!available)return result;
        Path root=FMLPaths.CONFIGDIR.get().resolve("watchdog");
        Map<String,String> names=new HashMap<>();
        for(var p:players) {
            var item=new CompoundTag();item.putString("uuid",p.id().toString());item.putString("name",p.name());
            item.putInt("trust",score(root,p.id()));scores.add(item);names.put(p.id().toString(),p.name());
        }
        Path report=root.resolve("reports").resolve(LocalDate.now()+".jsonl");
        try(RandomAccessFile input=new RandomAccessFile(report.toFile(),"r")) {
            long start=Math.max(0,input.length()-131072);input.seek(start);
            byte[] bytes=new byte[(int)(input.length()-start)];input.readFully(bytes);
            String contents=new String(bytes,StandardCharsets.UTF_8);int cut=start>0?contents.indexOf('\n')+1:0;
            if(start>0 && cut==0)return result;
            var parsed=parseEvents(root,names,contents.substring(cut));
            for(var item:parsed)events.add(item);

        } catch(java.io.IOException ignored) { /* no events yet */ }
        return result;
    }
    static ListTag parseEvents(Path root,Map<String,String> names,String contents) {
        var events=new ListTag();
            var incidents=new ArrayList<CompoundTag>();var legacy=new ArrayList<CompoundTag>();
            for(String line:contents.split("\n"))try {
                var json=JsonParser.parseString(line).getAsJsonObject();
                if(!json.has("event"))continue;
                String type=json.get("event").getAsString();
                boolean detailed=type.equals("watchdog_incident");
                if(!detailed && !type.equals("pack_enforcement"))continue;
                String message;
                if(detailed) {
                    String action=json.has("sanction")?json.get("sanction").getAsString():"";
                    message=action.equals("BAN")?"Бан за X-ray":action.equals("KICK")?"Кик за X-ray":"Подозрительная активность";
                } else {
                    if(!json.has("outcome"))continue;
                    String outcome=json.get("outcome").getAsString();
                    if(outcome.startsWith("geometry_detected_"))message="X-ray: изменённая геометрия";
                    else if(outcome.equals("active_blacklisted_pack"))message="Включён запрещённый ресурспак";
                    else if(outcome.startsWith("sanction_ban_"))message="Бан за X-ray";
                    else if(outcome.startsWith("sanction_kick_"))message="Кик за X-ray";
                    else continue;
                }
                String uuid=json.has("player")?json.get("player").getAsString():"";
                String name=json.has("player_name")?json.get("player_name").getAsString():names.getOrDefault(uuid,"");
                if(name.isBlank())name=storedName(root,uuid);
                var item=new CompoundTag();item.putString("name",name.isBlank()?uuid:name);item.putString("message",message);
                String time=json.has("time")?json.get("time").getAsString():"";item.putString("time",time.length()>=19?time.substring(11,19)+" UTC":time);
                if(detailed && json.has("reason")) {
                    String reason=json.get("reason").getAsString().replace("Geometry: thin faces on ","Геометрия: тонкие грани у ").replace(" terrain blocks (<=20%); "," блоков (площадь до 20%): ").replace("Previously blacklisted X-ray resource pack was enabled","Включён ранее запрещённый X-ray ресурспак");
                    item.putString("reason",reason);
                    if(json.has("trust_change"))item.putInt("trustChange",json.get("trust_change").getAsInt());
                    if(json.has("trust_score"))item.putInt("trustScore",json.get("trust_score").getAsInt());
                    if(json.has("ban_days"))item.putInt("banDays",json.get("ban_days").getAsInt());
                }
                var target=detailed?incidents:legacy;target.add(item);if(target.size()>30)target.remove(0);
            } catch(RuntimeException ignored) {}
            var found=incidents.isEmpty()?legacy:incidents;
            Collections.reverse(found);found.forEach(events::add);
            return events;
    }
    private static int score(Path root,UUID id) {
        try {Path p=root.resolve("trust").resolve(id+".json");if(!Files.exists(p))return 100;
            if(Files.size(p)>1048576)return -1;
            int score=JsonParser.parseString(Files.readString(p)).getAsJsonObject().get("score").getAsInt();return Math.max(0,Math.min(100,score));
        } catch(Exception ex){return -1;}
    }
    private static String storedName(Path root,String id) {
        try {UUID uuid=UUID.fromString(id);Path file=root.resolve("trust").resolve(uuid+".json");if(Files.size(file)>1048576)return "";
            var json=JsonParser.parseString(Files.readString(file)).getAsJsonObject();return json.has("player_name")?json.get("player_name").getAsString():"";
        } catch(Exception ex){return "";}
    }
}
