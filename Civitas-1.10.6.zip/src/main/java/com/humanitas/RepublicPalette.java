package com.humanitas;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.ClickEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;

/** Shared visual language for every public Res Publica message. */
public final class RepublicPalette {
    public static final int PAPER = 0xE8DCC4;
    public static final int GOLD = 0xA88B4A;
    public static final int GREEN = 0x9AA86A;
    public static final int INK = 0xD9D2C0;
    public static final int MUTED = 0x8C8677;

    private RepublicPalette() {}

    public static MutableComponent title(String text) {
        return Component.literal("▌ " + text.toUpperCase()).withStyle(style -> style.withColor(GOLD).withBold(true));
    }

    public static MutableComponent line(String label, String value) {
        return Component.literal("  " + label + " ").withStyle(style -> style.withColor(MUTED))
                .append(Component.literal(value).withStyle(style -> style.withColor(PAPER)));
    }

    public static MutableComponent note(String text) {
        return Component.literal("  " + text).withStyle(style -> style.withColor(PAPER));
    }

    public static MutableComponent status(String text) {
        return Component.literal("  " + text).withStyle(style -> style.withColor(GREEN));
    }

    public static MutableComponent action(String label, String command) {
        return Component.literal("[" + label + "]")
                .withStyle(style -> style.withColor(GOLD).withUnderlined(true).withClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, command)));
    }

    public static MutableComponent divider() {
        return Component.literal("  ───────────────────────────────────").withStyle(style -> style.withColor(INK));
    }
}
