package com.humanitas;

import net.neoforged.neoforge.common.ModConfigSpec;

/**
 * Client-only settings, file config/civitas-client.toml.
 */
public final class CivitasClientConfig {
    private CivitasClientConfig() {}

    /** True if the wheel interface is the one to open. Falls back to the wheel when the config is not loaded. */
    public static boolean wheelGui() {
        try {
            return WHEEL_GUI.get();
        } catch (RuntimeException e) {
            return true;
        }
    }

    public static final ModConfigSpec SPEC;
    public static final ModConfigSpec.BooleanValue CUSTOM_HOTBAR;
    public static final ModConfigSpec.BooleanValue WHEEL_GUI;
    public static final ModConfigSpec.BooleanValue CUSTOM_INVENTORY;
    public static final ModConfigSpec.ConfigValue<String> PALETTE;
    public static final ModConfigSpec.BooleanValue HUD_VISIBLE;

    static {
        ModConfigSpec.Builder b = new ModConfigSpec.Builder();
        CUSTOM_HOTBAR = b.comment(
                        "Replace the vanilla hotbar with the Civitas hotbar:",
                        "state and date on the left, player head and nickname on the right,",
                        "and Civitas-styled health, armour, hunger, air and experience bars.")
                .define("customHotbar", true);
        CUSTOM_INVENTORY = b.comment(
                        "Replace the vanilla survival inventory with the Civitas inventory:",
                        "cream card, gold frame, graphite portrait and olive-ruled slots.")
                .define("customInventory", true);
        PALETTE = b.comment(
                        "Colour palette used by the Civitas HUD, inventory and screens.",
                        "Changed from the radial wheel (H by default) and saved here.")
                .define("palette", "graphite");
        HUD_VISIBLE = b.comment(
                        "Whether the whole Civitas HUD is shown. Toggled from the radial wheel.")
                .define("hudVisible", true);
        WHEEL_GUI = b.comment("Open the Civitas wheel interface (semicircle of buttons) instead of the classic menu.")
                .define("wheelGui", true);
        SPEC = b.build();
    }
}
