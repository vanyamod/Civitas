package com.humanitas;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Parses "<type> <name> <owner>" from a greedy command argument.
 * Brigadier's word() only accepts ASCII, so Cyrillic names have to go through here.
 * Name may contain spaces, either bare or in double quotes.
 */
public final class CreateArgs {
    private CreateArgs() {}

    public record Parsed(String type, String name, String owner) {}

    private static final Pattern TOKEN = Pattern.compile("\"([^\"]+)\"|(\\S+)");

    public static Parsed parse(String raw) {
        List<String> tokens = new ArrayList<>();
        Matcher m = TOKEN.matcher(raw.trim());
        while (m.find()) {
            tokens.add(m.group(1) != null ? m.group(1) : m.group(2));
        }
        if (tokens.size() < 3) return null;
        String type = tokens.get(0);
        String owner = tokens.get(tokens.size() - 1);
        String name = String.join(" ", tokens.subList(1, tokens.size() - 1));
        return new Parsed(type, name, owner);
    }
}
