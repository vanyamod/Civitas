package com.humanitas.mixin;

import com.humanitas.client.CivitasCuriosStyle;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Repaints Curios' inventory at the end of {@code renderBg}. That point is after the stock
 * inventory and accessory textures have been drawn but before slot contents, widgets and labels,
 * which is exactly where an opaque Civitas plate can replace the background safely.
 */
@Mixin(targets = "top.theillusivec4.curios.client.gui.CuriosScreen", remap = false)
public abstract class CuriosScreenMixin {
    @Inject(method = "renderBg(Lnet/minecraft/client/gui/GuiGraphics;FII)V", at = @At("TAIL"))
    private void civitas$styleBackground(GuiGraphics g, float partialTick, int mouseX, int mouseY,
                                         CallbackInfo ci) {
        CivitasCuriosStyle.background(g, (AbstractContainerScreen<?>) (Object) this, mouseX, mouseY);
    }

    @Inject(method = "renderLabels(Lnet/minecraft/client/gui/GuiGraphics;II)V",
            at = @At("HEAD"), cancellable = true)
    private void civitas$styleLabels(GuiGraphics g, int mouseX, int mouseY, CallbackInfo ci) {
        CivitasCuriosStyle.labels(g, (AbstractContainerScreen<?>) (Object) this);
        ci.cancel();
    }
}
