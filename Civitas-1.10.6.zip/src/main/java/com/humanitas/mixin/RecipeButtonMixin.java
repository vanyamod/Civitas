package com.humanitas.mixin;

import com.humanitas.client.CivitasRecipeStyle;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.recipebook.RecipeButton;
import net.minecraft.resources.ResourceLocation;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/**
 * Replaces the vanilla red-framed result cell in the recipe book. Only the single sprite call is
 * redirected; the item icon is still drawn by vanilla code afterwards.
 */
@Mixin(RecipeButton.class)
public abstract class RecipeButtonMixin {
    @Redirect(
            method = "renderWidget(Lnet/minecraft/client/gui/GuiGraphics;IIF)V",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/gui/GuiGraphics;blitSprite(Lnet/minecraft/resources/ResourceLocation;IIII)V"))
    private void civitas$slot(GuiGraphics g, ResourceLocation sprite, int x, int y, int w, int h) {
        CivitasRecipeStyle.slot(g, sprite, x, y, w, h);
    }
}
