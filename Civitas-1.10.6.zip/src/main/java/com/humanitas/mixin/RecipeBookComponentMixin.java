package com.humanitas.mixin;

import com.humanitas.client.CivitasRecipeStyle;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.recipebook.RecipeBookComponent;
import net.minecraft.resources.ResourceLocation;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/**
 * Replaces the white vanilla texture behind the recipe book with the Civitas plate. Only the
 * background blit is redirected; search box, tabs, filter button and recipe cells keep working.
 */
@Mixin(RecipeBookComponent.class)
public abstract class RecipeBookComponentMixin {
    @Redirect(
            method = "render(Lnet/minecraft/client/gui/GuiGraphics;IIF)V",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/gui/GuiGraphics;blit(Lnet/minecraft/resources/ResourceLocation;IIIIII)V"))
    private void civitas$background(GuiGraphics g, ResourceLocation texture, int x, int y,
                                    int u, int v, int w, int h) {
        CivitasRecipeStyle.background(g, x, y, w, h);
    }
}
