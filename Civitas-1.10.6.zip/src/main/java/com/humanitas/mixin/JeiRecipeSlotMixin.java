// Removed: the JEI recipe-slot restyle was dropped. This file is intentionally empty and can be deleted.
