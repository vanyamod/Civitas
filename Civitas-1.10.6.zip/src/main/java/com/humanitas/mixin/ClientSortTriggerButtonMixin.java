package com.humanitas.mixin;

import com.humanitas.client.CivitasClientSortStyle;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractWidget;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Replaces the ClientSort mod's bright white trigger button with a Civitas-styled
 * graphite and gold button.
 */
@Mixin(targets = "dev.terminalmc.clientsort.client.gui.widget.TriggerButton", remap = false)
public abstract class ClientSortTriggerButtonMixin {
    @Inject(method = "renderWidget(Lnet/minecraft/client/gui/GuiGraphics;IIF)V", at = @At("HEAD"), cancellable = true)
    private void civitas$renderTriggerButton(GuiGraphics g, int mouseX, int mouseY, float partialTick, CallbackInfo ci) {
        CivitasClientSortStyle.render(g, (AbstractWidget) (Object) this, mouseX, mouseY);
        ci.cancel();
    }
}
