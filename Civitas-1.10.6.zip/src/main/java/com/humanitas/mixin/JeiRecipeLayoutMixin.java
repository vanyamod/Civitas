// Removed: the JEI recipe-layout mixin was dropped. This file is intentionally empty and can be deleted.
