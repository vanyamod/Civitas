package com.humanitas;

import java.util.List;

/** Fixed option lists and political rules. The server validates every choice against these. */
public final class CabinetPresets {
    private CabinetPresets() {}

    public static final List<String> IDEOLOGIES = List.of(
            "Республиканизм", "Монархизм", "Социализм", "Либерализм", "Консерватизм", "Технократия");

    public static final List<String> PARLIAMENTS = List.of(
            "Однопалатный", "Двухпалатный", "Совет", "Нет парламента");

    public static final List<String> GOVERNMENTS = List.of(
            "Монархия", "Президентская", "Парламентская", "Директория", "Диктатура");

    /** Colours a role can take: palette swatches, as ARGB. The server rejects anything else. */
    public static final List<Integer> ROLE_COLORS = List.of(
            0xFFA88B4A, 0xFF5C6B3A, 0xFFB04030, 0xFF3A5A7A, 0xFF6A3A7A, 0xFF3A7A6A, 0xFF6E6447, 0xFFE8DCC4);

    /** Names of the colours in ROLE_COLORS, in the same order. */
    public static final String[] ROLE_COLOR_NAMES = {
            "золото", "олива", "бордо", "сталь",
            "аметист", "бирюза", "пепел", "крем"
    };

    /** Seats in the parliament of a form of government. "Нет парламента" has none. */
    public static int seatsFor(String parliament) {
        return switch (parliament) {
            case "Однопалатный", "Двухпалатный" -> 12;
            case "Совет" -> 7;
            default -> 0;
        };
    }

    /** Forms of government an ideology allows. An unset ideology allows everything. */
    public static List<String> governmentsFor(String ideology) {
        return switch (ideology) {
            case "Монархизм" -> List.of("Монархия", "Диктатура");
            case "Республиканизм" -> List.of("Президентская", "Парламентская", "Директория");
            case "Социализм" -> List.of("Директория", "Диктатура");
            case "Либерализм" -> List.of("Президентская", "Парламентская");
            case "Консерватизм" -> List.of("Монархия", "Парламентская");
            case "Технократия" -> List.of("Директория", "Президентская");
            default -> GOVERNMENTS;
        };
    }

    /** Days between elections. Zero means no elections: monarchy and dictatorship. */
    public static int termDays(String government) {
        return switch (government) {
            case "Президентская" -> CivitasConfig.presidentTermDays();
            case "Парламентская" -> CivitasConfig.parliamentTermDays();
            case "Директория" -> CivitasConfig.directorateTermDays();
            default -> 0;
        };
    }

    /** Days an election stays open for votes. */
    public static int electionDays(String government) {
        return CivitasConfig.electionDays();
    }

    public static boolean hasElections(String government) {
        return termDays(government) > 0;
    }

    /**
     * Symbol for each ideology. Only characters from the Basic Multilingual Plane,
     * because the default Minecraft font can't draw most emoji.
     */
    public static String icon(String ideology) {
        return switch (ideology) {
            case "Республиканизм" -> "⚖";  // scales of justice
            case "Монархизм" -> "♛";       // chess queen
            case "Социализм" -> "☭";       // hammer and sickle
            case "Либерализм" -> "☀";      // enlightenment sun
            case "Консерватизм" -> "⚜";    // fleur-de-lis
            case "Технократия" -> "⚙";     // gear
            default -> "⚐";                // white flag, neutral / unknown
        };
    }
}
