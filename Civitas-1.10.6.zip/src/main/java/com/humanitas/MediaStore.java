package com.humanitas;

import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.storage.LevelResource;
import net.neoforged.neoforge.event.server.ServerStartedEvent;
import net.neoforged.neoforge.network.PacketDistributor;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.regex.Pattern;
import java.util.stream.Stream;

/**
 * Stores news photos in the world folder (world/civitas/images/<id>.png), not in the save file.
 * A client packet may carry at most 32 KB, so files arrive in 30 KB chunks and are put together here.
 * The server checks size, count and that the file is a PNG or JPEG. It never decodes the image.
 */
public final class MediaStore {
    private MediaStore() {}

    public static final int CHUNK = 30_000;
    public static final int MAX_BYTES = 262_144;
    private static final int MAX_CHUNKS = 10;
    private static final long UPLOAD_COOLDOWN_MS = 5_000L;
    private static final long STALE_MS = 120_000L;
    private static final Pattern ID = Pattern.compile("[0-9a-f]{32}");

    private static final class Upload {
        final int total;
        final byte[][] parts;
        final long started = System.currentTimeMillis();
        int received;
        int size;

        Upload(int total) {
            this.total = total;
            this.parts = new byte[total][];
        }
    }

    private static final Map<UUID, Upload> UPLOADS = new HashMap<>();
    private static final Map<UUID, Long> LAST_FINISHED = new HashMap<>();
    private static final Map<UUID, long[]> REQUESTS = new HashMap<>();

    // ---------- paths ----------

    private static Path dir(MinecraftServer server) {
        return server.getWorldPath(LevelResource.ROOT).resolve("civitas").resolve("images");
    }

    private static Path file(MinecraftServer server, String id) {
        return dir(server).resolve(id + ".img");
    }

    public static boolean validId(String id) {
        return id != null && ID.matcher(id).matches();
    }

    public static boolean exists(MinecraftServer server, String id) {
        return validId(id) && Files.isRegularFile(file(server, id));
    }

    /** Raw bytes of a stored photo, or null if it does not exist. Used for the Discord webhook. */
    public static byte[] bytes(MinecraftServer server, String id) {
        if (!exists(server, id)) {
            return null;
        }
        try {
            return Files.readAllBytes(file(server, id));
        } catch (IOException e) {
            return null;
        }
    }

    // ---------- upload ----------

    static void receive(ServerPlayer player, CabinetNet.UploadChunk chunk) {
        if (!chunk.kind().equals("image")) {
            return;
        }
        UUID who = player.getUUID();
        int total = chunk.total();
        int index = chunk.index();
        if (total < 1 || total > MAX_CHUNKS || index < 0 || index >= total || chunk.data().length > CHUNK) {
            UPLOADS.remove(who);
            fail(player, "Некорректная загрузка");
            return;
        }

        long now = System.currentTimeMillis();
        UPLOADS.values().removeIf(u -> now - u.started > STALE_MS);

        Upload up = UPLOADS.get(who);
        if (index == 0) {
            Long last = LAST_FINISHED.get(who);
            if (last != null && now - last < UPLOAD_COOLDOWN_MS) {
                fail(player, "Подождите несколько секунд");
                return;
            }
            up = new Upload(total);
            UPLOADS.put(who, up);
        }
        if (up == null || up.total != total || up.parts[index] != null) {
            return;
        }

        up.parts[index] = chunk.data();
        up.received++;
        up.size += chunk.data().length;
        if (up.size > MAX_BYTES) {
            UPLOADS.remove(who);
            fail(player, "Файл слишком большой");
            return;
        }
        if (up.received < up.total) {
            return;
        }

        UPLOADS.remove(who);
        LAST_FINISHED.put(who, now);
        finish(player, up);
    }

    private static void finish(ServerPlayer player, Upload up) {
        byte[] all = new byte[up.size];
        int pos = 0;
        for (byte[] part : up.parts) {
            System.arraycopy(part, 0, all, pos, part.length);
            pos += part.length;
        }
        if (!looksLikeImage(all)) {
            fail(player, "Это не изображение");
            return;
        }

        MinecraftServer server = player.getServer();
        if (server == null) {
            return;
        }
        String id = UUID.randomUUID().toString().replace("-", "");
        try {
            Files.createDirectories(dir(server));
            Files.write(file(server, id), all);
        } catch (IOException e) {
            Humanitas.LOGGER.error("Could not save a news photo", e);
            fail(player, "Сервер не смог сохранить файл");
            return;
        }
        PacketDistributor.sendToPlayer(player, new CabinetNet.UploadResult(true, id, ""));
    }

    private static boolean looksLikeImage(byte[] b) {
        if (b.length < 12) {
            return false;
        }
        boolean png = (b[0] & 0xFF) == 0x89 && b[1] == 'P' && b[2] == 'N' && b[3] == 'G';
        boolean jpeg = (b[0] & 0xFF) == 0xFF && (b[1] & 0xFF) == 0xD8;
        return png || jpeg;
    }

    private static void fail(ServerPlayer player, String message) {
        PacketDistributor.sendToPlayer(player, new CabinetNet.UploadResult(false, "", message));
    }

    // ---------- download ----------

    /** Sends one stored photo. At most 30 requests per 10 seconds per player. */
    static void sendMedia(ServerPlayer player, String kind, String id) {
        if (!kind.equals("image") || !validId(id)) {
            return;
        }
        MinecraftServer server = player.getServer();
        if (server == null) {
            return;
        }

        long now = System.currentTimeMillis();
        long[] window = REQUESTS.computeIfAbsent(player.getUUID(), k -> new long[]{now, 0});
        if (now - window[0] > 10_000L) {
            window[0] = now;
            window[1] = 0;
        }
        if (++window[1] > 30) {
            return;
        }

        Path path = file(server, id);
        try {
            if (!Files.isRegularFile(path)) {
                return;
            }
            PacketDistributor.sendToPlayer(player, new CabinetNet.MediaData(kind, id, Files.readAllBytes(path)));
        } catch (IOException e) {
            Humanitas.LOGGER.warn("Could not read news photo {}: {}", id, e.getMessage());
        }
    }

    // ---------- cleanup ----------

    /** Deletes a photo once no article uses it any more. */
    static void deleteIfUnused(MinecraftServer server, RepublicData data, String id) {
        if (!validId(id)) {
            return;
        }
        for (RepublicData.News n : data.news()) {
            if (id.equals(n.imageId)) {
                return;
            }
        }
        try {
            Files.deleteIfExists(file(server, id));
        } catch (IOException e) {
            Humanitas.LOGGER.warn("Could not delete news photo {}: {}", id, e.getMessage());
        }
    }

    /** On start, removes photos that were uploaded but never published. */
    public static void onServerStarted(ServerStartedEvent event) {
        MinecraftServer server = event.getServer();
        Path dir = dir(server);
        if (!Files.isDirectory(dir)) {
            return;
        }
        Set<String> used = new HashSet<>();
        for (RepublicData.News n : RepublicData.get(server).news()) {
            if (!n.imageId.isEmpty()) {
                used.add(n.imageId);
            }
        }
        try (Stream<Path> files = Files.list(dir)) {
            files.forEach(p -> {
                String name = p.getFileName().toString();
                String id = name.endsWith(".img") ? name.substring(0, name.length() - 4) : name;
                if (!used.contains(id)) {
                    try {
                        Files.deleteIfExists(p);
                    } catch (IOException ignored) {
                        // leave it for the next start
                    }
                }
            });
        } catch (IOException e) {
            Humanitas.LOGGER.warn("Could not clean the news photo folder: {}", e.getMessage());
        }
    }
}
