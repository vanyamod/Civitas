package com.humanitas;

import java.io.ByteArrayOutputStream;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import java.util.regex.Pattern;

/**
 * Posts news to a Discord channel as a rich embed, with the photo attached as a file.
 * Server side only: the URL is read from config/civitas/server.toml and never leaves the server.
 * Sending is asynchronous, so a slow or dead Discord never stalls the server tick.
 */
public final class DiscordWebhook {
    private DiscordWebhook() {}

    private static final int TITLE_MAX = 256;
    private static final int DESCRIPTION_MAX = 4000;
    private static final int FOOTER_MAX = 2000;
    /** Plain Discord message content limit. */
    private static final int CONTENT_MAX = 2000;
    /** Gold of the Civitas palette, shown as the strip on the left of the embed. */
    private static final int COLOR_GOLD = 0xA88B4A;

    /** Civitas markup that must not reach Discord as text: colour and style tags, photos, structures. */
    private static final Pattern MARKUP = Pattern.compile(
            "\\[/?(?:[bius]|c(?::[a-z]+)?)]|\\[img:[^\\]]+]|\\[nbt:[^\\]]+]");
    private static final DateTimeFormatter DATE = DateTimeFormatter.ofPattern("dd.MM.yyyy");
    private static final HttpClient CLIENT = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(5))
            .build();

    /**
     * Posts one news article.
     * image is the raw bytes of the photo, or null for a text-only article.
     */
    public static void news(String state, String title, String body, String footer, String author, long day, long dayTime, boolean asEmbed, int color, byte[] image) {
        String url = CivitasConfig.webhookUrl();
        if (url.isEmpty()) {
            return;
        }
        if (!isDiscordWebhook(url)) {
            Humanitas.LOGGER.warn(
                    "Discord webhook in config/civitas/server.toml is not a Discord webhook URL. Message not sent.");
            return;
        }

        String stateName = state.isEmpty() ? "Администрация" : state;
        String date = DATE.format(LocalDate.ofEpochDay(day));
        String clock = clockText(dayTime);
        String description = excerpt(body, footer);
        String fileName = image == null ? "" : imageName(image);

        StringBuilder embed = new StringBuilder("{");
        embed.append("\"title\":").append(quote(clip(title, TITLE_MAX))).append(',');
        if (!description.isEmpty()) {
            embed.append("\"description\":").append(quote(description)).append(',');
        }
        embed.append("\"color\":").append(color).append(',');
        embed.append("\"author\":{\"name\":").append(quote(stateName)).append("},");
        embed.append("\"footer\":{\"text\":")
                .append(quote(clip("Civitas · " + date + " " + clock + " · автор: " + author, FOOTER_MAX))).append("}");
        if (image != null) {
            embed.append(",\"image\":{\"url\":\"attachment://").append(fileName).append("\"}");
        }
        embed.append('}');

        String json = asEmbed
                ? "{\"username\":\"Civitas\",\"embeds\":[" + embed + "]}"
                : "{\"username\":\"Civitas\",\"content\":"
                        + quote(clip(plainContent(title, body, footer, stateName, author, date, clock), CONTENT_MAX)) + "}";

        HttpRequest request;
        if (image == null) {
            request = builder(url)
                    .header("Content-Type", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString(json, StandardCharsets.UTF_8))
                    .build();
        } else {
            String boundary = "civitas" + Long.toHexString(System.nanoTime());
            byte[] multipart = multipart(boundary, json, image, fileName);
            request = builder(url)
                    .header("Content-Type", "multipart/form-data; boundary=" + boundary)
                    .POST(HttpRequest.BodyPublishers.ofByteArray(multipart))
                    .build();
        }
        send(request);
    }

    /** In-game clock as HH:mm, the same way the hotbar shows it (0 ticks = 06:00). */
    static String clockText(long dayTime) {
        long t = Math.floorMod(dayTime, 24000L);
        long minutes = ((t * 1440L) / 24000L + 360L) % 1440L;
        return String.format(Locale.ROOT, "%02d:%02d", minutes / 60L, minutes % 60L);
    }

    private static HttpRequest.Builder builder(String url) {
        return HttpRequest.newBuilder(URI.create(url)).timeout(Duration.ofSeconds(15));
    }

    private static void send(HttpRequest request) {
        CLIENT.sendAsync(request, HttpResponse.BodyHandlers.discarding())
                .thenAccept(response -> {
                    if (response.statusCode() / 100 != 2) {
                        Humanitas.LOGGER.warn("Discord webhook answered HTTP {}", response.statusCode());
                    }
                })
                .exceptionally(e -> {
                    Humanitas.LOGGER.warn("Discord webhook failed: {}", e.getMessage());
                    return null;
                });
    }

    /** multipart/form-data: the embed as payload_json, the photo as files[0]. */
    private static byte[] multipart(String boundary, String json, byte[] image, String fileName) {
        ByteArrayOutputStream out = new ByteArrayOutputStream(image.length + json.length() + 512);
        String type = fileName.endsWith(".png") ? "image/png" : "image/jpeg";
        put(out, "--" + boundary + "\r\n");
        put(out, "Content-Disposition: form-data; name=\"payload_json\"\r\n");
        put(out, "Content-Type: application/json\r\n\r\n");
        put(out, json + "\r\n");
        put(out, "--" + boundary + "\r\n");
        put(out, "Content-Disposition: form-data; name=\"files[0]\"; filename=\"" + fileName + "\"\r\n");
        put(out, "Content-Type: " + type + "\r\n\r\n");
        out.writeBytes(image);
        put(out, "\r\n--" + boundary + "--\r\n");
        return out.toByteArray();
    }

    private static void put(ByteArrayOutputStream out, String s) {
        out.writeBytes(s.getBytes(StandardCharsets.UTF_8));
    }

    /** PNG starts with 0x89; anything else is sent as JPEG. */
    private static String imageName(byte[] image) {
        return (image.length > 0 && (image[0] & 0xFF) == 0x89) ? "news.png" : "news.jpg";
    }

    static boolean isDiscordWebhook(String url) {
        return url.startsWith("https://discord.com/api/webhooks/")
                || url.startsWith("https://discordapp.com/api/webhooks/");
    }

    /** Plain-message version of the article: bold headline, the body in Discord markdown, a small footer line. */
    static String plainContent(String title, String body, String footer, String state, String author, String date, String clock) {
        String text = MARKUP.matcher(body).replaceAll("").strip();
        return "**" + title + "**\n\n" + text + (footer.isEmpty() ? "" : "\n\n-# " + footer) + "\n\n-# " + state + " · " + author + " · " + date + " " + clock;
    }

    /** Plain excerpt of the article: no Civitas markup, no photo tags, cut to the limit. */
    private static String excerpt(String body, String footer) {
        String plain = MARKUP.matcher(body).replaceAll("").strip() + (footer.isEmpty() ? "" : "\n\n-# " + footer);
        return clip(plain, DESCRIPTION_MAX);
    }

    private static String clip(String s, int max) {
        return s.length() > max ? s.substring(0, max - 1) + "…" : s;
    }

    private static String quote(String s) {
        return "\"" + escape(s) + "\"";
    }

    /**
     * JSON string escape. A zero-width space after every @ stops @everyone and @here
     * from pinging the whole channel when a player writes them in a news article.
     */
    private static String escape(String s) {
        StringBuilder sb = new StringBuilder(s.length() + 16);
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '"' -> sb.append("\\\"");
                case '\\' -> sb.append("\\\\");
                case '\n' -> sb.append("\\n");
                case '\r' -> sb.append("\\r");
                case '\t' -> sb.append("\\t");
                case '@' -> sb.append("@\u200B");
                default -> {
                    if (c < 0x20) {
                        sb.append(String.format("\\u%04x", (int) c));
                    } else {
                        sb.append(c);
                    }
                }
            }
        }
        return sb.toString();
    }
}
