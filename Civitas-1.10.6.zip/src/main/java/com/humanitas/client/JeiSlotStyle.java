// Removed: the JEI recipe-slot style helper was dropped together with JeiRecipeSlotMixin. This file is intentionally empty and can be deleted.
