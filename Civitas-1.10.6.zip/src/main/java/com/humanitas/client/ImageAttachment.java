package com.humanitas.client;

import com.humanitas.CabinetNet;
import com.humanitas.Humanitas;
import com.humanitas.MediaStore;
import com.mojang.blaze3d.platform.NativeImage;
import net.minecraft.client.Minecraft;
import net.neoforged.neoforge.network.PacketDistributor;
import org.lwjgl.PointerBuffer;
import org.lwjgl.system.MemoryStack;
import org.lwjgl.util.tinyfd.TinyFileDialogs;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;

/**
 * One photo attached to a news article being written.
 * Flow: file dialog (worker thread) -> shrink to at most 384 px wide -> preview texture ->
 * upload in 30 KB chunks -> the server answers with a photo id. Only after that can the article be published.
 */
public final class ImageAttachment {
    public enum State { NONE, PROCESSING, UPLOADING, READY, FAILED }

    private static final int MAX_WIDTH = 384;

    /** The attachment that is waiting for the server's answer. */
    private static ImageAttachment awaiting;

    private volatile State state = State.NONE;
    private volatile String message = "";
    private volatile String serverId = "";
    private volatile String previewKey = "";
    private volatile String fileName = "";
    private volatile byte[] bytes;
    /** Bumped when the attachment is cleared, so a file dialog that closes later cannot revive it. */
    private volatile int generation = 0;

    public State state() {
        return state;
    }

    public String message() {
        return message;
    }

    public String serverId() {
        return serverId;
    }

    /** Key of the local preview texture, for the preview in the editor. Empty if there is none. */
    public String previewKey() {
        return previewKey.isEmpty() ? serverId : previewKey;
    }

    public void restore(String id, String name) {
        clear();
        if (id != null && id.matches("[0-9a-f]{32}")) {
            serverId = id;
            fileName = name;
            state = State.READY;
        }
    }

    /** Original file name of the chosen photo, without the extension. */
    public String fileName() {
        return fileName;
    }

    public boolean busy() {
        return state == State.PROCESSING || state == State.UPLOADING;
    }

    public boolean ready() {
        return state == State.READY;
    }

    // ---------- choosing ----------

    /** Opens the file dialog on a worker thread so the game keeps running. */
    public void choose() {
        if (busy()) {
            return;
        }
        state = State.PROCESSING;
        message = "Выберите файл…";
        int ticket = ++generation;
        Thread worker = new Thread(() -> pickAndProcess(ticket), "Civitas-photo-picker");
        worker.setDaemon(true);
        worker.start();
    }

    private void pickAndProcess(int ticket) {
        String chosen = openDialog();
        if (ticket != generation) {
            return;
        }
        if (chosen == null || chosen.isBlank()) {
            state = serverId.isEmpty() ? State.NONE : State.READY;
            message = "";
            return;
        }
        String base = Path.of(chosen).getFileName().toString();
        int dot = base.lastIndexOf('.');
        if (dot > 0) base = base.substring(0, dot);
        fileName = base;
        message = "Обработка: " + base + "…";
        try {
            byte[] bytes = prepare(Path.of(chosen));
            Minecraft.getInstance().execute(() -> {
                if (ticket == generation) {
                    begin(bytes);
                }
            });
        } catch (IOException | RuntimeException e) {
            Humanitas.LOGGER.warn("Could not prepare the photo: {}", e.getMessage());
            if (ticket == generation) {
                state = State.FAILED;
                message = "Не удалось прочитать файл";
            }
        }
    }

    /** The dialog starts in the Exposure folder if it exists, otherwise in the game folder. */
    private static String openDialog() {
        File gameDir = Minecraft.getInstance().gameDirectory;
        Path start = gameDir.toPath().resolve("exposures");
        if (!Files.isDirectory(start)) {
            start = gameDir.toPath();
        }
        String startPath = start.toAbsolutePath() + File.separator;
        try (MemoryStack stack = MemoryStack.stackPush()) {
            PointerBuffer filters = stack.mallocPointer(3);
            filters.put(stack.UTF8("*.png"));
            filters.put(stack.UTF8("*.jpg"));
            filters.put(stack.UTF8("*.jpeg"));
            filters.flip();
            return TinyFileDialogs.tinyfd_openFileDialog(
                    "Выберите фото для новости", startPath, filters, "Изображения (PNG, JPG)", false);
        }
    }

    // ---------- shrinking ----------

    /** Reads the file and shrinks it to at most 384 px wide, smaller still if the result is over the size limit. */
    private static byte[] prepare(Path path) throws IOException {
        if (Files.size(path) > 30L * 1024 * 1024) {
            throw new IOException("file is too large");
        }
        byte[] raw = Files.readAllBytes(path);
        try (NativeImage source = NativeImage.read(new ByteArrayInputStream(raw))) {
            int width = source.getWidth();
            int height = source.getHeight();
            int target = Math.min(width, MAX_WIDTH);
            while (true) {
                int targetH = Math.max(1, Math.round(height * (target / (float) width)));
                byte[] out = encode(source, target, targetH);
                if (out.length <= MediaStore.MAX_BYTES) {
                    return out;
                }
                if (target <= 96) {
                    throw new IOException("image does not fit the size limit");
                }
                target = (int) (target * 0.8f);
            }
        }
    }

    /** Shrinks by averaging the source pixels under each target pixel, which keeps photos smooth. */
    private static byte[] encode(NativeImage source, int tw, int th) throws IOException {
        int sw = source.getWidth();
        int sh = source.getHeight();
        try (NativeImage target = new NativeImage(tw, th, false)) {
            for (int y = 0; y < th; y++) {
                int y0 = y * sh / th;
                int y1 = Math.max(y0 + 1, (y + 1) * sh / th);
                for (int x = 0; x < tw; x++) {
                    int x0 = x * sw / tw;
                    int x1 = Math.max(x0 + 1, (x + 1) * sw / tw);
                    long a = 0;
                    long b = 0;
                    long g = 0;
                    long r = 0;
                    int n = 0;
                    for (int yy = y0; yy < y1; yy++) {
                        for (int xx = x0; xx < x1; xx++) {
                            int p = source.getPixelRGBA(xx, yy);
                            a += p >>> 24;
                            b += (p >> 16) & 255;
                            g += (p >> 8) & 255;
                            r += p & 255;
                            n++;
                        }
                    }
                    int pixel = ((int) (a / n) << 24) | ((int) (b / n) << 16) | ((int) (g / n) << 8) | (int) (r / n);
                    target.setPixelRGBA(x, y, pixel);
                }
            }
            return target.asByteArray();
        }
    }

    // ---------- uploading ----------

    /** Runs on the main thread: shows the preview and sends the file to the server. */
    private void begin(byte[] bytes) {
        this.bytes = bytes;
        releasePreview();
        String key = ImageCache.newLocalKey();
        if (ImageCache.register(key, bytes) == null) {
            state = State.FAILED;
            message = "Файл не удалось открыть";
            return;
        }
        previewKey = key;
        serverId = "";
        state = State.UPLOADING;
        message = "Загрузка: " + fileName + "…";
        awaiting = this;

        int total = (bytes.length + MediaStore.CHUNK - 1) / MediaStore.CHUNK;
        for (int i = 0; i < total; i++) {
            int from = i * MediaStore.CHUNK;
            int to = Math.min(bytes.length, from + MediaStore.CHUNK);
            PacketDistributor.sendToServer(new CabinetNet.UploadChunk("image", i, total, Arrays.copyOfRange(bytes, from, to)));
        }
    }

    /** The server answered the upload. */
    public static void onResult(boolean ok, String id, String text) {
        ImageAttachment target = awaiting;
        if (target == null) {
            return;
        }
        awaiting = null;
        if (ok) {
            target.serverId = id;
            target.state = State.READY;
            target.message = "Фото готово: " + target.fileName;
            if (target.bytes != null) {
                ImageCache.register(id, target.bytes);
            }
        } else {
            target.state = State.FAILED;
            target.message = text.isEmpty() ? "Ошибка загрузки" : text;
        }
    }

    // ---------- cleanup ----------

    /** Removes the photo from the article. */
    public void clear() {
        generation++;
        if (awaiting == this) {
            awaiting = null;
        }
        releasePreview();
        serverId = "";
        fileName = "";
        bytes = null;
        state = State.NONE;
        message = "";
    }

    /** Frees the preview texture. Called when the editor closes. */
    public void releasePreview() {
        if (!previewKey.isEmpty()) {
            ImageCache.release(previewKey);
            previewKey = "";
        }
    }
}
