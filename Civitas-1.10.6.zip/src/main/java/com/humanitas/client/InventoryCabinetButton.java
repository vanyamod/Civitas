package com.humanitas.client;

import com.humanitas.CabinetNet;
import com.humanitas.Humanitas;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ScreenEvent;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.Map;
import java.util.WeakHashMap;

/**
 * Adds the Civitas seal to the left of the armor column in the player inventory.
 * Its symbol follows the ideology, its tooltip shows the state name.
 *
 * <p>The inventory slides right when the recipe book opens, so the seal follows {@code getGuiLeft()}
 * instead of staying at a fixed screen coordinate. It is hidden while the book is open: otherwise
 * it would sit underneath the book and remain clickable through it.</p>
 */
@EventBusSubscriber(modid = Humanitas.MODID, value = Dist.CLIENT)
public final class InventoryCabinetButton {
    private static final Map<Screen, CabinetButton> BUTTONS = new WeakHashMap<>();

    private InventoryCabinetButton() {}

    @SubscribeEvent
    public static void addCabinetButton(ScreenEvent.Init.Post event) {
        if (!(event.getScreen() instanceof InventoryScreen screen)) return;

        CabinetButton button = new CabinetButton(screen.getGuiLeft() - 28, screen.getGuiTop() + 3, 24, 24,
                CabinetClientState::ideologyIcon,
                () -> PacketDistributor.sendToServer(new CabinetNet.RequestCabinet()))
                .withTip(CabinetClientState::stateName)
                .withOffset(0.5F, 0.5F)
                .withIconOffset(-0.5F, -0.5F);

        event.addListener(button);
        BUTTONS.put(screen, button);
    }

    @SubscribeEvent
    public static void followInventory(ScreenEvent.Render.Pre event) {
        if (!(event.getScreen() instanceof InventoryScreen screen)) return;

        CabinetButton button = BUTTONS.get(screen);
        if (button == null) return;

        button.setX(screen.getGuiLeft() - 28);
        button.setY(screen.getGuiTop() + 3);
        button.visible = !screen.getRecipeBookComponent().isVisible();
    }
}
