package com.humanitas.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.ResourceLocation;

import static com.humanitas.client.CivitasUi.*;

/**
 * Civitas drawing for the vanilla recipe book. The mixins redirect the two vanilla draw calls
 * (book background and result-cell sprite) here, so the item, search box, tabs and tooltips keep
 * their own vanilla behaviour.
 */
public final class CivitasRecipeStyle {
    private CivitasRecipeStyle() {}

    /** Replaces the white vanilla recipe-book texture with the dark Civitas plate. */
    public static void background(GuiGraphics g, int x, int y, int w, int h) {
        g.fill(x, y, x + w, y + h, GOLD_DEEP);
        g.fillGradient(x + 1, y + 1, x + w - 1, y + h - 1, PANEL, PLATE_DEEP);
        g.fill(x + 2, y + 2, x + w - 2, y + 3, CivitasColors.alpha(TEXT_LIGHT, 0x18));
    }

    /**
     * Replaces the vanilla result-cell sprite. Craftable results get a bright gold rim, the rest
     * a dim one; a small gold mark shows that the entry has several recipes.
     */
    public static void slot(GuiGraphics g, ResourceLocation sprite, int x, int y, int w, int h) {
        String path = sprite.getPath();
        boolean craftable = !path.contains("uncraftable");
        boolean many = path.contains("many");

        int rim = craftable ? GOLD : CivitasColors.alpha(GOLD_DEEP, 0x80);
        g.fill(x, y, x + w, y + h, 0xFF0E0F13);
        g.fillGradient(x + 1, y + 1, x + w - 1, y + h - 1,
                craftable ? 0xFF24262D : 0xFF191A1F, 0xFF121317);

        g.fill(x + 1, y, x + w - 1, y + 1, rim);
        g.fill(x + 1, y + h - 1, x + w - 1, y + h, rim);
        g.fill(x, y + 1, x + 1, y + h - 1, rim);
        g.fill(x + w - 1, y + 1, x + w, y + h - 1, rim);

        if (many) {
            g.fill(x + w - 5, y + 3, x + w - 3, y + 5, GOLD);
        }
    }
}
