package com.humanitas.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.ImageButton;
import net.minecraft.client.gui.components.events.GuiEventListener;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.client.gui.screens.recipebook.RecipeBookComponent;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.InventoryMenu;
import net.minecraft.world.inventory.Slot;

import static com.humanitas.client.CivitasUi.*;

/**
 * Player inventory in the Civitas chancellery style: the same graphite plate, matte gold rim,
 * cream lettering and olive accents as the hotbar. Slots, clicks, tooltips, the recipe book and
 * the cabinet seal keep their vanilla behaviour because this is still an {@link InventoryScreen}.
 */
public class CivitasInventoryScreen extends InventoryScreen {
    private CabinetButton recipeButton;

    public CivitasInventoryScreen(Player player) {
        super(player);
    }

    @Override
    protected void init() {
        super.init();

        // The vanilla recipe-book button is the only plain ImageButton here. Swap it for a Civitas
        // medallion at the vanilla position (inside the crafting panel), not over the output slot.
        // Remove it from every list (renderables, children and narratables), otherwise the invisible
        // vanilla button keeps consuming clicks and toggles the book a second time.
        ImageButton vanillaButton = null;
        for (GuiEventListener listener : this.children()) {
            if (listener.getClass() == ImageButton.class) {
                vanillaButton = (ImageButton) listener;
                break;
            }
        }
        if (vanillaButton != null) {
            this.removeWidget(vanillaButton);
        }
        this.recipeButton = new CabinetButton(this.leftPos + 104, this.height / 2 - 22, 20, 18,
                () -> "☰", 1.2F, this::toggleRecipeBook)
                .withTip(() -> "Рецепты");
        this.addRenderableWidget(this.recipeButton);
    }

    private void toggleRecipeBook() {
        RecipeBookComponent book = getRecipeBookComponent();
        book.toggleVisibility();
        // Rebuilding the widgets re-runs init(), so every widget that positions itself from leftPos
        // (including ClientSort's sort button) follows the inventory when the book opens or closes.
        this.rebuildWidgets();
    }

    @Override
    protected void renderBg(GuiGraphics g, float partialTick, int mouseX, int mouseY) {
        int x = this.leftPos;
        int y = this.topPos;

        drawFrame(g, x, y);
        drawSlots(g, x, y);
        drawDivider(g, x, y);
        drawCraftingArrow(g, x, y);
        drawPortrait(g, x, y, mouseX, mouseY);
    }

    /** Graphite plate with a heavy cut-corner gold rim, inner shadow and a soft outer glow. */
    private void drawFrame(GuiGraphics g, int x, int y) {
        int w = this.imageWidth;
        int h = this.imageHeight;

        // Outer shadow, two layers for depth.
        g.fill(x + 3, y + h + 1, x + w + 3, y + h + 3, 0x44000000);
        g.fill(x + w + 1, y + 3, x + w + 3, y + h + 1, 0x44000000);
        g.fill(x + 2, y + h, x + w + 2, y + h + 2, 0x66000000);
        g.fill(x + w, y + 2, x + w + 2, y + h, 0x66000000);

        // Gold rim, two pixels thick with mitered corners.
        g.fill(x + 2, y, x + w - 2, y + 2, GOLD);
        g.fill(x + 2, y + h - 2, x + w - 2, y + h, GOLD);
        g.fill(x, y + 2, x + 2, y + h - 2, GOLD);
        g.fill(x + w - 2, y + 2, x + w, y + h - 2, GOLD);
        g.fill(x + 1, y + 1, x + 2, y + 2, GOLD);
        g.fill(x + w - 2, y + 1, x + w - 1, y + 2, GOLD);
        g.fill(x + 1, y + h - 2, x + 2, y + h - 1, GOLD);
        g.fill(x + w - 2, y + h - 2, x + w - 1, y + h - 1, GOLD);

        // Darker inner hairline, giving the rim a bevelled look.
        g.fill(x + 2, y + 2, x + w - 2, y + 3, GOLD_DEEP);
        g.fill(x + 2, y + h - 3, x + w - 2, y + h - 2, GOLD_DEEP);
        g.fill(x + 2, y + 3, x + 3, y + h - 3, GOLD_DEEP);
        g.fill(x + w - 3, y + 3, x + w - 2, y + h - 3, GOLD_DEEP);

        // Body with a subtle vertical gradient.
        g.fillGradient(x + 2, y + 2, x + w - 2, y + h - 2, PANEL, PLATE_DEEP);

        // Inner gold rule, inset from the rim.
        g.fill(x + 7, y + 4, x + w - 7, y + 5, RULE);
        g.fill(x + 7, y + h - 5, x + w - 7, y + h - 4, RULE);
        g.fill(x + 4, y + 7, x + 5, y + h - 7, RULE);
        g.fill(x + w - 5, y + 7, x + w - 4, y + h - 7, RULE);

        // Cream light on the top edge, like the lip of a metal plate.
        g.fill(x + 7, y + 2, x + w - 7, y + 3, CivitasColors.alpha(CREAM_ACTIVE, 0x40));

        // Corner studs.
        g.fill(x + 3, y + 3, x + 5, y + 5, GOLD);
        g.fill(x + w - 5, y + 3, x + w - 3, y + 5, GOLD);
        g.fill(x + 3, y + h - 5, x + 5, y + h - 3, GOLD);
        g.fill(x + w - 5, y + h - 5, x + w - 3, y + h - 3, GOLD);
    }

    private void drawSlots(GuiGraphics g, int x, int y) {
        for (Slot slot : this.menu.slots) {
            if (!slot.isActive()) {
                continue;
            }
            int sx = x + slot.x - 1;
            int sy = y + slot.y - 1;
            boolean result = slot.index == InventoryMenu.RESULT_SLOT;

            g.fill(sx, sy, sx + 18, sy + 18, result ? GOLD : SLOT_EDGE);
            g.fill(sx + 1, sy + 1, sx + 17, sy + 17, result ? SLOT_RESULT : SLOT_FILL);
            // Inner bevel: a light lip on top-left, a shade on bottom-right.
            g.fill(sx + 1, sy + 1, sx + 17, sy + 2, result ? CivitasColors.alpha(CREAM_ACTIVE, 0x50) : SLOT_LIGHT);
            g.fill(sx + 1, sy + 1, sx + 2, sy + 17, result ? CivitasColors.alpha(CREAM_ACTIVE, 0x30) : SLOT_LIGHT);
            g.fill(sx + 16, sy + 2, sx + 17, sy + 17, SLOT_SHADE);
            g.fill(sx + 2, sy + 16, sx + 17, sy + 17, SLOT_SHADE);
            g.fill(sx + 1, sy + 16, sx + 2, sy + 17, SLOT_SHADE);

            if (result) {
                g.fill(sx + 2, sy + 2, sx + 16, sy + 3, CivitasColors.alpha(CREAM_ACTIVE, 0x45));
                g.fill(sx + 2, sy + 3, sx + 3, sy + 16, CivitasColors.alpha(CREAM_ACTIVE, 0x25));
            }
        }
    }

    /** A small gold clasp in the four-pixel gap between the inventory grid and the hotbar row. */
    private void drawDivider(GuiGraphics g, int x, int y) {
        int mid = x + this.imageWidth / 2;
        int ruleY = y + 139;
        g.fill(x + 8, ruleY, x + this.imageWidth - 8, ruleY + 1, CivitasColors.alpha(GOLD, 0x50));
        // Ornate clasp at the centre.
        g.fill(mid - 5, ruleY - 2, mid + 6, ruleY - 1, GOLD_DEEP);
        g.fill(mid - 4, ruleY - 1, mid + 5, ruleY, GOLD);
        g.fill(mid - 3, ruleY, mid + 4, ruleY + 1, GOLD);
        g.fill(mid - 4, ruleY + 1, mid + 5, ruleY + 2, GOLD_DEEP);
        g.fill(mid - 1, ruleY - 3, mid + 2, ruleY - 2, GOLD);
        g.fill(mid - 1, ruleY + 2, mid + 2, ruleY + 3, GOLD_DEEP);
    }

    /** The vanilla texture supplied this arrow; now it is a small olive-and-gold rule. */
    private void drawCraftingArrow(GuiGraphics g, int x, int y) {
        int ax = x + 136;
        int ay = y + 32;
        g.fill(ax, ay + 2, ax + 10, ay + 5, OLIVE);
        g.fill(ax + 10, ay, ax + 12, ay + 7, GOLD_DEEP);
        g.fill(ax + 12, ay + 1, ax + 14, ay + 6, GOLD_DEEP);
        g.fill(ax + 14, ay + 2, ax + 16, ay + 5, GOLD);
        g.fill(ax + 15, ay + 3, ax + 17, ay + 4, GOLD);
    }

    private void drawPortrait(GuiGraphics g, int x, int y, int mouseX, int mouseY) {
        int px = x + 26;
        int py = y + 8;
        int pw = 49;
        int ph = 70;

        // Double gold rim around the portrait.
        g.fill(px - 3, py - 3, px + pw + 3, py + ph + 3, GOLD_DEEP);
        g.fill(px - 2, py - 2, px + pw + 2, py + ph + 2, GOLD);
        g.fill(px - 1, py - 1, px + pw + 1, py + ph + 1, GOLD_DEEP);
        g.fill(px, py, px + pw, py + ph, PORTRAIT);

        // Lighting: bright top-left, deep bottom-right.
        g.fillGradient(px, py, px + pw, py + ph, CivitasColors.alpha(CREAM_ACTIVE, 0x22), 0x00000000);
        g.fillGradient(px, py, px + pw, py + ph, 0x00000000, 0x88000000);
        g.fill(px, py, px + pw, py + 1, CivitasColors.alpha(CREAM_ACTIVE, 0x55));
        g.fill(px, py, px + 1, py + ph, CivitasColors.alpha(CREAM_ACTIVE, 0x30));
        g.fill(px + pw - 1, py, px + pw, py + ph, 0x44000000);
        g.fill(px, py + ph - 1, px + pw, py + ph, 0x44000000);

        if (this.minecraft != null && this.minecraft.player != null) {
            InventoryScreen.renderEntityInInventoryFollowsMouse(g,
                    px, py, px + pw, py + ph,
                    30, 0.0625F, mouseX, mouseY, this.minecraft.player);
        }
    }

    @Override
    protected void renderLabels(GuiGraphics g, int mouseX, int mouseY) {
        // The plate is intentionally title-less: the seal and the portrait already identify it.
    }

    @Override
    protected void renderSlotHighlight(GuiGraphics g, Slot slot, int mouseX, int mouseY, float partialTick) {
        if (slot.isHighlightable()) {
            renderSlotHighlight(g, slot.x, slot.y, 0, HOVER);
        }
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        super.render(g, mouseX, mouseY, partialTick);
        if (getRecipeBookComponent().isVisible()) {
            styleRecipeBook(g);
        }
    }

    /**
     * Frames the vanilla recipe book instead of painting over it. The old full-body tint hid the
     * recipe cards and made JEI's book look broken; a frame keeps every page readable.
     */
    private void styleRecipeBook(GuiGraphics g) {
        RecipeBookComponent book = getRecipeBookComponent();
        if (!book.isVisible()) return;

        // The book always sits at the centre of the screen; only its horizontal offset changes
        // when the screen is wide enough to keep the inventory visible next to it.
        boolean narrow = this.width < 379;
        int bx = (this.width - RecipeBookComponent.IMAGE_WIDTH) / 2 - (narrow ? 0 : 86);
        int by = (this.height - RecipeBookComponent.IMAGE_HEIGHT) / 2;
        int fx = bx - (narrow ? 2 : 31);
        int fy = by - 2;
        int fw = RecipeBookComponent.IMAGE_WIDTH + (narrow ? 4 : 33);
        int fh = RecipeBookComponent.IMAGE_HEIGHT + 4;

        CivitasUi.frame(g, fx, fy, fw, fh);

    }
}
