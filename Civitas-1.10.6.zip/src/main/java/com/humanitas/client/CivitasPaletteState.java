package com.humanitas.client;

import com.humanitas.CivitasClientConfig;
import com.humanitas.Humanitas;

/**
 * Holds the palette the player chose and whether the whole HUD is visible. Persisted through
 * {@link CivitasClientConfig}; safe to call before the config has loaded.
 */
public final class CivitasPaletteState {
    private CivitasPaletteState() {}

    private static volatile CivitasPalette current = CivitasPalette.GRAPHITE;
    private static volatile boolean hudVisible = true;

    public static void load() {
        CivitasPalette palette = CivitasPalette.GRAPHITE;
        boolean visible = true;
        try {
            palette = CivitasPalette.byId(CivitasClientConfig.PALETTE.get());
            visible = CivitasClientConfig.HUD_VISIBLE.get();
        } catch (RuntimeException e) {
            Humanitas.LOGGER.warn("Civitas palette config not yet loaded: {}", e.toString());
        }
        current = palette;
        hudVisible = visible;
        CivitasUi.applyPalette(palette);
    }

    public static CivitasPalette current() { return current; }

    public static boolean hudVisible() { return hudVisible; }

    public static void select(CivitasPalette palette) {
        if (palette == null) return;
        current = palette;
        CivitasUi.applyPalette(palette);
        savePalette(palette.id());
    }

    public static void setHudVisible(boolean visible) {
        hudVisible = visible;
        saveHud(visible);
    }

    public static void toggleHud() {
        setHudVisible(!hudVisible);
    }

    private static void savePalette(String id) {
        try {
            CivitasClientConfig.PALETTE.set(id);
            CivitasClientConfig.SPEC.save();
        } catch (RuntimeException ignored) {}
    }

    private static void saveHud(boolean visible) {
        try {
            CivitasClientConfig.HUD_VISIBLE.set(visible);
            CivitasClientConfig.SPEC.save();
        } catch (RuntimeException ignored) {}
    }
}
