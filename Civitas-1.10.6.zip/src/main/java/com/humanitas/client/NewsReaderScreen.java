package com.humanitas.client;

import com.humanitas.CabinetNet;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.neoforged.neoforge.network.PacketDistributor;

import static com.humanitas.client.CivitasUi.*;

/** Reads one news article. The author's state, an admin, or the state's deputy can delete it (two clicks). */
public class NewsReaderScreen extends Screen {
    private final Screen parent;
    private final NewsItem item;

    private int px;
    private int py;
    private int pw;
    private int ph;
    private int scroll = 0;
    private int contentHeight = 0;
    private boolean confirmDelete = false;
    private final java.util.List<NewsView.Link> links = new java.util.ArrayList<>();

    public NewsReaderScreen(Screen parent, NewsItem item) {
        super(Component.literal("Civitas news"));
        this.parent = parent;
        this.item = item;
    }

    @Override
    protected void init() {
        pw = Math.min(width - 16, 420);
        ph = Math.min(height - 16, 300);
        px = (width - pw) / 2;
        py = (height - ph) / 2;
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    /** Nothing here: the dim is painted in render so the blur isn't applied twice. */
    @Override
    public void renderBackground(GuiGraphics g, int mx, int my, float partialTick) {
    }

    private int viewX() {
        return px + 6;
    }

    private int viewY() {
        return py + 28;
    }

    private int viewW() {
        return pw - 12 - 8;
    }

    private int viewH() {
        return ph - 28 - 38;
    }

    private int buttonY() {
        return py + ph - 28;
    }

    private int closeX() {
        return px + 12;
    }

    private int deleteX() {
        return px + pw - 12 - 150;
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float partialTick) {
        if (parent != null) {
            parent.render(g, -1, -1, partialTick);
        }
        // The parent wheel draws its windows at z 100 and above. Lift this reader over them, so the
        // news list can never paint on top of the article.
        g.pose().pushPose();
        g.pose().translate(0, 0, 400);
        g.fill(0, 0, width, height, SCRIM);
        panel(g, px, py, pw, ph);
        // Title strip.
        g.fill(px + 2, py + 2, px + pw - 2, py + 24, HEADER);
        g.fill(px + 2, py + 2, px + pw - 2, py + 3, CivitasColors.alpha(TEXT_LIGHT, 0x1A));
        g.fill(px + 2, py + 24, px + pw - 2, py + 25, GOLD_DEEP);
        g.drawString(font, "НОВОСТЬ", px + 12, py + 9, TEXT_LIGHT, false);
        String head = font.plainSubstrByWidth(item.title(), pw - 80);
        g.drawString(font, head, px + pw - 8 - font.width(head), py + 9, GOLD, false);

        int maxScroll = Math.max(0, contentHeight - viewH());
        scroll = Math.max(0, Math.min(maxScroll, scroll));

        g.fill(viewX(), viewY(), viewX() + viewW(), viewY() + viewH(), CREAM);
        g.enableScissor(viewX(), viewY(), viewX() + viewW(), viewY() + viewH());
        contentHeight = NewsView.draw(g, font, viewX(), viewY(), viewW(), item, scroll, 0, links);
        g.disableScissor();

        if (maxScroll > 0) {
            int trackX = viewX() + viewW() + 3;
            int thumbH = Math.max(18, viewH() * viewH() / contentHeight);
            int thumbY = viewY() + (viewH() - thumbH) * scroll / maxScroll;
            g.fill(trackX, viewY(), trackX + 4, viewY() + viewH(), CREAM_DEEP);
            g.fill(trackX, thumbY, trackX + 4, thumbY + thumbH, OLIVE);
        }

        int by = buttonY();
        button(g, font, closeX(), by, 100, 18, "ЗАКРЫТЬ", inside(mx, my, closeX(), by, 100, 18), Style.SECONDARY);
        if (item.canDelete()) {
            button(g, font, deleteX(), by, 150, 18, confirmDelete ? "НАЖМИТЕ ЕЩЁ РАЗ" : "УДАЛИТЬ НОВОСТЬ",
                    inside(mx, my, deleteX(), by, 150, 18), Style.DANGER);
        }
        if (inside(mx, my, viewX(), viewY(), viewW(), viewH())) {
            for (NewsView.Link link : links) if (link.contains(mx, my)) {
                g.renderTooltip(font, Component.literal(link.style().getClickEvent().getValue()), mx, my);
                break;
            }
        }
        g.flush();
        g.pose().popPose();
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (button != 0) return false;
        if (inside(mx, my, viewX(), viewY(), viewW(), viewH())) {
            for (NewsView.Link link : links) if (link.contains(mx, my)) return handleComponentClicked(link.style());
        }
        int by = buttonY();
        if (inside(mx, my, closeX(), by, 100, 18)) {
            onClose();
            return true;
        }
        if (item.canDelete() && inside(mx, my, deleteX(), by, 150, 18)) {
            if (confirmDelete) {
                PacketDistributor.sendToServer(new CabinetNet.DeleteNews(item.id()));
                onClose();
            } else {
                confirmDelete = true;
            }
            return true;
        }
        confirmDelete = false;
        return true;
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double scrollX, double scrollY) {
        scroll -= (int) (scrollY * 14);
        return true;
    }

    @Override
    public void onClose() {
        Minecraft.getInstance().setScreen(parent);
    }
}
