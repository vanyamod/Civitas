package com.humanitas.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.screens.inventory.ContainerScreen;
import net.minecraft.client.gui.screens.inventory.DispenserScreen;
import net.minecraft.client.gui.screens.inventory.HopperScreen;
import net.minecraft.client.gui.screens.inventory.ShulkerBoxScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.inventory.DispenserMenu;
import net.minecraft.world.inventory.HopperMenu;
import net.minecraft.world.inventory.ShulkerBoxMenu;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.entity.player.Inventory;

import static com.humanitas.client.CivitasUi.*;

/**
 * The Civitas look for the vanilla storage screens. The plate, rim, cells and seam are the same as the
 * Civitas player inventory, so a chest, a shulker box and the inventory read as one set. The storage
 * part sits above the seam, the player's own inventory below it.
 *
 * <p>Each screen is a thin subclass of the vanilla screen, so slots, clicks, tooltips and sorting keep
 * their stock behaviour. Only the background, the labels and the slot highlight are replaced.</p>
 */
public final class CivitasContainerStyle {
    private CivitasContainerStyle() {}

    /** Plate, gold rim with mitered corners, inner rule and corner studs. Same as the Civitas inventory. */
    static void drawPlate(GuiGraphics g, int x, int y, int w, int h) {
        // Outer shadow, two layers for depth.
        g.fill(x + 3, y + h + 1, x + w + 3, y + h + 3, 0x44000000);
        g.fill(x + w + 1, y + 3, x + w + 3, y + h + 1, 0x44000000);
        g.fill(x + 2, y + h, x + w + 2, y + h + 2, 0x66000000);
        g.fill(x + w, y + 2, x + w + 2, y + h, 0x66000000);

        // Gold rim, two pixels thick with mitered corners.
        g.fill(x + 2, y, x + w - 2, y + 2, GOLD);
        g.fill(x + 2, y + h - 2, x + w - 2, y + h, GOLD);
        g.fill(x, y + 2, x + 2, y + h - 2, GOLD);
        g.fill(x + w - 2, y + 2, x + w, y + h - 2, GOLD);
        g.fill(x + 1, y + 1, x + 2, y + 2, GOLD);
        g.fill(x + w - 2, y + 1, x + w - 1, y + 2, GOLD);
        g.fill(x + 1, y + h - 2, x + 2, y + h - 1, GOLD);
        g.fill(x + w - 2, y + h - 2, x + w - 1, y + h - 1, GOLD);

        // Darker inner hairline, giving the rim a bevelled look.
        g.fill(x + 2, y + 2, x + w - 2, y + 3, GOLD_DEEP);
        g.fill(x + 2, y + h - 3, x + w - 2, y + h - 2, GOLD_DEEP);
        g.fill(x + 2, y + 3, x + 3, y + h - 3, GOLD_DEEP);
        g.fill(x + w - 3, y + 3, x + w - 2, y + h - 3, GOLD_DEEP);

        // Body with a subtle vertical gradient.
        g.fillGradient(x + 2, y + 2, x + w - 2, y + h - 2, PANEL, PLATE_DEEP);

        // Inner gold rule, inset from the rim.
        g.fill(x + 7, y + 4, x + w - 7, y + 5, RULE);
        g.fill(x + 7, y + h - 5, x + w - 7, y + h - 4, RULE);
        g.fill(x + 4, y + 7, x + 5, y + h - 7, RULE);
        g.fill(x + w - 5, y + 7, x + w - 4, y + h - 7, RULE);

        // Cream light on the top edge, like the lip of a metal plate.
        g.fill(x + 7, y + 2, x + w - 7, y + 3, CivitasColors.alpha(CREAM_ACTIVE, 0x40));

        // Corner studs.
        g.fill(x + 3, y + 3, x + 5, y + 5, GOLD);
        g.fill(x + w - 5, y + 3, x + w - 3, y + 5, GOLD);
        g.fill(x + 3, y + h - 5, x + 5, y + h - 3, GOLD);
        g.fill(x + w - 5, y + h - 5, x + w - 3, y + h - 3, GOLD);
    }

    /** Every active slot of the menu, storage and player alike, as a Civitas cell. */
    static void drawCells(GuiGraphics g, AbstractContainerScreen<?> screen, int x, int y) {
        for (Slot slot : screen.getMenu().slots) {
            if (!slot.isActive()) {
                continue;
            }
            int sx = x + slot.x - 1;
            int sy = y + slot.y - 1;

            g.fill(sx, sy, sx + 18, sy + 18, SLOT_EDGE);
            g.fill(sx + 1, sy + 1, sx + 17, sy + 17, SLOT_FILL);
            // Inner bevel: a light lip on top-left, a shade on bottom-right.
            g.fill(sx + 1, sy + 1, sx + 17, sy + 2, SLOT_LIGHT);
            g.fill(sx + 1, sy + 1, sx + 2, sy + 17, SLOT_LIGHT);
            g.fill(sx + 16, sy + 2, sx + 17, sy + 17, SLOT_SHADE);
            g.fill(sx + 2, sy + 16, sx + 17, sy + 17, SLOT_SHADE);
            g.fill(sx + 1, sy + 16, sx + 2, sy + 17, SLOT_SHADE);
        }
    }

    /**
     * The gold seam between the storage and the player's inventory. The player's block starts 82 pixels
     * above the bottom of the vanilla screen, so the seam sits 6 pixels above it.
     */
    static void drawSeam(GuiGraphics g, int x, int y, int w, int h) {
        int mid = x + w / 2;
        int ruleY = y + h - 88;
        g.fill(x + 8, ruleY, x + w - 8, ruleY + 1, CivitasColors.alpha(GOLD, 0x50));
        g.fill(mid - 5, ruleY - 2, mid + 6, ruleY - 1, GOLD_DEEP);
        g.fill(mid - 4, ruleY - 1, mid + 5, ruleY, GOLD);
        g.fill(mid - 3, ruleY, mid + 4, ruleY + 1, GOLD);
        g.fill(mid - 4, ruleY + 1, mid + 5, ruleY + 2, GOLD_DEEP);
        g.fill(mid - 1, ruleY - 3, mid + 2, ruleY - 2, GOLD);
        g.fill(mid - 1, ruleY + 2, mid + 2, ruleY + 3, GOLD_DEEP);
    }

    /** Background of any storage screen: the plate, the cells and the seam. */
    static void background(GuiGraphics g, AbstractContainerScreen<?> screen, int x, int y, int w, int h) {
        drawPlate(g, x, y, w, h);
        drawCells(g, screen, x, y);
        drawSeam(g, x, y, w, h);
    }

    /** The screen title in cream, in the place vanilla uses. The player label is left out, as in the Civitas inventory. */
    static void drawTitle(GuiGraphics g, Component title) {
        g.drawString(Minecraft.getInstance().font, title, 8, 6, TEXT_LIGHT, true);
    }

    /** Hover highlight of a cell, the same colour as the Civitas inventory. */
    static boolean highlightable(Slot slot) {
        return slot.isHighlightable();
    }

    // ---------- screens ----------

    /** Chests, barrels and the ender chest. */
    public static final class Chest extends ContainerScreen {
        public Chest(ChestMenu menu, Inventory inventory, Component title) {
            super(menu, inventory, title);
        }

        @Override
        protected void renderBg(GuiGraphics g, float partialTick, int mouseX, int mouseY) {
            background(g, this, this.leftPos, this.topPos, this.imageWidth, this.imageHeight);
        }

        @Override
        protected void renderLabels(GuiGraphics g, int mouseX, int mouseY) {
            drawTitle(g, this.getTitle());
        }

        @Override
        protected void renderSlotHighlight(GuiGraphics g, Slot slot, int mouseX, int mouseY, float partialTick) {
            if (highlightable(slot)) {
                renderSlotHighlight(g, slot.x, slot.y, 0, HOVER);
            }
        }
    }

    /** Shulker boxes, in every colour. */
    public static final class Shulker extends ShulkerBoxScreen {
        public Shulker(ShulkerBoxMenu menu, Inventory inventory, Component title) {
            super(menu, inventory, title);
        }

        @Override
        protected void renderBg(GuiGraphics g, float partialTick, int mouseX, int mouseY) {
            background(g, this, this.leftPos, this.topPos, this.imageWidth, this.imageHeight);
        }

        @Override
        protected void renderLabels(GuiGraphics g, int mouseX, int mouseY) {
            drawTitle(g, this.getTitle());
        }

        @Override
        protected void renderSlotHighlight(GuiGraphics g, Slot slot, int mouseX, int mouseY, float partialTick) {
            if (highlightable(slot)) {
                renderSlotHighlight(g, slot.x, slot.y, 0, HOVER);
            }
        }
    }

    /** Hoppers: a single row of five cells. */
    public static final class Hopper extends HopperScreen {
        public Hopper(HopperMenu menu, Inventory inventory, Component title) {
            super(menu, inventory, title);
        }

        @Override
        protected void renderBg(GuiGraphics g, float partialTick, int mouseX, int mouseY) {
            background(g, this, this.leftPos, this.topPos, this.imageWidth, this.imageHeight);
        }

        @Override
        protected void renderLabels(GuiGraphics g, int mouseX, int mouseY) {
            drawTitle(g, this.getTitle());
        }

        @Override
        protected void renderSlotHighlight(GuiGraphics g, Slot slot, int mouseX, int mouseY, float partialTick) {
            if (highlightable(slot)) {
                renderSlotHighlight(g, slot.x, slot.y, 0, HOVER);
            }
        }
    }

    /** Droppers and dispensers: a 3x3 grid. */
    public static final class Dispenser extends DispenserScreen {
        public Dispenser(DispenserMenu menu, Inventory inventory, Component title) {
            super(menu, inventory, title);
        }

        @Override
        protected void renderBg(GuiGraphics g, float partialTick, int mouseX, int mouseY) {
            background(g, this, this.leftPos, this.topPos, this.imageWidth, this.imageHeight);
        }

        @Override
        protected void renderLabels(GuiGraphics g, int mouseX, int mouseY) {
            drawTitle(g, this.getTitle());
        }

        @Override
        protected void renderSlotHighlight(GuiGraphics g, Slot slot, int mouseX, int mouseY, float partialTick) {
            if (highlightable(slot)) {
                renderSlotHighlight(g, slot.x, slot.y, 0, HOVER);
            }
        }
    }
}
