package com.humanitas.client;

import com.humanitas.CivitasClientConfig;
import com.humanitas.Humanitas;
import net.minecraft.client.AttackIndicatorStatus;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.PlayerFaceRenderer;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.Mth;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.GameType;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RegisterGuiLayersEvent;
import net.neoforged.neoforge.client.event.RenderGuiLayerEvent;
import net.neoforged.neoforge.client.gui.VanillaGuiLayers;

import java.util.Set;

import static com.humanitas.client.CivitasUi.*;

/**
 * The Civitas hotbar and status bars.
 */
@EventBusSubscriber(modid = Humanitas.MODID, value = Dist.CLIENT)
public final class CivitasHud {
    private CivitasHud() {}

    private static final ResourceLocation LAYER = ResourceLocation.fromNamespaceAndPath(Humanitas.MODID, "hotbar");

    private static final Set<ResourceLocation> REPLACED = Set.of(
            VanillaGuiLayers.HOTBAR,
            VanillaGuiLayers.EXPERIENCE_BAR,
            VanillaGuiLayers.EXPERIENCE_LEVEL,
            VanillaGuiLayers.PLAYER_HEALTH,
            VanillaGuiLayers.ARMOR_LEVEL,
            VanillaGuiLayers.FOOD_LEVEL,
            VanillaGuiLayers.VEHICLE_HEALTH,
            VanillaGuiLayers.AIR_LEVEL);

    private static final Set<ResourceLocation> HIDDEN_WITH_HUD = Set.of(
            VanillaGuiLayers.HOTBAR,
            VanillaGuiLayers.EXPERIENCE_BAR,
            VanillaGuiLayers.EXPERIENCE_LEVEL,
            VanillaGuiLayers.PLAYER_HEALTH,
            VanillaGuiLayers.ARMOR_LEVEL,
            VanillaGuiLayers.FOOD_LEVEL,
            VanillaGuiLayers.VEHICLE_HEALTH,
            VanillaGuiLayers.AIR_LEVEL,
            VanillaGuiLayers.SELECTED_ITEM_NAME,
            VanillaGuiLayers.EFFECTS);

    /** 9 x 8 pixel heart, drawn with one-pixel runs. */
    private static final String[] HEART_MASK = {
            ".XX.XX...",
            "XXXXXXXX.",
            "XXXXXXXXX",
            "XXXXXXXXX",
            ".XXXXXXX.",
            "..XXXXX..",
            "...XXX...",
            "....X...."
    };

    /** 9 x 8 heater shield. */
    private static final String[] SHIELD_MASK = {
            "XXXXXXXXX",
            "XXXXXXXXX",
            "XXXXXXXXX",
            ".XXXXXXX.",
            ".XXXXXXX.",
            "..XXXXX..",
            "...XXX...",
            "....X...."
    };

    /** 9 x 8 apple body; the stem and leaf are drawn separately. */
    private static final String[] APPLE_MASK = {
            ".........",
            ".........",
            ".XXXXXXX.",
            "XXXXXXXXX",
            "XXXXXXXXX",
            ".XXXXXXX.",
            "..XXXXX..",
            "...XXX..."
    };

    /** 9 x 8 air bubble. */
    private static final String[] BUBBLE_MASK = {
            "...XXX...",
            "..XXXXX..",
            ".XXXXXXX.",
            "XXXXXXXXX",
            "XXXXXXXXX",
            ".XXXXXXX.",
            "..XXXXX..",
            "...XXX..."
    };

    @SubscribeEvent
    public static void registerLayer(RegisterGuiLayersEvent event) {
        event.registerAbove(VanillaGuiLayers.HOTBAR, LAYER, CivitasHud::render);
    }

    /** Hides the vanilla layers that the Civitas hotbar redraws. Off-palette: vanilla HUD comes back. */
    @SubscribeEvent
    public static void hideVanillaLayers(RenderGuiLayerEvent.Pre event) {
        if (REPLACED.contains(event.getName()) && paletteOn() && canDraw()) {
            event.setCanceled(true);
        }
    }

    /** The Civitas style for the hotbar and status bars: palette switched on and the config allows it. */
    private static boolean paletteOn() {
        return CivitasPaletteState.hudVisible() && customHotbar();
    }

    private static boolean customHotbar() {
        try {
            return CivitasClientConfig.CUSTOM_HOTBAR.get();
        } catch (RuntimeException e) {
            return false;
        }
    }

    private static boolean canDraw() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.gameMode == null || mc.options.hideGui) {
            return false;
        }
        if (mc.gameMode.getPlayerMode() == GameType.SPECTATOR) {
            return false;
        }
        return true;
    }

    private static void render(GuiGraphics g, DeltaTracker deltaTracker) {
        if (!canDraw()) {
            return;
        }
        boolean palette = paletteOn();
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        Font font = mc.font;
        int left = g.guiWidth() / 2 - 91;
        int top = g.guiHeight() - 22;

        if (palette) {
            drawStatusBars(g, font, mc, player, left, top);

            drawHotbar(g, font, deltaTracker, player, left, top);
        }

        ItemStack offhand = player.getOffhandItem();
        if (palette && !offhand.isEmpty()) {
            int ox = left + 182 + 7;
            plate(g, ox, top, 22, 22);
            renderSlot(g, font, deltaTracker, player, ox + 3, top + 3, offhand, 10);
        }

        int platesX = left + 182 + (palette && !offhand.isEmpty() ? 34 : 6);
        drawSidePanel(g, font, player, platesX, top);
    }

    // ---------- status bars ----------

    private static void drawStatusBars(GuiGraphics g, Font font, Minecraft mc, LocalPlayer player, int left, int top) {
        int heartsY = top - 17;
        boolean canHurt = mc.gameMode.canHurtPlayer();
        int healthRows = 1;
        int armourRows = 1;
        int foodRows = 1;
        boolean airShown = false;
        LivingEntity mount = mountWithHealth(player);

        if (canHurt) {
            int maxHealth = Mth.ceil(Math.max(player.getMaxHealth(), player.getHealth()));
            int maxHearts = Mth.ceil(maxHealth / 2.0F);
            int absorbHearts = Mth.ceil(player.getAbsorptionAmount() / 2.0F);
            int totalHearts = Math.max(1, maxHearts + absorbHearts);
            healthRows = (totalHearts + 9) / 10;
            drawHearts(g, player, left, heartsY, maxHearts, totalHearts, player.getHealth(),
                    player.getAbsorptionAmount());

            int armour = player.getArmorValue();
            armourRows = armour > 0 ? Math.max(1, (Mth.ceil(armour / 2.0F) + 9) / 10) : 0;
            drawArmour(g, font, left, heartsY - healthRows * 10, armour, armourRows);

            if (mount != null) {
                int mountMax = Mth.ceil(Math.min(mount.getMaxHealth(), 60.0F) / 2.0F);
                int mountRows = Math.max(1, (mountMax + 9) / 10);
                drawMountHearts(g, left, heartsY, mount.getHealth(), mountRows);
                foodRows = mountRows;
            } else {
                int food = player.getFoodData().getFoodLevel();
                foodRows = Math.max(1, (Mth.ceil(food / 2.0F) + 9) / 10);
                drawFood(g, player, left, heartsY, food, foodRows);
            }

            int maxAir = player.getMaxAirSupply();
            int air = Math.min(player.getAirSupply(), maxAir);
            if (maxAir > 0 && (player.isEyeInFluid(FluidTags.WATER) || air < maxAir)) {
                drawAir(g, left, heartsY - foodRows * 10, air, maxAir);
                airShown = true;
            }
        }

        drawExperience(g, font, mc, player, left, top);

        Gui gui = mc.gui;
        if (canHurt) {
            gui.leftHeight = 59 + Math.max(0, healthRows - 1) * 10 + Math.max(0, armourRows - 1) * 10;
            gui.rightHeight = 39 + foodRows * 10 + (airShown ? 10 : 0);
        } else {
            gui.leftHeight = 39;
            gui.rightHeight = 39;
        }
    }

    private static void drawHearts(GuiGraphics g, LocalPlayer player, int left, int y,
                                   int maxHearts, int totalHearts, float health, float absorption) {
        int fullHealth = Mth.ceil(health);
        int absorbPoints = Mth.ceil(absorption);
        int colour = heartColour(player);
        boolean blink = player.hurtTime > 0 && (player.tickCount / 3) % 2 == 0;
        int regen = player.hasEffect(MobEffects.REGENERATION)
                ? player.tickCount % Mth.ceil(player.getMaxHealth() + 5.0F)
                : -1;
        boolean low = health + absorption <= 4.0F;

        for (int i = totalHearts - 1; i >= 0; i--) {
            int row = i / 10;
            int column = i % 10;
            int x = left + column * 8;
            int iconY = y - row * 10;
            if (low) {
                iconY += ((player.tickCount + column * 13) % 3) - 1;
            }

            boolean absorbing = i >= maxHearts;
            int index = absorbing ? i - maxHearts : i;
            int points = absorbing ? absorbPoints : fullHealth;
            boolean half = index * 2 + 1 == points;
            boolean full = index * 2 + 2 <= points;

            if (!absorbing && i == regen) {
                iconY -= 2;
            }

            mask(g, HEART_MASK, x, iconY, 9, ICON_EMPTY);
            int fill = absorbing ? HEART_ABSORB : (blink ? TEXT_LIGHT : colour);
            if (full) {
                mask(g, HEART_MASK, x, iconY, 9, fill);
                highlight(g, x + 2, iconY + 1, 2, 1);
            } else if (half) {
                mask(g, HEART_MASK, x, iconY, 4, fill);
                highlight(g, x + 1, iconY + 1, 1, 1);
            }
        }
    }

    private static int heartColour(LocalPlayer player) {
        if (player.hasEffect(MobEffects.WITHER)) {
            return HEART_WITHER;
        }
        if (player.hasEffect(MobEffects.POISON)) {
            return HEART_POISON;
        }
        if (player.getTicksFrozen() > 0) {
            return HEART_FROZEN;
        }
        return HEART;
    }

    /**
     * Armour in the current palette: shields in the palette's shield colour, a metal rim,
     * dark plate for the empty cells, and the point count in metal to the right.
     */
    private static void drawArmour(GuiGraphics g, Font font, int left, int y, int armour, int rows) {
        if (armour <= 0 || rows <= 0) {
            return;
        }
        for (int i = 0; i < rows * 10; i++) {
            int row = i / 10;
            int column = i % 10;
            int x = left + column * 8;
            int iconY = y - row * 10;
            mask(g, SHIELD_MASK, x, iconY, 9, PLATE_DEEP);
            if (i * 2 + 2 <= armour) {
                mask(g, SHIELD_MASK, x, iconY, 9, SHIELD);
                g.fill(x + 2, iconY + 1, x + 6, iconY + 2, GOLD);
            } else if (i * 2 + 1 == armour) {
                mask(g, SHIELD_MASK, x, iconY, 4, SHIELD);
                g.fill(x + 1, iconY + 1, x + 3, iconY + 2, GOLD);
            }
        }
        g.drawString(font, Integer.toString(armour), left + 10 * 8 + 4, y + 1, GOLD, false);
    }

    private static void drawFood(GuiGraphics g, LocalPlayer player, int left, int y, int food, int rows) {
        boolean hungry = player.hasEffect(MobEffects.HUNGER);
        boolean jitter = player.getFoodData().getSaturationLevel() <= 0.0F
                && player.tickCount % (food * 3 + 1) == 0;
        int colour = hungry ? FOOD_HUNGER : FOOD_COLOR;

        for (int i = 0; i < rows * 10; i++) {
            int row = i / 10;
            int column = i % 10;
            int x = left + 182 - 9 - column * 8;
            int iconY = y - row * 10;
            if (jitter) {
                iconY += ((player.tickCount + column * 7) % 3) - 1;
            }

            // Count slots from the left so the bar fills left -> right and drains right -> left.
            int slot = (rows - 1 - row) * 10 + (9 - column);
            int fullPoint = slot * 2 + 2;
            int halfPoint = slot * 2 + 1;

            mask(g, APPLE_MASK, x, iconY, 9, ICON_EMPTY);
            g.fill(x + 4, iconY, x + 5, iconY + 1, ICON_EMPTY);
            g.fill(x + 5, iconY, x + 6, iconY + 1, ICON_EMPTY);

            if (fullPoint <= food) {
                mask(g, APPLE_MASK, x, iconY, 9, colour);
                highlight(g, x + 2, iconY + 3, 2, 1);
                stem(g, x, iconY);
            } else if (halfPoint == food) {
                mask(g, APPLE_MASK, x, iconY, 4, colour);
                highlight(g, x + 1, iconY + 3, 1, 1);
                stem(g, x, iconY);
            }
        }
    }

    private static void stem(GuiGraphics g, int x, int y) {
        g.fill(x + 4, y, x + 5, y + 2, GOLD);
        g.fill(x + 5, y, x + 7, y + 1, GOLD);
    }

    private static void drawMountHearts(GuiGraphics g, int left, int y, float health, int rows) {
        int points = Mth.ceil(health);
        for (int i = 0; i < rows * 10; i++) {
            int row = i / 10;
            int column = i % 10;
            int x = left + 182 - 9 - column * 8;
            int iconY = y - row * 10;
            mask(g, HEART_MASK, x, iconY, 9, ICON_EMPTY);
            if (i * 2 + 2 <= points) {
                mask(g, HEART_MASK, x, iconY, 9, HEART_MOUNT);
                highlight(g, x + 2, iconY + 1, 2, 1);
            } else if (i * 2 + 1 == points) {
                mask(g, HEART_MASK, x, iconY, 4, HEART_MOUNT);
                highlight(g, x + 1, iconY + 1, 1, 1);
            }
        }
    }

    private static void drawAir(GuiGraphics g, int left, int y, int air, int maxAir) {
        float per = (float) air * 10.0F / (float) maxAir;
        int full = (int) per;
        boolean half = per - full >= 0.5F;

        for (int i = 0; i < 10; i++) {
            int x = left + 182 - 9 - i * 8;
            mask(g, BUBBLE_MASK, x, y, 9, ICON_EMPTY);
            if (i < full) {
                mask(g, BUBBLE_MASK, x, y, 9, AIR_COLOR);
                highlight(g, x + 2, y + 2, 2, 1);
            } else if (i == full && half) {
                mask(g, BUBBLE_MASK, x, y, 4, AIR_COLOR);
                highlight(g, x + 1, y + 2, 1, 1);
            }
        }
    }

    private static LivingEntity mountWithHealth(LocalPlayer player) {
        return player.getVehicle() instanceof LivingEntity living && living.showVehicleHealth() ? living : null;
    }

    private static void drawExperience(GuiGraphics g, Font font, Minecraft mc, LocalPlayer player, int left, int top) {
        if (player.jumpableVehicle() != null || !mc.gameMode.hasExperience()) {
            return;
        }

        int y = top - 7;
        int width = 182;
        int inner = width - 2;
        g.fill(left, y, left + width, y + 5, GOLD);
        g.fill(left + 1, y + 1, left + width - 1, y + 4, PLATE_DEEP);

        int filled = Mth.clamp((int) (player.experienceProgress * inner), 0, inner);
        if (filled > 0) {
            g.fill(left + 1, y + 1, left + 1 + filled, y + 4, OLIVE);
            g.fill(left + 1, y + 1, left + 1 + filled, y + 2, HIGHLIGHT);
        }

        for (int i = 1; i < 10; i++) {
            int tickX = left + 1 + i * inner / 10;
            g.fill(tickX, y + 1, tickX + 1, y + 4, LINE);
        }

        int level = player.experienceLevel;
        if (level > 0) {
            String text = Integer.toString(level);
            int textX = left + 91 - font.width(text) / 2;
            g.drawString(font, text, textX, top - 17, TEXT_LIGHT, true);
        }
    }

    // ---------- hotbar ----------

    private static void plate(GuiGraphics g, int x, int y, int w, int h) {
        g.fill(x + 2, y + h, x + w + 1, y + h + 1, 0x55000000);
        g.fill(x + w, y + 2, x + w + 1, y + h, 0x55000000);
        g.fill(x + 1, y, x + w - 1, y + h, GOLD);
        g.fill(x, y + 1, x + w, y + h - 1, GOLD);
        g.fill(x + 2, y + 1, x + w - 2, y + h - 1, PLATE);
        g.fill(x + 1, y + 2, x + w - 1, y + h - 2, PLATE);
        g.fill(x + 3, y + 2, x + w - 3, y + 3, LINE);
    }

    private static void drawHotbar(GuiGraphics g, Font font, DeltaTracker dt, LocalPlayer player, int left, int top) {
        plate(g, left, top, 182, 22);
        for (int i = 1; i < 9; i++) {
            int x = left + 1 + i * 20;
            g.fill(x, top + 4, x + 1, top + 18, CELL_LINE);
        }

        int sx = left + 1 + player.getInventory().selected * 20;
        g.fill(sx + 1, top + 2, sx + 19, top + 20, SELECT_FILL);
        g.fill(sx + 1, top + 2, sx + 19, top + 3, GOLD);
        g.fill(sx + 1, top + 19, sx + 19, top + 20, GOLD);
        g.fill(sx + 1, top + 3, sx + 2, top + 19, GOLD);
        g.fill(sx + 18, top + 3, sx + 19, top + 19, GOLD);

        if (Minecraft.getInstance().options.attackIndicator().get() == AttackIndicatorStatus.HOTBAR) {
            float strength = player.getAttackStrengthScale(0.0F);
            if (strength < 1.0F) {
                int length = (int) (strength * 14.0F);
                g.fill(sx + 16 - length, top + 18, sx + 16, top + 19, GOLD);
            }
        }

        int seed = 1;
        for (int i = 0; i < 9; i++) {
            renderSlot(g, font, dt, player, left + 3 + i * 20, top + 3, player.getInventory().items.get(i), seed++);
        }
    }

    /** Same item drawing as vanilla, including the small "pop" when an item is picked up. */
    private static void renderSlot(GuiGraphics g, Font font, DeltaTracker dt, LocalPlayer player,
                                   int x, int y, ItemStack stack, int seed) {
        if (stack.isEmpty()) {
            return;
        }
        float pop = stack.getPopTime() - dt.getGameTimeDeltaPartialTick(false);
        if (pop > 0.0F) {
            float f = 1.0F + pop / 5.0F;
            g.pose().pushPose();
            g.pose().translate(x + 8, y + 12, 0);
            g.pose().scale(1.0F / f, (f + 1.0F) / 2.0F, 1.0F);
            g.pose().translate(-(x + 8), -(y + 12), 0);
        }
        g.renderItem(player, stack, x, y, seed);
        if (pop > 0.0F) {
            g.pose().popPose();
        }
        g.renderItemDecorations(font, stack, x, y);
    }

    // ---------- right-hand plates ----------

    /** Both plates (state above, player below) live on the right of the hotbar. */
    private static void drawRightPlates(GuiGraphics g, Font font, LocalPlayer player, int x, int top) {
        boolean hasState = CabinetClientState.hasState();
        String state = hasState ? CabinetClientState.stateName() : "Без государства";
        String date = CabinetClientState.dateText();
        String icon = CabinetClientState.ideologyIcon();
        String nick = player.getGameProfile().getName();
        String time = CabinetClientState.clockText();
        String day = "День " + CabinetClientState.gameDay();
        String weather = CabinetClientState.weatherText();
        String phase = CabinetClientState.phaseText();

        String meta = day + " · " + weather;
        String infoLine1 = icon + "  " + state;
        String infoLine2 = date + " · " + phase;
        String playerLine1 = nick + "   " + time;

        int maxW = g.guiWidth() - x - 4;
        if (maxW < 72) {
            return;
        }
        int wanted = Math.max(
                Math.max(font.width(playerLine1) + 30, font.width(meta) + 30),
                Math.max(font.width(infoLine1) + 24, font.width(infoLine2) + 24));
        int w = Math.min(maxW, Math.min(214, Math.max(96, wanted)));
        if (w < 72) {
            return;
        }

        // Flush the plates into the bottom-right corner, but never over the hotbar.
        int px = Math.max(x, g.guiWidth() - w - 4);
        if (px + w > g.guiWidth() - 2) {
            px = g.guiWidth() - w - 2;
        }

        // The two plates form one connected panel: no gap, shared rim, a clasp at the seam.
        int infoY = top - 22;
        if (infoY >= 2) {
            drawInfoPlate(g, font, px, infoY, w, hasState, icon, state, infoLine2);
        }
        drawPlayerPlate(g, font, player, px, top, w, nick, time, meta);

        // Seam clasp, tying the two halves together.
        int mid = px + w / 2;
        g.fill(mid - 3, top - 1, mid + 4, top, GOLD);
        g.fill(mid - 2, top - 2, mid + 3, top - 1, GOLD_DEEP);
    }

    private static void drawInfoPlate(GuiGraphics g, Font font, int x, int y, int w,
                                     boolean hasState, String icon, String state, String line2) {
        plate(g, x, y, w, 22);
        g.fill(x + 1, y + 1, x + 3, y + 21, OLIVE);

        int stateColor = hasState ? GOLD : DIM;
        g.drawString(font, icon, x + 7, y + 4, stateColor, false);
        g.drawString(font, font.plainSubstrByWidth(state, w - 24), x + 19, y + 4, stateColor, false);
        g.drawString(font, font.plainSubstrByWidth(line2, w - 24), x + 19, y + 13,
                hasState ? TEXT_LIGHT : DIM, false);
    }

    private static void drawPlayerPlate(GuiGraphics g, Font font, LocalPlayer player, int x, int top,
                                       int w, String nick, String time, String meta) {
        plate(g, x, top, w, 22);
        g.fill(x + 1, top + 1, x + 3, top + 21, OLIVE);

        g.fill(x + 3, top + 3, x + 19, top + 19, GOLD);
        PlayerFaceRenderer.draw(g, player.getSkin(), x + 4, top + 4, 14);

        int textX = x + 23;
        int timeX = x + w - 7 - font.width(time);
        int nickMax = Math.max(10, timeX - textX - 6);
        g.drawString(font, font.plainSubstrByWidth(nick, nickMax), textX, top + 4, TEXT_LIGHT, false);
        g.drawString(font, time, timeX, top + 4, GOLD, false);
        g.drawString(font, font.plainSubstrByWidth(meta, w - 28), textX, top + 13, DIM, false);
    }

    // ---------- side panel: three icons above, player card below ----------

    private static final int ICON_W = 24;
    private static final int ICON_H = 20;
    private static final int ICON_GAP = 4;
    private static final String[] SIDE_ICONS = {"✉", "✒", "⌂"};

    /**
     * Right of the hotbar: an icon row above (news, laws, state), the day and weather beside it,
     * and the player card below, level with the hotbar: head, nickname, time, state, date.
     */
    private static void drawSidePanel(GuiGraphics g, Font font, LocalPlayer player, int x, int top) {
        int avail = g.guiWidth() - x - 4;
        if (avail < 100) {
            return;
        }
        int w = Math.min(avail, Math.max(132, Math.min(230, cardWidth(font, player))));

        int iconY = top - ICON_H - 4;
        boolean hasState = CabinetClientState.hasState();
        for (int i = 0; i < SIDE_ICONS.length; i++) {
            boolean unread = (i == 0 && CivitasFeed.newsUnread()) || (i == 1 && CivitasFeed.lawsUnread());
            boolean enabled = i != 1 || hasState;
            drawSideIcon(g, font, x + i * (ICON_W + ICON_GAP), iconY, SIDE_ICONS[i], unread, enabled);
        }

        String meta = "День " + CabinetClientState.gameDay() + " · " + CabinetClientState.weatherText();
        int metaX = x + SIDE_ICONS.length * (ICON_W + ICON_GAP) + 2;
        int metaW = x + w - metaX;
        if (metaW > 24) {
            g.drawString(font, font.plainSubstrByWidth(meta, metaW), metaX, iconY + 6, DIM, false);
        }

        drawPlayerCard(g, font, player, x, top, w);
    }

    /** One icon button. Unread icons pulse gold; disabled icons are dimmed. */
    private static void drawSideIcon(GuiGraphics g, Font font, int x, int y, String glyph,
                                     boolean unread, boolean enabled) {
        boolean on = unread && (System.currentTimeMillis() / 450L) % 2L == 0L;
        int fill = !enabled ? PLATE_DEEP : unread ? (on ? GOLD : CREAM_HOVER) : PLATE;
        int rule = unread ? GOLD_DEEP : GOLD;
        g.fill(x, y, x + ICON_W, y + ICON_H, rule);
        g.fill(x + 1, y + 1, x + ICON_W - 1, y + ICON_H - 1, fill);
        int color = !enabled ? DIM : unread ? INK : TEXT_LIGHT;
        int tx = x + (ICON_W - font.width(glyph)) / 2;
        g.drawString(font, glyph, tx, y + (ICON_H - 8) / 2 + 1, color, false);
    }

    /** Width the player card needs so nothing is cut: the longer of its two lines. */
    private static int cardWidth(Font font, LocalPlayer player) {
        String state = CabinetClientState.hasState()
                ? CabinetClientState.ideologyIcon() + " " + CabinetClientState.stateName()
                : "Без государства";
        int stateLine = 26 + font.width(state) + 8 + font.width(CabinetClientState.dateText()) + 6;
        int nickLine = 26 + font.width(player.getGameProfile().getName()) + 8
                + font.width(CabinetClientState.clockText()) + 6;
        return Math.max(stateLine, nickLine);
    }

    /** Cuts text to the width and adds an ellipsis, so a cut is always visible. */
    private static String fit(Font font, String text, int maxWidth) {
        if (font.width(text) <= maxWidth) {
            return text;
        }
        return font.plainSubstrByWidth(text, Math.max(0, maxWidth - font.width("…"))) + "…";
    }

    private static void drawPlayerCard(GuiGraphics g, Font font, LocalPlayer player, int x, int top, int w) {
        plate(g, x, top, w, 22);
        g.fill(x + 1, top + 1, x + 3, top + 21, OLIVE);

        // Head: 14 px inside a gold frame.
        g.fill(x + 6, top + 4, x + 22, top + 20, GOLD);
        PlayerFaceRenderer.draw(g, player.getSkin(), x + 7, top + 5, 14);

        String nick = player.getGameProfile().getName();
        String time = CabinetClientState.clockText();
        int textX = x + 26;
        int timeX = x + w - 6 - font.width(time);
        g.drawString(font, fit(font, nick, Math.max(20, timeX - textX - 4)), textX, top + 3,
                TEXT_LIGHT, false);
        g.drawString(font, time, timeX, top + 3, GOLD, false);

        boolean hasState = CabinetClientState.hasState();
        String state = hasState
                ? CabinetClientState.ideologyIcon() + " " + CabinetClientState.stateName()
                : "Без государства";
        String date = CabinetClientState.dateText();
        int dateX = x + w - 6 - font.width(date);
        g.drawString(font, fit(font, state, Math.max(20, dateX - textX - 4)), textX, top + 12,
                hasState ? GOLD : DIM, false);
        g.drawString(font, date, dateX, top + 12, TEXT_LIGHT, false);
    }

    // ---------- pixel icons ----------

    private static void mask(GuiGraphics g, String[] rows, int x, int y, int maxColumns, int colour) {
        for (int row = 0; row < rows.length; row++) {
            String line = rows[row];
            int start = -1;
            for (int col = 0; col <= line.length(); col++) {
                boolean on = col < line.length() && col < maxColumns && line.charAt(col) == 'X';
                if (on && start < 0) {
                    start = col;
                } else if (!on && start >= 0) {
                    g.fill(x + start, y + row, x + col, y + row + 1, colour);
                    start = -1;
                }
            }
        }
    }

    private static void highlight(GuiGraphics g, int x, int y, int w, int h) {
        g.fill(x, y, x + w, y + h, HIGHLIGHT);
    }
}
