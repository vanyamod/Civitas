package com.humanitas.client;

import com.humanitas.Humanitas;
import net.minecraft.client.gui.screens.Screen;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ScreenEvent;

/** Wires CivitasSounds into the screen events: frame reset on render, sound on left click. */
@EventBusSubscriber(modid = Humanitas.MODID, value = Dist.CLIENT)
public final class CivitasClickSounds {
    private CivitasClickSounds() {}

    @SubscribeEvent
    public static void onRenderPre(ScreenEvent.Render.Pre event) {
        if (isCivitas(event.getScreen())) {
            CivitasSounds.beginFrame();
        }
    }

    @SubscribeEvent
    public static void onMousePressed(ScreenEvent.MouseButtonPressed.Pre event) {
        if (event.getButton() != 0 || !isCivitas(event.getScreen())) return;
        CivitasSounds.onClick(event.getMouseX(), event.getMouseY());
    }

    private static boolean isCivitas(Screen screen) {
        return screen != null && screen.getClass().getName().startsWith("com.humanitas.client.");
    }
}
