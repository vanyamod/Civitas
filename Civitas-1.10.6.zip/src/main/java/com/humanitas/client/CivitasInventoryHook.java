package com.humanitas.client;

import com.humanitas.CivitasClientConfig;
import com.humanitas.Humanitas;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ScreenEvent;

/**
 * Swaps the vanilla survival inventory for {@link CivitasInventoryScreen} when it is about to open.
 * Only the exact vanilla class is replaced: modded inventories and the creative inventory stay as
 * they are, and the switch can be turned off in config/civitas-client.toml.
 */
@EventBusSubscriber(modid = Humanitas.MODID, value = Dist.CLIENT)
public final class CivitasInventoryHook {
    private CivitasInventoryHook() {}

    @SubscribeEvent
    public static void opening(ScreenEvent.Opening event) {
        if (event.getNewScreen() == null || event.getNewScreen().getClass() != InventoryScreen.class) {
            return;
        }
        if (!enabled()) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) {
            return;
        }
        event.setNewScreen(new CivitasInventoryScreen(mc.player));
    }

    private static boolean enabled() {
        try {
            return CivitasClientConfig.CUSTOM_INVENTORY.get();
        } catch (RuntimeException e) {
            return false;
        }
    }
}
