package com.humanitas.client;

import com.humanitas.Humanitas;
import net.minecraft.client.Minecraft;
import net.minecraft.world.level.storage.LevelResource;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.Properties;
import java.util.UUID;

/** One local draft per world/server and player, plus the most recently submitted copy. */
public final class NewsDraftStore {
    public record Draft(String title, String body, String footer, String imageId, String imageName) {
        public static final Draft EMPTY = new Draft("", "", "", "", "");
        public boolean empty() { return title.isEmpty() && body.isEmpty() && footer.isEmpty() && imageId.isEmpty(); }
    }

    private final Path file;
    private final Path submitted;

    public NewsDraftStore() {
        this(currentFile());
    }

    NewsDraftStore(Path file) {
        this.file = file;
        this.submitted = file.resolveSibling(file.getFileName().toString().replace(".properties", ".submitted.properties"));
    }

    private static Path currentFile() {
        Minecraft mc = Minecraft.getInstance();
        String scope = mc.getCurrentServer() != null ? "server:" + mc.getCurrentServer().ip
                : mc.getSingleplayerServer() != null
                ? "world:" + mc.getSingleplayerServer().getWorldPath(LevelResource.ROOT).toAbsolutePath().normalize()
                : "offline-preview";
        String player = mc.player == null ? "preview" : mc.player.getUUID().toString();
        String key = UUID.nameUUIDFromBytes((scope + ":" + player).getBytes(StandardCharsets.UTF_8)).toString();
        Path dir = mc.gameDirectory.toPath().resolve("config/civitas-news-drafts");
        return dir.resolve(key + ".properties");
    }

    public Draft load() { return read(file); }
    public Draft lastSubmitted() { return read(submitted); }
    public boolean save(Draft draft) { return write(file, draft); }
    public boolean rememberSubmission(Draft draft) { return write(submitted, draft); }

    private static Draft read(Path file) {
        if (!Files.isRegularFile(file)) return Draft.EMPTY;
        Properties p = new Properties();
        try (var in = Files.newBufferedReader(file, StandardCharsets.UTF_8)) {
            p.load(in);
            return new Draft(p.getProperty("title", ""), p.getProperty("body", ""), p.getProperty("footer", ""),
                    p.getProperty("image", ""), p.getProperty("imageName", ""));
        } catch (IOException | IllegalArgumentException e) {
            Humanitas.LOGGER.warn("Could not read news draft: {}", e.getMessage());
            return Draft.EMPTY;
        }
    }

    private static boolean write(Path file, Draft draft) {
        Properties p = new Properties();
        p.setProperty("title", draft.title()); p.setProperty("body", draft.body());
        p.setProperty("footer", draft.footer()); p.setProperty("image", draft.imageId());
        p.setProperty("imageName", draft.imageName());
        try {
            Files.createDirectories(file.getParent());
            Path temp = file.resolveSibling(file.getFileName() + ".tmp");
            try (var out = Files.newBufferedWriter(temp, StandardCharsets.UTF_8)) { p.store(out, "Civitas news draft"); }
            try { Files.move(temp, file, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (AtomicMoveNotSupportedException e) { Files.move(temp, file, StandardCopyOption.REPLACE_EXISTING); }
            return true;
        } catch (IOException e) {
            Humanitas.LOGGER.warn("Could not save news draft: {}", e.getMessage());
            return false;
        }
    }
}
