package com.humanitas.client;

import com.humanitas.Humanitas;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Click sounds for every Civitas button. Buttons register their rectangle while they are drawn; on a
 * click the last registered rectangle under the cursor decides the sound by its style. Volume comes
 * from the "Громкость звука" setting, and the pitch varies slightly so repeated clicks don't sound
 * mechanical.
 *
 * The sounds come from the CC0 UI SFX "minimal" pack (github.com/romainsimon/uisfx), re-encoded
 * to Ogg Vorbis for Minecraft, stored in assets/humanitas/sounds/ui and declared in
 * assets/humanitas/sounds.json.
 */
public final class CivitasSounds {
    private static final List<int[]> RECTS = new ArrayList<>();
    private static final List<CivitasUi.Style> STYLES = new ArrayList<>();

    private static final SoundEvent PRESS = sound("ui.press");
    private static final SoundEvent OPEN = sound("ui.open");
    private static final SoundEvent CLOSE = sound("ui.close");
    private static final SoundEvent SELECT = sound("ui.select");

    private CivitasSounds() {}

    private static SoundEvent sound(String name) {
        return SoundEvent.createVariableRangeEvent(
                ResourceLocation.fromNamespaceAndPath(Humanitas.MODID, name));
    }

    /** Called at the start of each frame of a Civitas screen, so stale rectangles never linger. */
    public static void beginFrame() {
        RECTS.clear();
        STYLES.clear();
    }

    /** Called by every drawn button. Disabled buttons are silent. */
    public static void register(int x, int y, int w, int h, CivitasUi.Style style) {
        if (style == CivitasUi.Style.DISABLED || w <= 0 || h <= 0) return;
        RECTS.add(new int[]{x, y, w, h});
        STYLES.add(style);
    }

    /** Plays the sound of the topmost registered button under the cursor, if there is one. */
    public static void onClick(double mx, double my) {
        for (int i = RECTS.size() - 1; i >= 0; i--) {
            int[] r = RECTS.get(i);
            if (CivitasUi.inside(mx, my, r[0], r[1], r[2], r[3])) {
                play(STYLES.get(i));
                return;
            }
        }
    }

    /** Plays the generic click for custom widgets and overlay choices that are not drawn as buttons. */
    public static void playPress() {
        play(CivitasUi.Style.SECONDARY);
    }

    /** Plays the "open" cue for a custom widget that reveals a panel or a window. */
    public static void playOpen() {
        play(CivitasUi.Style.PRIMARY);
    }

    /** Plays the "danger" cue for a custom widget that performs a destructive action. */
    public static void playClose() {
        play(CivitasUi.Style.DANGER);
    }

    /** Plays the "select" cue for a custom list row or a palette sector. */
    public static void playSelect() {
        play(CivitasUi.Style.CHOSEN);
    }

    /** Primary actions and the wheel open with "open", danger with "close", chosen items with "select". */
    private static void play(CivitasUi.Style style) {
        SoundEvent sound = switch (style) {
            case PRIMARY -> OPEN;
            case DANGER -> CLOSE;
            case CHOSEN -> SELECT;
            default -> PRESS;
        };
        float volume = CivitasSettings.soundPercent() / 100F * 0.8F;
        if (volume <= 0F) return;
        float pitch = 0.95F + ThreadLocalRandom.current().nextFloat() * 0.1F;
        Minecraft.getInstance().getSoundManager().play(SimpleSoundInstance.forUI(sound, pitch, volume));
    }
}
