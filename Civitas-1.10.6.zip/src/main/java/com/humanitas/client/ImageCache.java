package com.humanitas.client;

import com.humanitas.CabinetNet;
import com.humanitas.Humanitas;
import com.mojang.blaze3d.platform.NativeImage;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.PacketDistributor;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

/**
 * Photos as GUI textures. A photo is requested from the server once, decoded when it arrives
 * and kept while it is in use. At most 24 are kept; the least recently used one is dropped first.
 * Everything here runs on the client main thread.
 */
public final class ImageCache {
    private ImageCache() {}

    public record Entry(ResourceLocation texture, int width, int height) {}

    private static final int MAX_ENTRIES = 24;
    private static final Map<String, Entry> ENTRIES = new LinkedHashMap<>(32, 0.75f, true);
    private static final Set<String> REQUESTED = new HashSet<>();
    private static int counter = 0;

    /** A key for a photo that only exists on this client, such as the preview in the editor. */
    public static String newLocalKey() {
        return "local_" + (++counter);
    }

    /** The photo if it is ready; otherwise null, and for a server photo the request is sent once. */
    public static Entry get(String id) {
        if (id == null || id.isEmpty()) {
            return null;
        }
        Entry entry = ENTRIES.get(id);
        if (entry != null) {
            return entry;
        }
        if (!id.startsWith("local_") && REQUESTED.add(id)) {
            PacketDistributor.sendToServer(new CabinetNet.RequestMedia("image", id));
        }
        return null;
    }

    /** Called when the server sends a photo. */
    public static void onData(String id, byte[] data) {
        register(id, data);
    }

    /** Decodes the bytes and registers a texture under the key. Returns null if the file can't be read. */
    public static Entry register(String key, byte[] bytes) {
        release(key);
        try {
            NativeImage image = NativeImage.read(new ByteArrayInputStream(bytes));
            int width = image.getWidth();
            int height = image.getHeight();
            DynamicTexture texture = new DynamicTexture(image);
            ResourceLocation location = ResourceLocation.fromNamespaceAndPath(Humanitas.MODID, "news/" + key);
            Minecraft.getInstance().getTextureManager().register(location, texture);
            texture.setFilter(true, false);
            Entry entry = new Entry(location, width, height);
            ENTRIES.put(key, entry);
            trim();
            return entry;
        } catch (IOException | RuntimeException e) {
            Humanitas.LOGGER.warn("Could not decode photo {}: {}", key, e.getMessage());
            return null;
        }
    }

    public static void release(String key) {
        if (key == null || key.isEmpty()) {
            return;
        }
        Entry old = ENTRIES.remove(key);
        if (old != null) {
            Minecraft.getInstance().getTextureManager().release(old.texture());
        }
    }

    private static void trim() {
        Iterator<Map.Entry<String, Entry>> it = ENTRIES.entrySet().iterator();
        while (ENTRIES.size() > MAX_ENTRIES && it.hasNext()) {
            Map.Entry<String, Entry> eldest = it.next();
            it.remove();
            REQUESTED.remove(eldest.getKey());
            Minecraft.getInstance().getTextureManager().release(eldest.getValue().texture());
        }
    }
}
