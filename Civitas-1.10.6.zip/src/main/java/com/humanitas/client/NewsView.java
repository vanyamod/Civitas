package com.humanitas.client;

import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.util.FormattedCharSequence;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static com.humanitas.client.CivitasUi.*;

/**
 * Draws a news article as a newspaper page: ribbon, state, headline, rule, body, footer, byline.
 * Used by the reader and by the live preview in the editor.
 *
 * The body is read block by block: headings (# ## ###), quotes (&gt;), bullet items (- ), code blocks
 * (```), paragraphs and photos ([img:id]). Inline formatting is delegated to {@link RichText}.
 */
public final class NewsView {
    private NewsView() {}

    public record Link(int x, int y, int w, int h, net.minecraft.network.chat.Style style) {
        public boolean contains(double mx, double my) { return inside(mx, my, x, y, w, h); }
    }

    private static void trackLinks(Font font, FormattedCharSequence line, int x, int y, float scale, List<Link> links) {
        if (links == null) return;
        int[] offset = {0};
        line.accept((index, style, point) -> {
            int width = font.width(Component.literal(new String(Character.toChars(point))).withStyle(style));
            if (style.getClickEvent() != null) links.add(new Link(x + (int) (offset[0] * scale), y,
                    Math.max(1, (int) Math.ceil(width * scale)), (int) Math.ceil(10 * scale), style));
            offset[0] += width;
            return true;
        });
    }

    private static final float TITLE_SCALE = 1.4f;
    private static final float H2_SCALE = 1.2f;
    private static final int LINE = 10;
    private static final Pattern IMAGE = Pattern.compile("\\[img:([^\\]]+)\\]");

    /**
     * Draws the article starting at (x, y - scrollPx). The caller sets the scissor.
     * Returns the full height of the article so the caller can limit scrolling.
     */
    public static int draw(GuiGraphics g, Font font, int x, int y, int w, NewsItem n, int scrollPx) {
        return draw(g, font, x, y, w, n, scrollPx, 0);
    }

    public static int draw(GuiGraphics g, Font font, int x, int y, int w, NewsItem n, int scrollPx, int photoPos) {
        return draw(g, font, x, y, w, n, scrollPx, photoPos, null);
    }

    public static int draw(GuiGraphics g, Font font, int x, int y, int w, NewsItem n, int scrollPx, int photoPos, List<Link> links) {
        if (links != null) links.clear();
        int top = y - scrollPx;
        int cy = top;
        int pad = 10;
        int inner = w - pad * 2;

        // Ribbon.
        g.fill(x, cy, x + w, cy + 18, HEADER);
        g.fill(x + 1, cy + 1, x + w - 1, cy + 2, CivitasColors.alpha(TEXT_LIGHT, 0x1A));
        g.fill(x, cy + 18, x + w, cy + 19, GOLD_DEEP);
        g.fill(x + 6, cy + 4, x + 12, cy + 14, GOLD);
        String date = n.when();
        String masthead = w < 290 ? "CIVITAS" : "ВСЕМИРНЫЕ НОВОСТИ";
        g.drawString(font, font.plainSubstrByWidth(masthead, Math.max(12, w - font.width(date) - 35)), x + 16, cy + 5, GOLD, false);
        g.drawString(font, date, x + w - 8 - font.width(date), cy + 5, TEXT_LIGHT, false);
        cy += 18 + 10;

        // State name.
        String state = n.stateName().isEmpty() ? "АДМИНИСТРАЦИЯ" : n.stateName().toUpperCase();
        if (n.hideState() && !n.stateName().isEmpty() && !n.stateName().equals("?????")) state += " · СКРЫТО";
        g.drawString(font, font.plainSubstrByWidth(state, inner), x + pad, cy, OLIVE, false);
        cy += 13;

        // Headline, larger and bold.
        List<FormattedCharSequence> titleLines = font.split(
                Component.literal(n.title()).withStyle(ChatFormatting.BOLD), (int) (inner / TITLE_SCALE));
        for (FormattedCharSequence line : titleLines) {
            g.pose().pushPose();
            g.pose().translate(x + pad, cy, 0);
            g.pose().scale(TITLE_SCALE, TITLE_SCALE, 1f);
            g.drawString(font, line, 0, 0, INK, false);
            g.pose().popPose();
            cy += (int) (10 * TITLE_SCALE) + 2;
        }
        cy += 4;
        g.fill(x + pad, cy, x + w - pad, cy + 1, GOLD);
        cy += 9;

        // Photo before the body, if the author chose that and it is not already inlined.
        if (!n.imageId().isEmpty() && photoPos == 0 && !n.body().contains("[img:")) {
            cy = drawPhoto(g, font, x, pad, inner, cy, n.imageId()) + 10;
        }

        // Body.
        cy = drawBody(g, font, x, pad, inner, cy, n.body(), links);
        cy += 8;

        // Photo after the body, if requested and not already inlined.
        if (!n.imageId().isEmpty() && photoPos == 1 && !n.body().contains("[img:")) {
            cy = drawPhoto(g, font, x, pad, inner, cy, n.imageId()) + 10;
        }

        // Footer.
        if (!n.footer().isEmpty()) {
            g.fill(x + pad, cy, x + w - pad, cy + 1, GOLD);
            cy += 7;
            List<FormattedCharSequence> footerLines = font.split(
                    Component.literal(n.footer()).withStyle(ChatFormatting.ITALIC), inner);
            for (FormattedCharSequence line : footerLines) {
                g.drawString(font, line, x + pad, cy, MUTED, false);
                cy += LINE;
            }
            cy += 4;
        }

        if (!n.author().isEmpty()) {
            String byline = "Автор: " + n.author() + (n.hideAuthor() && !n.author().equals("?????") ? " · СКРЫТ" : "");
            g.drawString(font, font.plainSubstrByWidth(byline, inner), x + pad, cy, MUTED, false);
            cy += 12;
        }
        return cy - top + 6;
    }

    // ---------- body ----------

    /** Splits the body around photo tags and draws the text between them as blocks. */
    private static int drawBody(GuiGraphics g, Font font, int x, int pad, int inner, int cy, String body, List<Link> links) {
        Matcher m = IMAGE.matcher(body);
        int last = 0;
        while (m.find()) {
            cy = drawBlocks(g, font, x, pad, inner, cy, body.substring(last, m.start()), links);
            cy = drawPhoto(g, font, x, pad, inner, cy, m.group(1)) + 10;
            last = m.end();
        }
        return drawBlocks(g, font, x, pad, inner, cy, body.substring(last), links);
    }

    private static int drawBlocks(GuiGraphics g, Font font, int x, int pad, int inner, int cy, String text, List<Link> links) {
        if (text.trim().isEmpty()) {
            return cy;
        }
        List<String> code = null;
        for (String raw : text.split("\n", -1)) {
            String line = raw.stripTrailing();
            String t = line.strip();

            if (code != null) {
                if (t.startsWith("```")) {
                    cy = drawCode(g, font, x, pad, inner, cy, code);
                    code = null;
                } else {
                    code.add(line);
                }
                continue;
            }
            if (t.startsWith("```")) {
                code = new ArrayList<>();
                continue;
            }

            if (t.isEmpty()) {
                cy += 6;
            } else if (line.startsWith("### ")) {
                cy = drawHeading(g, font, x, pad, inner, cy, line.substring(4), 1.0f, links);
            } else if (line.startsWith("## ")) {
                cy = drawHeading(g, font, x, pad, inner, cy, line.substring(3), H2_SCALE, links);
            } else if (line.startsWith("# ")) {
                cy = drawHeading(g, font, x, pad, inner, cy, line.substring(2), TITLE_SCALE, links);
            } else if (line.startsWith("> ")) {
                cy = drawQuote(g, font, x, pad, inner, cy, line.substring(2), links);
            } else if (line.startsWith("- ") || line.startsWith("* ")) {
                cy = drawBullet(g, font, x, pad, inner, cy, line.substring(2), links);
            } else {
                cy = drawParagraph(g, font, x + pad, cy, inner, line, INK, links);
            }
        }
        // A code block that was never closed is still shown as code.
        if (code != null) {
            cy = drawCode(g, font, x, pad, inner, cy, code);
        }
        return cy;
    }

    private static int drawParagraph(GuiGraphics g, Font font, int lx, int cy, int width, String text, int colour, List<Link> links) {
        for (FormattedCharSequence line : font.split(RichText.parse(RichText.inline(text)), width)) {
            trackLinks(font, line, lx, cy, 1f, links);
            g.drawString(font, line, lx, cy, colour, false);
            cy += LINE;
        }
        return cy;
    }

    private static int drawHeading(GuiGraphics g, Font font, int x, int pad, int inner, int cy,
                                   String text, float scale, List<Link> links) {
        Component c = RichText.parse(RichText.inline(text.strip()), true, false);
        for (FormattedCharSequence line : font.split(c, (int) (inner / scale))) {
            trackLinks(font, line, x + pad, cy, scale, links);
            g.pose().pushPose();
            g.pose().translate(x + pad, cy, 0);
            g.pose().scale(scale, scale, 1f);
            g.drawString(font, line, 0, 0, INK, false);
            g.pose().popPose();
            cy += (int) (LINE * scale) + 2;
        }
        return cy + 4;
    }

    /** A quote: a gold bar on the left, italic muted text. */
    private static int drawQuote(GuiGraphics g, Font font, int x, int pad, int inner, int cy, String text, List<Link> links) {
        int startY = cy;
        int lx = x + pad + 8;
        for (FormattedCharSequence line : font.split(
                RichText.parse(RichText.inline(text), false, true), inner - 8)) {
            trackLinks(font, line, lx, cy, 1f, links);
            g.drawString(font, line, lx, cy, MUTED, false);
            cy += LINE;
        }
        g.fill(x + pad + 1, startY, x + pad + 3, cy - 2, GOLD);
        return cy + 2;
    }

    private static int drawBullet(GuiGraphics g, Font font, int x, int pad, int inner, int cy, String text, List<Link> links) {
        g.drawString(font, "•", x + pad + 2, cy, GOLD_DEEP, false);
        return drawParagraph(g, font, x + pad + 12, cy, inner - 12, text, INK, links);
    }

    /** A code block: dark plate, light monospace-like text. Long lines are cut, not wrapped. */
    private static int drawCode(GuiGraphics g, Font font, int x, int pad, int inner, int cy, List<String> lines) {
        int h = lines.isEmpty() ? 6 : lines.size() * LINE + 8;
        g.fill(x + pad, cy, x + pad + inner, cy + h, 0xFF1E1F22);
        g.fill(x + pad, cy, x + pad + inner, cy + 1, GOLD_DEEP);
        g.fill(x + pad, cy + h - 1, x + pad + inner, cy + h, GOLD_DEEP);
        int ty = cy + 4;
        for (String line : lines) {
            g.drawString(font, font.plainSubstrByWidth(line, inner - 12), x + pad + 6, ty, 0xFFEDE3CE, false);
            ty += LINE;
        }
        return cy + h + 6;
    }

    // ---------- photo ----------

    /** Draws a photo inside the page width, framed in gold. Returns the y just below it. */
    private static int drawPhoto(GuiGraphics g, Font font, int x, int pad, int inner, int cy, String imageId) {
        ImageCache.Entry img = ImageCache.get(imageId);
        int boxW = inner;
        int boxH;
        int drawW;
        if (img == null) {
            boxH = boxW * 9 / 16;
            drawW = boxW;
        } else {
            boxH = boxW * img.height() / img.width();
            drawW = boxW;
            int maxH = boxW * 3 / 4;
            if (boxH > maxH) {
                boxH = maxH;
                drawW = boxH * img.width() / img.height();
            }
        }
        int bx = x + pad + (boxW - drawW) / 2;
        g.fill(bx - 1, cy - 1, bx + drawW + 1, cy + boxH + 1, GOLD);
        if (img == null) {
            g.fill(bx, cy, bx + drawW, cy + boxH, FIELD);
            String wait = "Загрузка фото…";
            g.drawString(font, wait, bx + (drawW - font.width(wait)) / 2, cy + boxH / 2 - 4, MUTED, false);
        } else {
            g.blit(img.texture(), bx, cy, drawW, boxH, 0f, 0f, img.width(), img.height(), img.width(), img.height());
        }
        return cy + boxH;
    }
}
