package com.humanitas.client;

import com.humanitas.CivitasClientConfig;
import com.humanitas.Humanitas;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.ContainerScreen;
import net.minecraft.client.gui.screens.inventory.DispenserScreen;
import net.minecraft.client.gui.screens.inventory.HopperScreen;
import net.minecraft.client.gui.screens.inventory.ShulkerBoxScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ScreenEvent;

/**
 * Swaps the vanilla storage screens for their Civitas versions when they are about to open:
 * chests and barrels, shulker boxes, hoppers and droppers. Only the exact vanilla classes are replaced,
 * so modded screens keep their own look. The switch is the same one that controls the Civitas
 * inventory, in config/civitas-client.toml.
 */
@EventBusSubscriber(modid = Humanitas.MODID, value = Dist.CLIENT)
public final class CivitasContainerHook {
    private CivitasContainerHook() {}

    @SubscribeEvent
    public static void opening(ScreenEvent.Opening event) {
        Screen next = event.getNewScreen();
        if (next == null || !enabled()) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) {
            return;
        }
        Inventory inventory = mc.player.getInventory();
        Component title = next.getTitle();
        Class<?> type = next.getClass();

        if (type == ContainerScreen.class) {
            event.setNewScreen(new CivitasContainerStyle.Chest(
                    ((ContainerScreen) next).getMenu(), inventory, title));
        } else if (type == ShulkerBoxScreen.class) {
            event.setNewScreen(new CivitasContainerStyle.Shulker(
                    ((ShulkerBoxScreen) next).getMenu(), inventory, title));
        } else if (type == HopperScreen.class) {
            event.setNewScreen(new CivitasContainerStyle.Hopper(
                    ((HopperScreen) next).getMenu(), inventory, title));
        } else if (type == DispenserScreen.class) {
            event.setNewScreen(new CivitasContainerStyle.Dispenser(
                    ((DispenserScreen) next).getMenu(), inventory, title));
        }
    }

    private static boolean enabled() {
        try {
            return CivitasClientConfig.CUSTOM_INVENTORY.get();
        } catch (RuntimeException e) {
            return false;
        }
    }
}
