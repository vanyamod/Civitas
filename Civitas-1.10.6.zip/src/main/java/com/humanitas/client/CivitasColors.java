package com.humanitas.client;

/**
 * Small colour helpers shared by the palettes and the UI.
 * Every colour the mod draws is packed like vanilla's {@code 0xAARRGGBB}, so these helpers
 * keep the alpha channel intact while mixing RGB.
 */
public final class CivitasColors {
    private CivitasColors() {}

    /** Replaces the alpha channel of an ARGB colour. */
    public static int alpha(int colour, int alpha) {
        return (alpha & 0xFF) << 24 | colour & 0xFFFFFF;
    }

    /** Linear blend of two ARGB colours; {@code t == 0} returns {@code a}, {@code t == 1} returns {@code b}. */
    public static int mix(int a, int b, float t) {
        float k = Math.max(0.0F, Math.min(1.0F, t));
        int aa = a >>> 24;
        int ba = b >>> 24;
        int ar = a >> 16 & 0xFF;
        int ag = a >> 8 & 0xFF;
        int ab = a & 0xFF;
        int br = b >> 16 & 0xFF;
        int bg = b >> 8 & 0xFF;
        int bb = b & 0xFF;
        int alpha = Math.round(aa + (ba - aa) * k);
        int red = Math.round(ar + (br - ar) * k);
        int green = Math.round(ag + (bg - ag) * k);
        int blue = Math.round(ab + (bb - ab) * k);
        return alpha << 24 | red << 16 | green << 8 | blue;
    }

    public static int lighten(int colour, float amount) {
        return mix(colour, 0xFFFFFFFF, amount);
    }

    public static int darken(int colour, float amount) {
        return mix(colour, 0xFF000000, amount);
    }
}
