package com.humanitas.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.world.inventory.Slot;

import static com.humanitas.client.CivitasUi.*;

/**
 * The Civitas plate for Curios' inventory screen.
 *
 * <p>Curios draws the vanilla inventory texture and its own accessory panel in {@code renderBg},
 * then the screen draws slot contents on top. The mixin calls this class at the tail of
 * {@code renderBg}: the opaque plate is painted over the stock textures, and the slot wells are
 * painted before the items, so nothing is hidden. No Curios class is referenced here, which keeps
 * the screen styling optional at runtime.</p>
 */
public final class CivitasCuriosStyle {
    private static final int INV_W = 176;
    private static final int INV_H = 166;

    private CivitasCuriosStyle() {}

    /** Paints the whole plate and every slot well. Called from the Curios screen mixin. */
    public static void background(GuiGraphics g, AbstractContainerScreen<?> screen, int mouseX, int mouseY) {
        // Curios' narrow fallback hides the inventory on purpose. Painting under the book would
        // leave a half-empty plate around it, so leave that path entirely vanilla.
        if (CivitasCuriosHook.narrowOf(screen)) return;

        int left = screen.getGuiLeft();
        int top = screen.getGuiTop();
        int panel = CivitasCuriosHook.panelOf(screen);

        int bodyX = left - panel - 3;
        int bodyY = top - 3;
        int bodyW = panel + INV_W + 6;
        int bodyH = INV_H + 6;

        int x0 = bodyX + 1;
        int y0 = bodyY + 1;
        int x1 = bodyX + bodyW - 1;
        int y1 = bodyY + bodyH - 1;

        // Opaque graphite plate. This replaces the vanilla inventory texture completely.
        g.fill(x0, y0, x1, y1, PANEL);
        g.fillGradient(x0, y0, x1, y1, PLATE, PLATE_DEEP);

        // The accessory bay is a slightly deeper recessed strip on the left.
        if (panel > 0) {
            int px = left - panel;
            g.fillGradient(px - 1, y0, left - 1, y1,
                    CivitasColors.mix(PLATE, PLATE_DEEP, 0.45F), PLATE_DEEP);
            g.fillGradient(px - 1, y0, left - 1, y0 + (y1 - y0) / 2,
                    CivitasColors.alpha(OLIVE, 0x1A), 0x00000000);

            // Gold seam between the accessory bay and the player inventory.
            g.fill(left - 2, top - 1, left - 1, top + INV_H + 1, GOLD_DEEP);
            g.fill(left - 1, top, left, top + INV_H, CivitasColors.alpha(GOLD, 0x55));
        }

        // Cream lip along the top, like the edge of a metal plate.
        g.fill(x0 + 3, y0, x1 - 3, y0 + 1, CivitasColors.alpha(CREAM_ACTIVE, 0x28));

        // Inner gold hairline, inset from the heavy rim.
        g.fill(bodyX + 7, bodyY + 4, bodyX + bodyW - 7, bodyY + 5, RULE);
        g.fill(bodyX + 7, bodyY + bodyH - 5, bodyX + bodyW - 7, bodyY + bodyH - 4, RULE);
        g.fill(bodyX + 4, bodyY + 7, bodyX + 5, bodyY + bodyH - 7, RULE);
        g.fill(bodyX + bodyW - 5, bodyY + 7, bodyX + bodyW - 4, bodyY + bodyH - 7, RULE);

        drawSlots(g, screen, left, top, x0, y0, x1, y1);
        drawPortrait(g, screen, mouseX, mouseY);
        drawCraftingArrow(g, left, top);
        drawDivider(g, left, top);

        // The heavy gold rim goes on last so it sits above the plate and the slot edges.
        CivitasUi.frame(g, bodyX, bodyY, bodyW, bodyH);
    }

    /** Title and the accessory-bay heading. Called from the Curios screen mixin in local space. */
    public static void labels(GuiGraphics g, AbstractContainerScreen<?> screen) {
        if (CivitasCuriosHook.narrowOf(screen)) return;

        Font font = Minecraft.getInstance().font;
        int panel = CivitasCuriosHook.panelOf(screen);
        int top = screen.getGuiTop();

        if (top < 18) return;

        String heading = "АКСЕССУАРЫ";
        int textWidth = font.width(heading);
        if (panel >= textWidth + 10) {
            int hx = -panel + (panel - textWidth) / 2;
            g.drawString(font, heading, hx, -15, GOLD, true);
            g.fill(hx - 10, -7, hx + textWidth + 10, -6,
                    CivitasColors.alpha(GOLD, 0x80));
        } else if (panel > 0) {
            // Narrow bay: a small gold badge instead of text that would spill over the inventory.
            int cx = -panel / 2;
            g.fill(cx - 16, -11, cx - 5, -10, CivitasColors.alpha(GOLD, 0x70));
            g.fill(cx + 6, -11, cx + 17, -10, CivitasColors.alpha(GOLD, 0x70));
            g.fill(cx - 1, -13, cx + 1, -11, GOLD);
            g.fill(cx - 2, -11, cx + 2, -10, GOLD_DEEP);
            g.fill(cx - 1, -10, cx + 1, -9, GOLD);
        }
    }

    private static void drawSlots(GuiGraphics g, AbstractContainerScreen<?> screen,
                                  int left, int top, int x0, int y0, int x1, int y1) {
        for (Slot slot : screen.getMenu().slots) {
            if (!slot.isActive()) continue;

            int sx = left + slot.x - 1;
            int sy = top + slot.y - 1;
            if (sx < x0 || sy < y0 || sx + 18 > x1 || sy + 18 > y1) continue;

            boolean result = slot.index == 0;
            boolean curio = slot.getClass().getName().equals(CivitasCuriosHook.CURIOS_SLOT);

            int edge = result ? GOLD
                    : curio ? CivitasColors.mix(SLOT_EDGE, GOLD_DEEP, 0.55F)
                    : SLOT_EDGE;
            int fill = result ? SLOT_RESULT : SLOT_FILL;

            g.fill(sx, sy, sx + 18, sy + 18, edge);
            g.fill(sx + 1, sy + 1, sx + 17, sy + 17, fill);

            // Inner bevel: light lip top-left, shade bottom-right.
            g.fill(sx + 1, sy + 1, sx + 17, sy + 2,
                    result ? CivitasColors.alpha(CREAM_ACTIVE, 0x50)
                            : curio ? CivitasColors.alpha(GOLD, 0x38) : SLOT_LIGHT);
            g.fill(sx + 1, sy + 1, sx + 2, sy + 17,
                    result ? CivitasColors.alpha(CREAM_ACTIVE, 0x30)
                            : curio ? CivitasColors.alpha(GOLD, 0x28) : SLOT_LIGHT);
            g.fill(sx + 16, sy + 2, sx + 17, sy + 17, SLOT_SHADE);
            g.fill(sx + 2, sy + 16, sx + 17, sy + 17, SLOT_SHADE);
            g.fill(sx + 1, sy + 16, sx + 2, sy + 17, SLOT_SHADE);

            if (result) {
                g.fill(sx + 2, sy + 2, sx + 16, sy + 3, CivitasColors.alpha(CREAM_ACTIVE, 0x45));
                g.fill(sx + 2, sy + 3, sx + 3, sy + 16, CivitasColors.alpha(CREAM_ACTIVE, 0x25));
            } else if (curio) {
                // Tiny gold notches, so accessory wells read as fittings rather than holes.
                g.fill(sx + 2, sy + 2, sx + 4, sy + 3, CivitasColors.alpha(GOLD, 0x60));
                g.fill(sx + 2, sy + 2, sx + 3, sy + 4, CivitasColors.alpha(GOLD, 0x60));
                g.fill(sx + 14, sy + 15, sx + 16, sy + 16, CivitasColors.alpha(GOLD, 0x45));
                g.fill(sx + 15, sy + 14, sx + 16, sy + 15, CivitasColors.alpha(GOLD, 0x45));
            }
        }
    }

    private static void drawPortrait(GuiGraphics g, AbstractContainerScreen<?> screen,
                                     int mouseX, int mouseY) {
        int x = screen.getGuiLeft() + 26;
        int y = screen.getGuiTop() + 8;
        int w = 49;
        int h = 70;

        // Opaque portrait well, so the vanilla player render underneath is fully replaced.
        g.fill(x, y, x + w, y + h, PORTRAIT);
        g.fillGradient(x, y, x + w, y + h,
                CivitasColors.alpha(CREAM_ACTIVE, 0x18), 0x00000000);
        g.fillGradient(x, y, x + w, y + h, 0x00000000, 0x77000000);

        // Thin gold inlay on the inside of the well.
        g.fill(x, y, x + w, y + 1, GOLD_DEEP);
        g.fill(x, y + h - 1, x + w, y + h, GOLD_DEEP);
        g.fill(x, y, x + 1, y + h, GOLD_DEEP);
        g.fill(x + w - 1, y, x + w, y + h, GOLD_DEEP);
        g.fill(x + 1, y + 1, x + w - 1, y + 2, CivitasColors.alpha(GOLD, 0x70));

        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null) {
            InventoryScreen.renderEntityInInventoryFollowsMouse(g,
                    x + 2, y + 2, x + w - 2, y + h - 2,
                    30, 0.0625F, mouseX, mouseY, mc.player);
        }
    }

    /** The vanilla texture supplied this arrow; now it is a small olive-and-gold rule. */
    private static void drawCraftingArrow(GuiGraphics g, int left, int top) {
        int ax = left + 136;
        int ay = top + 32;
        g.fill(ax, ay + 2, ax + 10, ay + 5, OLIVE);
        g.fill(ax + 10, ay, ax + 12, ay + 7, GOLD_DEEP);
        g.fill(ax + 12, ay + 1, ax + 14, ay + 6, GOLD_DEEP);
        g.fill(ax + 14, ay + 2, ax + 16, ay + 5, GOLD);
        g.fill(ax + 15, ay + 3, ax + 17, ay + 4, GOLD);
    }

    /** A small gold clasp in the four-pixel gap between the inventory grid and the hotbar row. */
    private static void drawDivider(GuiGraphics g, int left, int top) {
        int mid = left + INV_W / 2;
        int ruleY = top + 139;
        g.fill(left + 8, ruleY, left + INV_W - 8, ruleY + 1,
                CivitasColors.alpha(GOLD, 0x50));
        g.fill(mid - 5, ruleY - 2, mid + 6, ruleY - 1, GOLD_DEEP);
        g.fill(mid - 4, ruleY - 1, mid + 5, ruleY, GOLD);
        g.fill(mid - 3, ruleY, mid + 4, ruleY + 1, GOLD);
        g.fill(mid - 4, ruleY + 1, mid + 5, ruleY + 2, GOLD_DEEP);
        g.fill(mid - 1, ruleY - 3, mid + 2, ruleY - 2, GOLD);
        g.fill(mid - 1, ruleY + 2, mid + 2, ruleY + 3, GOLD_DEEP);
    }
}
