package com.humanitas.client;

import net.minecraft.nbt.CompoundTag;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

/** One news article as the client sees it. The date is an in-world calendar day, not the real date. */
public record NewsItem(int id, String title, String stateName, String author, long day,
                       String body, String footer, String imageId, String modelId, boolean canDelete, boolean hideState, boolean hideAuthor) {

    private static final DateTimeFormatter FORMAT = DateTimeFormatter.ofPattern("dd.MM.yyyy");

    /** An ordinary, signed article. */
    public NewsItem(int id, String title, String stateName, String author, long day,
                    String body, String footer, String imageId, String modelId, boolean canDelete) {
        this(id, title, stateName, author, day, body, footer, imageId, modelId, canDelete, false, false);
    }

    public static NewsItem fromTag(CompoundTag t) {
        return new NewsItem(
                t.getInt("id"),
                t.getString("title"),
                t.getString("stateName"),
                t.getString("author"),
                t.getLong("day"),
                t.getString("body"),
                t.getString("footer"),
                t.getString("imageId"),
                t.getString("modelId"),
                t.getBoolean("canDelete"),
                t.getBoolean("hideState"),
                t.getBoolean("hideAuthor"));
    }

    public String when() {
        return FORMAT.format(LocalDate.ofEpochDay(day));
    }

    public String whenShort() {
        return when();
    }
}
