package com.humanitas.client;

import java.net.URI;
import java.util.regex.Pattern;

/** Pure editing operations. Each result is applied as a single undo transaction. */
public final class NewsFormatting {
    private NewsFormatting() {}
    public record Edit(String text, int cursor, int anchor) {}
    private static final Pattern PREFIX = Pattern.compile("^(#{1,3} |[>\\-*] )+");

    public static Edit inline(String text, int cursor, int anchor, String open, String close) {
        int start = Math.min(cursor, anchor), end = Math.max(cursor, anchor);
        if (!open.contains("\n") && text.substring(start, end).contains("\n")) {
            String[] lines = text.substring(start, end).split("\n", -1);
            boolean remove = true;
            for (String line : lines) if (!line.isBlank()) {
                remove &= line.startsWith(open) && line.endsWith(close) && line.length() >= open.length() + close.length();
            }
            for (int i = 0; i < lines.length; i++) if (!lines[i].isBlank()) {
                lines[i] = remove ? lines[i].substring(open.length(), lines[i].length() - close.length()) : open + lines[i] + close;
            }
            String result = String.join("\n", lines);
            return new Edit(text.substring(0, start) + result + text.substring(end), start + result.length(), start);
        }
        // Keep the content selected: a second click removes the format, and another style composes.
        boolean italicInsideBold = open.equals("*") && start >= 2 && text.substring(0, start).endsWith("**")
                && !(start >= 3 && text.substring(0, start).endsWith("***"));
        if (!italicInsideBold && start >= open.length() && text.substring(0, start).endsWith(open)
                && text.startsWith(close, end)) {
            return new Edit(text.substring(0, start - open.length()) + text.substring(start, end)
                    + text.substring(end + close.length()), end - open.length(), start - open.length());
        }
        if (end - start >= open.length() + close.length() && text.startsWith(open, start)
                && text.substring(0, end).endsWith(close)) {
            String inner = text.substring(start + open.length(), end - close.length());
            return new Edit(text.substring(0, start) + inner + text.substring(end), start + inner.length(), start);
        }
        if (start == end) {
            while (start > 0 && word(text.charAt(start - 1))) start--;
            while (end < text.length() && word(text.charAt(end))) end++;
            if (start != end) return inline(text, end, start, open, close);
        }
        String selected = start == end ? "текст" : text.substring(start, end);
        return new Edit(text.substring(0, start) + open + selected + close + text.substring(end),
                start + open.length() + selected.length(), start + open.length());
    }

    private static boolean word(char c) { return Character.isLetterOrDigit(c) || c == '_'; }

    public static Edit block(String text, int cursor, int anchor, String prefix) {
        int a = Math.min(cursor, anchor), b = Math.max(cursor, anchor);
        int start = text.lastIndexOf('\n', Math.max(-1, a - 1)) + 1;
        int last = b > a && text.charAt(b - 1) == '\n' ? b - 1 : b;
        int end = text.indexOf('\n', last);
        if (end < 0) end = text.length();
        String[] lines = text.substring(start, end).split("\n", -1);
        boolean remove = !prefix.isEmpty();
        for (String line : lines) remove &= line.startsWith(prefix);
        StringBuilder out = new StringBuilder();
        int firstDelta = 0;
        for (int i = 0; i < lines.length; i++) {
            String clean = PREFIX.matcher(lines[i]).replaceFirst("");
            String changed = (remove ? "" : prefix) + clean;
            if (i == 0) firstDelta = changed.length() - lines[i].length();
            if (i > 0) out.append('\n');
            out.append(changed);
        }
        String result = text.substring(0, start) + out + text.substring(end);
        if (a == b) {
            int caret = Math.max(start, Math.min(start + out.length(), cursor + firstDelta));
            return new Edit(result, caret, caret);
        }
        return new Edit(result, start + out.length(), start);
    }

    public static boolean validUrl(String value) {
        try {
            URI uri = URI.create(value.strip());
            return ("https".equalsIgnoreCase(uri.getScheme()) || "http".equalsIgnoreCase(uri.getScheme()))
                    && uri.getHost() != null && uri.getUserInfo() == null
                    && !value.contains("(") && !value.contains(")");
        } catch (IllegalArgumentException e) { return false; }
    }
}
