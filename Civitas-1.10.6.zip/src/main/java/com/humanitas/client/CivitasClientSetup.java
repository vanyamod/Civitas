package com.humanitas.client;

import com.humanitas.Humanitas;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;

@EventBusSubscriber(modid = Humanitas.MODID, value = Dist.CLIENT, bus = EventBusSubscriber.Bus.MOD)
public final class CivitasClientSetup {
    private CivitasClientSetup() {}

    @SubscribeEvent
    public static void setup(FMLClientSetupEvent event) {
        event.enqueueWork(CivitasPaletteState::load);
    }
}
