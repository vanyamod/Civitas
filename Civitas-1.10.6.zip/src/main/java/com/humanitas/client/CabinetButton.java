package com.humanitas.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.narration.NarrationElementOutput;
import net.minecraft.client.sounds.SoundManager;
import net.minecraft.network.chat.Component;

import java.util.function.Supplier;

/**
 * The Civitas seal in the inventory: a graphite medallion with a gold rim, cut corners,
 * a thin inner line and a soft shadow. It shows the symbol of the current ideology in gold.
 * On hover it turns olive with a cream rim and a cream symbol.
 * The symbol and the tooltip are suppliers, so they change as soon as the state changes.
 */
public final class CabinetButton extends AbstractWidget {
    private static final int SHADOW = 0x66000000;

    private final Supplier<String> symbol;
    private final float scale;
    private final Runnable action;
    private Supplier<String> tip;
    private String shownTip = "";
    /** Sub-pixel drawing offset, for buttons that must sit between two whole GUI pixels. */
    private float offsetX;
    private float offsetY;
    private float iconOffsetX;
    private float iconOffsetY;

    public CabinetButton(int x, int y, int width, int height, Supplier<String> symbol, Runnable action) {
        this(x, y, width, height, symbol, 1.7f, action);
    }

    public CabinetButton(int x, int y, int width, int height, Supplier<String> symbol, float scale, Runnable action) {
        super(x, y, width, height, Component.literal("Civitas"));
        this.symbol = symbol;
        this.scale = scale;
        this.action = action;
    }

    /** Tooltip text that follows a supplier, for example the state name. */
    public CabinetButton withTip(Supplier<String> tipSupplier) {
        this.tip = tipSupplier;
        return this;
    }

    /** Draws the button shifted by a sub-pixel amount. The hit box stays on whole pixels. */
    public CabinetButton withOffset(float dx, float dy) {
        this.offsetX = dx;
        this.offsetY = dy;
        return this;
    }

    /** Shifts only the symbol and its shadow, independently of the frame and hit box. */
    public CabinetButton withIconOffset(float dx, float dy) {
        this.iconOffsetX = dx;
        this.iconOffsetY = dy;
        return this;
    }

    @Override
    protected void renderWidget(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        g.pose().pushPose();
        g.pose().translate(offsetX, offsetY, 0);
        boolean hot = isHoveredOrFocused();
        if (tip != null) {
            String now = tip.get();
            if (!now.equals(shownTip)) {
                setTooltip(Tooltip.create(Component.literal(now)));
                shownTip = now;
            }
        }

        int x1 = getX();
        int y1 = getY();
        int x2 = x1 + width;
        int y2 = y1 + height;
        int rim = hot ? CivitasUi.TEXT_LIGHT : CivitasUi.GOLD;
        int body = hot ? CivitasUi.OLIVE : CivitasUi.PLATE_SOLID;
        int line = hot ? CivitasUi.alpha(CivitasUi.TEXT_LIGHT, 0x66) : CivitasUi.alpha(CivitasUi.GOLD, 0x55);
        int glyph = hot ? CivitasUi.TEXT_LIGHT : CivitasUi.GOLD;

        // Soft shadow to the lower right.
        g.fill(x1 + 2, y2, x2 + 1, y2 + 1, SHADOW);
        g.fill(x2, y1 + 2, x2 + 1, y2, SHADOW);

        // Rim and body, both with cut corners.
        g.fill(x1 + 1, y1, x2 - 1, y2, rim);
        g.fill(x1, y1 + 1, x2, y2 - 1, rim);
        g.fill(x1 + 2, y1 + 1, x2 - 2, y2 - 1, body);
        g.fill(x1 + 1, y1 + 2, x2 - 1, y2 - 2, body);

        // Thin inner line, like the edge of a coin.
        g.fill(x1 + 3, y1 + 3, x2 - 3, y1 + 4, line);
        g.fill(x1 + 3, y2 - 4, x2 - 3, y2 - 3, line);
        g.fill(x1 + 3, y1 + 4, x1 + 4, y2 - 4, line);
        g.fill(x2 - 4, y1 + 4, x2 - 3, y2 - 4, line);

        // Ideology symbol with a small shadow.
        String s = symbol.get();
        Font font = Minecraft.getInstance().font;
        float cx = x1 + width / 2f;
        float cy = y1 + height / 2f;
        g.pose().pushPose();
        g.pose().translate(iconOffsetX, iconOffsetY, 0);
        CivitasUi.icon(g, font, s, cx + 1f, cy + 1f, scale, 0xAA000000);
        CivitasUi.icon(g, font, s, cx, cy, scale, glyph);
        g.pose().popPose();
        g.pose().popPose();
    }


    /** The vanilla click sound is silenced: onClick plays the Civitas press sound instead, once. */
    @Override
    public void playDownSound(SoundManager soundManager) {
    }

    @Override
    public void onClick(double mouseX, double mouseY) {
        CivitasSounds.playPress();
        action.run();
    }

    @Override
    protected void updateWidgetNarration(NarrationElementOutput output) {
        defaultButtonNarrationText(output);
    }
}
