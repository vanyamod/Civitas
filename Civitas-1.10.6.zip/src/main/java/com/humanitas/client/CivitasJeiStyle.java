// Removed: the JEI style helper was dropped. This file is intentionally empty and can be deleted.
