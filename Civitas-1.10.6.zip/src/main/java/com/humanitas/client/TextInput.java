package com.humanitas.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

/**
 * A text field drawn in the Civitas palette. One class for both a single line and a multi-line editor.
 * Supports selection (mouse drag and Shift+arrows), clipboard (Ctrl+A/C/X/V), undo/redo (Ctrl+Z/Y).
 */
public final class TextInput {
    private static final int PAD = 4;

    private final Font font = Minecraft.getInstance().font;
    private final boolean multiline;
    private final int maxLen;
    private final String placeholder;
    private final StringBuilder text = new StringBuilder();

    private int x;
    private int y;
    private int w;
    private int h;
    private int cursor;
    private int anchor; // selection anchor; selection is [min(anchor,cursor), max(...)]
    private int scrollLines;
    private int firstChar;
    private boolean followCursor;
    private int lineGap = 1;
    public boolean focused;

    // Undo/redo.
    private final List<Snapshot> undo = new ArrayList<>();
    private final List<Snapshot> redo = new ArrayList<>();
    private static final int MAX_UNDO = 100;

    private record Snapshot(String text, int cursor, int anchor) {}

    public TextInput(boolean multiline, int maxLen, String placeholder) {
        this.multiline = multiline;
        this.maxLen = maxLen;
        this.placeholder = placeholder;
        this.anchor = 0;
    }

    public void setBounds(int x, int y, int w, int h) {
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
    }

    public String value() {
        return text.toString();
    }

    public void setLineGap(int gap) { lineGap = Math.max(1, gap); }

    public void setValue(String v) {
        pushUndo();
        text.setLength(0);
        text.append(sanitize(v));
        if (text.length() > maxLen) {
            text.setLength(maxLen);
        }
        cursor = text.length();
        anchor = cursor;
        followCursor = true;
    }

    // ---------- selection ----------

    public boolean hasSelection() {
        return anchor != cursor;
    }

    private int selStart() { return Math.min(anchor, cursor); }
    private int selEnd() { return Math.max(anchor, cursor); }

    public String selectedText() {
        if (!hasSelection()) return "";
        return text.substring(selStart(), selEnd());
    }

    private void deleteSelection() {
        if (!hasSelection()) return;
        pushUndo();
        text.delete(selStart(), selEnd());
        cursor = selStart();
        anchor = cursor;
        followCursor = true;
    }

    private void selectAll() {
        anchor = 0;
        cursor = text.length();
        followCursor = true;
    }

    private void clearSelection() {
        anchor = cursor;
    }

    // ---------- editing ----------

    private void pushUndo() {
        undo.add(new Snapshot(text.toString(), cursor, anchor));
        if (undo.size() > MAX_UNDO) {
            undo.remove(0);
        }
        redo.clear();
    }

    public void undo() {
        if (undo.isEmpty()) return;
        redo.add(new Snapshot(text.toString(), cursor, anchor));
        Snapshot s = undo.remove(undo.size() - 1);
        text.setLength(0);
        text.append(s.text());
        cursor = Math.min(s.cursor(), text.length());
        anchor = Math.min(s.anchor(), text.length());
        followCursor = true;
    }

    public void redo() {
        if (redo.isEmpty()) return;
        undo.add(new Snapshot(text.toString(), cursor, anchor));
        Snapshot s = redo.remove(redo.size() - 1);
        text.setLength(0);
        text.append(s.text());
        cursor = Math.min(s.cursor(), text.length());
        anchor = Math.min(s.anchor(), text.length());
        followCursor = true;
    }

    public void insert(String raw) {
        String s = sanitize(raw);
        if (s.isEmpty()) return;
        int start = selStart(), end = selEnd();
        int room = maxLen - text.length() + end - start;
        if (room <= 0) return;
        if (s.length() > room) {
            s = s.substring(0, room);
        }
        pushUndo();
        text.replace(start, end, s);
        cursor = start + s.length();
        anchor = cursor;
        followCursor = true;
    }

    /** Inserts an opening and a closing tag and puts the cursor between them. */
    public void insertPair(String open, String close) {
        if (text.length() + open.length() + close.length() > maxLen) {
            return;
        }
        if (hasSelection()) {
            String sel = selectedText();
            deleteSelection();
            pushUndo();
            String combined = open + sel + close;
            text.insert(cursor, combined);
            cursor += open.length() + sel.length();
            anchor = cursor;
        } else {
            pushUndo();
            text.insert(cursor, open + close);
            cursor += open.length();
            anchor = cursor;
        }
        followCursor = true;
    }

    public boolean canUndo() { return !undo.isEmpty(); }
    public boolean canRedo() { return !redo.isEmpty(); }

    public boolean format(String open, String close) {
        return apply(NewsFormatting.inline(value(), cursor, anchor, open, close));
    }

    public boolean formatBlock(String prefix) {
        return apply(NewsFormatting.block(value(), cursor, anchor, prefix));
    }

    private boolean apply(NewsFormatting.Edit edit) {
        if (edit.text().length() > maxLen) return false;
        if (!value().equals(edit.text())) pushUndo();
        text.setLength(0);
        text.append(edit.text());
        cursor = edit.cursor();
        anchor = edit.anchor();
        firstChar = Math.min(firstChar, text.length());
        followCursor = true;
        return true;
    }

    public void selectAllText() { selectAll(); }

    public String blockPrefix() {
        int start = text.lastIndexOf("\n", Math.max(-1, cursor - 1)) + 1;
        String line = text.substring(start);
        for (String prefix : new String[]{"### ", "## ", "# ", "> ", "- "}) {
            if (line.startsWith(prefix)) return prefix;
        }
        return "";
    }

    private String sanitize(String raw) {
        StringBuilder sb = new StringBuilder();
        String s = raw.replace("\r\n", "\n").replace('\r', '\n');
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '\n') {
                if (multiline) {
                    sb.append(c);
                }
            } else if (c >= 32 && c != 127) {
                sb.append(c);
            }
        }
        return sb.toString();
    }

    /** Puts a prefix at the start of the hard line the cursor is on, e.g. "# " for a heading. */
    public void insertLinePrefix(String prefix) {
        if (text.length() + prefix.length() > maxLen) {
            return;
        }
        int start = 0;
        for (int i = cursor - 1; i >= 0; i--) {
            if (text.charAt(i) == '\n') {
                start = i + 1;
                break;
            }
        }
        pushUndo();
        text.insert(start, prefix);
        cursor += prefix.length();
        anchor = cursor;
        followCursor = true;
    }

    private void copy() {
        String s = selectedText();
        if (!s.isEmpty()) {
            Minecraft.getInstance().keyboardHandler.setClipboard(s);
        }
    }

    private void cut() {
        if (!hasSelection()) return;
        copy();
        deleteSelection();
    }

    private void paste() {
        insert(Minecraft.getInstance().keyboardHandler.getClipboard());
    }

    public boolean charTyped(char c) {
        if (!focused || c < 32 || c == 127) {
            return false;
        }
        insert(String.valueOf(c));
        return true;
    }

    public boolean keyPressed(int key, int mods) {
        if (!focused) {
            return false;
        }
        boolean ctrl = (mods & GLFW.GLFW_MOD_CONTROL) != 0;
        boolean shift = (mods & GLFW.GLFW_MOD_SHIFT) != 0;

        if (ctrl) {
            switch (key) {
                case GLFW.GLFW_KEY_A -> { selectAll(); return true; }
                case GLFW.GLFW_KEY_C -> { copy(); return true; }
                case GLFW.GLFW_KEY_X -> { cut(); return true; }
                case GLFW.GLFW_KEY_V -> { paste(); return true; }
                case GLFW.GLFW_KEY_Z -> {
                    if (shift) redo(); else undo();
                    return true;
                }
                case GLFW.GLFW_KEY_Y -> { redo(); return true; }
            }
        }

        if (key == GLFW.GLFW_KEY_BACKSPACE) {
            if (hasSelection()) {
                deleteSelection();
            } else if (cursor > 0) {
                pushUndo();
                int from = ctrl ? wordLeft(cursor) : cursor - 1;
                text.delete(from, cursor);
                cursor = from;
                anchor = cursor;
                followCursor = true;
            }
            return true;
        }
        if (key == GLFW.GLFW_KEY_DELETE) {
            if (hasSelection()) {
                deleteSelection();
            } else if (cursor < text.length()) {
                pushUndo();
                text.delete(cursor, ctrl ? wordRight(cursor) : cursor + 1);
            }
            return true;
        }
        if (key == GLFW.GLFW_KEY_LEFT) {
            if (ctrl) { cursor = wordLeft(cursor); if (!shift) clearSelection(); followCursor = true; return true; }
            if (shift) {
                if (cursor > 0) cursor--;
            } else {
                if (hasSelection()) {
                    cursor = selStart();
                } else if (cursor > 0) {
                    cursor--;
                }
                clearSelection();
            }
            followCursor = true;
            return true;
        }
        if (key == GLFW.GLFW_KEY_RIGHT) {
            if (ctrl) { cursor = wordRight(cursor); if (!shift) clearSelection(); followCursor = true; return true; }
            if (shift) {
                if (cursor < text.length()) cursor++;
            } else {
                if (hasSelection()) {
                    cursor = selEnd();
                } else if (cursor < text.length()) {
                    cursor++;
                }
                clearSelection();
            }
            followCursor = true;
            return true;
        }
        if (key == GLFW.GLFW_KEY_HOME) {
            int target = multiline && !ctrl ? lineStart(cursor) : 0;
            if (shift) {
                cursor = target;
            } else {
                cursor = target;
                clearSelection();
            }
            followCursor = true;
            return true;
        }
        if (key == GLFW.GLFW_KEY_END) {
            int target = multiline && !ctrl ? lineEnd(cursor) : text.length();
            if (shift) {
                cursor = target;
            } else {
                cursor = target;
                clearSelection();
            }
            followCursor = true;
            return true;
        }
        if (multiline && (key == GLFW.GLFW_KEY_UP || key == GLFW.GLFW_KEY_DOWN)) {
            moveVertically(key == GLFW.GLFW_KEY_UP ? -1 : 1, shift);
            return true;
        }
        if (multiline && (key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER)) {
            insert("\n");
            return true;
        }
        return false;
    }

    // ---------- mouse ----------

    public boolean mouseClicked(double mx, double my) {
        boolean in = CivitasUi.inside(mx, my, x, y, w, h);
        focused = in;
        if (!in) {
            return false;
        }
        if (multiline) {
            List<int[]> lines = wrap();
            int lh = font.lineHeight + lineGap;
            int li = scrollLines + (int) ((my - y - PAD) / lh);
            li = Math.max(0, Math.min(lines.size() - 1, li));
            int nc = indexInLine(lines.get(li), mx - x - PAD);
            if (isShiftDown()) {
                cursor = nc;
            } else {
                anchor = nc;
                cursor = nc;
            }
        } else {
            int nc = indexInLine(new int[]{firstChar, text.length()}, mx - x - PAD);
            if (isShiftDown()) {
                cursor = nc;
            } else {
                anchor = nc;
                cursor = nc;
            }
        }
        followCursor = true;
        return true;
    }

    public boolean mouseDragged(double mx, double my) {
        if (!focused) return false;
        if (!CivitasUi.inside(mx, my, x, y, w, h)) return false;
        if (multiline) {
            List<int[]> lines = wrap();
            int lh = font.lineHeight + lineGap;
            int li = scrollLines + (int) ((my - y - PAD) / lh);
            li = Math.max(0, Math.min(lines.size() - 1, li));
            cursor = indexInLine(lines.get(li), mx - x - PAD);
        } else {
            cursor = indexInLine(new int[]{firstChar, text.length()}, mx - x - PAD);
        }
        followCursor = true;
        return true;
    }

    public boolean mouseScrolled(double mx, double my, double dy) {
        if (!multiline || !CivitasUi.inside(mx, my, x, y, w, h)) {
            return false;
        }
        scrollLines -= (int) Math.signum(dy);
        return true;
    }

    // ---------- layout helpers ----------

    private static boolean isShiftDown() {
        long win = Minecraft.getInstance().getWindow().getWindow();
        return org.lwjgl.glfw.GLFW.glfwGetKey(win, org.lwjgl.glfw.GLFW.GLFW_KEY_LEFT_SHIFT) == org.lwjgl.glfw.GLFW.GLFW_PRESS
                || org.lwjgl.glfw.GLFW.glfwGetKey(win, org.lwjgl.glfw.GLFW.GLFW_KEY_RIGHT_SHIFT) == org.lwjgl.glfw.GLFW.GLFW_PRESS;
    }

    private int maxLineWidth() {
        return Math.max(1, w - PAD * 2 - 4);
    }

    private int wordLeft(int pos) {
        while (pos > 0 && Character.isWhitespace(text.charAt(pos - 1))) pos--;
        while (pos > 0 && !Character.isWhitespace(text.charAt(pos - 1))) pos--;
        return pos;
    }

    private int wordRight(int pos) {
        while (pos < text.length() && !Character.isWhitespace(text.charAt(pos))) pos++;
        while (pos < text.length() && Character.isWhitespace(text.charAt(pos))) pos++;
        return pos;
    }

    private List<int[]> wrap() {
        List<int[]> out = new ArrayList<>();
        int n = text.length();
        int maxW = maxLineWidth();
        int start = 0;
        while (true) {
            int i = start;
            int width = 0;
            int lastBreak = -1;
            boolean newline = false;
            while (i < n) {
                char c = text.charAt(i);
                if (c == '\n') {
                    newline = true;
                    break;
                }
                int cw = font.width(String.valueOf(c));
                if (width + cw > maxW && i > start) {
                    break;
                }
                width += cw;
                if (c == ' ') {
                    lastBreak = i + 1;
                }
                i++;
            }
            if (newline) {
                out.add(new int[]{start, i});
                start = i + 1;
                continue;
            }
            if (i >= n) {
                out.add(new int[]{start, n});
                break;
            }
            int end = lastBreak > start ? lastBreak : i;
            out.add(new int[]{start, end});
            start = end;
        }
        return out;
    }

    private int lineOfCursor(List<int[]> lines) {
        int n = text.length();
        for (int i = 0; i < lines.size(); i++) {
            int[] ln = lines.get(i);
            if (cursor < ln[1]) {
                return i;
            }
            if (cursor == ln[1]) {
                boolean hardEnd = ln[1] >= n || text.charAt(ln[1]) == '\n';
                if (hardEnd || i == lines.size() - 1) {
                    return i;
                }
            }
        }
        return lines.size() - 1;
    }

    private int lineStart(int pos) {
        List<int[]> lines = wrap();
        return lines.get(lineOfCursor(lines))[0];
    }

    private int lineEnd(int pos) {
        List<int[]> lines = wrap();
        return lines.get(lineOfCursor(lines))[1];
    }

    private int indexInLine(int[] ln, double px) {
        int best = ln[0];
        for (int i = ln[0]; i <= ln[1]; i++) {
            if (font.width(text.substring(ln[0], i)) <= px + 2) {
                best = i;
            } else {
                break;
            }
        }
        return best;
    }

    private void moveVertically(int dir, boolean shift) {
        List<int[]> lines = wrap();
        int cur = lineOfCursor(lines);
        int target = cur + dir;
        if (target < 0 || target >= lines.size()) {
            return;
        }
        int px = font.width(text.substring(lines.get(cur)[0], cursor));
        int nc = indexInLine(lines.get(target), px);
        if (shift) {
            cursor = nc;
        } else {
            cursor = nc;
            anchor = nc;
        }
        followCursor = true;
    }

    // ---------- drawing ----------

    public void render(GuiGraphics g, int mx, int my) {
        g.fill(x - 1, y - 1, x + w + 1, y + h + 1, focused ? CivitasUi.GOLD : CivitasColors.alpha(CivitasUi.GOLD_DEEP, 0x60));
        g.fill(x, y, x + w, y + h, CivitasColors.mix(CivitasUi.PLATE_DEEP, CivitasUi.TEXT_LIGHT, 0.035f));
        g.fill(x, y, x + w, y + 1, 0x50000000);
        if (multiline) {
            renderMulti(g);
        } else {
            renderSingle(g);
        }
    }

    private boolean blink() {
        return focused && (System.currentTimeMillis() / 500) % 2 == 0;
    }

    private void drawSelection(GuiGraphics g, int x0, int y0, int x1, int y1) {
        g.fill(x0, y0, x1, y1, CivitasColors.alpha(CivitasUi.GOLD, 0x45));
    }

    private void renderSingle(GuiGraphics g) {
        firstChar = Math.max(0, Math.min(firstChar, text.length()));
        if (cursor < firstChar) {
            firstChar = cursor;
        }
        int avail = w - PAD * 2;
        while (firstChar < cursor && font.width(text.substring(firstChar, cursor)) > avail - 2) {
            firstChar++;
        }
        int ty = y + (h - 8) / 2;
        if (text.length() == 0) {
            g.drawString(font, font.plainSubstrByWidth(placeholder, avail), x + PAD, ty,
                    CivitasColors.alpha(CivitasUi.TEXT_LIGHT, focused ? 0x55 : 0x70), false);
            if (!focused) {
                return;
            }
        }
        // selection highlight
        if (hasSelection()) {
            int s = Math.max(firstChar, selStart());
            int e = Math.min(firstChar + visibleLen(avail), selEnd());
            if (e > s) {
                int sx = x + PAD + font.width(text.substring(firstChar, s));
                int ex = x + PAD + font.width(text.substring(firstChar, e));
                drawSelection(g, sx, ty - 1, ex, ty + 9);
            }
        }
        String visible = font.plainSubstrByWidth(text.substring(firstChar), avail);
        g.drawString(font, visible, x + PAD, ty, CivitasUi.TEXT_LIGHT, false);
        if (blink() && !hasSelection()) {
            int cx = x + PAD + font.width(text.substring(firstChar, cursor));
            g.fill(cx, ty - 1, cx + 1, ty + 9, CivitasUi.GOLD);
        }
    }

    private int visibleLen(int avail) {
        int i = firstChar;
        int width = 0;
        while (i < text.length()) {
            int cw = font.width(String.valueOf(text.charAt(i)));
            if (width + cw > avail) break;
            width += cw;
            i++;
        }
        return i - firstChar;
    }

    private void renderMulti(GuiGraphics g) {
        List<int[]> lines = wrap();
        int lh = font.lineHeight + lineGap;
        int visible = Math.max(1, (h - PAD * 2) / lh);
        int maxScroll = Math.max(0, lines.size() - visible);

        if (followCursor) {
            int cl = lineOfCursor(lines);
            if (cl < scrollLines) {
                scrollLines = cl;
            } else if (cl >= scrollLines + visible) {
                scrollLines = cl - visible + 1;
            }
            followCursor = false;
        }
        scrollLines = Math.max(0, Math.min(maxScroll, scrollLines));

        g.enableScissor(x + 1, y + 1, x + w - 1, y + h - 1);
        if (text.length() == 0) {
            g.drawString(font, font.plainSubstrByWidth(placeholder, maxLineWidth()),
                    x + PAD, y + PAD, CivitasColors.alpha(CivitasUi.TEXT_LIGHT, focused ? 0x55 : 0x70), false);
        }
        for (int i = 0; i < visible; i++) {
            int idx = scrollLines + i;
            if (idx >= lines.size()) {
                break;
            }
            int[] ln = lines.get(idx);
            int ly = y + PAD + i * lh;
            // selection highlight for this line
            if (hasSelection()) {
                int s = Math.max(ln[0], selStart());
                int e = Math.min(ln[1], selEnd());
                if (e > s) {
                    int sx = x + PAD + font.width(text.substring(ln[0], s));
                    int ex = x + PAD + font.width(text.substring(ln[0], e));
                    drawSelection(g, sx, ly - 1, ex, ly + lh - 2);
                }
            }
            g.drawString(font, text.substring(ln[0], ln[1]), x + PAD, ly, CivitasUi.TEXT_LIGHT, false);
        }
        if (blink() && !hasSelection()) {
            int cl = lineOfCursor(lines);
            if (cl >= scrollLines && cl < scrollLines + visible) {
                int[] ln = lines.get(cl);
                int cx = x + PAD + font.width(text.substring(ln[0], Math.min(cursor, ln[1])));
                int cy = y + PAD + (cl - scrollLines) * lh;
                g.fill(cx, cy - 1, cx + 1, cy + lh - 1, CivitasUi.GOLD);
            }
        }
        g.disableScissor();

        if (maxScroll > 0) {
            int trackH = h - 4;
            int thumbH = Math.max(12, trackH * visible / lines.size());
            int thumbY = y + 2 + (trackH - thumbH) * scrollLines / maxScroll;
            g.fill(x + w - 4, y + 2, x + w - 2, y + 2 + trackH, 0x40000000);
            g.fill(x + w - 4, thumbY, x + w - 2, thumbY + thumbH, CivitasUi.GOLD);
        }
    }
}
