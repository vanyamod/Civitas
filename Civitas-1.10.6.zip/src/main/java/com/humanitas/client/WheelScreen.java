package com.humanitas.client;

import com.humanitas.CabinetNet;
import com.humanitas.CabinetPresets;
import com.humanitas.Perms;
import net.minecraft.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.util.FormattedCharSequence;
import net.neoforged.neoforge.network.PacketDistributor;
import org.lwjgl.glfw.GLFW;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Properties;
import java.util.Set;

import static com.humanitas.client.CivitasUi.*;

/**
 * The Civitas wheel: two deep semicircles of gold medallions, one for the citizen and one for the
 * administration. Every medallion has a permanent label, every label opens a large opaque window,
 * and every window contains the full set of actions for its section. Nothing here delegates to the
 * old classic menu: forms, pickers, confirmations and the palette are opened directly on top of the
 * wheel, and a fresh snapshot from the server refreshes it in place.
 */
public class WheelScreen extends Screen {
    /** The open wheel, so snapshots can refresh it while a form is on top. */
    static WheelScreen latest;

    private static final int BTN = 36;
    private static final int WIN_W = 432;
    private static final int WIN_H = 356;
    private static final int HEAD = 40;
    private static final int FOOT = 16;
    private static final int ENTRY = 30;
    /** Half a medallion plus a small air gap, so the top and bottom buttons stay fully visible. */
    private static final int SIDE = BTN / 2 + 9;
    private static final int SMALL_W = 58;
    private static final int SMALL_H = 16;
    private static final int PICKER_W = 384;
    private static final int PICKER_ROW = 24;
    private static final int PICKER_VISIBLE = 10;

    /** key, label, icon. */
    private static final String[][] PLAYER_ITEMS = {
            {"overview", "ОБЗОР", "⌂"},
            {"manage", "ПРАВЛЕНИЕ", "✎"},
            {"roles", "РОЛИ", "⚜"},
            {"laws", "ЗАКОНЫ", "✒"},
            {"news", "НОВОСТИ", "✉"},
            {"archive", "АРХИВ", "☰"},
            {"factions", "ФРАКЦИИ", "⚔"},
            {"settings", "НАСТРОЙКИ", "⚙"}
    };
    private static final String[][] ADMIN_ITEMS = {
            {"states", "ГОСУДАРСТВА", "⚑"},
            {"parliaments", "ПАРЛАМЕНТЫ", "⚖"},
            {"players", "ИГРОКИ", "☺"},
            {"watchdog", "WATCHDOG", "◆"}
    };

    private static final int P_DEPUTY = 0;
    private static final int P_IDEOLOGY = 1;
    private static final int P_PARLIAMENT = 2;
    private static final int P_GOVERNMENT = 3;
    private static final int P_MEMBER = 4;
    private static final int P_WRITER = 5;
    private static final int P_HEIR = 6;
    private static final int P_ROLE_ASSIGN = 7;
    private static final int P_ROLE_MEMBER = 8;
    private static final int P_KICK = 9;
    private static final int P_ROLE_MANAGE = 10;
    private static final int P_ROLE_COLOR = 11;
    private static final int P_ROLE_PERMS = 12;
    private static final int P_FACTION = 13;
    private static final int P_REQUESTS = 14;
    private static final int P_FACTION_VOTE = 15;
    private static final int P_DELETE_STATE = 16;
    private static final int P_STATE_FOR = 17;

    /** One line of a window: a title, a muted value and up to two small buttons. */
    private record Entry(String title, String value, String btnA, Runnable actA,
                         String btnB, Runnable actB, boolean danger) {}

    private static final class Win {
        final String key;
        final String title;
        final String icon;
        int x;
        int y;
        double scroll;
        boolean dragging;
        int grabX;
        int grabY;

        Win(String key, String title, String icon, int x, int y) {
            this.key = key;
            this.title = title;
            this.icon = icon;
            this.x = x;
            this.y = y;
        }
    }

    private static final Properties POS = new Properties();
    private static boolean posLoaded = false;

    CompoundTag data;
    private final Screen parent;
    private final List<Win> windows = new ArrayList<>();

    /** Collapse of the dial while windows are open: 0 is the full arc, 1 is a narrow column at the edge. */
    private double collapse;

    /** Rotation of the two dials, in radians. The display value eases towards the target. */
    private double spinLeft;
    private double spinRight;
    private double shownLeft;
    private double shownRight;
    private long lastFrame = Util.getMillis();
    private long lastWatchdogRequest;
    private CompoundTag watchdogData = new CompoundTag();

    /** Which dial the arrow keys and WASD turn: 0 = citizen, 1 = administration. */
    private int focusSide = 0;
    private boolean hudHidden;
    private boolean hudWasHidden;

    private final List<String[]> pickerRows = new ArrayList<>();
    private int pickerMode = -1;
    private String pickerTarget = "";
    private int pickerScroll = 0;

    private int detailIndex = -1;
    /** True when the open card shows a player (allPlayers), false when it shows a state. */
    private boolean detailPlayer;
    private CompoundTag detailIncident;
    private int detailScroll;

    private boolean confirmOpen = false;
    private String confirmTitle = "";
    private String confirmText = "";
    private Runnable confirmAction;

    public WheelScreen(CompoundTag data, Screen parent) {
        super(Component.literal("Civitas"));
        this.data = data;
        this.parent = parent;
        latest = this;
    }

    @Override
    protected void init() {
        super.init();
        if (!hudHidden) {
            hudWasHidden = this.minecraft != null && this.minecraft.options.hideGui;
            hudHidden = true;
        }
        if (this.minecraft != null) {
            // The wheel is a full-screen desk, not an in-world overlay: bars and hearts under it
            // read as leftovers. They come back in removed().
            this.minecraft.options.hideGui = true;
        }
        lastFrame = Util.getMillis();
    }

    @Override
    public void tick() {
        super.tick();
        if(adminWheel() && (isOpen("players") || isOpen("watchdog") || detailPlayer)
                && Util.getMillis()-lastWatchdogRequest>=2000 && Minecraft.getInstance().getConnection()!=null) {
            lastWatchdogRequest=Util.getMillis();
            PacketDistributor.sendToServer(new CabinetNet.RequestWatchdog());
        }
    }
    public static void onWatchdogSnapshot(CompoundTag snapshot) {
        WheelScreen wheel=latest;
        if(wheel==null || !wheel.adminWheel())return;
        wheel.watchdogData=snapshot;
        var scores=snapshot.getList("scores",Tag.TAG_COMPOUND);
        var players=wheel.data.getList("allPlayers",Tag.TAG_COMPOUND);
        for(int i=0;i<players.size();i++) {
            var player=players.getCompound(i);player.putInt("trust",-1);
            for(int j=0;j<scores.size();j++) {
                var score=scores.getCompound(j);
                if(score.getString("uuid").equals(player.getString("uuid"))) {player.putInt("trust",score.getInt("trust"));break;}
            }
        }
    }

    @Override
    public void removed() {
        if (hudHidden && this.minecraft != null) {
            this.minecraft.options.hideGui = hudWasHidden;
            hudHidden = false;
        }
        super.removed();
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    /** Nothing here: the backdrop is painted in render so it isn't blurred twice. */
    @Override
    public void renderBackground(GuiGraphics g, int mx, int my, float partialTick) {
    }

    // ---------- geometry ----------

    private double radius() {
        // Leave a real margin above and below the dial even on small GUI scales. A generous
        // radius is what keeps neighbouring medallions and their plaques from crowding.
        double byHeight = height / 2.0 - BTN / 2.0 - 10;
        return Math.max(60, Math.min(Math.min(height * 0.44, 260), byHeight));
    }

    /** Horizontal reach of the dial. Shrinks to zero while windows are open, so the dial becomes a column. */
    private double radiusX() {
        return radius() * (1.0 - collapse);
    }

    private boolean adminWheel() {
        return data.getBoolean("op");
    }

    private static double step(int count) {
        return Math.PI / Math.max(1, count);
    }

    /**
     * Angle of item {@code i} on a dial. The dial is a half-circle; the items sit one half-step
     * away from each end, so both extreme medallions are fully visible. Scrolling shifts the
     * whole set and the item that leaves one end re-enters at the other, exactly like a wheel.
     */
    private double itemAngle(int side, int i, int count) {
        double shown = side == 0 ? shownLeft : shownRight;
        double a = -Math.PI / 2 + (i + 0.5) * step(count) + shown;
        // Wrap into [-PI/2, PI/2): moving by PI changes every item's position by exactly one
        // full half-turn, so the picture is continuous while the values stay small.
        a = (a + Math.PI / 2) % Math.PI;
        if (a < 0) a += Math.PI;
        return a - Math.PI / 2;
    }

    /** 0 at the very end of the arc, 1 in the safe middle. Hides the teleport when an item wraps. */
    private float edgeFade(double angle, int count) {
        double feather = step(count) * 0.34;
        double distance = Math.PI / 2 - Math.abs(angle);
        return (float) clamp(distance / feather, 0.0, 1.0);
    }

    /** Centre of medallion i. side 0 = left arc, 1 = right arc. */
    private double[] center(int side, int i, int count) {
        double th = itemAngle(side, i, count);
        double r = radius();
        double cy = height / 2.0;
        double cx = side == 0 ? SIDE : width - SIDE;
        double dir = side == 0 ? 1 : -1;
        double rx = radiusX();
        // Vertical spacing: an arc while the dial is open, evenly spaced while it is collapsed to a column.
        double arc = Math.sin(th) * (1.0 - collapse) + (th / (Math.PI / 2)) * collapse;
        return new double[]{cx + dir * rx * Math.cos(th), cy + r * arc};
    }

    /** State name with the same fallback the HUD uses when no state has been founded yet. */
    private String stateName() {
        if (data.getBoolean("noState")) return "ГРАЖДАНСКАЯ ПАЛАТА";
        String name = data.getString("name");
        return name.isBlank() ? "CIVITAS" : name;
    }

    private int winW() {
        int band = width - dialZoneLeft() - dialZoneRight();
        return Math.min(WIN_W, Math.max(220, Math.min(band, width - 20)));
    }

    private int maxWinH() {
        return Math.min(WIN_H, Math.max(140, height - 20));
    }

    /** Windows are only as tall as their contents, so a four-row style card is not a black wall. */
    private int winH(String key) {
        int rows = Math.max(1, entries(key).size());
        int wanted = HEAD + 10 + rows * ENTRY + FOOT;
        return Math.min(maxWinH(), Math.max(140, wanted));
    }

    private int viewH(Win w) {
        return Math.max(ENTRY, winH(w.key) - HEAD - FOOT - 10);
    }

    private int closeX(Win w) {
        return w.x + winW() - 26;
    }

    private int closeY(Win w) {
        return w.y + 10;
    }

    // ---------- drawing ----------

    @Override
    public void render(GuiGraphics g, int mx, int my, float partialTick) {
        // Smooth dial easing. Snapping avoids endless sub-pixel redraws when the wheel is idle.
        long now = Util.getMillis();
        double dt = Math.min(0.1, (now - lastFrame) / 1000.0);
        lastFrame = now;
        double ease = CivitasSettings.reducedMotion() ? 1.0 : 1.0 - Math.exp(-dt * 10.0);
        shownLeft += (spinLeft - shownLeft) * ease;
        shownRight += (spinRight - shownRight) * ease;
        if (Math.abs(spinLeft - shownLeft) < 0.0005) shownLeft = spinLeft;
        if (Math.abs(spinRight - shownRight) < 0.0005) shownRight = spinRight;
        double collapseTarget = windows.isEmpty() ? 0.0 : 1.0;
        collapse += (collapseTarget - collapse) * ease;
        if (Math.abs(collapseTarget - collapse) < 0.001) collapse = collapseTarget;

        g.fill(0, 0, width, height, CivitasColors.alpha(PLATE_DEEP, CivitasSettings.backdropPercent() * 255 / 100));
        drawTitle(g);
        drawArc(g, 0, PLAYER_ITEMS.length);
        if (adminWheel()) {
            drawArc(g, 1, ADMIN_ITEMS.length);
        }
        g.flush();

        for (int i = 0; i < windows.size(); i++) {
            Win w = windows.get(i);
            g.pose().pushPose();
            g.pose().translate(0, 0, 100 + i * 2);
            drawWindow(g, w, mx, my);
            g.flush();
            g.pose().popPose();
        }
        // Medallions and their labels sit above every window, so the wheel stays reachable while a
        // window is open. Overlays (details, pickers, confirm) are higher still.
        g.pose().pushPose();
        g.pose().translate(0, 0, 400);
        drawWheel(g, mx, my, PLAYER_ITEMS, 0);
        if (adminWheel()) {
            drawWheel(g, mx, my, ADMIN_ITEMS, 1);
        }
        g.flush();
        g.pose().popPose();
        if (detailIndex >= 0) {
            g.pose().pushPose();
            g.pose().translate(0, 0, 450);
            drawDetail(g);
            g.flush();
            g.pose().popPose();
        }
        if (pickerMode >= 0) {
            g.pose().pushPose();
            g.pose().translate(0, 0, 500);
            drawPicker(g, mx, my);
            g.flush();
            g.pose().popPose();
        }
        if (confirmOpen) {
            g.pose().pushPose();
            g.pose().translate(0, 0, 550);
            drawConfirm(g, mx, my);
            g.flush();
            g.pose().popPose();
        }
    }

    private boolean isMouseOverAnyWindow(int mx, int my) {
        for (Win win : windows) {
            if (inside(mx, my, win.x, win.y, winW(), winH(win.key))) return true;
        }
        return detailIndex >= 0 || pickerMode >= 0 || confirmOpen;
    }

    private boolean isCovered(int x, int y, int w, int h) {
        for (Win win : windows) {
            int ww = winW();
            int wh = winH(win.key);
            if (x + w > win.x && x < win.x + ww && y + h > win.y && y < win.y + wh) {
                return true;
            }
        }
        return false;
    }

    /** The state and the in-world date above the wheel. No branding, no key hints. */
    private void drawTitle(GuiGraphics g) {
        int cx = width / 2;
        String name = font.plainSubstrByWidth(stateName().toUpperCase(Locale.ROOT), width - 120);
        int tw = font.width(name);
        drawTextCentered(g, name, cx, 12, GOLD, true);
        g.fill(cx - tw / 2 - 36, 17, cx - tw / 2 - 12, 18, CivitasColors.alpha(GOLD, 0x60));
        g.fill(cx + tw / 2 + 12, 17, cx + tw / 2 + 36, 18, CivitasColors.alpha(GOLD, 0x60));

        String date = day(data.getLong("today"));
        drawTextCentered(g, date, cx, 26, TEXT_LIGHT, false);
    }

    private void drawWheel(GuiGraphics g, int mx, int my, String[][] items, int side) {
        if (mx == -1 && my == -1) {
            // Rendered as an inactive backdrop: suppress button plaques and text
            return;
        }
        boolean mouseInWindow = isMouseOverAnyWindow(mx, my);
        for (int i = 0; i < items.length; i++) {
            double[] c = center(side, i, items.length);
            double th = itemAngle(side, i, items.length);
            float fade = edgeFade(th, items.length);
            if (fade <= 0.03F) continue;

            int cx = (int) Math.round(c[0]);
            int cy = (int) Math.round(c[1]);
            int bx = cx - BTN / 2;
            int by = cy - BTN / 2;
            String key = items[i][0];
            String label = items[i][1];
            int[] lr = labelRect(side, cx, cy, label);

            boolean overlayOpen = pickerMode >= 0 || detailIndex >= 0 || confirmOpen;
            boolean plaqueCovered = overlayOpen;
            boolean medallionCovered = false;
            // While an overlay is open it swallows wheel clicks, so only its own controls may click.
            if (!overlayOpen) {
                CivitasSounds.register(bx, by, BTN, BTN, CivitasUi.Style.PRIMARY);
                if (windows.isEmpty()) {
                    CivitasSounds.register(lr[0], lr[1], lr[2], lr[3], CivitasUi.Style.SECONDARY);
                }
            }

            boolean hot = !overlayOpen && fade > 0.30F
                    && (inside(mx, my, bx, by, BTN, BTN) || (windows.isEmpty() && inside(mx, my, lr[0], lr[1], lr[2], lr[3])));
            boolean open = isOpen(key);
            if (!plaqueCovered && windows.isEmpty() && (CivitasSettings.labelsAlways() || hot)) {
                if (hot) {
                    drawPlaque(g, lr[0], lr[1], lr[2], lr[3], true, fade);
                    if (side == 0) {
                        g.fill(bx + BTN + 2, cy - 1, lr[0], cy, fade(CivitasColors.alpha(GOLD, 0x80), fade));
                    } else {
                        g.fill(lr[0] + lr[2], cy - 1, bx, cy, fade(CivitasColors.alpha(GOLD, 0x80), fade));
                    }
                } else {
                    drawPlaque(g, lr[0], lr[1], lr[2], lr[3], false, fade);
                }
                g.drawString(font, label, lr[0] + 9, lr[1] + 4,
                        fade(hot ? GOLD : TEXT_LIGHT, fade), true);
            }
            if (!medallionCovered) {
                drawMedallion(g, cx, cy, items[i][2], hot, open, alert(key), fade);
            }
        }
    }

    /** Dark window body: the wheel's own frame, so windows and pickers never read as white sheets. */
    private void panel(GuiGraphics g, int x, int y, int w, int h) {
        darkPanel(g, x, y, w, h);
    }

    private int[] labelRect(int side, int cx, int cy, String label) {
        int w = font.width(label) + 18;
        int h = 16;
        int gap = 6;
        int x = side == 0 ? cx + BTN / 2 + gap : cx - BTN / 2 - gap - w;
        // Nudge tags away from the equator. Near the top and bottom of the dial the next
        // medallion sits just below/above its neighbour's plaque, so a centred tag can clip it.
        int lift = cy < height / 2 - 30 ? -10 : cy > height / 2 + 30 ? 10 : 0;
        return new int[]{x, cy - h / 2 + lift, w, h};
    }

    /** Label plaques sit next to their medallion; the y position is worked out from the medallion. */
    private void drawPlaque(GuiGraphics g, int x, int y, int w, int h, boolean hot, float fade) {
        g.fill(x + 1, y + 2, x + w + 1, y + h + 2, fade(0x55000000, fade));
        g.fill(x, y, x + w, y + h, fade(hot ? CivitasColors.mix(PLATE, OLIVE, 0.35F)
                : CivitasColors.mix(PLATE_DEEP, PLATE, 0.35F), fade));
        g.fill(x, y, x + w, y + 1, fade(hot ? GOLD : CivitasColors.alpha(GOLD_DEEP, 0xA0), fade));
        g.fill(x, y + h - 1, x + w, y + h, fade(CivitasColors.alpha(0x000000, 0x50), fade));
        if (hot) {
            g.fill(x, y, x + 2, y + h, fade(GOLD, fade));
        }
    }

    private void drawArc(GuiGraphics g, int side, int count) {
        double cx = side == 0 ? SIDE : width - SIDE;
        double cy = height / 2.0;
        double dir = side == 0 ? 1 : -1;
        double r = radius();
        double rx = radiusX();
        for (double a = -Math.PI / 2; a <= Math.PI / 2; a += 0.018) {
            int x = (int) Math.round(cx + dir * rx * Math.cos(a));
            int y = (int) Math.round(cy + r * Math.sin(a));
            g.fill(x, y, x + 2, y + 2, CivitasColors.alpha(GOLD, side == focusSide ? 0x70 : 0x38));
            int x2 = (int) Math.round(cx + dir * (rx + 15) * Math.cos(a));
            int y2 = (int) Math.round(cy + (r + 15) * Math.sin(a));
            g.fill(x2, y2, x2 + 1, y2 + 1, CivitasColors.alpha(GOLD, 0x16));
        }
        // Short radial ticks every five degrees, offset by the dial's spin. Unlike a mark tied to
        // each medallion, these stay visible in the gaps and make the rotation readable.
        double shown = side == 0 ? shownLeft : shownRight;
        double spacing = Math.PI / 36.0;
        double start = -Math.PI / 2 + ((shown % spacing) + spacing) % spacing;
        for (double a = start; a <= Math.PI / 2; a += spacing) {
            double edge = Math.min(1.0, (Math.PI / 2 - Math.abs(a)) / (Math.PI / 24.0));
            int alpha = (int) Math.round(0x55 * edge);
            if (alpha <= 2) continue;
            for (int k = 9; k <= 13; k += 2) {
                int x = (int) Math.round(cx + dir * (rx + k) * Math.cos(a));
                int y = (int) Math.round(cy + (r + k) * Math.sin(a));
                g.fill(x, y, x + 1, y + 1, alpha << 24 | GOLD & 0xFFFFFF);
            }
        }
    }

    private void drawMedallion(GuiGraphics g, int cx, int cy, String icon, boolean hot, boolean open,
                               boolean alert, float fade) {
        int r = BTN / 2;
        if (hot) {
            disc(g, cx, cy, r + 8, fade(CivitasColors.alpha(GOLD, 0x20), fade));
            disc(g, cx, cy, r + 4, fade(CivitasColors.alpha(GOLD, 0x2C), fade));
        }
        disc(g, cx + 2, cy + 3, r, fade(0x70000000, fade));
        disc(g, cx, cy, r, fade(GOLD, fade));
        disc(g, cx, cy, r - 2, fade(GOLD_DEEP, fade));
        disc(g, cx, cy, r - 4, fade(open ? OLIVE : HEADER, fade));
        disc(g, cx, cy, r - 6, fade(CivitasColors.alpha(TEXT_LIGHT, 0x12), fade));
        disc(g, cx, cy, r - 8, fade(open ? CivitasColors.mix(OLIVE, PLATE_DEEP, 0.55F) : PLATE_DEEP, fade));
        drawIconCentered(g, icon, cx, cy, 1.8F, fade(hot ? GOLD : TEXT_LIGHT, fade));
        if (alert) {
            disc(g, cx + r - 2, cy - r + 2, 5, fade(CivitasColors.alpha(0x000000, 0x70), fade));
            disc(g, cx + r - 2, cy - r + 2, 4, fade(HEART, fade));
            disc(g, cx + r - 3, cy - r + 1, 2, fade(CivitasColors.alpha(TEXT_LIGHT, 0xB0), fade));
        }
    }

    /** Multiplies the existing alpha of a packed colour. Used to fade the dial's wrapped ends. */
    private static int fade(int colour, float factor) {
        int a = Math.round(((colour >>> 24) & 0xFF) * Math.max(0F, Math.min(1F, factor)));
        return a << 24 | colour & 0xFFFFFF;
    }

    /** A filled pixel circle. Enough segments to look round at medallion size, cheap to draw. */
    private static void disc(GuiGraphics g, int cx, int cy, int r, int colour) {
        if (r <= 0) return;
        for (int dy = -r; dy <= r; dy++) {
            int dx = (int) Math.sqrt((double) r * r - (double) dy * dy);
            g.fill(cx - dx, cy + dy, cx + dx + 1, cy + dy + 1, colour);
        }
    }

    private void drawIconCentered(GuiGraphics g, String icon, float cx, float cy, float scale, int colour) {
        CivitasUi.icon(g, font, icon, cx, cy, scale, colour);
    }

    

    private void drawTextCentered(GuiGraphics g, String text, int cx, int y, int colour, boolean shadow) {
        g.drawString(font, text, cx - font.width(text) / 2, y, colour, shadow);
    }

    // ---------- windows ----------

    private void drawWindow(GuiGraphics g, Win w, int mx, int my) {
        int ww = winW();
        int wh = winH(w.key);
        if (w.y + wh > height) w.y = Math.max(0, height - wh);
        
        // New window style matching CabinetScreen: panel with cream cards
        panel(g, w.x, w.y, ww, wh);

        // Header matching CabinetScreen style
        g.fill(w.x + 2, w.y + 2, w.x + ww - 2, w.y + 40, HEADER);
        g.fill(w.x + 2, w.y + 2, w.x + ww - 2, w.y + 3, CivitasColors.alpha(TEXT_LIGHT, 0x1A));
        g.fill(w.x + 2, w.y + 39, w.x + ww - 2, w.y + 40, GOLD_DEEP);
        g.fill(w.x + 8, w.y + 40, w.x + ww - 8, w.y + 41, CivitasColors.alpha(GOLD, 0x40));
        drawSmallMedallion(g, w.x + 23, w.y + 21, w.icon);
        g.drawString(font, w.title, w.x + 42, w.y + 9, TEXT_LIGHT, true);
        String sub = windowSubtitle(w.key);
        g.drawString(font, font.plainSubstrByWidth(sub, ww - 90), w.x + 42, w.y + 22, GOLD, false);

        // Close button matching CabinetScreen
        int cx = closeX(w);
        int cy = closeY(w);
        boolean closeHot = inside(mx, my, cx, cy, 20, 20);
        button(g, font, cx, cy, 20, 20, "×", closeHot, Style.SECONDARY);

        List<Entry> entries = entries(w.key);
        int top = w.y + HEAD + 6; // Below header
        int vh = viewH(w);
        double maxScroll = Math.max(0, entries.size() * ENTRY - vh);
        w.scroll = clamp(w.scroll, 0, maxScroll);

        g.enableScissor(w.x + 12, top, w.x + ww - 12, top + vh);
        for (int i = 0; i < entries.size(); i++) {
            Entry e = entries.get(i);
            int ey = top + i * ENTRY - (int) w.scroll;
            if (ey + ENTRY - 2 <= top || ey >= top + vh) continue;
            drawRow(g, w, e, ey, mx, my, w.x + 12, ww - 24);
        }
        g.disableScissor();

        // New scrollbar style
        drawScrollbar(g, w.x + ww - 10, top, vh, entries.size() * ENTRY, w.scroll, maxScroll);

        // Remove foot line for cleaner look
        // int fy = w.y + wh - FOOT;
        // g.fill(w.x + 2, fy, w.x + ww - 2, fy + 1, CivitasColors.alpha(GOLD_DEEP, 0x90));
    }

    private String windowSubtitle(String key) {
        return switch (key) {
            case "states", "parliaments", "players" -> "АДМИНИСТРАЦИЯ  ·  " + data.getList(key.equals("states")
                    || key.equals("parliaments") ? "states" : "allPlayers", Tag.TAG_COMPOUND).size() + " записей";
            case "watchdog" -> "МОНИТОРИНГ  ·  LIVE";
            case "settings" -> "ЛИЧНЫЕ НАСТРОЙКИ";
            case "overview", "manage", "roles" -> data.getBoolean("noState")
                    ? "ГОСУДАРСТВО НЕ ВЫБРАНО" : data.getString("name").toUpperCase(Locale.ROOT);
            case "laws" -> "ЗАКОНОДАТЕЛЬНАЯ ПАЛАТА";
            case "news" -> "ПРЕСС-СЛУЖБА";
            case "archive" -> "АРХИВ ГОСУДАРСТВА";
            case "factions" -> "ПАРТИИ И ФРАКЦИИ";
            default -> stateName().toUpperCase(Locale.ROOT);
        };
    }

    private void drawSmallMedallion(GuiGraphics g, int cx, int cy, String icon) {
        disc(g, cx + 1, cy + 2, 11, 0x60000000);
        disc(g, cx, cy, 11, GOLD);
        disc(g, cx, cy, 9, GOLD_DEEP);
        disc(g, cx, cy, 8, HEADER);
        drawIconCentered(g, icon, cx, cy, 1.15F, GOLD);
    }

    private void drawRow(GuiGraphics g, Win w, Entry e, int y, int mx, int my,
                         int x, int rw) {
        boolean hot = inside(mx, my, x, y, rw, ENTRY - 2);
        
        // Draw a rich card like CabinetScreen with cream background and hover
        g.fill(x, y, x + rw, y + ENTRY - 2, hot ? 0xFF3B3322 : 0xFF2A2B31);
        g.fill(x, y + ENTRY - 3, x + rw, y + ENTRY - 2, CivitasColors.alpha(0x000000, 0x18));
        g.fill(x, y, x + 3, y + ENTRY - 2, e.danger() ? GOLD_DEEP : (hot ? GOLD : OLIVE));
        if (hot) {
            g.fill(x + 3, y, x + rw, y + 1, CivitasColors.alpha(GOLD, 0x30));
        }

        int[] bx = buttonX(w, e);
        int right = bx[0] >= 0 ? bx[0] : bx[1] >= 0 ? bx[1] : x + rw;
        int textRight = right - 8;
        int maxText = Math.max(20, textRight - (x + 11));

        if (e.value().isEmpty()) {
            g.drawString(font, font.plainSubstrByWidth(e.title(), maxText), x + 11, y + ENTRY / 2 - 4,
                    e.danger() ? GOLD : TEXT_LIGHT, false);
        } else {
            g.drawString(font, font.plainSubstrByWidth(e.title(), maxText), x + 11, y + 5,
                    e.danger() ? GOLD : (hot ? GOLD : TEXT_LIGHT), false);
            g.drawString(font, font.plainSubstrByWidth(e.value(), maxText), x + 11, y + 16, CivitasColors.mix(TEXT_LIGHT, MUTED, 0.45F), false);
        }
        if(w.key.equals("players") && e.value().startsWith("Trust Rate: ")) {
            int score=-1;try {score=Integer.parseInt(e.value().substring(12).split(" ")[0]);}catch(Exception ignored) {}
            int barX=x+11,barW=Math.max(0,Math.min(110,maxText));
            g.fill(barX,y+25,barX+barW,y+27,0xFF17191C);
            if(score>=0)g.fill(barX,y+25,barX+barW*Math.max(0,Math.min(100,score))/100,y+27,score>=60?0xFF8FA95D:score>=30?0xFFD3A651:0xFFCC655A);
        }
        if (e.btnA() != null) {
            button(g, font, bx[0], y + 5, SMALL_W, SMALL_H, e.btnA(),
                    inside(mx, my, bx[0], y + 5, SMALL_W, SMALL_H),
                    e.danger() ? Style.DANGER : Style.SECONDARY);
        }
        if (e.btnB() != null) {
            button(g, font, bx[1], y + 5, SMALL_W, SMALL_H, e.btnB(),
                    inside(mx, my, bx[1], y + 5, SMALL_W, SMALL_H), Style.SECONDARY);
        }
    }

    /** X of the two button slots (B is rightmost). -1 when absent. */
    private int[] buttonX(Win w, Entry e) {
        int right = w.x + winW() - 16;
        int ax = -1;
        int bx = -1;
        if (e.btnB() != null) {
            bx = right - SMALL_W;
            right = bx - 4;
        }
        if (e.btnA() != null) {
            ax = right - SMALL_W;
        }
        return new int[]{ax, bx};
    }

    private void drawScrollbar(GuiGraphics g, int x, int y, int trackH, int contentH,
                               double pos, double maxScroll) {
        g.fill(x, y, x + 3, y + trackH, CivitasColors.alpha(0x000000, 0x40));
        if (maxScroll <= 0) return;
        int thumbH = Math.max(20, (int) ((double) trackH * trackH / contentH));
        int thumbY = y + (int) ((trackH - thumbH) * (pos / maxScroll));
        g.fill(x, thumbY, x + 3, thumbY + thumbH, GOLD);
    }

    /** The shared frame: shadow, heavy gold rim, dark opaque body and corner studs. */
    private void darkPanel(GuiGraphics g, int x, int y, int w, int h) {
        g.fill(x + 2, y + h, x + w + 2, y + h + 2, 0x70000000);
        g.fill(x + w, y + 2, x + w + 2, y + h, 0x70000000);

        g.fill(x + 2, y, x + w - 2, y + 2, GOLD);
        g.fill(x + 2, y + h - 2, x + w - 2, y + h, GOLD);
        g.fill(x, y + 2, x + 2, y + h - 2, GOLD);
        g.fill(x + w - 2, y + 2, x + w, y + h - 2, GOLD);
        g.fill(x + 1, y + 1, x + 2, y + 2, GOLD);
        g.fill(x + w - 2, y + 1, x + w - 1, y + 2, GOLD);
        g.fill(x + 1, y + h - 2, x + 2, y + h - 1, GOLD);
        g.fill(x + w - 2, y + h - 2, x + w - 1, y + h - 1, GOLD);

        g.fill(x + 2, y + 2, x + w - 2, y + 3, GOLD_DEEP);
        g.fill(x + 2, y + h - 3, x + w - 2, y + h - 2, GOLD_DEEP);
        g.fill(x + 2, y + 3, x + 3, y + h - 3, GOLD_DEEP);
        g.fill(x + w - 3, y + 3, x + w - 2, y + h - 3, GOLD_DEEP);

        g.fillGradient(x + 2, y + 2, x + w - 2, y + h - 2, PANEL, PLATE_DEEP);
        g.fill(x + 3, y + 2, x + w - 3, y + 3, CivitasColors.alpha(TEXT_LIGHT, 0x18));

        g.fill(x + 3, y + 3, x + 5, y + 5, GOLD);
        g.fill(x + w - 5, y + 3, x + w - 3, y + 5, GOLD);
        g.fill(x + 3, y + h - 5, x + 5, y + h - 3, GOLD);
        g.fill(x + w - 5, y + h - 5, x + w - 3, y + h - 3, GOLD);
    }

    // ---------- entries ----------

    private static Entry text(String title) {
        return new Entry(title, "", null, null, null, null, false);
    }

    private static Entry text(String title, String value) {
        return new Entry(title, value, null, null, null, null, false);
    }

    private static Entry action(String title, String btn, Runnable act) {
        return new Entry(title, "", btn, act, null, null, false);
    }

    private static Entry action(String title, String value, String btn, Runnable act) {
        return new Entry(title, value, btn, act, null, null, false);
    }

    private static Entry danger(String title, String value, String btn, Runnable act) {
        return new Entry(title, value, btn, act, null, null, true);
    }

    private static Entry vote(String title, String value, String yes, Runnable yesAct,
                              String no, Runnable noAct) {
        return new Entry(title, value, yes, yesAct, no, noAct, false);
    }

    private List<Entry> entries(String key) {
        List<Entry> out = new ArrayList<>();
        switch (key) {
            case "overview" -> overview(out);
            case "manage" -> manage(out);
            case "roles" -> roles(out);
            case "laws" -> laws(out);
            case "news" -> news(out);
            case "archive" -> archive(out);
            case "factions" -> factions(out);
            case "settings" -> style(out);
            case "states" -> states(out);
            case "parliaments" -> parliaments(out);
            case "players" -> players(out);
            case "watchdog" -> watchdog(out);
            default -> out.add(text("Пусто"));
        }
        if (out.isEmpty()) out.add(text("Здесь пока нечего показать"));
        return out;
    }

    private void overview(List<Entry> out) {
        if (data.getBoolean("noState")) {
            out.add(text("Государство", "Вы пока не состоите в государстве"));
            out.add(text("Доступ", "Новости открыты для всех игроков"));
            if (data.getBoolean("op")) {
                out.add(action("Создать государство", "СОЗДАТЬ", () -> form("state")));
            }
            return;
        }
        out.add(text("Государство", data.getString("name")));
        out.add(text("Тип", data.getString("type")));
        out.add(text("Владелец", data.getString("ownerName")));
        out.add(text("Лидер", data.getString("leaderName")));
        out.add(text("Заместитель", value(0)));
        out.add(text("Идеология", CabinetPresets.icon(data.getString("ideology")) + "  " + value(1)));
        out.add(text("Парламент", value(2)));
        out.add(text("Форма правления", value(3)));
        out.add(text("Население", data.getList("members", Tag.TAG_COMPOUND).size() + " человек  ·  законов "
                + data.getList("bills", Tag.TAG_COMPOUND).size()));
        if (data.getBoolean("canRename")) {
            out.add(action("Название и тип страны", "ИЗМЕНИТЬ", () -> form("rename")));
        }
        if (!data.getBoolean("canEdit")) {
            out.add(danger("Выйти из государства", "Вы покинете страну", "ВЫЙТИ", () -> form("leave")));
        }
        if (data.getBoolean("op")) {
            out.add(action("Создать другое государство", "СОЗДАТЬ", () -> form("state")));
            out.add(danger("Удалить государство", "Требуется точное название", "УДАЛИТЬ",
                    () -> openPicker(P_DELETE_STATE)));
        }
    }

    private void editable(List<Entry> out,String title,String value,boolean edit,int picker) {
        out.add(edit?action(title,value,"ИЗМЕНИТЬ",()->openPicker(picker)):text(title,value));
    }

    private void manage(List<Entry> out) {
        if (data.getBoolean("noState")) {
            out.add(text("Государство", "Сначала вступите в государство"));
            return;
        }
        boolean edit = data.getBoolean("canEdit");
        editable(out,"Заместитель",value(0),edit,P_DEPUTY);
        editable(out,"Идеология",CabinetPresets.icon(data.getString("ideology"))+"  ·  "+value(1),edit,P_IDEOLOGY);
        editable(out,"Парламент",value(2),edit,P_PARLIAMENT);
        editable(out,"Форма правления",value(3),edit,P_GOVERNMENT);
        editable(out,"Члены государства",membersText(),edit,P_MEMBER);
        editable(out,"Писатели новостей",writersText(),edit,P_WRITER);
        if ("Монархия".equals(data.getString("government"))) {
            editable(out,"Наследник",heirText(),edit,P_HEIR);
            if(edit && !data.getString("heirName").isEmpty())
                out.add(danger("Отречься от престола","Власть перейдёт наследнику","ОТРЕЧЬСЯ",()->form("abdicate")));
        }

        long electionEnd = data.getLong("electionEnd");
        if (electionEnd != Long.MIN_VALUE) {
            out.add(text("Выборы до", day(electionEnd)));
            ListTag cands = data.getList("candidates", Tag.TAG_COMPOUND);
            for (int i = 0; i < cands.size(); i++) {
                CompoundTag c = cands.getCompound(i);
                String uuid = c.getString("uuid");
                String mark = uuid.equals(data.getString("myVote")) ? "  ·  ваш голос" : "";
                out.add(action(c.getString("name"), "голосов " + c.getInt("votes") + mark,
                        "ГОЛОС", () -> apply("vote", uuid)));
            }
            if (data.getBoolean("isMember")) {
                boolean running = data.getBoolean("isCandidate");
                out.add(action(running ? "Снять кандидатуру" : "Баллотироваться",
                        "Вы участвуете в выборах", running ? "СНЯТЬ" : "ВСТАТЬ",
                        () -> apply("candidacy", "toggle")));
            }
        } else if (CabinetPresets.hasElections(data.getString("government"))) {
            out.add(text("Следующие выборы", day(data.getLong("termEnd"))));
        } else {
            out.add(text("Срок власти", "бессрочно"));
        }
    }

    private void roles(List<Entry> out) {
        if (data.getBoolean("noState")) {
            out.add(text("Роли", "Сначала вступите в государство"));
            return;
        }
        long perms = data.getLong("myPerms");
        ListTag roleList = data.getList("roles", Tag.TAG_COMPOUND);
        if (roleList.isEmpty()) out.add(text("Роли", "В государстве ещё нет ролей"));
        for (int i = 0; i < roleList.size(); i++) {
            CompoundTag r = roleList.getCompound(i);
            String id = r.getString("id");
            String name = r.getString("name");
            boolean canManage = (perms & Perms.ROLE_MANAGE) != 0;
            if (canManage) {
                out.add(action(name, "участников " + r.getInt("count") + "  ·  управление",
                        "ОТКРЫТЬ", () -> {
                            pickerTarget = id;
                            openPicker(P_ROLE_MANAGE);
                        }));
            } else {
                out.add(text(name, "участников " + r.getInt("count")));
            }
        }
        if ((perms & Perms.ROLE_MANAGE) != 0) {
            out.add(action("Новая роль", "СОЗДАТЬ", () -> form("role")));
        }
        if ((perms & (Perms.ROLE_ASSIGN | Perms.MEMBER_KICK)) != 0) {
            out.add(action("Назначить роли участникам", "НАЗНАЧИТЬ", () -> openPicker(P_ROLE_ASSIGN)));
        }
        ListTag members = data.getList("members", Tag.TAG_COMPOUND);
        for (int i = 0; i < members.size(); i++) {
            CompoundTag m = members.getCompound(i);
            out.add(text(m.getString("name"), roleNameOf(m.getString("uuid"))));
        }
    }

    private void laws(List<Entry> out) {
        if (data.getBoolean("noState")) {
            out.add(text("Законы", "Нет государства — нет законодательной палаты"));
            return;
        }
        out.add(action("Предложить закон", "СОЗДАТЬ", () -> form("bill")));
        ListTag bills = data.getList("bills", Tag.TAG_COMPOUND);
        if (bills.isEmpty()) out.add(text("Законопроектов пока нет"));
        boolean canClose = data.getBoolean("canEdit") || data.getBoolean("op");
        for (int i = 0; i < bills.size(); i++) {
            CompoundTag b = bills.getCompound(i);
            int id = b.getInt("id");
            boolean open = !b.getBoolean("closed");
            String mine = b.getString("mine");
            String tally = "за " + b.getInt("yes") + "  ·  против " + b.getInt("no")
                    + (b.getBoolean("bloc") ? "  ·  по местам" : "");
            String title="#"+b.getInt("number")+(open?"":"  [закрыт]")+"  "+b.getString("title");
            if(open && mine.isEmpty()) {
                out.add(vote(title,tally,"ЗА",()->PacketDistributor.sendToServer(new CabinetNet.VoteBill(id,true)),
                        "ПРОТИВ",()->PacketDistributor.sendToServer(new CabinetNet.VoteBill(id,false))));
            } else {
                out.add(text(title,tally+(open?(mine.equals("yes")?"  ·  ваш голос: за":"  ·  ваш голос: против"):"")));
            }
            if (open && canClose) {
                out.add(action("Закрыть голосование", "#" + b.getInt("number"), "ЗАКРЫТЬ",
                        () -> PacketDistributor.sendToServer(new CabinetNet.CloseBill(id))));
            }
        }
    }

    private void news(List<Entry> out) {
        if (data.getBoolean("canPost")) {
            out.add(action("Написать новость", "СОЗДАТЬ",
                    () -> Minecraft.getInstance().setScreen(new NewsEditorScreen(this))));
        }
        ListTag news = data.getList("news", Tag.TAG_COMPOUND);
        if (news.isEmpty()) out.add(text("Новостей пока нет"));
        for (int i = 0; i < news.size(); i++) {
            CompoundTag n = news.getCompound(i);
            int id = n.getInt("id");
            String who = n.getString("stateName").isEmpty() ? "Администрация" : n.getString("stateName");
            out.add(action(who + "  ·  " + day(n.getLong("day"))
                            + (n.getBoolean("image") ? "  ·  фото" : ""), n.getString("title"),
                    "ЧИТАТЬ", () -> PacketDistributor.sendToServer(new CabinetNet.RequestNews(id))));
        }
    }

    private void archive(List<Entry> out) {
        ListTag archive = data.getList("archive", Tag.TAG_STRING);
        if (archive.isEmpty()) out.add(text("Архив пока пуст"));
        for (int i = 0; i < archive.size(); i++) {
            out.add(text(archive.getString(i)));
        }
    }

    private void factions(List<Entry> out) {
        if (data.getBoolean("noState")) {
            out.add(text("Фракции", "Фракции существуют внутри государства"));
            return;
        }
        ListTag facs = data.getList("factions", Tag.TAG_COMPOUND);
        boolean inAny = false;
        for (int i = 0; i < facs.size(); i++) {
            if (facs.getCompound(i).getBoolean("mine")) inAny = true;
        }
        if (!inAny) {
            out.add(action("Создать фракцию", "Вы станете её лидером", "СОЗДАТЬ", () -> form("faction")));
        }
        boolean electing = data.getLong("electionEnd") != Long.MIN_VALUE;
        boolean canVote = electing && data.getInt("parliamentSeats") > 0 && !data.getBoolean("myVoteSet");
        if (facs.isEmpty()) out.add(text("Фракций пока нет"));
        for (int i = 0; i < facs.size(); i++) {
            CompoundTag f = facs.getCompound(i);
            String fid = f.getString("id");
            String name = f.getString("name");
            String status = f.getBoolean("mine") ? "  ·  вы в ней" : f.getBoolean("requested") ? "  ·  заявка" : "";
            String summary="членов "+f.getInt("members")+"  ·  мест "+f.getInt("seats")+status;
            if (f.getBoolean("mine")) out.add(danger(name,summary,"ВЫЙТИ",()->apply("faction","leave")));
            else if (!inAny && !f.getBoolean("requested")) out.add(action(name,summary,"ВСТУПИТЬ",()->apply("faction","join|"+fid)));
            else out.add(text(name,summary));
            if (f.getBoolean("manage")) {
                out.add(action("Заявки во фракцию", name, "ОТКРЫТЬ", () -> {
                    pickerTarget = fid;
                    openPicker(P_REQUESTS);
                }));
                out.add(danger("Распустить фракцию", name, "РАСПУСТИТЬ", () -> {
                    closePicker();
                    askConfirm("РАСПУСТИТЬ ФРАКЦИЮ", "Фракция «" + name + "» будет удалена безвозвратно.",
                            () -> apply("faction", "disband|" + fid));
                }));
            }
            if (canVote) {
                out.add(action("Голос в парламент", name, "ГОЛОС", () -> {
                    pickerTarget = fid;
                    openPicker(P_FACTION_VOTE);
                }));
            }
        }
    }

    private void style(List<Entry> out) {
        out.add(action("Движение колеса",CivitasSettings.reducedMotion()?"без анимации":"плавная анимация",
                "ПЕРЕКЛ.",CivitasSettings::toggleReducedMotion));
        out.add(action("Расположение окон",CivitasSettings.rememberWindows()?"запоминается":"стандартное при открытии",
                "ПЕРЕКЛ.",CivitasSettings::toggleRememberWindows));
        int bp = CivitasSettings.backdropPercent();
        out.add(vote("Прозрачность фона", bp + "%", "-", () -> CivitasSettings.setBackdropPercent(bp - 10),
                "+", () -> CivitasSettings.setBackdropPercent(bp + 10)));
        int sp = CivitasSettings.soundPercent();
        out.add(vote("Громкость звука", sp + "%", "-", () -> CivitasSettings.setSoundPercent(sp - 10),
                "+", () -> CivitasSettings.setSoundPercent(sp + 10)));
        out.add(action("Подписи кнопок", CivitasSettings.labelsAlways() ? "всегда видны" : "только при наведении",
                "ПЕРЕКЛ.", CivitasSettings::toggleLabelsAlways));
    }

    private void states(List<Entry> out) {
        out.add(action("Создать государство", "СОЗДАТЬ", () -> form("state")));
        out.add(danger("Удалить государство", "Требуется точное название", "УДАЛИТЬ",
                () -> openPicker(P_DELETE_STATE)));
        ListTag states = data.getList("states", Tag.TAG_COMPOUND);
        if (states.isEmpty()) out.add(text("Государств пока нет"));
        for (int i = 0; i < states.size(); i++) {
            CompoundTag s = states.getCompound(i);
            int index = i;
            String name = s.getString("name");
            out.add(action(name, s.getString("type") + "  ·  " + s.getString("ownerName")
                            + "  ·  " + s.getString("government"),
                    "ИНФО", () -> detailIndex = index));
        }
    }

    private void parliaments(List<Entry> out) {
        ListTag states = data.getList("states", Tag.TAG_COMPOUND);
        if (states.isEmpty()) out.add(text("Государств пока нет"));
        for (int i = 0; i < states.size(); i++) {
            CompoundTag s = states.getCompound(i);
            int index = i;
            int seats = CabinetPresets.seatsFor(s.getString("parliament"));
            out.add(action(s.getString("name"),
                    s.getString("parliament") + "  ·  " + s.getString("government")
                            + "  ·  мест " + seats,
                    "ИНФО", () -> detailIndex = index));
        }
    }

    private void watchdog(List<Entry> out) {
        if(!watchdogData.getBoolean("available")) {out.add(text("Watchdog", "Нет данных от сервера"));return;}
        var events=watchdogData.getList("events",Tag.TAG_COMPOUND);
        if(events.isEmpty())out.add(text("Событий пока нет", "Проверки обновляются автоматически"));
        for(int i=0;i<events.size();i++) {
            CompoundTag event=events.getCompound(i).copy();
            out.add(action(event.getString("name"),orDash(event.getString("time")),"ИНФО",()->openIncident(event)));
        }
    }

    private void players(List<Entry> out) {
        ListTag players = data.getList("allPlayers", Tag.TAG_COMPOUND);
        if (players.isEmpty()) out.add(text("Игроков нет"));
        for (int i = 0; i < players.size(); i++) {
            CompoundTag p = players.getCompound(i);
            String name = p.getString("name");
            int trust=p.contains("trust")?p.getInt("trust"):-1;
            String sub=trust<0?"Trust Rate: —":"Trust Rate: "+trust+" / 100";
            int index = i;
            if (p.getString("state").isEmpty()) {
                out.add(new Entry(name, sub, "ИНФО", () -> openPlayer(index), "СТРАНА",
                        () -> Minecraft.getInstance().setScreen(
                                new FormScreen(this, "state").withPrefill(2, name)), false));
            } else {
                out.add(action(name, sub, "ИНФО", () -> openPlayer(index)));
            }
        }
    }

    // ---------- small data helpers ----------

    private String value(int i) {
        String v = switch (i) {
            case 0 -> data.getBoolean("hasDeputy") ? data.getString("deputyName") : "";
            case 1 -> data.getString("ideology");
            case 2 -> data.getString("parliament");
            default -> data.getString("government");
        };
        if (!v.isEmpty()) return v;
        return i == 0 ? "не назначен" : "не задано";
    }

    private String heirText() {
        String name = data.getString("heirName");
        return name.isEmpty() ? "не назначен" : name;
    }

    private String writersText() {
        ListTag writers = data.getList("writers", Tag.TAG_COMPOUND);
        if (writers.isEmpty()) return "никто";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < writers.size(); i++) {
            if (i > 0) sb.append(", ");
            sb.append(writers.getCompound(i).getString("name"));
        }
        return sb.toString();
    }

    private String membersText() {
        ListTag members = data.getList("members", Tag.TAG_COMPOUND);
        if (members.isEmpty()) return "нет";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < members.size(); i++) {
            if (i > 0) sb.append(", ");
            sb.append(members.getCompound(i).getString("name"));
        }
        return sb.toString();
    }

    private String roleNameOf(String uuid) {
        ListTag entries = data.getList("memberRoles", Tag.TAG_COMPOUND);
        for (int i = 0; i < entries.size(); i++) {
            CompoundTag e = entries.getCompound(i);
            if (e.getString("uuid").equals(uuid)) {
                String role = e.getString("role");
                return role.isEmpty() ? "без роли" : role;
            }
        }
        return "без роли";
    }

    private static String day(long epochDay) {
        if (epochDay == Long.MIN_VALUE) return "—";
        return LocalDate.ofEpochDay(epochDay).format(DateTimeFormatter.ofPattern("dd.MM.yyyy"));
    }

    // ---------- pickers ----------

    private void openPicker(int mode) {
        pickerMode = mode;
        pickerScroll = 0;
        pickerRows.clear();

        switch (mode) {
            case P_DEPUTY -> {
                pickerRows.add(new String[]{"", "— без заместителя —"});
                ListTag players = data.getList("players", Tag.TAG_COMPOUND);
                for (int i = 0; i < players.size(); i++) {
                    CompoundTag e = players.getCompound(i);
                    pickerRows.add(new String[]{e.getString("uuid"), e.getString("name")});
                }
            }
            case P_IDEOLOGY -> {
                for (String o : CabinetPresets.IDEOLOGIES) {
                    pickerRows.add(new String[]{o, CabinetPresets.icon(o) + "  " + o});
                }
            }
            case P_PARLIAMENT -> {
                for (String o : CabinetPresets.PARLIAMENTS) {
                    pickerRows.add(new String[]{o, o});
                }
            }
            case P_GOVERNMENT -> {
                for (String o : CabinetPresets.governmentsFor(data.getString("ideology"))) {
                    pickerRows.add(new String[]{o, o});
                }
            }
            case P_MEMBER -> {
                Set<String> members = new HashSet<>();
                ListTag saved = data.getList("members", Tag.TAG_COMPOUND);
                for (int i = 0; i < saved.size(); i++) {
                    members.add(saved.getCompound(i).getString("uuid"));
                }
                ListTag players = data.getList("players", Tag.TAG_COMPOUND);
                for (int i = 0; i < players.size(); i++) {
                    CompoundTag e = players.getCompound(i);
                    String uuid = e.getString("uuid");
                    pickerRows.add(new String[]{uuid,
                            (members.contains(uuid) ? "− " : "+ ") + e.getString("name")});
                }
            }
            case P_WRITER -> {
                Set<String> writers = new HashSet<>();
                ListTag saved = data.getList("writers", Tag.TAG_COMPOUND);
                for (int i = 0; i < saved.size(); i++) {
                    writers.add(saved.getCompound(i).getString("uuid"));
                }
                ListTag members = data.getList("members", Tag.TAG_COMPOUND);
                for (int i = 0; i < members.size(); i++) {
                    CompoundTag e = members.getCompound(i);
                    String uuid = e.getString("uuid");
                    pickerRows.add(new String[]{uuid,
                            (writers.contains(uuid) ? "− " : "+ ") + e.getString("name")});
                }
            }
            case P_HEIR -> {
                pickerRows.add(new String[]{"", "— без наследника —"});
                ListTag members = data.getList("members", Tag.TAG_COMPOUND);
                for (int i = 0; i < members.size(); i++) {
                    CompoundTag e = members.getCompound(i);
                    pickerRows.add(new String[]{e.getString("uuid"), e.getString("name")});
                }
            }
            case P_ROLE_ASSIGN -> {
                ListTag members = data.getList("members", Tag.TAG_COMPOUND);
                for (int i = 0; i < members.size(); i++) {
                    CompoundTag e = members.getCompound(i);
                    String uuid = e.getString("uuid");
                    pickerRows.add(new String[]{uuid,
                            e.getString("name") + "  ·  " + roleNameOf(uuid)});
                }
            }
            case P_ROLE_MEMBER -> {
                pickerRows.add(new String[]{"", "— без роли —"});
                ListTag roles = data.getList("roles", Tag.TAG_COMPOUND);
                for (int i = 0; i < roles.size(); i++) {
                    CompoundTag r = roles.getCompound(i);
                    pickerRows.add(new String[]{r.getString("id"), r.getString("name")});
                }
                pickerRows.add(new String[]{"__kick__", "× Исключить из государства"});
            }
            case P_KICK -> pickerRows.add(new String[]{pickerTarget, "Да, исключить участника"});
            case P_ROLE_MANAGE -> {
                pickerRows.add(new String[]{"up|" + pickerTarget, "Поднять выше"});
                pickerRows.add(new String[]{"down|" + pickerTarget, "Опустить ниже"});
                pickerRows.add(new String[]{"delete|" + pickerTarget, "Удалить роль"});
                pickerRows.add(new String[]{"__rename__", "Переименовать"});
                pickerRows.add(new String[]{"__color__", "Цвет роли"});
                pickerRows.add(new String[]{"__perms__", "Права роли"});
            }
            case P_ROLE_COLOR -> {
                for (int i = 0; i < CabinetPresets.ROLE_COLORS.size(); i++) {
                    pickerRows.add(new String[]{
                            Integer.toString(CabinetPresets.ROLE_COLORS.get(i)),
                            CabinetPresets.ROLE_COLOR_NAMES[i]});
                }
            }
            case P_ROLE_PERMS -> {
                ListTag roles = data.getList("roles", Tag.TAG_COMPOUND);
                long perms = 0L;
                for (int i = 0; i < roles.size(); i++) {
                    if (roles.getCompound(i).getString("id").equals(pickerTarget)) {
                        perms = roles.getCompound(i).getLong("perms");
                    }
                }
                for (int bit = 0; bit < Perms.NAMES.length; bit++) {
                    boolean on = (perms & (1L << bit)) != 0;
                    pickerRows.add(new String[]{Integer.toString(bit),
                            (on ? "✔ " : "✖ ") + Perms.NAMES[bit]});
                }
            }
            case P_FACTION, P_REQUESTS -> {
                ListTag facs = data.getList("factions", Tag.TAG_COMPOUND);
                boolean inAny = false;
                for (int i = 0; i < facs.size(); i++) {
                    if (facs.getCompound(i).getBoolean("mine")) inAny = true;
                }
                for (int i = 0; i < facs.size(); i++) {
                    CompoundTag f = facs.getCompound(i);
                    if (!f.getString("id").equals(pickerTarget)) continue;
                    if (mode == P_FACTION) {
                        if (!inAny && !f.getBoolean("requested")) {
                            pickerRows.add(new String[]{"join|" + pickerTarget, "Подать заявку"});
                        }
                        if (f.getBoolean("mine")) {
                            pickerRows.add(new String[]{"leave", "Выйти из фракции"});
                        }
                        if (f.getBoolean("manage")) {
                            pickerRows.add(new String[]{"__requests__", "Заявки в фракцию"});
                            pickerRows.add(new String[]{"disband|" + pickerTarget, "Распустить фракцию"});
                        }
                    } else {
                        ListTag reqs = f.getList("reqs", Tag.TAG_COMPOUND);
                        for (int r = 0; r < reqs.size(); r++) {
                            CompoundTag q = reqs.getCompound(r);
                            pickerRows.add(new String[]{"accept|" + pickerTarget + "|" + q.getString("uuid"),
                                    "Принять: " + q.getString("name")});
                            pickerRows.add(new String[]{"decline|" + pickerTarget + "|" + q.getString("uuid"),
                                    "Отклонить: " + q.getString("name")});
                        }
                    }
                }
            }
            case P_FACTION_VOTE -> {
                ListTag facs = data.getList("factions", Tag.TAG_COMPOUND);
                for (int i = 0; i < facs.size(); i++) {
                    CompoundTag f = facs.getCompound(i);
                    pickerRows.add(new String[]{"pvote|" + f.getString("id"), f.getString("name")});
                }
            }
            case P_DELETE_STATE -> {
                ListTag states = data.getList("states", Tag.TAG_COMPOUND);
                for (int i = 0; i < states.size(); i++) {
                    CompoundTag s = states.getCompound(i);
                    pickerRows.add(new String[]{s.getString("name"),
                            s.getString("name") + "  ·  " + s.getString("ownerName")});
                }
            }
            case P_STATE_FOR -> {
                ListTag players = data.getList("allPlayers", Tag.TAG_COMPOUND);
                for (int i = 0; i < players.size(); i++) {
                    CompoundTag p = players.getCompound(i);
                    pickerRows.add(new String[]{p.getString("name"),
                            p.getString("name") + "  ·  "
                                    + (p.getString("state").isEmpty() ? "без государства" : p.getString("state"))});
                }
            }
            default -> {
            }
        }
        if (pickerRows.isEmpty()) {
            pickerRows.add(new String[]{"", "Нет доступных вариантов"});
        }
    }

    private void closePicker() {
        pickerMode = -1;
        pickerRows.clear();
        pickerTarget = "";
        pickerScroll = 0;
    }

    private void choose(String value) {
        int mode = pickerMode;
        String target = pickerTarget;
        switch (mode) {
            case P_DEPUTY -> apply("deputy", value);
            case P_IDEOLOGY -> apply("ideology", value);
            case P_PARLIAMENT -> apply("parliament", value);
            case P_GOVERNMENT -> apply("government", value);
            case P_MEMBER -> apply("member", value);
            case P_WRITER -> apply("writer", value);
            case P_HEIR -> apply("heir", value);
            case P_ROLE_ASSIGN -> {
                pickerTarget = value;
                openPicker(P_ROLE_MEMBER);
                return;
            }
            case P_ROLE_MEMBER -> {
                if (value.equals("__kick__")) {
                    openPicker(P_KICK);
                    return;
                }
                apply("assign", target + "|" + value);
            }
            case P_KICK -> {
                closePicker();
                askConfirm("ИСКЛЮЧИТЬ УЧАСТНИКА",
                        "Участник покинет государство и потеряет роль.",
                        () -> apply("kick", target));
                return;
            }
            case P_ROLE_MANAGE -> {
                if (value.equals("__rename__")) {
                    closePicker();
                    Minecraft.getInstance().setScreen(new FormScreen(this, "roleRename").withExtra(target));
                    return;
                }
                if (value.equals("__color__")) {
                    openPicker(P_ROLE_COLOR);
                    return;
                }
                if (value.equals("__perms__")) {
                    openPicker(P_ROLE_PERMS);
                    return;
                }
                if (value.startsWith("delete|")) {
                    String id = value.substring("delete|".length());
                    closePicker();
                    askConfirm("УДАЛИТЬ РОЛЬ", "Роль будет удалена у всех участников.",
                            () -> apply("role", "delete|" + id));
                    return;
                }
                apply("role", value);
            }
            case P_ROLE_COLOR -> apply("role", "color|" + target + "|" + value);
            case P_ROLE_PERMS -> apply("role", "perm|" + target + "|" + value);
            case P_FACTION -> {
                if (value.equals("__requests__")) {
                    openPicker(P_REQUESTS);
                    return;
                }
                if (value.startsWith("disband|")) {
                    String id = value.substring("disband|".length());
                    closePicker();
                    askConfirm("РАСПУСТИТЬ ФРАКЦИЮ", "Это действие необратимо.",
                            () -> apply("faction", "disband|" + id));
                    return;
                }
                apply("faction", value);
            }
            case P_REQUESTS, P_FACTION_VOTE -> apply("faction", value);
            case P_DELETE_STATE -> {
                closePicker();
                Minecraft.getInstance().setScreen(new FormScreen(this, "delete").withPrefill(0, value));
                return;
            }
            case P_STATE_FOR -> {
                closePicker();
                Minecraft.getInstance().setScreen(new FormScreen(this, "state").withPrefill(2, value));
                return;
            }
            default -> {
            }
        }
        closePicker();
    }

    private int pickerVisible() {
        int byHeight = Math.max(3, (height - 160) / PICKER_ROW);
        return Math.min(PICKER_VISIBLE, Math.min(pickerRows.size(), byHeight));
    }

    private int pickerW() {
        return Math.min(PICKER_W, width - 24);
    }

    private int pickerH() {
        return 44 + pickerVisible() * PICKER_ROW + 18;
    }

    private int pickerX() {
        return (width - pickerW()) / 2;
    }

    private int pickerY() {
        return (height - pickerH()) / 2;
    }

    private void drawPicker(GuiGraphics g, int mx, int my) {
        g.fill(0, 0, width, height, SCRIM);
        int x = pickerX();
        int y = pickerY();
        int w = pickerW();
        int h = pickerH();
        panel(g, x, y, w, h);

        g.fill(x + 2, y + 2, x + w - 2, y + 40, HEADER);
        g.fill(x + 2, y + 40, x + w - 2, y + 41, GOLD_DEEP);
        String title = pickerTitle(pickerMode);
        g.drawString(font, title, x + 14, y + 12, TEXT_LIGHT, true);

        int top = y + 46;
        int visible = pickerVisible();
        int maxScroll = Math.max(0, pickerRows.size() - visible);
        pickerScroll = (int) clamp(pickerScroll, 0, maxScroll);

        g.enableScissor(x + 8, top, x + w - 8, top + visible * PICKER_ROW);
        for (int r = 0; r < visible; r++) {
            int index = pickerScroll + r;
            String[] row = pickerRows.get(index);
            int ry = top + r * PICKER_ROW;
            boolean emptyAllowed = pickerMode == P_DEPUTY
                    || pickerMode == P_HEIR
                    || pickerMode == P_ROLE_MEMBER;
            if (!row[0].isEmpty() || emptyAllowed) {
                CivitasSounds.register(x + 6, ry, w - 12, PICKER_ROW - 2, CivitasUi.Style.CHOSEN);
            }
            boolean hot = inside(mx, my, x + 6, ry, w - 12, PICKER_ROW - 2);
            g.fill(x + 6, ry, x + w - 6, ry + PICKER_ROW - 2,
                    hot ? CivitasColors.mix(PLATE, GOLD, 0.22F) : CivitasColors.mix(PLATE_DEEP, TEXT_LIGHT, 0.08F));
            g.fill(x + 6, ry, x + 9, ry + PICKER_ROW - 2, hot ? GOLD : OLIVE);
            int tx = x + 18;
            if (pickerMode == P_ROLE_COLOR) {
                int colour = 0;
                try {
                    colour = Integer.parseInt(row[0]);
                } catch (NumberFormatException ignored) {
                }
                g.fill(tx, ry + 6, tx + 12, ry + 14, GOLD_DEEP);
                g.fill(tx + 1, ry + 7, tx + 11, ry + 13, colour);
                tx += 20;
            }
            g.drawString(font, font.plainSubstrByWidth(row[1], x + w - 22 - tx),
                    tx, ry + 7, hot ? GOLD : TEXT_LIGHT, false);
        }
        g.disableScissor();

        if (visible < pickerRows.size()) {
            int trackH = visible * PICKER_ROW;
            g.fill(x + w - 8, top, x + w - 5, top + trackH, CivitasColors.alpha(0x000000, 0x40));
            int thumbH = Math.max(18, trackH * visible / Math.max(1, pickerRows.size()));
            int thumbY = top + (int) ((trackH - thumbH) * ((double) pickerScroll / Math.max(1, maxScroll)));
            g.fill(x + w - 8, thumbY, x + w - 5, thumbY + thumbH, OLIVE);
        }
    }

    private String pickerTitle(int mode) {
        return switch (mode) {
            case P_DEPUTY -> "ВЫБЕРИТЕ ЗАМЕСТИТЕЛЯ";
            case P_IDEOLOGY -> "ВЫБЕРИТЕ ИДЕОЛОГИЮ";
            case P_PARLIAMENT -> "ВЫБЕРИТЕ ПАРЛАМЕНТ";
            case P_GOVERNMENT -> "ВЫБЕРИТЕ ФОРМУ ПРАВЛЕНИЯ";
            case P_MEMBER -> "СОСТАВ ГОСУДАРСТВА";
            case P_WRITER -> "ПИСАТЕЛИ НОВОСТЕЙ";
            case P_HEIR -> "НАСЛЕДНИК ПРЕСТОЛА";
            case P_ROLE_ASSIGN -> "КОМУ НАЗНАЧИТЬ РОЛЬ";
            case P_ROLE_MEMBER -> "ВЫБЕРИТЕ РОЛЬ";
            case P_KICK -> "ИСКЛЮЧИТЬ УЧАСТНИКА";
            case P_ROLE_MANAGE -> "УПРАВЛЕНИЕ РОЛЬЮ";
            case P_ROLE_COLOR -> "ЦВЕТ РОЛИ";
            case P_ROLE_PERMS -> "ПРАВА РОЛИ";
            case P_FACTION -> "ДЕЙСТВИЯ ФРАКЦИИ";
            case P_REQUESTS -> "ЗАЯВКИ ВО ФРАКЦИЮ";
            case P_FACTION_VOTE -> "ГОЛОС В ПАРЛАМЕНТ";
            case P_DELETE_STATE -> "УДАЛИТЬ ГОСУДАРСТВО";
            case P_STATE_FOR -> "СОЗДАТЬ СТРАНУ ДЛЯ ИГРОКА";
            default -> "ВЫБОР";
        };
    }

    // ---------- details and confirmation ----------

    private void closeDetail() {
        detailIndex = -1;
        detailPlayer = false;
        detailIncident = null;
        detailScroll = 0;
    }

    private void openIncident(CompoundTag incident) {
        detailPlayer=false;
        detailIncident=incident.copy();
        detailIndex=0;
        detailScroll=0;
    }

    private void openPlayer(int index) {
        detailIncident=null;
        detailPlayer = true;
        detailIndex = index;
        detailScroll = 0;
    }

    private void drawDetail(GuiGraphics g) {
        if(detailIncident!=null) {
            drawCard(g,"WATCHDOG",detailIncident.getString("name"),"◆",incidentLines(detailIncident));
            return;
        }
        if (detailPlayer) {
            ListTag players = data.getList("allPlayers", Tag.TAG_COMPOUND);
            if (detailIndex < 0 || detailIndex >= players.size()) {
                closeDetail();
                return;
            }
            CompoundTag p = players.getCompound(detailIndex);
            drawCard(g, "ИГРОК", p.getString("name"), "☺", playerLines(p));
            return;
        }
        ListTag states = data.getList("states", Tag.TAG_COMPOUND);
        if (detailIndex < 0 || detailIndex >= states.size()) {
            closeDetail();
            return;
        }
        CompoundTag s = states.getCompound(detailIndex);
        drawCard(g, "ГОСУДАРСТВО", s.getString("name"), "⚑", stateLines(s));
    }

    private static List<String[]> incidentLines(CompoundTag incident) {
        List<String[]> lines=new ArrayList<>();
        lines.add(new String[]{"ИГРОК",orDash(incident.getString("name"))});
        lines.add(new String[]{"ВРЕМЯ",orDash(incident.getString("time"))});
        lines.add(new String[]{"РЕШЕНИЕ",orDash(incident.getString("message"))});
        if(incident.contains("banDays") && incident.getInt("banDays")>0)
            lines.add(new String[]{"СРОК БАНА",incident.getInt("banDays")+" дн."});
        lines.add(new String[]{"ПРИЧИНА",incident.contains("reason")?orDash(incident.getString("reason")):"В старой записи подробности не сохранены"});
        if(incident.contains("trustChange")) {
            int delta=incident.getInt("trustChange");
            lines.add(new String[]{"ИЗМЕНЕНИЕ ТРАСТА",(delta>0?"+":"")+delta});
        } else lines.add(new String[]{"ИЗМЕНЕНИЕ ТРАСТА","Нет данных"});
        lines.add(new String[]{"TRUST RATE",incident.contains("trustScore")?incident.getInt("trustScore")+" / 100":"Нет данных"});
        return lines;
    }

    private static String orDash(String s) {
        return s == null || s.isEmpty() ? "—" : s;
    }

    private static String yesNo(boolean b) {
        return b ? "да" : "нет";
    }

    /** Everything the state record holds, in reading order. Admin-only data. */
    private static List<String[]> stateLines(CompoundTag s) {
        List<String[]> l = new ArrayList<>();
        l.add(new String[]{"НАЗВАНИЕ", s.getString("name")});
        l.add(new String[]{"ТИП", orDash(s.getString("type"))});
        l.add(new String[]{"ВЛАДЕЛЕЦ", orDash(s.getString("ownerName"))});
        l.add(new String[]{"ГЛАВА", orDash(s.getString("leader"))});
        l.add(new String[]{"ЗАМЕСТИТЕЛЬ", orDash(s.getString("deputyName"))});
        l.add(new String[]{"НАСЛЕДНИК", orDash(s.getString("heir"))});
        l.add(new String[]{"ИДЕОЛОГИЯ", CabinetPresets.icon(s.getString("ideology")) + "  "
                + orDash(s.getString("ideology"))});
        l.add(new String[]{"ПАРЛАМЕНТ", orDash(s.getString("parliament")) + "  ·  мест " + s.getInt("seats")});
        l.add(new String[]{"ФОРМА ПРАВЛЕНИЯ", orDash(s.getString("government"))});
        l.add(new String[]{"ЧЛЕНЫ (" + s.getInt("memberCount") + ")", orDash(s.getString("members"))});
        l.add(new String[]{"ПИСАТЕЛИ НОВОСТЕЙ", orDash(s.getString("writers"))});
        l.add(new String[]{"РОЛИ", orDash(s.getString("roles"))});
        l.add(new String[]{"ФРАКЦИИ", orDash(s.getString("factions"))});
        l.add(new String[]{"КАНДИДАТОВ", String.valueOf(s.getInt("candidates"))});
        l.add(new String[]{"ВЫБОРЫ ДО", s.getLong("electionEnd") == Long.MIN_VALUE
                ? "—" : day(s.getLong("electionEnd"))});
        l.add(new String[]{"СРОК ВЛАСТИ ДО", s.getLong("termEnd") == Long.MIN_VALUE
                ? "бессрочно" : day(s.getLong("termEnd"))});
        l.add(new String[]{"ЗАКОНОПРОЕКТОВ", String.valueOf(s.getInt("bills"))});
        l.add(new String[]{"НОВОСТЕЙ", String.valueOf(s.getInt("news"))});
        return l;
    }

    /** Everything the admin sees about one online player. */
    private static List<String[]> playerLines(CompoundTag p) {
        List<String[]> l = new ArrayList<>();
        l.add(new String[]{"НИК", p.getString("name")});
        l.add(new String[]{"UUID", p.getString("uuid")});
        l.add(new String[]{"СТАТУС", orDash(p.getString("status"))});
        l.add(new String[]{"ГОСУДАРСТВО", orDash(p.getString("state"))});
        l.add(new String[]{"ТИП СТРАНЫ", orDash(p.getString("stateType"))});
        l.add(new String[]{"РОЛЬ", orDash(p.getString("role"))});
        l.add(new String[]{"ФРАКЦИЯ", orDash(p.getString("faction"))});
        l.add(new String[]{"ПИСАТЕЛЬ НОВОСТЕЙ", yesNo(p.getBoolean("writer"))});
        l.add(new String[]{"КАНДИДАТ", yesNo(p.getBoolean("candidate"))});
        l.add(new String[]{"ОПЕРАТОР (OP)", yesNo(p.getBoolean("op"))});
        l.add(new String[]{"РЕЖИМ ИГРЫ", orDash(p.getString("gameMode"))});
        l.add(new String[]{"ЗДОРОВЬЕ", p.getInt("health") + " / 20"});
        l.add(new String[]{"ГОЛОД", p.getInt("food") + " / 20"});
        l.add(new String[]{"УРОВЕНЬ ОПЫТА", String.valueOf(p.getInt("xp"))});
        int trust=p.contains("trust")?p.getInt("trust"):-1;
        l.add(new String[]{"ДОВЕРИЕ", trust<0?"—":trust+" / 100"});
        return l;
    }

    /**
     * A scrollable card: header with icon and title, then label/value rows. Long values wrap, and the
     * body scrolls with the mouse wheel when the card is taller than the screen.
     */
    private void drawCard(GuiGraphics g, String kind, String title, String icon, List<String[]> lines) {
        g.fill(0, 0, width, height, SCRIM);
        int w = Math.min(460, width - 20);
        int valueW = w - 150;
        int headH = 46;
        int footH = 18;
        int maxH = height - 20;

        List<List<FormattedCharSequence>> wrapped = new ArrayList<>();
        int rowsH = 0;
        for (String[] row : lines) {
            List<FormattedCharSequence> vl = font.split(Component.literal(row[1]), valueW);
            wrapped.add(vl);
            rowsH += Math.max(1, vl.size()) * 10 + 6;
        }
        int vh = Math.min(rowsH, Math.max(40, maxH - headH - footH));
        int h = headH + vh + footH;
        int x = (width - w) / 2;
        int y = (height - h) / 2;
        panel(g, x, y, w, h);
        g.fill(x + 2, y + 2, x + w - 2, y + 38, HEADER);
        g.fill(x + 2, y + 38, x + w - 2, y + 39, GOLD_DEEP);
        drawSmallMedallion(g, x + 22, y + 20, icon);
        g.drawString(font, kind, x + 40, y + 10, TEXT_LIGHT, true);
        g.drawString(font, font.plainSubstrByWidth(title, w - 60), x + 40, y + 23, GOLD, false);

        int vy = y + headH;
        double maxScroll = Math.max(0, rowsH - vh);
        detailScroll = (int) clamp(detailScroll, 0, maxScroll);
        g.enableScissor(x + 4, vy, x + w - 4, vy + vh);
        int ly = vy + 4 - detailScroll;
        for (int i = 0; i < lines.size(); i++) {
            List<FormattedCharSequence> vl = wrapped.get(i);
            g.drawString(font, font.plainSubstrByWidth(lines.get(i)[0], 124), x + 14, ly, OLIVE, false);
            int vyy = ly;
            for (FormattedCharSequence line : vl) {
                g.drawString(font, line, x + 140, vyy, TEXT_LIGHT, false);
                vyy += 10;
            }
            if(lines.get(i)[0].equals("ДОВЕРИЕ") && !lines.get(i)[1].equals("—"))try {
                int trust=Integer.parseInt(lines.get(i)[1].split(" ")[0]);int bx=x+140, bw=Math.min(130,valueW);
                g.fill(bx,ly+10,bx+bw,ly+13,0xFF17191C);
                g.fill(bx,ly+10,bx+bw*Math.max(0,Math.min(100,trust))/100,ly+13,trust>=60?0xFF8FA95D:trust>=30?0xFFD3A651:0xFFCC655A);
            } catch(NumberFormatException ignored) {}
            ly += Math.max(1, vl.size()) * 10 + 6;
        }
        g.disableScissor();

        if (maxScroll > 0) {
            int trackX = x + w - 9;
            int thumbH = Math.max(18, vh * vh / rowsH);
            int thumbY = vy + (int) ((vh - thumbH) * (detailScroll / maxScroll));
            g.fill(trackX, vy, trackX + 3, vy + vh, CivitasColors.alpha(0x000000, 0x40));
            g.fill(trackX, thumbY, trackX + 3, thumbY + thumbH, GOLD);
        }
        g.drawString(font, "Esc или клик — закрыть  ·  колесо — прокрутка", x + 14, y + h - 12, MUTED, false);
    }

    private void askConfirm(String title, String text, Runnable action) {
        confirmOpen = true;
        confirmTitle = title;
        confirmText = text;
        confirmAction = action;
    }

    private void drawConfirm(GuiGraphics g, int mx, int my) {
        g.fill(0, 0, width, height, SCRIM);
        int w = Math.min(380, width - 20);
        int h = 160;
        int x = (width - w) / 2;
        int y = (height - h) / 2;
        panel(g, x, y, w, h);
        g.fill(x + 2, y + 2, x + w - 2, y + 40, HEADER);
        g.fill(x + 2, y + 40, x + w - 2, y + 41, GOLD_DEEP);
        g.drawString(font, confirmTitle, x + 14, y + 12, TEXT_LIGHT, true);
        g.drawString(font, font.plainSubstrByWidth(confirmText, w - 28), x + 14, y + 50, TEXT_LIGHT, false);
        g.drawString(font, "Это действие нельзя отменить.", x + 14, y + 66, MUTED, false);

        int by = y + h - 38;
        boolean cancel = inside(mx, my, x + 10, by, 140, 24);
        boolean ok = inside(mx, my, x + w - 150, by, 140, 24);
        button(g, font, x + 10, by, 140, 24, "ОТМЕНА", cancel, Style.SECONDARY);
        button(g, font, x + w - 150, by, 140, 24, "ПОДТВЕРДИТЬ", ok, Style.DANGER);
    }

    // ---------- windows state ----------

    private boolean isOpen(String key) {
        for (Win w : windows) {
            if (w.key.equals(key)) return true;
        }
        return false;
    }

    private boolean alert(String key) {
        return (key.equals("news") && CivitasFeed.newsUnread())
                || (key.equals("laws") && CivitasFeed.lawsUnread());
    }

    /** Right edge of the collapsed left column. Labels are hidden while windows are open. */
    private int dialZoneLeft() {
        return SIDE + BTN / 2 + 12;
    }

    /** Width taken by the collapsed right column. Labels are hidden while windows are open. */
    private int dialZoneRight() {
        return adminWheel() ? SIDE + BTN / 2 + 12 : 0;
    }

    /**
     * Keeps a window between the two dials, so its contents never cover the medallions or labels.
     * On a screen too narrow for that band the window falls back to the whole width.
     */
    private int clampWinX(int x) {
        int lo = dialZoneLeft();
        int hi = width - winW() - dialZoneRight();
        if (hi < lo) {
            lo = 0;
            hi = width - winW();
        }
        return (int) clamp(x, lo, Math.max(lo, hi));
    }

    private void openWindow(String key) {
        for (Win w : windows) {
            if (w.key.equals(key)) {
                bringToFront(w);
                return;
            }
        }
        String[] item = item(key);
        if (item == null) return;
        loadPositions();

        int offset = windows.size() % 5;
        int wh = winH(key);
        int x = (width - winW()) / 2 + offset * 16 - 32;
        int y = (height - wh) / 2 + offset * 16 - 32;
        if (CivitasSettings.rememberWindows() && POS.containsKey(key + ".x")) {
            try {
                x = Integer.parseInt(POS.getProperty(key + ".x"));
                y = Integer.parseInt(POS.getProperty(key + ".y"));
            } catch (NumberFormatException ignored) {
                // fall back to the default cascade
            }
        }
        x = clampWinX(x);
        y = (int) clamp(y, 0, Math.max(0, height - wh));
        windows.add(new Win(key, item[1], item[2], x, y));
        markSeen(key);
    }

    private void markSeen(String key) {
        if (key.equals("news")) CivitasFeed.markNewsSeen();
        if (key.equals("laws")) CivitasFeed.markLawsSeen();
    }

    private static String[] item(String key) {
        for (String[] row : PLAYER_ITEMS) {
            if (row[0].equals(key)) return row;
        }
        for (String[] row : ADMIN_ITEMS) {
            if (row[0].equals(key)) return row;
        }
        return null;
    }

    private void bringToFront(Win w) {
        windows.remove(w);
        windows.add(w);
    }

    private static Path positionFile() {
        return Minecraft.getInstance().gameDirectory.toPath().resolve("config").resolve("civitas-windows.properties");
    }

    private static void loadPositions() {
        if (posLoaded) return;
        posLoaded = true;
        Path path = positionFile();
        if (!Files.isRegularFile(path)) return;
        try (InputStream in = Files.newInputStream(path)) {
            POS.load(in);
        } catch (IOException e) {
            // start with the default positions
        }
    }

    private static void savePosition(Win w) {
        if(!CivitasSettings.rememberWindows())return;
        POS.setProperty(w.key + ".x", Integer.toString(w.x));
        POS.setProperty(w.key + ".y", Integer.toString(w.y));
        Path path = positionFile();
        try {
            Files.createDirectories(path.getParent());
            try (OutputStream out = Files.newOutputStream(path)) {
                POS.store(out, "Civitas: remembered window positions");
            }
        } catch (IOException e) {
            // not critical: the window goes back to its default place
        }
    }

    // ---------- input ----------

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (button != 0) return false;

        if (confirmOpen) {
            int w = Math.min(380, width - 20);
            int h = 160;
            int x = (width - w) / 2;
            int y = (height - h) / 2;
            int by = y + h - 38;
            if (inside(mx, my, x + w - 150, by, 140, 24)) {
                Runnable action = confirmAction;
                confirmOpen = false;
                confirmAction = null;
                if (action != null) action.run();
            } else {
                confirmOpen = false;
                confirmAction = null;
            }
            return true;
        }

        if (pickerMode >= 0) {
            clickPicker(mx, my);
            return true;
        }

        if (detailIndex >= 0) {
            closeDetail();
            return true;
        }

        String dialKey = dialKeyAt(mx, my);
        if (dialKey != null) {
            openWindow(dialKey);
            return true;
        }
        for (int i = windows.size() - 1; i >= 0; i--) {
            Win w = windows.get(i);
            if (!inside(mx, my, w.x, w.y, winW(), winH(w.key))) continue;
            bringToFront(w);
            if (inside(mx, my, closeX(w), closeY(w), 20, 20)) {
                windows.remove(w);
                return true;
            }
            if (inside(mx, my, w.x, w.y, winW(), HEAD)) {
                w.dragging = true;
                w.grabX = (int) mx - w.x;
                w.grabY = (int) my - w.y;
                return true;
            }
            List<Entry> entries = entries(w.key);
            int top = w.y + HEAD + 6;
            int vh = viewH(w);
            for (int k = 0; k < entries.size(); k++) {
                Entry e = entries.get(k);
                int ey = top + k * ENTRY - (int) w.scroll;
                if (ey + ENTRY - 2 <= top || ey >= top + vh) continue;
                int[] bx = buttonX(w, e);
                if (e.btnA() != null && inside(mx, my, bx[0], ey + 5, SMALL_W, SMALL_H)) {
                    e.actA().run();
                    return true;
                }
                if (e.btnB() != null && inside(mx, my, bx[1], ey + 5, SMALL_W, SMALL_H)) {
                    e.actB().run();
                    return true;
                }
            }
            return true; // click on the window body does not fall through to the wheel
        }

        for (int side = 0; side < (adminWheel() ? 2 : 1); side++) {
            String[][] items = side == 0 ? PLAYER_ITEMS : ADMIN_ITEMS;
            for (int i = 0; i < items.length; i++) {
                double[] c = center(side, i, items.length);
                if (edgeFade(itemAngle(side, i, items.length), items.length) <= 0.30F) continue;
                int cx = (int) Math.round(c[0]);
                int cy = (int) Math.round(c[1]);
                int bx = cx - BTN / 2;
                int by = cy - BTN / 2;
                int[] lr = labelRect(side, cx, cy, items[i][1]);
                if (inside(mx, my, bx, by, BTN, BTN) || (windows.isEmpty() && inside(mx, my, lr[0], lr[1], lr[2], lr[3]))) {
                    openWindow(items[i][0]);
                    return true;
                }
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    /** The dial medallion or label under the cursor, if any. Dial items take priority over windows. */
    private String dialKeyAt(double mx, double my) {
        for (int side = 0; side < (adminWheel() ? 2 : 1); side++) {
            String[][] items = side == 0 ? PLAYER_ITEMS : ADMIN_ITEMS;
            for (int i = 0; i < items.length; i++) {
                double[] c = center(side, i, items.length);
                if (edgeFade(itemAngle(side, i, items.length), items.length) <= 0.30F) continue;
                int cx = (int) Math.round(c[0]);
                int cy = (int) Math.round(c[1]);
                int[] lr = labelRect(side, cx, cy, items[i][1]);
                if (inside(mx, my, cx - BTN / 2, cy - BTN / 2, BTN, BTN)
                        || (windows.isEmpty() && inside(mx, my, lr[0], lr[1], lr[2], lr[3]))) {
                    return items[i][0];
                }
            }
        }
        return null;
    }

    private void clickPicker(double mx, double my) {
        int x = pickerX();
        int y = pickerY();
        int w = pickerW();
        int top = y + 46;
        int visible = pickerVisible();
        for (int r = 0; r < visible; r++) {
            int ry = top + r * PICKER_ROW;
            if (inside(mx, my, x + 6, ry, w - 12, PICKER_ROW - 2)) {
                String value = pickerRows.get(pickerScroll + r)[0];
                boolean emptyAllowed = pickerMode == P_DEPUTY
                        || pickerMode == P_HEIR
                        || pickerMode == P_ROLE_MEMBER;
                if (!value.isEmpty() || emptyAllowed) {
                    choose(value);
                }
                return;
            }
        }
        if (!inside(mx, my, x, y, w, pickerH())) {
            closePicker();
        }
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        for (Win w : windows) {
            if (w.dragging) {
                w.x = clampWinX((int) (mx - w.grabX));
                w.y = (int) clamp(my - w.grabY, 0, Math.max(0, height - winH(w.key)));
                return true;
            }
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        for (Win w : windows) {
            if (w.dragging) {
                w.dragging = false;
                savePosition(w);
            }
        }
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double scrollX, double scrollY) {
        if (confirmOpen) return true;
        if (pickerMode >= 0) {
            int visible = pickerVisible();
            int max = Math.max(0, pickerRows.size() - visible);
            pickerScroll = (int) clamp(pickerScroll - Math.signum(scrollY), 0, max);
            return true;
        }
        if (detailIndex >= 0) {
            detailScroll -= (int) (scrollY * 14);
            return true;
        }
        for (int i = windows.size() - 1; i >= 0; i--) {
            Win w = windows.get(i);
            if (inside(mx, my, w.x, w.y, winW(), winH(w.key))) {
                w.scroll -= scrollY * ENTRY;
                return true;
            }
        }

        // Scroll over the dial spins it. The item under the cursor decides which half turns; over
        // the central seal both halves turn together, like one wheel.
        double delta = Math.abs(scrollY) > 1.0E-4 ? scrollY : -scrollX;
        if (Math.abs(delta) < 1.0E-4) return true;
        double turn = -delta * 0.2;
        boolean middle = Math.abs(mx - width / 2.0) < width * 0.16;
        if (adminWheel() && !middle && mx > width / 2.0) {
            spinRight += turn * 1.15;
        } else if (adminWheel() && middle) {
            spinLeft += turn * 0.7;
            spinRight += turn * 0.7;
        } else {
            spinLeft += turn;
        }
        return true;
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        boolean openKey = key != GLFW.GLFW_KEY_UNKNOWN && CabinetKeys.OPEN.matches(key, scan);
        boolean overlay = confirmOpen || pickerMode >= 0 || detailIndex >= 0;
        if (!overlay && key != GLFW.GLFW_KEY_UNKNOWN) {
            if (key == GLFW.GLFW_KEY_LEFT || key == GLFW.GLFW_KEY_A) {
                focusSide = 0;
                return true;
            }
            if ((key == GLFW.GLFW_KEY_RIGHT || key == GLFW.GLFW_KEY_D) && adminWheel()) {
                focusSide = 1;
                return true;
            }
            boolean up = key == GLFW.GLFW_KEY_UP || key == GLFW.GLFW_KEY_W;
            boolean down = key == GLFW.GLFW_KEY_DOWN || key == GLFW.GLFW_KEY_S;
            if (up || down) {
                int count = focusSide == 0 ? PLAYER_ITEMS.length : ADMIN_ITEMS.length;
                double dir = up ? -1 : 1;
                if (focusSide == 0) {
                    spinLeft += dir * step(count);
                } else {
                    spinRight += dir * step(count);
                }
                return true;
            }
        }
        if (key == GLFW.GLFW_KEY_ESCAPE || openKey) {
            if (confirmOpen) {
                confirmOpen = false;
                confirmAction = null;
            } else if (pickerMode >= 0) {
                closePicker();
            } else if (detailIndex >= 0) {
                closeDetail();
            } else if (!windows.isEmpty()) {
                Win w = windows.remove(windows.size() - 1);
                savePosition(w);
            } else {
                onClose();
            }
            return true;
        }
        return super.keyPressed(key, scan, mods);
    }

    @Override
    public void onClose() {
        latest = null;
        Minecraft.getInstance().setScreen(parent);
    }

    // ---------- actions ----------

    private void form(String kind) {
        Minecraft.getInstance().setScreen(new FormScreen(this, kind));
    }

    private static void apply(String field, String value) {
        PacketDistributor.sendToServer(new CabinetNet.EditCabinet(field, value));
    }

    private static double clamp(double value, double lo, double hi) {
        return Math.max(lo, Math.min(hi, value));
    }
}
