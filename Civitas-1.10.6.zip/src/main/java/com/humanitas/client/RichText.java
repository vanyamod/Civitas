package com.humanitas.client;

import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;
import net.minecraft.network.chat.ClickEvent;

import java.util.regex.Pattern;

/**
 * News markup: Discord-style markdown plus the explicit tags the editor has always used.
 *
 *   Inline markdown:  **bold**  *italic*  __underline__  ~~strike~~  ||spoiler||  `code`  [text](link)
 *   Block markdown:   # heading  ## heading  ### heading  &gt; quote  - item  ```code block```
 *   Explicit tags:    [b] [i] [u] [s] [ob] [code] ... [/..]    [c:gold] ... [/c]
 *
 * Markdown is turned into tags first, then the tags are parsed, so both syntaxes share one renderer.
 * Anything that is not a known tag or marker stays as plain text, so typing cannot break the renderer.
 */
public final class RichText {
    private RichText() {}

    /** Colour names offered in the editor and their RGB values. Chosen to stay readable on cream paper. */
    public static final String[] COLOR_NAMES = {"ink", "olive", "gold", "red", "blue", "gray", "dark"};
    public static final int[] COLOR_VALUES = {0x2A2619, 0x5C6B3A, 0x8F7330, 0x8E3B2F, 0x2F4F7F, 0x6E6447, 0x1E1F22};

    /** Inline code is shown in a warm brown, distinct from the link olive. */
    public static final int CODE_COLOR = 0x6B3F2A;

    private static final Pattern TAGS = Pattern.compile("\\[(/?(?:b|i|u|s|ob|code)|c:[a-z]+|/c)]");
    private static final Pattern MARKERS = Pattern.compile("\\*\\*|__|~~|\\|\\||`");

    private static final Pattern LINK = Pattern.compile("\\[([^\\]\\n]+)]\\(([^)\\s]+)\\)");
    private static final Pattern SPOILER = Pattern.compile("\\|\\|(.+?)\\|\\|");
    private static final Pattern BOLD = Pattern.compile("\\*\\*(.+?)\\*\\*");
    private static final Pattern BOLD_ITALIC = Pattern.compile("\\*\\*\\*(.+?)\\*\\*\\*");
    private static final Pattern UNDERLINE = Pattern.compile("__(.+?)__");
    private static final Pattern STRIKE = Pattern.compile("~~(.+?)~~");
    private static final Pattern ITALIC_STAR = Pattern.compile("(?<!\\*)\\*(?!\\s)(.+?)(?<!\\s)\\*(?!\\*)");
    private static final Pattern ITALIC_UNDER = Pattern.compile("(?<![\\p{L}\\p{N}_])_(?!\\s)(.+?)(?<!\\s)_(?![\\p{L}\\p{N}_])");

    private static final class State {
        boolean bold;
        boolean italic;
        boolean underline;
        boolean strike;
        boolean obfuscated;
        boolean code;
        boolean forceBold;
        boolean forceItalic;
        int color = -1;
        String link;
        final java.util.Deque<Integer> colors = new java.util.ArrayDeque<>();
    }

    public static int colorOf(String name) {
        for (int i = 0; i < COLOR_NAMES.length; i++) {
            if (COLOR_NAMES[i].equals(name)) {
                return COLOR_VALUES[i];
            }
        }
        return -1;
    }

    /** Text without tags or markdown markers, for short previews such as the news list. */
    public static String plain(String src) {
        String s = LINK.matcher(src).replaceAll("$1");
        s = s.replaceAll("\\[img:[^\\]]+]", " ").replaceAll("(?m)^\\s*(?:#{1,3} |[>\\-*] )", "");
        s = TAGS.matcher(s).replaceAll("");
        return MARKERS.matcher(s).replaceAll("").replaceAll("(?<!\\*)\\*(?!\\*)", "");
    }

    /**
     * Turns the inline markdown of one line into explicit tags. Inline code is cut out first, so
     * formatting characters inside backticks are shown literally. An unpaired backtick stays as typed.
     */
    public static String inline(String line) {
        String[] parts = line.split("`", -1);
        int backticks = parts.length - 1;
        if (backticks == 0 || backticks % 2 == 1) {
            return formatOutsideCode(line);
        }
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < parts.length; i++) {
            if (i % 2 == 1) {
                out.append("[code]").append(parts[i]).append("[/code]");
            } else {
                out.append(formatOutsideCode(parts[i]));
            }
        }
        return out.toString();
    }

    private static String formatOutsideCode(String s) {
        java.util.regex.Matcher links = LINK.matcher(s);
        StringBuilder out = new StringBuilder();
        java.util.List<String> protectedLinks = new java.util.ArrayList<>();
        int last = 0;
        while (links.find()) {
            out.append(s, last, links.start());
            if (NewsFormatting.validUrl(links.group(2))) {
                out.append('\0').append(protectedLinks.size()).append('\0');
                protectedLinks.add("[link:" + links.group(2) + "]" + formatStyles(links.group(1)) + "[/link]");
            } else out.append(links.group());
            last = links.end();
        }
        String formatted = formatStyles(out.append(s.substring(last)).toString());
        for (int i = 0; i < protectedLinks.size(); i++) formatted = formatted.replace("\0" + i + "\0", protectedLinks.get(i));
        return formatted;
    }

    private static String formatStyles(String s) {
        s = SPOILER.matcher(s).replaceAll("$1");
        s = BOLD_ITALIC.matcher(s).replaceAll("[b][i]$1[/i][/b]");
        s = BOLD.matcher(s).replaceAll("[b]$1[/b]");
        s = UNDERLINE.matcher(s).replaceAll("[u]$1[/u]");
        s = STRIKE.matcher(s).replaceAll("[s]$1[/s]");
        s = ITALIC_STAR.matcher(s).replaceAll("[i]$1[/i]");
        s = ITALIC_UNDER.matcher(s).replaceAll("[i]$1[/i]");
        return s;
    }

    public static MutableComponent parse(String src) {
        return parse(src, false, false);
    }

    /** Parses tags. forceBold and forceItalic make a heading or a quote bold or italic from the start. */
    public static MutableComponent parse(String src, boolean forceBold, boolean forceItalic) {
        MutableComponent out = Component.empty();
        State st = new State();
        st.forceBold = forceBold;
        st.forceItalic = forceItalic;
        StringBuilder buf = new StringBuilder();
        int n = src.length();
        int pos = 0;
        while (pos < n) {
            char c = src.charAt(pos);
            if (c == '[') {
                int end = src.indexOf(']', pos);
                if (end > pos && end - pos <= 1024) {
                    String tag = src.substring(pos + 1, end);
                    if (isKnown(tag) && (!st.code || tag.equals("/code"))) {
                        flush(out, buf, st);
                        apply(tag, st);
                        pos = end + 1;
                        continue;
                    }
                }
            }
            buf.append(c);
            pos++;
        }
        flush(out, buf, st);
        return out;
    }

    private static boolean isKnown(String tag) {
        return switch (tag) {
            case "b", "i", "u", "s", "ob", "code", "/b", "/i", "/u", "/s", "/ob", "/code", "/c", "/link" -> true;
            default -> tag.startsWith("c:") && colorOf(tag.substring(2)) >= 0
                    || tag.startsWith("link:") && NewsFormatting.validUrl(tag.substring(5));
        };
    }

    private static void apply(String tag, State st) {
        switch (tag) {
            case "b" -> st.bold = true;
            case "/b" -> st.bold = false;
            case "i" -> st.italic = true;
            case "/i" -> st.italic = false;
            case "u" -> st.underline = true;
            case "/u" -> st.underline = false;
            case "s" -> st.strike = true;
            case "/s" -> st.strike = false;
            case "ob" -> st.obfuscated = true;
            case "/ob" -> st.obfuscated = false;
            case "code" -> st.code = true;
            case "/code" -> st.code = false;
            case "/c" -> st.color = st.colors.isEmpty() ? -1 : st.colors.pop();
            case "/link" -> st.link = null;
            default -> {
                if (tag.startsWith("link:")) st.link = tag.substring(5);
                else { st.colors.push(st.color); st.color = colorOf(tag.substring(2)); }
            }
        }
    }

    private static void flush(MutableComponent out, StringBuilder buf, State st) {
        if (buf.length() == 0) {
            return;
        }
        Style style = Style.EMPTY
                .withBold(st.bold || st.forceBold)
                .withItalic(st.italic || st.forceItalic)
                .withUnderlined(st.underline)
                .withStrikethrough(st.strike)
                .withObfuscated(st.obfuscated);
        if (st.code) {
            style = style.withColor(CODE_COLOR);
        } else if (st.color >= 0) {
            style = style.withColor(st.color);
        }
        if (st.link != null) {
            style = style.withColor(COLOR_VALUES[4]).withUnderlined(true)
                    .withClickEvent(new ClickEvent(ClickEvent.Action.OPEN_URL, st.link));
        }
        out.append(Component.literal(buf.toString()).withStyle(style));
        buf.setLength(0);
    }
}
