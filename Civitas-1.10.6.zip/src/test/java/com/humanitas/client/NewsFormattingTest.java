package com.humanitas.client;

/** Regression cases for editor transactions; no game window or network required. */
public final class NewsFormattingTest {
    private static int checks;
    private static void eq(Object expected, Object actual) {
        checks++;
        if (!expected.equals(actual)) throw new AssertionError("Expected <" + expected + ">, got <" + actual + ">");
    }
    public static void main(String[] args) throws Exception {
        var bold = NewsFormatting.inline("Новость", 7, 0, "**", "**");
        eq("**Новость**", bold.text());
        eq("Новость", NewsFormatting.inline(bold.text(), bold.cursor(), bold.anchor(), "**", "**").text());
        var both = NewsFormatting.inline(bold.text(), bold.cursor(), bold.anchor(), "*", "*");
        eq("***Новость***", both.text());
        eq("**Новость**", NewsFormatting.inline(both.text(), both.cursor(), both.anchor(), "*", "*").text());
        eq("Срочная **новость**!", NewsFormatting.inline("Срочная новость!", 10, 10, "**", "**").text());
        eq("**текст**", NewsFormatting.inline("", 0, 0, "**", "**").text());
        var multiline = NewsFormatting.inline("один\n\nдва", 9, 0, "**", "**");
        eq("**один**\n\n**два**", multiline.text());
        eq("один\n\nдва", NewsFormatting.inline(multiline.text(), multiline.cursor(), multiline.anchor(), "**", "**").text());
        eq("Новость", NewsFormatting.inline("**Новость**", 11, 0, "**", "**").text());
        var heading = NewsFormatting.block("первый\nвторой\nтретий", 13, 0, "# ");
        eq("# первый\n# второй\nтретий", heading.text());
        eq("## первый\n## второй\nтретий", NewsFormatting.block(heading.text(), heading.cursor(), heading.anchor(), "## ").text());
        eq("первый\nвторой\nтретий", NewsFormatting.block(heading.text(), heading.cursor(), heading.anchor(), "# ").text());
        eq("# текст", NewsFormatting.block("- > ## текст", 12, 12, "# ").text());
        eq("# ", NewsFormatting.block("", 0, 0, "# ").text());
        eq("# один\nдва", NewsFormatting.block("один\nдва", 5, 0, "# ").text());
        eq("# один\n# два", NewsFormatting.block("один\nдва", 0, 8, "# ").text());
        eq("строка", NewsFormatting.block("> строка", 3, 3, "").text());
        eq(true, NewsFormatting.validUrl("https://example.com/a_b?q=one"));
        eq(true, NewsFormatting.validUrl("http://example.com"));
        eq(false, NewsFormatting.validUrl("javascript:alert(1)"));
        eq(false, NewsFormatting.validUrl("file:///C:/secret"));
        eq(false, NewsFormatting.validUrl("https://"));
        eq(false, NewsFormatting.validUrl("https://example.com/a b"));
        eq(false, NewsFormatting.validUrl("https://user:pass@example.com"));
        eq("[b][i]Текст[/i][/b]", RichText.inline("***Текст***"));
        eq("[code][b]буквально[/b][/code]", RichText.inline("`[b]буквально[/b]`"));
        eq("[link:https://example.com/a_b_c]Источник[/link]", RichText.inline("[Источник](https://example.com/a_b_c)"));
        eq("Заголовок\nПункт\nссылка", RichText.plain("## Заголовок\n- **Пункт**\n[ссылка](https://example.com)"));
        eq("не закрыт `", RichText.inline("не закрыт `"));
        eq("[b]Вот [link:https://example.com/a_b_c]ссылка[/link][/b]", RichText.inline("**Вот [ссылка](https://example.com/a_b_c)**"));
        eq("[b]буквально[/b]", RichText.parse(RichText.inline("`[b]буквально[/b]`")).getString());
        var styled = RichText.parse(RichText.inline("***Текст***")).getSiblings().getFirst().getStyle();
        eq(true, styled.isBold()); eq(true, styled.isItalic());
        var link = RichText.parse(RichText.inline("[ссылка](https://example.com/a_b_c)")).getSiblings().getFirst().getStyle();
        eq("https://example.com/a_b_c", link.getClickEvent().getValue());
        eq(true, link.isUnderlined());
        var color = RichText.parse("[c:red]A[c:blue]B[/c]C[/c]");
        eq(RichText.COLOR_VALUES[3], color.getSiblings().get(2).getStyle().getColor().getValue());
        java.nio.file.Path temp = java.nio.file.Files.createTempDirectory("civitas-news-test-");
        try {
            NewsDraftStore store = new NewsDraftStore(temp.resolve("world-a.properties"));
            var draft = new NewsDraftStore.Draft("Заголовок", "Строка 1\n\n**Строка 2**", "Источник", "a".repeat(32), "фото");
            eq(NewsDraftStore.Draft.EMPTY, store.load());
            eq(true, store.save(draft));
            eq(draft, new NewsDraftStore(temp.resolve("world-a.properties")).load());
            eq(NewsDraftStore.Draft.EMPTY, new NewsDraftStore(temp.resolve("world-b.properties")).load());
            eq(true, store.rememberSubmission(draft));
            eq(true, store.save(NewsDraftStore.Draft.EMPTY));
            eq(NewsDraftStore.Draft.EMPTY, store.load());
            eq(draft, store.lastSubmitted());
        } finally {
            java.nio.file.Files.deleteIfExists(temp.resolve("world-a.properties"));
            java.nio.file.Files.deleteIfExists(temp.resolve("world-a.submitted.properties"));
            java.nio.file.Files.deleteIfExists(temp.resolve("world-a.properties.tmp"));
            java.nio.file.Files.deleteIfExists(temp.resolve("world-a.submitted.properties.tmp"));
            java.nio.file.Files.delete(temp);
        }
        System.out.println("News editor: " + checks + " regression checks passed.");
    }
}
