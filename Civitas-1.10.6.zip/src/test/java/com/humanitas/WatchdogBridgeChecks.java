package com.humanitas;
import java.nio.file.Path;
import java.util.Map;
import net.minecraft.nbt.Tag;
public final class WatchdogBridgeChecks {
    public static void main(String[] args) {
        String legacy="{\"event\":\"pack_enforcement\",\"outcome\":\"geometry_detected_100_percent\",\"player\":\"p\"}";
        String incident="{\"event\":\"watchdog_incident\",\"player\":\"p\",\"player_name\":\"Tester\",\"time\":\"2026-11-08T10:12:13Z\",\"reason\":\"Geometry: thin faces on 13/13 terrain blocks (<=20%); stone\",\"trust_change\":-7,\"trust_score\":54,\"sanction\":\"KICK\"}";
        var rows=WatchdogBridge.parseEvents(Path.of("."),Map.of("p","Tester"),legacy+"\n"+incident+"\n{bad}");
        if(rows.size()!=1)throw new AssertionError("Expected one detailed incident");
        var row=rows.getCompound(0);
        if(!row.getString("name").equals("Tester") || row.getInt("trustChange")!=-7 || row.getInt("trustScore")!=54 || !row.getString("reason").contains("stone") || !row.getString("message").contains("Кик"))throw new AssertionError("Incident details lost");
        String banned=incident.replace("\"sanction\":\"KICK\"", "\"sanction\":\"BAN\",\"ban_days\":3");
        var banRow=WatchdogBridge.parseEvents(Path.of("."),Map.of("p","Tester"),banned).getCompound(0);
        if(banRow.getInt("banDays")!=3 || !banRow.getString("message").contains("Бан"))throw new AssertionError("Ban details lost");
        var old=WatchdogBridge.parseEvents(Path.of("."),Map.of("p","Tester"),legacy);
        if(old.size()!=1 || old.getCompound(0).contains("trustChange"))throw new AssertionError("Legacy incidents must not invent trust changes");
        System.out.println("Watchdog dashboard checks passed.");
    }
}
