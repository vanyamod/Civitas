# Humanitas: Res Publica

Server-side political registry for a postwar world: bills, votes, treaties, a public chronicle and a polity cabinet. It adds no items, recipes or balance-changing mechanics.

## Visual language

Every public message uses a shared chancellery palette: paper cream, muted gold, olive green, and dark ink. The style is deliberately neutral, so it can belong to any fictional state or ideology in the project.

## Commands

| Command | Purpose |
| --- | --- |
| `/respublica` | Open help and quick links. |
| `/respublica bills` | Show bills and clickable vote actions. |
| `/respublica bill propose <text>` | Submit a bill. |
| `/respublica bill vote <id> yes\|no` | Cast one vote. |
| `/respublica bill close <id>` | Close a vote; operator level 2. |
| `/respublica treaties` | Open the diplomatic register. |
| `/respublica treaty draft <side_A> <side_B> <title>` | Draft a treaty; operator level 2. |
| `/respublica treaty ratify <id>` | Ratify a treaty; operator level 2. |
| `/respublica archive` | Read the latest chronicle entries. |
| `/humanitas create <type> <name> <owner>` | Create a country, commune, city or another polity; operator level 2; the owner must be online. |
| `/humanitas open` | Open the owner's political cabinet. Normally invoked by the inventory button. |

Use underscores in multi-word party names, for example `Novograd_Republic`.

## Cabinet

After a staff member creates a polity, its owner opens their inventory and clicks the gold **Res Publica** button placed left of the armour slots. The cabinet is a protected GUI: the shown items cannot be taken or moved.

The owner can click the cabinet cards to cycle through an online deputy, ideology, parliamentary model and form of government. Every change is written to the world data immediately. Deputies can open the cabinet to inspect it; only the owner can alter it.

## Persistence

The registry is saved per world in `data/humanitas_res_publica.dat` and survives restarts. The public archive retains the latest 40 events.
