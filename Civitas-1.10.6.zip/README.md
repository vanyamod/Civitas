# Civitas

Civitas is a Minecraft NeoForge mod for political institutions, news, diplomacy and administration in the Humanitas project. It includes an optional admin dashboard for Watchdog data.

- Minecraft: 1.21.1
- NeoForge: 21.1.250 (development target)
- Java: 21
- Mod ID: `humanitas`

## Build

```sh
./gradlew build
```

On Windows use `gradlew.bat build`. The resulting JAR is in `build/libs/`. To run a development client, use `./gradlew runClient` (Windows: `gradlew.bat runClient`). Gradle may need internet access to download dependencies.

Optional ClientSort integration can be tested with `-PclientSortJar=/absolute/path/to/clientsort.jar`; no third-party mod JARs are bundled. Watchdog integration requires a separately installed compatible Watchdog mod and its server-side data.

See [CONTEXT.md](CONTEXT.md) for development notes and known limitations, and [docs](docs/) for feature documentation.

## Rights and attribution

The project metadata says **All Rights Reserved**; no open-source license is granted by this repository. Do not assume that source code, assets, or names may be reused or redistributed without permission. Third-party UI sounds have separate credits and terms in [CREDITS.txt](src/main/resources/assets/humanitas/sounds/CREDITS.txt). The NeoForge template license is in [TEMPLATE_LICENSE.txt](TEMPLATE_LICENSE.txt).

Do not commit game worlds, logs, player data, server configuration, Discord webhooks or API keys. If a credential has been exposed, revoke and replace it.
