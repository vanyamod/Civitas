# Project context

## Overview

Civitas (`humanitas`) is a Minecraft 1.21.1 / NeoForge mod with political institutions, news, client UI and administration. This repository is a sanitized working-tree snapshot; Watchdog is a separate optional mod and is not included here. See `gradle.properties` for exact development versions.

Build and run the checks with `./gradlew build` (Windows: `gradlew.bat build`); this includes `newsEditorTest` and `watchdogDashboardChecks`. See the README for setup.

## Known limitations and issues

- The Watchdog dashboard reads the current server-local date's `config/watchdog/reports/YYYY-MM-DD.jsonl`; timestamps are displayed as UTC. Around midnight, the local date can differ from UTC, so incidents in another day's report may not appear. It reads at most the last 128 KiB and displays at most 30 events.
- The dashboard depends on Watchdog's private file layout and JSON fields. A Watchdog update or missing/unreadable data can produce missing events or unknown trust scores. A missing trust file is displayed as 100, which is a default rather than proof of a recorded score.
- UI compatibility hooks for optional mods, including ClientSort, JEI and Curios, are version-sensitive. Verify the supported combinations in game before release. The clean project does not ship these mods or test worlds.
- No complete in-game or multiplayer regression run is documented for this sanitized snapshot; building successfully does not prove every screen, permission check or third-party integration works.

## Privacy and security

Server configuration may contain a Discord webhook. Watchdog and game runtime directories can contain player data and API keys. Keep all runtime state, logs, worlds and secrets out of Git; `.gitignore` is only a safeguard and does not remove files already committed. Do not paste credentials into issues or screenshots.

## License

Mod metadata declares All Rights Reserved. Third-party assets and template files retain their respective terms; see README and sound credits. Public source visibility does not prevent copying.
